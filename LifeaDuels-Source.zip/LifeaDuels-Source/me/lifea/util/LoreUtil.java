/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.configuration.ConfigurationSection
 */
package me.lifea.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.ConfigurationSection;

public class LoreUtil {
    public static List<Component> read(ConfigurationSection sec, String key) {
        ArrayList<Component> result = new ArrayList<Component>();
        Object raw = sec.get(key);
        if (raw == null) {
            return result;
        }
        if (raw instanceof List) {
            for (Object obj : (List)raw) {
                String line = obj != null ? obj.toString() : "";
                if (line.isEmpty()) continue;
                result.add(ColorUtil.parse(line));
            }
        } else {
            String line = raw.toString();
            if (!line.isEmpty()) {
                result.add(ColorUtil.parse(line));
            }
        }
        return result;
    }

    public static List<Component> readFromMap(Map<?, ?> entry, String key) {
        ArrayList<Component> result = new ArrayList<Component>();
        Object raw = entry.get(key);
        if (raw == null) {
            return result;
        }
        if (raw instanceof List) {
            for (Object obj : (List)raw) {
                String line = obj != null ? obj.toString() : "";
                if (line.isEmpty()) continue;
                result.add(ColorUtil.parse(line));
            }
        } else {
            String line = raw.toString();
            if (!line.isEmpty()) {
                result.add(ColorUtil.parse(line));
            }
        }
        return result;
    }
}

