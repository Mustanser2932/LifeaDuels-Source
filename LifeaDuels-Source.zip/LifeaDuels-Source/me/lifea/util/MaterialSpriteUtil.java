/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.viaversion.viaversion.api.Via
 *  com.viaversion.viaversion.api.protocol.version.ProtocolVersion
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

public final class MaterialSpriteUtil {
    private MaterialSpriteUtil() {
    }

    public static String prefix(Material material, String name) {
        return MaterialSpriteUtil.prefix(null, material, name);
    }

    public static String prefix(Player viewer, Material material, String name) {
        if (material == null || material.isAir() || name == null || name.isBlank()) {
            return name;
        }
        Material spriteMaterial = MaterialSpriteUtil.spriteMaterial(name, material);
        boolean forcedEnderPearl = MaterialSpriteUtil.isSmpName(name);
        Sprite sprite = switch (spriteMaterial) {
            case Material.COBWEB -> new Sprite("minecraft:blocks", "block/cobweb");
            case Material.RED_BED -> new Sprite("minecraft:beds", "entity/bed/red");
            case Material.SHIELD -> new Sprite("minecraft:shield_patterns", "entity/shield_base_nopattern");
            default -> null;
        };
        String atlas = "minecraft:items";
        if (!forcedEnderPearl && viewer != null && Bukkit.getPluginManager().isPluginEnabled("ViaVersion")) {
            ProtocolVersion version = Via.getAPI().getPlayerProtocolVersion(viewer.getUniqueId());
            if (sprite == null && version.newerThanOrEqualTo(ProtocolVersion.v1_21_9) && version.olderThan(ProtocolVersion.v1_21_11)) {
                atlas = "minecraft:blocks";
            }
        }
        String key = spriteMaterial.getKey().getKey();
        Object path = "item/" + key;
        if (sprite != null) {
            atlas = sprite.atlas();
            path = sprite.path();
        }
        return "&f<sprite:\"" + atlas + "\":" + (String)path + "> " + name;
    }

    private static Material spriteMaterial(String name, Material fallback) {
        String normalized = MaterialSpriteUtil.normalize(name);
        if (normalized.contains("manhunt")) {
            return Material.WATER_BUCKET;
        }
        if (normalized.contains("diasmp")) {
            return Material.COBWEB;
        }
        if (normalized.contains("bedpvp")) {
            return Material.RED_DYE;
        }
        if (normalized.contains("smp")) {
            return Material.ENDER_PEARL;
        }
        return fallback;
    }

    private static boolean isSmpName(String name) {
        return MaterialSpriteUtil.normalize(name).contains("smp");
    }

    private static String normalize(String name) {
        return name.replaceAll("(?:&|\u00a7)[0-9a-fk-orx#]", "").replaceAll("<[^>]+>", "").toLowerCase().replace('\u0455', 's').replace('\u1d0d', 'm').replace('\u1d0f', 'o').replace('\u1d18', 'p').replace('\u0299', 'b').replace('\u1d07', 'e').replace('\u1d05', 'd').replace('\u1d20', 'v').replace('\u0280', 'r').replace('\u0274', 'n').replace('\u1d00', 'a').replace('\u029c', 'h').replace('\u1d1c', 'u').replace('\u1d1b', 't').replaceAll("[^a-z]+", "");
    }

    private record Sprite(String atlas, String path) {
    }
}

