/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.lang.reflect.Method;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class PacketUtil {
    private static final int STATUS_DEATH = 3;

    private PacketUtil() {
    }

    public static void sendDeathAnimation(Player dead) {
        try {
            Object craftPlayer = dead.getClass().getMethod("getHandle", new Class[0]).invoke((Object)dead, new Object[0]);
            if (craftPlayer == null) {
                return;
            }
            Class<?> entityClass = Class.forName("net.minecraft.world.entity.Entity");
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundEntityEventPacket");
            Object packet = packetClass.getConstructor(entityClass, Byte.TYPE).newInstance(craftPlayer, 3);
            Method sendPacketMethod = Player.class.getMethod("sendPacket", Object.class);
            for (Player online : dead.getWorld().getPlayers()) {
                if (!online.isOnline()) continue;
                sendPacketMethod.invoke((Object)online, packet);
            }
        }
        catch (Exception var8) {
            dead.getWorld().playSound(dead.getLocation(), Sound.ENTITY_PLAYER_DEATH, 1.0f, 1.0f);
        }
    }
}

