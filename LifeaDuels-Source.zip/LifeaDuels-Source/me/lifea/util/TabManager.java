/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.neznamy.tab.api.TabAPI
 *  me.neznamy.tab.api.TabPlayer
 *  me.neznamy.tab.api.event.player.PlayerLoadEvent
 *  me.neznamy.tab.api.nametag.NameTagManager
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.util;

import java.util.UUID;
import me.lifea.Lifea;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.event.player.PlayerLoadEvent;
import me.neznamy.tab.api.nametag.NameTagManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

public final class TabManager
implements Listener {
    private static boolean tabLoadListenerRegistered;

    public static void start() {
        if (!tabLoadListenerRegistered) {
            TabAPI.getInstance().getEventBus().register(PlayerLoadEvent.class, event -> {
                UUID playerId = event.getPlayer().getUniqueId();
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> TabManager.hideVanillaNametag(playerId));
            });
            tabLoadListenerRegistered = true;
        }
        TabManager.refreshAll();
    }

    public static void stop() {
        NameTagManager manager = TabManager.nameTagManager();
        if (manager != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                TabPlayer tabPlayer = TabAPI.getInstance().getPlayer(player.getUniqueId());
                if (tabPlayer == null) continue;
                manager.showNameTag(tabPlayer);
            }
        }
    }

    public static void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            TabManager.hideVanillaNametag(player.getUniqueId());
        }
    }

    public static void forceRefreshFor(UUID playerId) {
        TabManager.hideVanillaNametag(playerId);
    }

    public static void forceResend(UUID viewerId) {
        TabManager.refreshAll();
    }

    public static void reload() {
        TabManager.refreshAll();
    }

    public static void clearViewer(UUID viewerId) {
    }

    public static void clearTarget(UUID targetId) {
    }

    private static void hideVanillaNametag(UUID playerId) {
        TabPlayer tabPlayer = TabAPI.getInstance().getPlayer(playerId);
        if (tabPlayer != null) {
            TabManager.hideVanillaNametag(tabPlayer);
        }
    }

    private static void hideVanillaNametag(TabPlayer player) {
        NameTagManager manager = TabManager.nameTagManager();
        if (manager != null) {
            manager.hideNameTag(player);
        }
    }

    private static NameTagManager nameTagManager() {
        return TabAPI.getInstance().getNameTagManager();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> TabManager.hideVanillaNametag(event.getPlayer().getUniqueId()), 3L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        TabManager.clearViewer(event.getPlayer().getUniqueId());
        TabManager.clearTarget(event.getPlayer().getUniqueId());
    }
}

