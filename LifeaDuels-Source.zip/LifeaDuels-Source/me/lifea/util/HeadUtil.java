/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.destroystokyo.paper.profile.PlayerProfile
 *  com.destroystokyo.paper.profile.ProfileProperty
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 */
package me.lifea.util;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public final class HeadUtil {
    private static final Logger LOGGER = Logger.getLogger("Lifea");
    private static final ConcurrentHashMap<String, PlayerProfile> CACHE = new ConcurrentHashMap();

    private HeadUtil() {
    }

    public static ItemBuilder from(Material mat, ConfigurationSection sec) {
        ItemStack stack = new ItemStack(mat);
        if (sec != null) {
            HeadUtil.applyTexture(stack, sec.getString("texture"));
        }
        return ItemBuilder.from(stack);
    }

    public static ItemBuilder from(Material mat, String texture) {
        ItemStack stack = new ItemStack(mat);
        HeadUtil.applyTexture(stack, texture);
        return ItemBuilder.from(stack);
    }

    public static void applyTexture(ItemStack item, ConfigurationSection sec) {
        if (sec != null) {
            HeadUtil.applyTexture(item, sec.getString("texture"));
        }
    }

    public static void applyTexture(ItemStack item, String texture) {
        ItemMeta var3;
        if (item != null && texture != null && !texture.isBlank() && (var3 = item.getItemMeta()) instanceof SkullMeta) {
            SkullMeta skullMeta = (SkullMeta)var3;
            PlayerProfile profile = HeadUtil.resolve(texture.trim());
            if (profile != null) {
                skullMeta.setPlayerProfile(profile);
                item.setItemMeta((ItemMeta)skullMeta);
            }
        }
    }

    public static void clear() {
        CACHE.clear();
    }

    public static int size() {
        return CACHE.size();
    }

    private static PlayerProfile resolve(String texture) {
        return CACHE.computeIfAbsent(texture, HeadUtil::build);
    }

    private static PlayerProfile build(String texture) {
        try {
            String base64 = texture.startsWith("http") ? HeadUtil.encodeUrl(texture) : texture;
            UUID id = UUID.nameUUIDFromBytes(base64.getBytes(StandardCharsets.UTF_8));
            PlayerProfile profile = Bukkit.createProfile((UUID)id, (String)null);
            profile.setProperty(new ProfileProperty("textures", base64));
            return profile;
        }
        catch (Exception e) {
            LOGGER.log(Level.WARNING, "Invalid head texture (ignored): " + texture, e);
            return null;
        }
    }

    private static String encodeUrl(String url) {
        String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + url + "\"}}}";
        return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }
}

