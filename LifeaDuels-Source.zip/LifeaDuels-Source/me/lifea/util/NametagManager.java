/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.retrooper.packetevents.PacketEvents
 *  com.github.retrooper.packetevents.protocol.entity.data.EntityData
 *  com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes
 *  com.github.retrooper.packetevents.util.Vector3f
 *  com.github.retrooper.packetevents.wrapper.PacketWrapper
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetPassengers
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity
 *  com.viaversion.viaversion.api.Via
 *  com.viaversion.viaversion.api.protocol.version.ProtocolVersion
 *  io.github.retrooper.packetevents.util.SpigotConversionUtil
 *  io.github.retrooper.packetevents.util.SpigotReflectionUtil
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.format.NamedTextColor
 *  net.kyori.adventure.text.format.TextColor
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerChangedWorldEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.util;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
import com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes;
import com.github.retrooper.packetevents.util.Vector3f;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetPassengers;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import io.github.retrooper.packetevents.util.SpigotConversionUtil;
import io.github.retrooper.packetevents.util.SpigotReflectionUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.duel.KitRulesListener;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.CountryHeadManager;
import me.lifea.util.LifeaRelationalExpansion;
import me.lifea.util.SummerChatBridge;
import me.lifea.util.TabManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;

public final class NametagManager
implements Listener {
    private static final Map<UUID, DisplayNametag> NAMETAGS = new ConcurrentHashMap<UUID, DisplayNametag>();
    private static final Set<UUID> PENDING_TARGET_REBUILDS = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> PENDING_VIEWER_REBUILDS = ConcurrentHashMap.newKeySet();
    private static final int VISIBILITY_CYCLE_TICKS = 20;
    private static final int REMOUNT_CYCLES = 5;
    private static int task = -1;
    private static int rebuildTask = -1;
    private static List<Player> visibilitySnapshot = List.of();
    private static Map<UUID, Location> visibilityLocations = Map.of();
    private static int visibilityCursor;
    private static int visibilityTick;

    public static void start() {
        if (task != -1) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            NametagManager.ensure(player);
        }
        NametagManager.refreshAll();
        NametagManager.resetVisibilityCycle();
        task = Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), NametagManager::refreshVisibilityBatch, 1L, 1L).getTaskId();
    }

    public static void stop() {
        if (task != -1) {
            Bukkit.getScheduler().cancelTask(task);
            task = -1;
        }
        if (rebuildTask != -1) {
            Bukkit.getScheduler().cancelTask(rebuildTask);
            rebuildTask = -1;
        }
        PENDING_TARGET_REBUILDS.clear();
        PENDING_VIEWER_REBUILDS.clear();
        NametagManager.resetVisibilityCycle();
        for (DisplayNametag nametag : NAMETAGS.values()) {
            nametag.hideForAll();
        }
        NAMETAGS.clear();
    }

    public static void refreshAll() {
        List<Player> online = List.copyOf(Bukkit.getOnlinePlayers());
        Map<UUID, Location> locations = NametagManager.snapshotLocations(online);
        for (Player player : online) {
            NametagManager.ensure(player).refreshVisibility(online, locations);
        }
        NametagManager.resetVisibilityCycle();
    }

    private static void refreshVisibilityBatch() {
        int total;
        if (visibilityTick == 0) {
            visibilitySnapshot = List.copyOf(Bukkit.getOnlinePlayers());
            visibilityLocations = NametagManager.snapshotLocations(visibilitySnapshot);
            visibilityCursor = 0;
        }
        int batchSize = (total = visibilitySnapshot.size()) == 0 ? 0 : Math.max(1, (int)Math.ceil((double)total / 20.0));
        int end = Math.min(total, visibilityCursor + batchSize);
        while (visibilityCursor < end) {
            Player target;
            if ((target = visibilitySnapshot.get(visibilityCursor++)) == null || !target.isOnline()) continue;
            NametagManager.ensure(target).refreshVisibility(visibilitySnapshot, visibilityLocations);
        }
        visibilityTick = (visibilityTick + 1) % 20;
    }

    private static void resetVisibilityCycle() {
        visibilitySnapshot = List.of();
        visibilityLocations = Map.of();
        visibilityCursor = 0;
        visibilityTick = 0;
    }

    public static void refresh(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        List<Player> online = List.copyOf(Bukkit.getOnlinePlayers());
        NametagManager.ensure(player).refreshVisibility(online, NametagManager.snapshotLocations(online));
    }

    private static Map<UUID, Location> snapshotLocations(Collection<Player> players) {
        HashMap<UUID, Location> locations = new HashMap<UUID, Location>(players.size());
        for (Player player : players) {
            locations.put(player.getUniqueId(), player.getLocation());
        }
        return locations;
    }

    private static DisplayNametag ensure(Player player) {
        return NAMETAGS.computeIfAbsent(player.getUniqueId(), ignored -> new DisplayNametag(player));
    }

    public static void refreshTextFor(Collection<Player> targets) {
        for (Player target : targets) {
            DisplayNametag nametag;
            if (target == null || !target.isOnline() || (nametag = NAMETAGS.get(target.getUniqueId())) == null) continue;
            nametag.refreshTextForVisibleViewers();
        }
    }

    private static void queueRebuild(Player player, boolean rebuildViewer) {
        if (player == null) {
            return;
        }
        PENDING_TARGET_REBUILDS.add(player.getUniqueId());
        if (rebuildViewer) {
            PENDING_VIEWER_REBUILDS.add(player.getUniqueId());
        }
        if (rebuildTask != -1) {
            return;
        }
        rebuildTask = Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            rebuildTask = -1;
            Set<UUID> targets = Set.copyOf(PENDING_TARGET_REBUILDS);
            Set<UUID> viewers = Set.copyOf(PENDING_VIEWER_REBUILDS);
            PENDING_TARGET_REBUILDS.clear();
            PENDING_VIEWER_REBUILDS.clear();
            for (UUID id : targets) {
                DisplayNametag nametag = NAMETAGS.get(id);
                if (nametag == null) continue;
                nametag.rebuildForAllViewers();
            }
            for (UUID id : viewers) {
                Player viewer = Bukkit.getPlayer((UUID)id);
                if (viewer == null || !viewer.isOnline()) continue;
                for (DisplayNametag nametag : NAMETAGS.values()) {
                    nametag.rebuildFor(viewer);
                }
            }
        }, 2L).getTaskId();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (!event.getPlayer().isOnline()) {
                return;
            }
            NametagManager.ensure(event.getPlayer());
            NametagManager.queueRebuild(event.getPlayer(), true);
            NametagManager.resetVisibilityCycle();
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> TabManager.forceRefreshFor(event.getPlayer().getUniqueId()), 3L);
        }, 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        DisplayNametag nametag = NAMETAGS.remove(event.getPlayer().getUniqueId());
        if (nametag != null) {
            nametag.hideForAll();
        }
        for (DisplayNametag remaining : NAMETAGS.values()) {
            remaining.clearViewer(event.getPlayer().getUniqueId());
        }
        TabManager.clearTarget(event.getPlayer().getUniqueId());
        NametagManager.resetVisibilityCycle();
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        NametagManager.queueRebuild(event.getPlayer(), true);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        if (event.getTo() == null) {
            return;
        }
        NametagManager.queueRebuild(event.getPlayer(), false);
    }

    private static boolean isOpponent(Player viewer, Player target) {
        PartyDuelSession partySession = PartyDuelSession.getSession(viewer.getUniqueId());
        if (partySession != null) {
            return partySession.getParticipants().contains(target.getUniqueId()) && !partySession.isSameTeam(viewer, target);
        }
        Match match = MatchManager.getMatch(viewer.getUniqueId());
        return match != null && match.isActive() && (match.getPlayer1().equals(target.getUniqueId()) || match.getPlayer2().equals(target.getUniqueId())) && !viewer.getUniqueId().equals(target.getUniqueId());
    }

    private static boolean supportsHeadComponents(Player player) {
        if (!Bukkit.getPluginManager().isPluginEnabled("ViaVersion")) {
            return true;
        }
        try {
            return Via.getAPI().getPlayerProtocolVersion(player.getUniqueId()).newerThanOrEqualTo(ProtocolVersion.v1_21_6);
        }
        catch (Exception ignored) {
            return false;
        }
    }

    private static final class DisplayNametag {
        private final Player target;
        private final ClientTextDisplay display;
        private final Map<UUID, Boolean> viewers = new ConcurrentHashMap<UUID, Boolean>();
        private final Map<UUID, RenderedText> renderedText = new ConcurrentHashMap<UUID, RenderedText>();
        private final Map<UUID, Component> sentText = new ConcurrentHashMap<UUID, Component>();
        private int visibilityCycles;

        private DisplayNametag(Player target) {
            this.target = target;
            this.display = new ClientTextDisplay(target.getLocation());
            this.display.setTranslation(new Vector3f(0.0f, 0.25f, 0.0f));
            this.display.setScale(new Vector3f(1.0f, 1.0f, 1.0f));
            this.display.setBillboard((byte)3);
            this.display.setBackgroundColor(0);
            this.display.setFlags((byte)1);
        }

        private void refreshVisibility(List<Player> online, Map<UUID, Location> locations) {
            if (!this.target.isOnline()) {
                return;
            }
            Location targetLocation = locations.get(this.target.getUniqueId());
            if (targetLocation == null) {
                return;
            }
            this.display.setLocation(targetLocation);
            boolean remount = ++this.visibilityCycles % 5 == 0;
            for (Player viewer : online) {
                boolean shouldSee = this.shouldSee(viewer, targetLocation, locations.get(viewer.getUniqueId()));
                boolean visible = this.viewers.containsKey(viewer.getUniqueId());
                if (shouldSee && !visible) {
                    this.show(viewer);
                    continue;
                }
                if (shouldSee) {
                    this.update(viewer, false, remount);
                    continue;
                }
                if (!visible) continue;
                this.hide(viewer);
            }
        }

        private boolean shouldSee(Player viewer, Location targetLocation, Location viewerLocation) {
            return viewer.isOnline() && !viewer.getUniqueId().equals(this.target.getUniqueId()) && !viewer.isDead() && !this.target.isDead() && this.target.getGameMode() != GameMode.SPECTATOR && viewerLocation != null && viewerLocation.getWorld().equals((Object)targetLocation.getWorld()) && viewer.canSee(this.target) && this.target.isTrackedBy(viewer) && viewerLocation.distanceSquared(targetLocation) <= 4096.0;
        }

        private void refreshTextForVisibleViewers() {
            if (!this.target.isOnline()) {
                return;
            }
            Location targetLocation = this.target.getLocation();
            this.display.setLocation(targetLocation);
            for (UUID viewerId : List.copyOf(this.viewers.keySet())) {
                Player viewer = Bukkit.getPlayer((UUID)viewerId);
                if (viewer == null || !this.shouldSee(viewer, targetLocation, viewer.getLocation())) continue;
                this.update(viewer, false, false);
            }
        }

        private void rebuildForAllViewers() {
            if (!this.target.isOnline()) {
                return;
            }
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                this.rebuildFor(viewer);
            }
        }

        private void rebuildFor(Player viewer) {
            if (viewer == null || !this.target.isOnline()) {
                return;
            }
            Location targetLocation = this.target.getLocation();
            boolean visible = this.viewers.containsKey(viewer.getUniqueId());
            if (!this.shouldSee(viewer, targetLocation, viewer.getLocation())) {
                if (visible) {
                    this.hide(viewer);
                }
                return;
            }
            this.display.setLocation(targetLocation);
            if (!visible) {
                this.show(viewer);
                return;
            }
            this.display.despawn(viewer);
            this.display.spawn(viewer);
            this.update(viewer, true, true);
        }

        private Component text(Player viewer) {
            UUID viewerId = viewer.getUniqueId();
            String prefix = LifeaRelationalExpansion.resolvePrefix(viewer, this.target);
            String tag = SummerChatBridge.getTag(this.target);
            boolean showTag = !tag.isBlank() && LifeaRelationalExpansion.mayShowSummerTag(viewer, this.target);
            TextComponent flag = NametagManager.supportsHeadComponents(this.target) ? CountryHeadManager.getComponent(this.target) : Component.empty();
            NamedTextColor healthColor = KitRulesListener.healthIndicatorColor(viewer, this.target);
            int healthValue = healthColor == null ? 0 : KitRulesListener.healthIndicatorValue(this.target);
            boolean showPing = PlayerSettingsManager.getPingDisplay(viewerId) && NametagManager.isOpponent(viewer, this.target);
            int ping = showPing ? Math.max(0, this.target.getPing()) : 0;
            TextInputs inputs = new TextInputs(prefix, tag, showTag, (Component)flag, healthColor, healthValue, showPing, ping, this.target.getName());
            RenderedText cached = this.renderedText.get(viewerId);
            if (cached != null && cached.inputs().equals(inputs)) {
                return cached.component();
            }
            String nameColor = ColorUtil.extractLastColorCode(prefix, "&f");
            Component name = ColorUtil.parseTab(prefix).append(ColorUtil.parseTab(nameColor + this.target.getName()));
            if (showTag) {
                name = ColorUtil.parseTab(tag).append((Component)Component.newline()).append(name);
            }
            if (!flag.equals((Object)Component.empty())) {
                name = name.append(ColorUtil.parse("&r&f ")).append(flag.color((TextColor)NamedTextColor.WHITE));
            }
            if (healthColor == null && !showPing) {
                this.renderedText.put(viewerId, new RenderedText(inputs, name));
                return name;
            }
            TextComponent indicators = Component.empty();
            if (healthColor != null) {
                String color = healthColor == NamedTextColor.YELLOW ? "&e" : "&#FB0000";
                indicators = ColorUtil.parseTab("&f" + healthValue + " " + color + "\u2764");
            }
            if (showPing) {
                Component pingComponent = ColorUtil.parseTab("&7[&#0EFF00" + ping + "ms&7]");
                indicators = healthColor == null ? pingComponent : indicators.append(ColorUtil.parseTab(" &8| ")).append(pingComponent);
            }
            Component result = name.append((Component)Component.newline()).append((Component)indicators);
            this.renderedText.put(viewerId, new RenderedText(inputs, result));
            return result;
        }

        private void show(Player viewer) {
            this.viewers.put(viewer.getUniqueId(), Boolean.TRUE);
            this.display.spawn(viewer);
            this.update(viewer, true, true);
        }

        private void update(Player viewer, boolean forceMetadata, boolean remount) {
            boolean textChanged;
            Component current = this.text(viewer);
            UUID viewerId = viewer.getUniqueId();
            Component previous = this.sentText.get(viewerId);
            boolean bl = textChanged = forceMetadata || !current.equals((Object)previous);
            if (remount) {
                this.display.mount(this.target, viewer);
            }
            if (textChanged) {
                this.sentText.put(viewerId, current);
                this.display.setText(current);
                this.display.update(viewer);
            }
        }

        private void hide(Player viewer) {
            if (this.viewers.remove(viewer.getUniqueId()) == null) {
                return;
            }
            this.renderedText.remove(viewer.getUniqueId());
            this.sentText.remove(viewer.getUniqueId());
            this.display.despawn(viewer);
        }

        private void hideForAll() {
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                this.hide(viewer);
            }
        }

        private void clearViewer(UUID viewerId) {
            this.viewers.remove(viewerId);
            this.renderedText.remove(viewerId);
            this.sentText.remove(viewerId);
        }

        private record TextInputs(String prefix, String tag, boolean showTag, Component flag, NamedTextColor healthColor, int healthValue, boolean showPing, int ping, String playerName) {
        }

        private record RenderedText(TextInputs inputs, Component component) {
        }
    }

    private static final class ClientTextDisplay {
        private final int entityId = SpigotReflectionUtil.generateEntityId();
        private final UUID uuid = UUID.randomUUID();
        private final List<EntityData<?>> data = new ArrayList();
        private Location location;
        private Component text;

        private ClientTextDisplay(Location location) {
            this.location = location;
        }

        private void setLocation(Location location) {
            this.location = location;
        }

        private void setText(Component text) {
            this.text = text;
        }

        private void setTranslation(Vector3f value) {
            this.data.add(new EntityData(11, EntityDataTypes.VECTOR3F, (Object)value));
        }

        private void setScale(Vector3f value) {
            this.data.add(new EntityData(12, EntityDataTypes.VECTOR3F, (Object)value));
        }

        private void setBillboard(byte value) {
            this.data.add(new EntityData(15, EntityDataTypes.BYTE, (Object)value));
        }

        private void setBackgroundColor(int value) {
            this.data.add(new EntityData(25, EntityDataTypes.INT, (Object)value));
        }

        private void setFlags(byte value) {
            this.data.add(new EntityData(27, EntityDataTypes.BYTE, (Object)value));
        }

        private void spawn(Player viewer) {
            this.send((PacketWrapper<?>)new WrapperPlayServerSpawnEntity(this.entityId, this.uuid, SpigotConversionUtil.fromBukkitEntityType((EntityType)EntityType.TEXT_DISPLAY), SpigotConversionUtil.fromBukkitLocation((Location)this.location), this.location.getYaw(), 0, null), viewer);
        }

        private void update(Player viewer) {
            ArrayList values = new ArrayList(this.data);
            if (this.text != null) {
                values.add(new EntityData(23, EntityDataTypes.ADV_COMPONENT, (Object)this.text));
            }
            this.send((PacketWrapper<?>)new WrapperPlayServerEntityMetadata(this.entityId, values), viewer);
        }

        private void despawn(Player viewer) {
            this.send((PacketWrapper<?>)new WrapperPlayServerDestroyEntities(this.entityId), viewer);
        }

        private void mount(Player target, Player viewer) {
            this.send((PacketWrapper<?>)new WrapperPlayServerSetPassengers(target.getEntityId(), new int[]{this.entityId}), viewer);
        }

        private void send(PacketWrapper<?> packet, Player viewer) {
            PacketEvents.getAPI().getPlayerManager().sendPacket((Object)viewer, packet);
        }
    }
}

