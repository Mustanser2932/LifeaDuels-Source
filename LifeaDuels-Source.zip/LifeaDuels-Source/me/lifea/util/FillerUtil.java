/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.util;

import java.util.List;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemFlag;

public class FillerUtil {
    private static GuiItem fromConfig(ConfigurationSection sec) {
        if (sec == null) {
            return null;
        }
        Material mat = Material.matchMaterial((String)sec.getString("material", ""));
        String name = sec.getString("name", " ");
        return mat == null ? null : ((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sec).name(ColorUtil.parse(name))).flags(ItemFlag.values())).asGuiItem();
    }

    public static void fill(Gui gui, ConfigurationSection fillerSec) {
        if (fillerSec != null) {
            for (String key : fillerSec.getKeys(false)) {
                List slots;
                GuiItem item;
                ConfigurationSection sec = fillerSec.getConfigurationSection(key);
                if (sec == null || (item = FillerUtil.fromConfig(sec)) == null || (slots = sec.getList("slots")) == null || slots.isEmpty()) continue;
                for (Object s : slots) {
                    gui.setItem(((Number)s).intValue(), item);
                }
            }
        }
    }
}

