/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.util;

public final class TabRole
extends Enum<TabRole> {
    public static final /* enum */ TabRole TEAM_B = new TabRole("0_teamb", "&b\u2691 ");
    public static final /* enum */ TabRole TEAM_R = new TabRole("1_teamr", "&#FB0000\u2691 ");
    public static final /* enum */ TabRole FFA = new TabRole("2_ffa", "&e\u2691 ");
    public static final /* enum */ TabRole SPECTATOR = new TabRole("5_spec", "&f\u2691 ");
    private final String teamName;
    private final String flag;
    private static final /* synthetic */ TabRole[] $VALUES;

    public static TabRole[] values() {
        return (TabRole[])$VALUES.clone();
    }

    public static TabRole valueOf(String name) {
        return Enum.valueOf(TabRole.class, name);
    }

    private TabRole(String teamName, String flag) {
        this.teamName = teamName;
        this.flag = flag;
    }

    public String teamName() {
        return this.teamName;
    }

    public String flag() {
        return this.flag;
    }

    public static TabRole forDuelTeam(boolean isBlue) {
        return isBlue ? TEAM_B : TEAM_R;
    }

    private static TabRole[] $values() {
        return new TabRole[]{TEAM_B, TEAM_R, FFA, SPECTATOR};
    }

    private static /* synthetic */ TabRole[] $values$() {
        return new TabRole[]{TEAM_B, TEAM_R, FFA, SPECTATOR};
    }

    static {
        $VALUES = TabRole.$values$();
    }
}

