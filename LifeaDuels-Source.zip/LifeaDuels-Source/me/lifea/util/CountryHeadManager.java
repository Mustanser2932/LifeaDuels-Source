/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.object.ObjectContents
 *  net.kyori.adventure.text.object.PlayerHeadObjectContents
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.lifea.Lifea;
import me.lifea.util.IpCache;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.object.ObjectContents;
import net.kyori.adventure.text.object.PlayerHeadObjectContents;
import org.bukkit.entity.Player;

public final class CountryHeadManager {
    private static final Pattern COUNTRY_CODE = Pattern.compile("\\\"country_code\\\"\\s*:\\s*\\\"([A-Za-z]{2})\\\"");
    private static final Map<String, String> HEADS = new ConcurrentHashMap<String, String>();
    private static final Map<UUID, String> FLAGS = new ConcurrentHashMap<UUID, String>();
    private static final Map<String, String> FLAGS_BY_IP = new ConcurrentHashMap<String, String>();
    private static final Map<String, Boolean> LOOKUPS = new ConcurrentHashMap<String, Boolean>();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2L)).build();

    private CountryHeadManager() {
    }

    public static void load() {
        HEADS.clear();
        try (InputStream stream = Lifea.class.getResourceAsStream("/countries.txt");){
            if (stream == null) {
                Lifea.getInstance().getLogger().warning("countries.txt was not found in the plugin JAR.");
                return;
            }
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));){
                String line;
                while ((line = reader.readLine()) != null) {
                    String countryCode;
                    int separator = line.indexOf(58);
                    if (separator <= 0 || separator == line.length() - 1) continue;
                    String code = line.substring(0, separator).trim().toLowerCase(Locale.ROOT);
                    String value = line.substring(separator + 1).trim();
                    if (value.startsWith("'") && value.endsWith("'")) {
                        value = value.substring(1, value.length() - 1);
                    }
                    if ((countryCode = CountryHeadManager.countryCode(code)) == null || value.isBlank()) continue;
                    HEADS.put(countryCode, value);
                }
            }
        }
        catch (Exception exception) {
            Lifea.getInstance().getLogger().warning("Could not load countries.txt: " + exception.getMessage());
        }
    }

    public static String get(Player player) {
        return "";
    }

    public static Component getComponent(Player player) {
        if (player == null) {
            return Component.empty();
        }
        String cached = FLAGS.get(player.getUniqueId());
        if (cached != null) {
            return CountryHeadManager.toHeadComponent(cached);
        }
        CountryHeadManager.lookup(player);
        return CountryHeadManager.toHeadComponent(CountryHeadManager.fallback());
    }

    private static void lookup(Player player) {
        String ip = IpCache.get(player.getUniqueId());
        if (ip == null || ip.isBlank()) {
            IpCache.store(player);
            ip = IpCache.get(player.getUniqueId());
        }
        if (ip == null || ip.isBlank()) {
            CountryHeadManager.warnLookup(player, "no IP was available from the server connection");
            return;
        }
        if (!CountryHeadManager.isPublicAddress(ip)) {
            CountryHeadManager.warnLookup(player, "the server received a private/proxy address (" + ip + "); enable real-IP forwarding");
            FLAGS.put(player.getUniqueId(), CountryHeadManager.fallback());
            return;
        }
        String cached = FLAGS_BY_IP.get(ip);
        if (cached != null) {
            FLAGS.put(player.getUniqueId(), cached);
            return;
        }
        if (LOOKUPS.putIfAbsent(ip, Boolean.TRUE) != null) {
            return;
        }
        String lookupIp = ip;
        CountryHeadManager.lookupCountryCode(lookupIp).thenAccept(countryCode -> {
            String head;
            String texture = countryCode == null ? null : HEADS.get(countryCode);
            String string = head = texture == null ? CountryHeadManager.fallback() : texture;
            if (countryCode == null) {
                CountryHeadManager.warnLookup(player, "the geolocation providers returned no country for " + lookupIp);
            } else if (texture == null) {
                CountryHeadManager.warnLookup(player, "geolocation resolved " + countryCode.toUpperCase(Locale.ROOT) + ", but countries.txt has no matching flag entry");
            } else {
                CountryHeadManager.logResolution(player, countryCode);
            }
            FLAGS_BY_IP.put(lookupIp, head);
            FLAGS.put(player.getUniqueId(), head);
        });
    }

    private static CompletableFuture<String> lookupCountryCode(String ip) {
        return ((CompletableFuture)CountryHeadManager.request("https://ipwho.is/" + ip + "?fields=success,country_code").thenCompose(response -> {
            Matcher matcher = COUNTRY_CODE.matcher(response.statusCode() == 200 ? (CharSequence)response.body() : "");
            if (matcher.find()) {
                return CompletableFuture.completedFuture(matcher.group(1).toLowerCase(Locale.ROOT));
            }
            return CountryHeadManager.request("https://ipapi.co/" + ip + "/country/").thenApply(fallback -> {
                String code = fallback.statusCode() == 200 ? ((String)fallback.body()).trim() : "";
                return code.matches("[A-Za-z]{2}") ? code.toLowerCase(Locale.ROOT) : null;
            });
        })).exceptionally(ignored -> null);
    }

    private static CompletableFuture<HttpResponse<String>> request(String url) {
        try {
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).timeout(Duration.ofSeconds(3L)).header("Accept", "application/json").GET().build();
            return HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString());
        }
        catch (IllegalArgumentException exception) {
            return CompletableFuture.failedFuture(exception);
        }
    }

    private static boolean isPublicAddress(String value) {
        try {
            InetAddress address = InetAddress.getByName(value);
            return !address.isAnyLocalAddress() && !address.isLoopbackAddress() && !address.isLinkLocalAddress() && !address.isSiteLocalAddress();
        }
        catch (Exception ignored) {
            return false;
        }
    }

    private static void warnLookup(Player player, String reason) {
        String key = "country-lookup:" + reason;
        if (LOOKUPS.putIfAbsent(key, Boolean.TRUE) == null) {
            Lifea.getInstance().getLogger().warning("Could not resolve country for " + player.getName() + ": " + reason);
        }
    }

    private static void logResolution(Player player, String countryCode) {
        String key = "country-resolution:" + String.valueOf(player.getUniqueId()) + ":" + countryCode;
        if (LOOKUPS.putIfAbsent(key, Boolean.TRUE) == null) {
            Lifea.getInstance().getLogger().info("Country for " + player.getName() + " resolved as " + countryCode.toUpperCase(Locale.ROOT));
        }
    }

    private static String fallback() {
        String texture = HEADS.get("none");
        if (texture == null || texture.isBlank()) {
            return "";
        }
        return texture;
    }

    private static Component toHeadComponent(String textureValue) {
        if (textureValue == null || textureValue.isBlank()) {
            return Component.empty();
        }
        return Component.object((ObjectContents)ObjectContents.playerHead().profileProperty(PlayerHeadObjectContents.property((String)"textures", (String)textureValue)).build());
    }

    private static String countryCode(String input) {
        String alias;
        String normalized;
        if (input.equals("none")) {
            return input;
        }
        if (input.matches("[a-z]{2}")) {
            return input;
        }
        switch (normalized = input.replaceAll("[^a-z]", "").replace(" ", "")) {
            case "uae": {
                String string = "ae";
                break;
            }
            case "saudi": 
            case "saudiarabia": {
                String string = "sa";
                break;
            }
            case "palestine": {
                String string = "ps";
                break;
            }
            case "turkey": {
                String string = "tr";
                break;
            }
            case "afganistan": 
            case "afghanistan": {
                String string = "af";
                break;
            }
            default: {
                String string = alias = null;
            }
        }
        if (alias != null) {
            return alias;
        }
        return Arrays.stream(Locale.getISOCountries()).filter(iso -> new Locale("", (String)iso).getDisplayCountry(Locale.ENGLISH).toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "").equals(normalized)).findFirst().map(code -> code.toLowerCase(Locale.ROOT)).orElse(null);
    }

    public static void clear() {
        HEADS.clear();
        FLAGS.clear();
        FLAGS_BY_IP.clear();
        LOOKUPS.clear();
    }
}

