/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  me.clip.placeholderapi.expansion.Relational
 *  net.luckperms.api.LuckPerms
 *  net.luckperms.api.LuckPermsProvider
 *  net.luckperms.api.model.user.User
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.util.Set;
import java.util.UUID;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import me.lifea.duel.DuelSession;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.party.match.PartyMatchType;
import me.lifea.spectate.SpectateManager;
import me.lifea.spectate.SpectateSession;
import me.lifea.util.CountryFlagManager;
import me.lifea.util.SummerChatBridge;
import me.lifea.util.TabRole;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class LifeaRelationalExpansion
extends PlaceholderExpansion
implements Relational {
    public String getIdentifier() {
        return "dvr";
    }

    public String getAuthor() {
        return "Lifea";
    }

    public String getVersion() {
        return "1.0";
    }

    public boolean persist() {
        return true;
    }

    public String onPlaceholderRequest(Player viewer, Player target, String params) {
        if (viewer != null && target != null) {
            if ("dueling".equals(params)) {
                return String.valueOf(this.countDuelingPlayers());
            }
            if ("country_flag".equals(params)) {
                return CountryFlagManager.getFlag(target);
            }
            if ("prefix".equals(params)) {
                return LifeaRelationalExpansion.resolvePrefix(viewer, target);
            }
            if ("summer_tag".equals(params)) {
                return LifeaRelationalExpansion.resolveSummerTag(viewer, target);
            }
            if (!"suffix".equals(params) && !"rel_suffix".equals(params)) {
                return null;
            }
            if (!this.isInMatch(viewer) && !SpectateManager.isSpectating(viewer.getUniqueId())) {
                if (this.isInMatch(target)) {
                    return " &8\u2694";
                }
                return SpectateManager.isSpectating(target.getUniqueId()) ? " &8\ud83d\udc41" : " &f";
            }
            return " &f";
        }
        return "";
    }

    public static String resolvePrefix(Player viewer, Player target) {
        if (target == null) {
            return "";
        }
        TabRole role = LifeaRelationalExpansion.resolveRole(viewer, target);
        return role != null ? role.flag() : LifeaRelationalExpansion.luckPermsPrefixOf(target);
    }

    public static String resolveSummerTag(Player viewer, Player target) {
        if (!LifeaRelationalExpansion.mayShowSummerTag(viewer, target)) {
            return "";
        }
        String tag = SummerChatBridge.getTag(target);
        return tag == null || tag.isBlank() ? "" : " " + tag;
    }

    public static boolean mayShowSummerTag(Player viewer, Player target) {
        return viewer != null && target != null && !LifeaRelationalExpansion.isInMatchOrSpectating(target);
    }

    private static boolean isInMatchOrSpectating(Player player) {
        return LifeaRelationalExpansion.resolveActiveMatch(player) != null || SpectateManager.isSpectating(player.getUniqueId());
    }

    private int countDuelingPlayers() {
        int count = 0;
        for (Match match : MatchManager.getUniqueActiveMatches()) {
            Set<UUID> ids = MatchManager.getParticipantIds(match);
            if (ids == null) continue;
            count += ids.size();
        }
        return count;
    }

    private boolean isInMatch(Player player) {
        return LifeaRelationalExpansion.resolveActiveMatch(player) != null;
    }

    public static TabRole resolveRole(Player viewer, Player target) {
        if (viewer == null || target == null) {
            return null;
        }
        Match viewerMatch = LifeaRelationalExpansion.resolveActiveMatch(viewer);
        if (viewerMatch != null) {
            return LifeaRelationalExpansion.roleForViewerMatch(target, viewerMatch);
        }
        SpectateSession viewerSpec = SpectateManager.getSession(viewer.getUniqueId());
        if (viewerSpec == null) {
            return null;
        }
        Match viewerSpecMatch = LifeaRelationalExpansion.activeMatchForSpectator(viewerSpec);
        return viewerSpecMatch == null ? null : LifeaRelationalExpansion.roleForViewerMatch(target, viewerSpecMatch);
    }

    private static TabRole roleForViewerMatch(Player target, Match viewerMatch) {
        Match targetSpecMatch;
        Match targetMatch = LifeaRelationalExpansion.resolveActiveMatch(target);
        if (targetMatch != null && targetMatch.getMatchId().equals(viewerMatch.getMatchId())) {
            return LifeaRelationalExpansion.getRoleInMatch(target, targetMatch);
        }
        SpectateSession targetSpec = SpectateManager.getSession(target.getUniqueId());
        if (targetSpec != null && (targetSpecMatch = LifeaRelationalExpansion.activeMatchForSpectator(targetSpec)) != null && targetSpecMatch.getMatchId().equals(viewerMatch.getMatchId())) {
            return TabRole.SPECTATOR;
        }
        return null;
    }

    private static Match activeMatchForSpectator(SpectateSession session) {
        if (session == null) {
            return null;
        }
        Player target = Bukkit.getPlayer((UUID)session.getTargetId());
        if (target == null) {
            return null;
        }
        return LifeaRelationalExpansion.resolveActiveMatch(target);
    }

    public static Match resolveActiveMatch(Player player) {
        if (player == null) {
            return null;
        }
        Match match = MatchManager.getMatch(player.getUniqueId());
        if (match != null && match.isActive()) {
            return match;
        }
        DuelSession duelSession = DuelSession.getSession(player.getUniqueId());
        if (duelSession != null && !duelSession.isEnded() && duelSession.getMatch() != null && duelSession.getMatch().isActive()) {
            return duelSession.getMatch();
        }
        PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
        if (partySession != null && !partySession.isEnded() && partySession.getMatch() != null && partySession.getMatch().isActive()) {
            return partySession.getMatch();
        }
        return null;
    }

    private static TabRole getRoleInMatch(Player player, Match match) {
        PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
        if (partySession != null && partySession.getMatch().getMatchId().equals(match.getMatchId())) {
            if (!partySession.isAlive(player.getUniqueId())) {
                return TabRole.SPECTATOR;
            }
            return switch (partySession.getMatchType()) {
                default -> throw new MatchException(null, null);
                case PartyMatchType.FFA -> TabRole.FFA;
                case PartyMatchType.SPLIT, PartyMatchType.DUEL, PartyMatchType.JUGGERNAUT -> TabRole.forDuelTeam(partySession.getPlayerTeamIndex(player.getUniqueId()) == 0);
            };
        }
        if (match.getPlayer1().equals(player.getUniqueId()) || match.getPlayer2().equals(player.getUniqueId())) {
            return TabRole.forDuelTeam(match.getPlayer1().equals(player.getUniqueId()));
        }
        return null;
    }

    public static String luckPermsPrefixOf(Player player) {
        try {
            LuckPerms lp = LuckPermsProvider.get();
            User user = lp.getUserManager().getUser(player.getUniqueId());
            if (user == null) {
                return "";
            }
            String prefix = user.getCachedData().getMetaData().getPrefix();
            return prefix == null ? "" : prefix;
        }
        catch (Exception ignored) {
            return "";
        }
    }

    public static String luckPermsSuffixOf(Player player) {
        try {
            LuckPerms lp = LuckPermsProvider.get();
            User user = lp.getUserManager().getUser(player.getUniqueId());
            if (user == null) {
                return "";
            }
            String suffix = user.getCachedData().getMetaData().getSuffix();
            return suffix == null ? "" : suffix;
        }
        catch (Exception ignored) {
            return "";
        }
    }
}

