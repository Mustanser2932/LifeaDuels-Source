/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.WorldBorder
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import me.lifea.arena.Arena;
import me.lifea.config.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;

public class WorldBorderUtil {
    private static final Set<UUID> activeBorders = new HashSet<UUID>();

    public static void set(Player player, Arena arena) {
        if (ConfigManager.config().getBoolean("duel.world-border-enabled", true)) {
            double centerZ;
            double centerX;
            int minX = Math.min(arena.getRegionMinX(), arena.getRegionMaxX());
            int maxX = Math.max(arena.getRegionMinX(), arena.getRegionMaxX());
            int minZ = Math.min(arena.getRegionMinZ(), arena.getRegionMaxZ());
            int maxZ = Math.max(arena.getRegionMinZ(), arena.getRegionMaxZ());
            if (arena.hasCenter()) {
                Location c = arena.getCenter();
                centerX = c.getX();
                centerZ = c.getZ();
            } else {
                centerX = ((double)minX + (double)maxX + 1.0) / 2.0;
                centerZ = ((double)minZ + (double)maxZ + 1.0) / 2.0;
            }
            double sizeX = (double)(maxX - minX) + 1.0;
            double sizeZ = (double)(maxZ - minZ) + 1.0;
            double size = Math.max(sizeX, sizeZ);
            WorldBorder border = Bukkit.createWorldBorder();
            border.setCenter(centerX, centerZ);
            border.setSize(size);
            border.setWarningDistance(0);
            border.setWarningTime(0);
            border.setDamageBuffer(0.0);
            border.setDamageAmount(0.0);
            player.setWorldBorder(border);
            activeBorders.add(player.getUniqueId());
        }
    }

    public static void remove(Player player) {
        if (activeBorders.remove(player.getUniqueId())) {
            player.setWorldBorder((WorldBorder)null);
        }
    }

    public static boolean isOutsideBorder(Location loc, Arena arena) {
        return !arena.isInside(loc);
    }
}

