/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.key.Key
 *  net.kyori.adventure.sound.Sound
 *  net.kyori.adventure.sound.Sound$Source
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import me.lifea.config.ConfigManager;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class SoundUtil {
    public static final String GUI_SOUND = "minecraft:block.bamboo_wood_button.click_on";

    public static void play(Player player, String key) {
        ConfigurationSection sec = ConfigManager.sounds();
        if (sec != null && sec.getBoolean(key + ".enabled", true)) {
            String soundStr = sec.getString(key + ".sound", "");
            float volume = (float)sec.getDouble(key + ".volume", 1.0);
            float pitch = (float)sec.getDouble(key + ".pitch", 1.0);
            if (!soundStr.isEmpty()) {
                SoundUtil.playRaw(player, soundStr, Sound.Source.MASTER, volume, pitch);
            }
        }
    }

    public static void playClick(Player player) {
        SoundUtil.playRaw(player, GUI_SOUND, Sound.Source.MASTER, 0.6f, 1.0f);
    }

    public static void playOpen(Player player) {
        SoundUtil.playRaw(player, GUI_SOUND, Sound.Source.MASTER, 0.6f, 1.0f);
    }

    public static void playRaw(Player player, String soundStr, Sound.Source source, float volume, float pitch) {
        Object ns = soundStr.contains(":") ? soundStr : "minecraft:" + soundStr;
        try {
            player.playSound(Sound.sound((Key)Key.key((String)ns), (Sound.Source)source, (float)volume, (float)pitch));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

