/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.minimessage.MiniMessage
 *  net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
 */
package me.lifea.util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public class ColorUtil {
    private static final Pattern HEX_PATTERN = Pattern.compile("&(#[A-Fa-f0-9]{6})");
    private static final Pattern SECTION_PATTERN = Pattern.compile("\u00a7([0-9a-fA-FklmnorKLMNOR])");
    private static final Pattern SPREAD_HEX_PATTERN = Pattern.compile("[&\u00a7]x([&\u00a7][A-Fa-f0-9]){6}");
    private static final LegacyComponentSerializer TAB_SERIALIZER = LegacyComponentSerializer.builder().character('&').hexColors().useUnusualXRepeatedCharacterHexFormat().build();
    private static final int PARSE_TAB_CACHE_SIZE = 512;
    private static final Map<String, Component> PARSE_TAB_CACHE = new LinkedHashMap<String, Component>(512, 0.75f, true){

        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Component> eldest) {
            return this.size() > 512;
        }
    };

    public static Component parse(String text) {
        text = ColorUtil.normalizeLegacyResets(text);
        text = ColorUtil.collapseSpreadHex(text);
        text = SECTION_PATTERN.matcher(text).replaceAll("&$1");
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(sb, "<" + matcher.group(1) + ">");
        }
        matcher.appendTail(sb);
        String legacyConverted = sb.toString().replace("&0", "<black>").replace("&1", "<dark_blue>").replace("&2", "<dark_green>").replace("&3", "<dark_aqua>").replace("&4", "<dark_red>").replace("&5", "<dark_purple>").replace("&6", "<gold>").replace("&7", "<gray>").replace("&8", "<dark_gray>").replace("&9", "<blue>").replace("&a", "<green>").replace("&b", "<aqua>").replace("&c", "<red>").replace("&d", "<light_purple>").replace("&e", "<yellow>").replace("&f", "<white>").replace("&A", "<green>").replace("&B", "<aqua>").replace("&C", "<red>").replace("&D", "<light_purple>").replace("&E", "<yellow>").replace("&F", "<white>").replace("&l", "<bold>").replace("&L", "<bold>").replace("&-l", "</bold>").replace("&-L", "</bold>").replace("&-o", "</italic>").replace("&-O", "</italic>").replace("&-n", "</underlined>").replace("&-N", "</underlined>").replace("&-m", "</strikethrough>").replace("&-M", "</strikethrough>").replace("&-k", "</obfuscated>").replace("&-K", "</obfuscated>").replace("&o", "<italic>").replace("&O", "<italic>").replace("&n", "<underlined>").replace("&N", "<underlined>").replace("&m", "<strikethrough>").replace("&M", "<strikethrough>").replace("&k", "<obfuscated>").replace("&K", "<obfuscated>").replace("&r", "<reset>").replace("&R", "<reset>");
        return MiniMessage.miniMessage().deserialize((Object)("<!italic>" + legacyConverted));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static Component parseTab(String text) {
        String key = text == null ? "" : text;
        Map<String, Component> map = PARSE_TAB_CACHE;
        synchronized (map) {
            Component cached = PARSE_TAB_CACHE.get(key);
            if (cached != null) {
                return cached;
            }
            TextComponent parsed = TAB_SERIALIZER.deserialize(ColorUtil.normalizeTabLegacy(key));
            PARSE_TAB_CACHE.put(key, (Component)parsed);
            return parsed;
        }
    }

    private static String normalizeTabLegacy(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        String value = ColorUtil.collapseSpreadHex(SECTION_PATTERN.matcher(text).replaceAll("&$1"));
        StringBuilder normalized = new StringBuilder(value.length() + 16);
        Object color = "&f";
        for (int i = 0; i < value.length(); ++i) {
            char character = value.charAt(i);
            if (character != '&') {
                normalized.append(character);
                continue;
            }
            if (i + 1 >= value.length()) {
                normalized.append("&r").append((String)color);
                continue;
            }
            char code = value.charAt(i + 1);
            if (code == '#' && i + 7 < value.length() && value.substring(i + 2, i + 8).matches("[A-Fa-f0-9]{6}")) {
                color = value.substring(i, i + 8);
                normalized.append((String)color);
                i += 7;
                continue;
            }
            if ("0123456789abcdefABCDEF".indexOf(code) >= 0) {
                color = "&" + Character.toLowerCase(code);
                normalized.append('&').append(code);
                ++i;
                continue;
            }
            if (code == 'r' || code == 'R') {
                color = "&f";
                normalized.append('&').append(code);
                ++i;
                continue;
            }
            if ("kKlLmMnNoO".indexOf(code) >= 0) {
                normalized.append('&').append(code);
                ++i;
                continue;
            }
            normalized.append("&r").append((String)color);
        }
        return normalized.toString();
    }

    private static String normalizeLegacyResets(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        StringBuilder normalized = new StringBuilder(text.length() + 4);
        for (int i = 0; i < text.length(); ++i) {
            char character = text.charAt(i);
            if (!(character != '&' || i + 1 < text.length() && ColorUtil.isLegacyCodeStart(text.charAt(i + 1)))) {
                normalized.append("&-l&-o&-n&-m&-k");
                continue;
            }
            normalized.append(character);
        }
        return normalized.toString();
    }

    private static boolean isLegacyCodeStart(char character) {
        return character == '#' || character == 'x' || character == 'X' || "0123456789abcdefABCDEFklmnorKLMNOR".indexOf(character) >= 0;
    }

    private static String collapseSpreadHex(String text) {
        Matcher matcher = SPREAD_HEX_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String match = matcher.group();
            String stripped = match.replace("&", "").replace("\u00a7", "");
            String hex = stripped.substring(1);
            matcher.appendReplacement(sb, Matcher.quoteReplacement("&#" + hex));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    public static String extractLastColorCode(String text) {
        return ColorUtil.extractLastColorCode(text, "&#FB0000");
    }

    public static String extractLastColorCode(String text, String fallbackColor) {
        if (text != null && !text.isEmpty()) {
            Object currentColor = "";
            String lastColor = fallbackColor;
            boolean hasVisibleText = false;
            int i = 0;
            while (i < text.length()) {
                char marker = text.charAt(i);
                if (marker != '&' && marker != '\u00a7') {
                    if (!Character.isWhitespace(marker)) {
                        hasVisibleText = true;
                        if (!((String)currentColor).isEmpty()) {
                            lastColor = currentColor;
                        }
                    }
                    ++i;
                    continue;
                }
                if (i + 1 >= text.length()) break;
                char code = text.charAt(i + 1);
                if (code != 'x' && code != 'X') {
                    if (code == '#') {
                        if (i + 8 <= text.length()) {
                            currentColor = text.substring(i, i + 8).replace('\u00a7', '&');
                            i += 8;
                            continue;
                        }
                    } else {
                        if ("0123456789AaBbCcDdEeFf".indexOf(code) >= 0) {
                            currentColor = "&" + Character.toLowerCase(code);
                            i += 2;
                            continue;
                        }
                        if (code == 'r' || code == 'R') {
                            currentColor = fallbackColor;
                            lastColor = fallbackColor;
                            i += 2;
                            continue;
                        }
                        if ("kKlLmMnNoO".indexOf(code) >= 0) {
                            i += 2;
                            continue;
                        }
                    }
                } else if (i + 13 < text.length() && (text.charAt(i + 2) == '&' || text.charAt(i + 2) == '\u00a7')) {
                    StringBuilder hex = new StringBuilder(6);
                    int pos = i + 2;
                    for (int h = 0; h < 6 && pos + 1 < text.length(); ++h) {
                        hex.append(text.charAt(pos + 1));
                        pos += 2;
                    }
                    if (hex.length() == 6) {
                        currentColor = "&#" + hex.toString().toLowerCase();
                        i = pos;
                        continue;
                    }
                }
                ++i;
            }
            return hasVisibleText ? lastColor : (((String)currentColor).isEmpty() ? fallbackColor : currentColor);
        }
        return fallbackColor;
    }
}

