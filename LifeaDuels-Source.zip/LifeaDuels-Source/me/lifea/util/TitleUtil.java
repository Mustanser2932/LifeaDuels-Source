/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.title.Title
 *  net.kyori.adventure.title.Title$Times
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.time.Duration;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class TitleUtil {
    public static void send(Player player, String key) {
        TitleUtil.send(player, key, new String[0][0]);
    }

    public static void sendSubtitle(Player player, String subtitle) {
        TitleUtil.sendSubtitle(player, subtitle, TitleUtil.opponentPing(player));
    }

    public static void sendSubtitle(Player player, String subtitle, Player opponent) {
        String ping = opponent != null && opponent.isOnline() ? String.valueOf(Math.max(0, opponent.getPing())) : TitleUtil.opponentPing(player);
        TitleUtil.sendSubtitle(player, subtitle, ping);
    }

    private static void sendSubtitle(Player player, String subtitle, String opponentPing) {
        if (player == null || !player.isOnline()) {
            return;
        }
        player.showTitle(Title.title((Component)Component.empty(), (Component)ColorUtil.parseTab(subtitle.replace("%ping_opp%", opponentPing)), (Title.Times)Title.Times.times((Duration)Duration.ZERO, (Duration)Duration.ofMillis(500L), (Duration)Duration.ZERO)));
    }

    private static String opponentPing(Player player) {
        Player opponent;
        Match match;
        if (player == null) {
            return "0";
        }
        PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
        if (partySession != null) {
            for (UUID uuid : partySession.getParticipants()) {
                Player opponent2 = Bukkit.getPlayer((UUID)uuid);
                if (opponent2 == null || !opponent2.isOnline() || partySession.isSameTeam(player, opponent2)) continue;
                return String.valueOf(Math.max(0, opponent2.getPing()));
            }
        }
        if ((match = MatchManager.getMatch(player.getUniqueId())) != null && match.isActive() && match.isPlayer(player.getUniqueId()) && (opponent = Bukkit.getPlayer((UUID)match.getOpponent(player.getUniqueId()))) != null && opponent.isOnline()) {
            return String.valueOf(Math.max(0, opponent.getPing()));
        }
        return "0";
    }

    public static void send(Player player, String key, String[][] placeholders) {
        String subtitleStr;
        ConfigurationSection sec = ConfigManager.titles();
        String titleStr = sec != null ? sec.getString(key + ".title", "") : "";
        String string = subtitleStr = sec != null ? sec.getString(key + ".subtitle", "") : "";
        if (titleStr.isEmpty() && subtitleStr.isEmpty()) {
            if (key.equals("duel-bed-broken")) {
                titleStr = "&c&lBED BROKEN";
                subtitleStr = "&fYou will not respawn after your next death.";
            } else if (key.equals("duel-respawn")) {
                titleStr = "&c&lYOU DIED";
                subtitleStr = "&fRespawning in &c%seconds%&f...";
            }
        }
        for (String[] placeholder : placeholders) {
            titleStr = titleStr.replace(placeholder[0], placeholder[1]);
            subtitleStr = subtitleStr.replace(placeholder[0], placeholder[1]);
        }
        String opponentPing = TitleUtil.opponentPing(player);
        titleStr = titleStr.replace("%ping_opp%", opponentPing);
        subtitleStr = subtitleStr.replace("%ping_opp%", opponentPing);
        player.showTitle(Title.title((Component)ColorUtil.parse(titleStr), (Component)ColorUtil.parse(subtitleStr), (Title.Times)Title.Times.times((Duration)Duration.ofMillis(500L), (Duration)Duration.ofMillis(3000L), (Duration)Duration.ofMillis(500L))));
    }
}

