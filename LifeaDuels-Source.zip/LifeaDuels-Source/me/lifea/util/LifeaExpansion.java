/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.util.Set;
import java.util.UUID;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

public class LifeaExpansion
extends PlaceholderExpansion {
    public String getIdentifier() {
        return "dv";
    }

    public String getAuthor() {
        return "Lifea";
    }

    public String getVersion() {
        return "1.0";
    }

    public boolean persist() {
        return true;
    }

    public String onRequest(OfflinePlayer player, String params) {
        String string;
        switch (params) {
            case "dueling": {
                return String.valueOf(this.countDuelingPlayers());
            }
            case "queuing": {
                return String.valueOf(this.countQueueingPlayers());
            }
        }
        if (player instanceof Player) {
            Player online = (Player)player;
            string = this.onPlaceholderRequest(online, params);
        } else {
            string = "";
        }
        return string;
    }

    public String onPlaceholderRequest(Player player, String params) {
        switch (params) {
            case "dueling": {
                return String.valueOf(this.countDuelingPlayers());
            }
            case "queuing": {
                return String.valueOf(this.countQueueingPlayers());
            }
        }
        if (player == null) {
            return "";
        }
        return switch (params) {
            case "comp_match" -> {
                if (this.inCompetitiveMatch(player)) {
                    yield "yes";
                }
                yield "no";
            }
            case "kills" -> String.valueOf(StatsManager.getCachedKills(player.getUniqueId()));
            case "deaths" -> String.valueOf(StatsManager.getCachedDeaths(player.getUniqueId()));
            case "wins" -> String.valueOf(StatsManager.getCachedWins(player.getUniqueId()));
            case "losses" -> String.valueOf(StatsManager.getCachedLosses(player.getUniqueId()));
            case "matches" -> String.valueOf(StatsManager.getCachedMatches(player.getUniqueId()));
            case "winstreak" -> String.valueOf(StatsManager.getCachedWinStreak(player.getUniqueId()));
            case "beststreak" -> String.valueOf(StatsManager.getCachedBestStreak(player.getUniqueId()));
            case "kdr" -> String.valueOf(StatsManager.getCachedKDR(player.getUniqueId()));
            default -> "";
        };
    }

    private int countDuelingPlayers() {
        int count = 0;
        for (Match match : MatchManager.getUniqueActiveMatches()) {
            Set<UUID> ids = MatchManager.getParticipantIds(match);
            if (ids == null) continue;
            count += ids.size();
        }
        return count;
    }

    private int countQueueingPlayers() {
        return QueueManager.getTotalQueuedCount();
    }

    private boolean inCompetitiveMatch(Player player) {
        Match match = MatchManager.getMatch(player.getUniqueId());
        return match != null && match.isCompetitive();
    }
}

