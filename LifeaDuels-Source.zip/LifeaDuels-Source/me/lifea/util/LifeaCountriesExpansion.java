/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.lifea.util.CountryHeadManager;
import org.bukkit.entity.Player;

public final class LifeaCountriesExpansion
extends PlaceholderExpansion {
    public String getIdentifier() {
        return "lifea";
    }

    public String getAuthor() {
        return "Lifea";
    }

    public String getVersion() {
        return "1.0";
    }

    public boolean persist() {
        return true;
    }

    public String onPlaceholderRequest(Player player, String params) {
        if ("countries".equalsIgnoreCase(params)) {
            return CountryHeadManager.get(player);
        }
        return "";
    }
}

