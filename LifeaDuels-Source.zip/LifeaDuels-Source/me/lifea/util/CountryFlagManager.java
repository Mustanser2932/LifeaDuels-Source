/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class CountryFlagManager {
    private static final String COUNTRY_FLAG_PLACEHOLDER = "%countryflags_flag%";

    private CountryFlagManager() {
    }

    public static String getFlag(Player player) {
        if (player == null || Bukkit.getPluginManager().getPlugin("PlaceholderAPI") == null || Bukkit.getPluginManager().getPlugin("CountryFlags") == null) {
            return "";
        }
        String flag = PlaceholderAPI.setPlaceholders((Player)player, (String)COUNTRY_FLAG_PLACEHOLDER);
        if (flag == null || flag.isBlank() || flag.equals(COUNTRY_FLAG_PLACEHOLDER)) {
            return "";
        }
        return flag;
    }
}

