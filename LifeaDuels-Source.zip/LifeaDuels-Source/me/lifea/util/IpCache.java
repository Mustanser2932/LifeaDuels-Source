/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package me.lifea.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

public final class IpCache {
    private static final Map<UUID, String> cache = new ConcurrentHashMap<UUID, String>();

    private IpCache() {
    }

    public static void store(Player player) {
        if (player.getAddress() != null) {
            cache.put(player.getUniqueId(), player.getAddress().getAddress().getHostAddress());
        }
    }

    public static void remove(UUID uuid) {
        cache.remove(uuid);
    }

    public static String get(UUID uuid) {
        return cache.get(uuid);
    }

    public static boolean sameIp(UUID a, UUID b) {
        String ipA = cache.get(a);
        String ipB = cache.get(b);
        return ipA != null && ipA.equals(ipB);
    }

    public static void clear() {
        cache.clear();
    }
}

