/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.util;

import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class SummerChatBridge {
    private static Method getTag;
    private static boolean resolved;

    private SummerChatBridge() {
    }

    public static String getTag(Player player) {
        if (player == null || Bukkit.getPluginManager().getPlugin("SummerChat") == null) {
            return "";
        }
        SummerChatBridge.resolveApi();
        if (getTag == null) {
            return "";
        }
        try {
            Object result = getTag.invoke(null, player);
            return result == null ? "" : result.toString();
        }
        catch (ReflectiveOperationException ignored) {
            return "";
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void resolveApi() {
        if (resolved) {
            return;
        }
        Class<SummerChatBridge> clazz = SummerChatBridge.class;
        synchronized (SummerChatBridge.class) {
            if (resolved) {
                // ** MonitorExit[var0] (shouldn't be in output)
                return;
            }
            try {
                Plugin summerChat = Bukkit.getPluginManager().getPlugin("SummerChat");
                if (summerChat == null) {
                    resolved = true;
                    // ** MonitorExit[var0] (shouldn't be in output)
                    return;
                }
                Class<?> api = Class.forName("org.mortic.summerChat.api.SummerChatAPI", true, summerChat.getClass().getClassLoader());
                getTag = api.getMethod("getTag", Player.class);
            }
            catch (ReflectiveOperationException ignored) {
                getTag = null;
            }
            resolved = true;
            // ** MonitorExit[var0] (shouldn't be in output)
            return;
        }
    }
}

