/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package me.lifea.queue;

import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.config.PerformanceConfig;
import me.lifea.duel.DuelSession;
import me.lifea.gui.CompGUI;
import me.lifea.gui.GUIManager;
import me.lifea.hotbar.HotbarManager;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.PartyManager;
import me.lifea.player.PlayerCacheEvictor;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.queue.QueueEntry;
import me.lifea.queue.QuickQueuePreferenceManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spawn.SpawnElytraManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import me.lifea.util.TitleUtil;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class QueueManager {
    private static final Map<String, List<QueueEntry>> queues = new ConcurrentHashMap<String, List<QueueEntry>>();
    private static final Map<UUID, List<QueueEntry>> playerQueues = new ConcurrentHashMap<UUID, List<QueueEntry>>();
    private static final Map<String, Integer> inDuelCountCache = new ConcurrentHashMap<String, Integer>();
    private static long inDuelCountCacheTime;
    private static final Map<String, Integer> queuedByGamemode;
    private static final Map<String, String> TIER_SUFFIX;

    private static List<QueueEntry> entries(UUID uuid) {
        return playerQueues.computeIfAbsent(uuid, k -> Collections.synchronizedList(new ArrayList()));
    }

    private static void removeEntryEverywhere(QueueEntry entry) {
        List<QueueEntry> bucket = queues.get(entry.getKey());
        if (bucket != null) {
            bucket.remove(entry);
        }
        QueueManager.adjustQueuedGamemodeCount(entry.getGamemode(), -1);
        List<QueueEntry> mine = playerQueues.get(entry.getPlayer().getUniqueId());
        if (mine != null) {
            mine.remove(entry);
            if (mine.isEmpty()) {
                playerQueues.remove(entry.getPlayer().getUniqueId());
            }
        }
    }

    private static void adjustQueuedGamemodeCount(String gamemode, int delta) {
        if (gamemode != null && delta != 0) {
            String key = gamemode.toLowerCase(Locale.ROOT);
            queuedByGamemode.merge(key, delta, Integer::sum);
            if (queuedByGamemode.getOrDefault(key, 0) <= 0) {
                queuedByGamemode.remove(key);
            }
        }
    }

    private static void refreshQueueHud(Player player) {
        QueueEntry primary;
        List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
        QueueEntry queueEntry = primary = mine != null && !mine.isEmpty() ? mine.get(0) : null;
        if (mine != null && !mine.isEmpty()) {
            if (HotbarManager.shouldHaveLobbyItems(player)) {
                HotbarManager.give(player, HotbarManager.HotbarType.QUEUE);
            }
            HashMap<String, String> placeholders = new HashMap<String, String>();
            if (mine.size() == 1) {
                String var10002 = primary.getGamemode();
                placeholders.put("%queue_mode%", var10002 + " (" + QueueManager.matchModeLabel(primary.getMatchMode()) + ")");
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < mine.size() && i < 3; ++i) {
                    if (i > 0) {
                        sb.append(", ");
                    }
                    sb.append(mine.get(i).getGamemode());
                }
                if (mine.size() > 3) {
                    sb.append(" +").append(mine.size() - 3);
                }
                String var6 = String.valueOf(sb);
                placeholders.put("%queue_mode%", var6 + " &f(" + mine.size() + " queues)");
            }
            placeholders.put("%queue_time%", "0s");
            placeholders.put("%tier%", primary.getTier());
            placeholders.put("%gamemode%", primary.getGamemode());
            placeholders.put("%match_mode%", QueueManager.matchModeLabel(primary.getMatchMode()));
            ScoreboardManager.setType(player, ScoreboardManager.Type.QUEUE, placeholders);
        } else {
            ScoreboardManager.setType(player, ScoreboardManager.Type.OVERALL, null);
            if (HotbarManager.shouldHaveLobbyItems(player)) {
                HotbarManager.give(player, HotbarManager.HotbarType.SPAWN);
            }
        }
    }

    public static void joinQueue(Player player, String tier, String gamemode, QueueEntry.MatchMode matchMode) {
        if (MatchManager.inMatch(player.getUniqueId())) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
        } else if (PartyManager.inParty(player.getUniqueId())) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.in-party")));
        } else if (!KitManager.isKitEnabled(tier, gamemode)) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.kit-disabled").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
        } else {
            String key = tier + ":" + gamemode;
            for (QueueEntry e : QueueManager.entries(player.getUniqueId())) {
                if (!e.getKey().equals(key)) continue;
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.already-in-this-mode").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
                return;
            }
            QueueEntry entry = new QueueEntry(player, tier, gamemode, matchMode);
            queues.computeIfAbsent(key, k -> Collections.synchronizedList(new ArrayList())).add(entry);
            QueueManager.adjustQueuedGamemodeCount(gamemode, 1);
            QueueManager.entries(player.getUniqueId()).add(entry);
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.joined").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
            SoundUtil.play(player, "queue-join");
            if (player.hasPermission("lifea.cosmetics.elytra") && PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA)) {
                SpawnElytraManager.removeWindCharge(player);
            }
            QueueManager.refreshQueueHud(player);
            CompGUI.refreshOpenViews();
            QueueManager.tryMatch(key);
        }
    }

    public static void leaveQueue(Player player) {
        List<QueueEntry> mine = playerQueues.remove(player.getUniqueId());
        if (mine != null && !mine.isEmpty()) {
            for (QueueEntry e : mine) {
                List<QueueEntry> bucket = queues.get(e.getKey());
                if (bucket != null) {
                    bucket.remove(e);
                }
                QueueManager.adjustQueuedGamemodeCount(e.getGamemode(), -1);
            }
            PlayerCacheEvictor.evict(player.getUniqueId());
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.left-all")));
            SoundUtil.play(player, "queue-leave");
            ScoreboardManager.setType(player, ScoreboardManager.Type.OVERALL, null);
            if (HotbarManager.shouldHaveLobbyItems(player)) {
                HotbarManager.give(player, HotbarManager.HotbarType.SPAWN);
            }
            if (player.hasPermission("lifea.cosmetics.elytra") && PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA)) {
                PlayerStateManager.scheduleLobbyCosmetics(player);
            }
            CompGUI.refreshOpenViews();
        } else {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.not-in-queue")));
        }
    }

    public static void leaveOneQueue(Player player, String tier, String gamemode) {
        String key = tier + ":" + gamemode;
        List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
        if (mine != null) {
            QueueEntry found = null;
            for (QueueEntry e : mine) {
                if (!e.getKey().equals(key)) continue;
                found = e;
                break;
            }
            if (found != null) {
                QueueManager.removeEntryEverywhere(found);
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.left").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
                SoundUtil.play(player, "queue-leave");
                QueueManager.refreshQueueHud(player);
                if (!QueueManager.inQueue(player) && player.hasPermission("lifea.cosmetics.elytra") && PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA)) {
                    PlayerStateManager.scheduleLobbyCosmetics(player);
                }
                CompGUI.refreshOpenViews();
            }
        }
    }

    public static void toggleQueue(Player player, String tier, String gamemode, QueueEntry.MatchMode matchMode) {
        if (QueueManager.isQueuedFor(player, tier, gamemode)) {
            QueueManager.leaveOneQueue(player, tier, gamemode);
        } else {
            QueueManager.joinQueue(player, tier, gamemode, matchMode);
        }
    }

    public static boolean isQueuedFor(Player player, String tier, String gamemode) {
        String key = tier + ":" + gamemode;
        List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
        if (mine == null) {
            return false;
        }
        for (QueueEntry e : mine) {
            if (!e.getKey().equals(key)) continue;
            return true;
        }
        return false;
    }

    public static int getTotalQueuedCount() {
        int total = 0;
        for (List<QueueEntry> bucket : queues.values()) {
            total += bucket.size();
        }
        return total;
    }

    public static int getQueuedCount(String gamemode) {
        return gamemode == null ? 0 : queuedByGamemode.getOrDefault(gamemode.toLowerCase(Locale.ROOT), 0);
    }

    public static int getQueuedCount(String tier, String gamemode) {
        List<QueueEntry> bucket = queues.get(tier + ":" + gamemode);
        return bucket != null ? bucket.size() : 0;
    }

    public static int getInDuelCount(String gamemode) {
        if (gamemode == null) {
            return 0;
        }
        int count = 0;
        for (Match match : MatchManager.getUniqueActiveMatches()) {
            if (!match.getGamemode().equalsIgnoreCase(gamemode)) continue;
            count += MatchManager.getParticipantIds(match).size();
        }
        return count;
    }

    public static int getInDuelCount(String tier, String gamemode) {
        long ttlMs = PerformanceConfig.getQueueStatsCacheTtlMs();
        long now = System.currentTimeMillis();
        if (now - inDuelCountCacheTime < ttlMs && !inDuelCountCache.isEmpty()) {
            return inDuelCountCache.getOrDefault(QueueManager.statsKey(tier, gamemode), 0);
        }
        QueueManager.refreshInDuelCountCache();
        return inDuelCountCache.getOrDefault(QueueManager.statsKey(tier, gamemode), 0);
    }

    public static void invalidateDuelCountCache() {
        inDuelCountCacheTime = 0L;
    }

    private static String statsKey(String tier, String gamemode) {
        String var10000 = tier.toLowerCase(Locale.ROOT);
        return var10000 + ":" + gamemode.toLowerCase(Locale.ROOT);
    }

    private static void refreshInDuelCountCache() {
        inDuelCountCache.clear();
        for (Match match : MatchManager.getUniqueActiveMatches()) {
            String key = QueueManager.statsKey(match.getTier(), match.getGamemode());
            int players = MatchManager.getParticipantIds(match).size();
            inDuelCountCache.merge(key, players, Integer::sum);
        }
        inDuelCountCacheTime = System.currentTimeMillis();
    }

    public static boolean inQueue(Player player) {
        List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
        return mine != null && !mine.isEmpty();
    }

    public static boolean isQueuedForAnyMode(Player player, List<String> gamemodes) {
        if (gamemodes != null && !gamemodes.isEmpty()) {
            List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
            if (mine != null && !mine.isEmpty()) {
                for (QueueEntry entry : mine) {
                    for (String mode : gamemodes) {
                        if (!entry.getGamemode().equalsIgnoreCase(mode)) continue;
                        return true;
                    }
                }
                return false;
            }
            return false;
        }
        return false;
    }

    public static boolean isQueuedForTierModes(Player player, String tier, List<String> gamemodes) {
        if (gamemodes != null && !gamemodes.isEmpty()) {
            List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
            if (mine != null && !mine.isEmpty()) {
                for (QueueEntry entry : mine) {
                    if (!entry.getTier().equalsIgnoreCase(tier)) continue;
                    for (String mode : gamemodes) {
                        if (!entry.getGamemode().equalsIgnoreCase(mode)) continue;
                        return true;
                    }
                }
                return false;
            }
            return false;
        }
        return false;
    }

    public static void removePlayerFromQueues(Player player) {
        List<QueueEntry> mine = playerQueues.remove(player.getUniqueId());
        if (mine != null) {
            for (QueueEntry e : mine) {
                List<QueueEntry> bucket = queues.get(e.getKey());
                if (bucket != null) {
                    bucket.remove(e);
                }
                QueueManager.adjustQueuedGamemodeCount(e.getGamemode(), -1);
            }
            PlayerCacheEvictor.evict(player.getUniqueId());
        }
    }

    public static QueueEntry getEntry(Player player) {
        List<QueueEntry> mine = playerQueues.get(player.getUniqueId());
        return mine != null && !mine.isEmpty() ? mine.get(0) : null;
    }

    private static void tryMatch(String key) {
        List<QueueEntry> list = queues.get(key);
        if (list != null && list.size() >= 2) {
            int size = list.size();
            QueueEntry bestA = null;
            QueueEntry bestB = null;
            long bestJoinTime = Long.MAX_VALUE;
            for (int i = 0; i < size; ++i) {
                for (int j = i + 1; j < size; ++j) {
                    long pairJoinTime;
                    QueueEntry a = list.get(i);
                    QueueEntry b = list.get(j);
                    if (!QueueManager.compatible(a.getMatchMode(), b.getMatchMode()) || !QueueManager.acceptsPing(a, b) || !QueueManager.acceptsPing(b, a) || (pairJoinTime = Math.min(a.getJoinTime(), b.getJoinTime())) >= bestJoinTime) continue;
                    bestJoinTime = pairJoinTime;
                    bestA = a;
                    bestB = b;
                }
            }
            if (bestA != null) {
                list.remove(bestA);
                list.remove(bestB);
                QueueManager.removeEntryEverywhere(bestA);
                QueueManager.removeEntryEverywhere(bestB);
                QueueManager.refreshQueueHud(bestA.getPlayer());
                QueueManager.refreshQueueHud(bestB.getPlayer());
                QueueManager.matchFound(bestA, bestB);
            }
        }
    }

    private static boolean acceptsPing(QueueEntry seeker, QueueEntry opponent) {
        return PlayerSettingsManager.getPingRange(seeker.getPlayer().getUniqueId()).matches(Math.max(0, opponent.getPlayer().getPing()));
    }

    private static boolean compatible(QueueEntry.MatchMode a, QueueEntry.MatchMode b) {
        return true;
    }

    private static void matchFound(QueueEntry e1, QueueEntry e2) {
        List<String> frames;
        Player p1 = e1.getPlayer();
        Player p2 = e2.getPlayer();
        SoundUtil.play(p1, "queue-found");
        SoundUtil.play(p2, "queue-found");
        p1.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.match-found").replace("%opponent%", p2.getName()).replace("%tier%", e1.getTier()).replace("%gamemode%", GamemodeRegistry.getDisplayName(e1.getTier(), e1.getGamemode()))));
        p2.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.match-found").replace("%opponent%", p1.getName()).replace("%tier%", e1.getTier()).replace("%gamemode%", GamemodeRegistry.getDisplayName(e1.getTier(), e1.getGamemode()))));
        if (SpectateManager.isSpectating(p1.getUniqueId())) {
            SpectateManager.stopSpectating(p1);
        }
        if (SpectateManager.isSpectating(p2.getUniqueId())) {
            SpectateManager.stopSpectating(p2);
        }
        GUIManager.closeMenus(p1, p2);
        QueueManager.invalidateDuelCountCache();
        SpawnElytraManager.removeWindCharge(p1);
        SpawnElytraManager.removeWindCharge(p2);
        ConfigurationSection animation = ConfigManager.titles() == null ? null : ConfigManager.titles().getConfigurationSection("queue-match-found-animation");
        List<String> list = frames = animation == null ? List.of("&cMatch Found") : animation.getStringList("frames");
        if (frames.isEmpty()) {
            frames = List.of("&cMatch Found");
        }
        int durationTicks = Math.max(0, animation == null ? 60 : animation.getInt("duration-ticks", 60));
        int intervalTicks = Math.max(1, animation == null ? 10 : animation.getInt("interval-ticks", 10));
        int blindnessTicks = Math.max(1, animation == null ? 60 : animation.getInt("blindness-duration-ticks", 60));
        p1.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blindnessTicks, 0, false, false, false));
        p2.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blindnessTicks, 0, false, false, false));
        QueueManager.playMatchFoundSubtitle(p1, p2, e1, e2, frames, durationTicks, intervalTicks, 0, 0);
    }

    private static void playMatchFoundSubtitle(Player p1, Player p2, QueueEntry e1, QueueEntry e2, List<String> frames, int durationTicks, int intervalTicks, int elapsedTicks, int frame) {
        if (!p1.isOnline() || !p2.isOnline()) {
            if (p1.isOnline()) {
                p1.removePotionEffect(PotionEffectType.BLINDNESS);
            }
            if (p2.isOnline()) {
                p2.removePotionEffect(PotionEffectType.BLINDNESS);
            }
            return;
        }
        if (elapsedTicks >= durationTicks) {
            int rounds = QueueManager.getRoundsForKey(e1.getTier(), e1.getGamemode());
            DuelSession.startDuel(p1, p2, e1.getTier(), e1.getGamemode(), rounds, Match.MatchType.QUEUE, true);
            return;
        }
        TitleUtil.sendSubtitle(p1, frames.get(frame % frames.size()), p2);
        TitleUtil.sendSubtitle(p2, frames.get(frame % frames.size()), p1);
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> QueueManager.playMatchFoundSubtitle(p1, p2, e1, e2, frames, durationTicks, intervalTicks, elapsedTicks + intervalTicks, frame + 1), (long)intervalTicks);
    }

    public static int getRoundsForKey(String tier, String gamemode) {
        int v;
        String suffix;
        int def = ConfigManager.queue().getInt("rounds.default", 1);
        String string = suffix = tier != null ? TIER_SUFFIX.get(tier) : null;
        if (suffix != null && gamemode != null) {
            String key = gamemode + "-" + suffix;
            int v2 = ConfigManager.queue().getInt("rounds." + key, -1);
            if (v2 > 0) {
                return v2;
            }
        }
        if (gamemode != null && (v = ConfigManager.queue().getInt("rounds." + gamemode, -1)) > 0) {
            return v;
        }
        return def;
    }

    private static String matchModeLabel(QueueEntry.MatchMode mode) {
        return switch (mode) {
            case QueueEntry.MatchMode.CASUAL -> "Casual";
            case QueueEntry.MatchMode.COMPETITIVE -> "Competitive";
            case QueueEntry.MatchMode.BOTH -> "Both";
            default -> throw new MatchException(null, null);
        };
    }

    public static void quickQueue(Player player) {
        if (!QuickQueuePreferenceManager.isLoaded(player.getUniqueId())) {
            QuickQueuePreferenceManager.loadAsync(player.getUniqueId(), () -> QueueManager.quickQueue(player));
            return;
        }
        if (PartyManager.inParty(player.getUniqueId())) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.in-party")));
        } else if (QueueManager.inQueue(player)) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.already-in-queue")));
        } else {
            String bestKey = null;
            int bestCount = 0;
            for (Map.Entry<String, List<QueueEntry>> entry : queues.entrySet()) {
                String[] parts = entry.getKey().split(":", 2);
                if (parts.length != 2 || !QuickQueuePreferenceManager.isEnabled(player.getUniqueId(), parts[0], parts[1]) || ((List)entry.getValue()).size() <= bestCount) continue;
                bestCount = ((List)entry.getValue()).size();
                bestKey = (String)entry.getKey();
            }
            if (bestKey == null) {
                ArrayList<CallSite> pool = new ArrayList<CallSite>();
                for (Map m : ConfigManager.queue().getMapList("comp-gui.modes")) {
                    String tier = (String)m.get("tier");
                    String gamemode = (String)m.get("gamemode");
                    if (tier == null || gamemode == null || !QuickQueuePreferenceManager.isEnabled(player.getUniqueId(), tier, gamemode) || !KitManager.isKitEnabled(tier, gamemode)) continue;
                    pool.add((CallSite)((Object)(tier + ":" + gamemode)));
                }
                ConfigurationSection itemsSec = ConfigManager.queue().getConfigurationSection("pvptiers.items");
                if (itemsSec != null) {
                    for (String key : itemsSec.getKeys(false)) {
                        String[] parsed;
                        String kit;
                        ConfigurationSection itemSec = itemsSec.getConfigurationSection(key);
                        if (itemSec == null || (kit = itemSec.getString("kit")) == null || (parsed = KitManager.parseKitKey(kit)) == null || !QuickQueuePreferenceManager.isEnabled(player.getUniqueId(), parsed[0], parsed[1]) || !KitManager.isKitEnabled(parsed[0], parsed[1])) continue;
                        pool.add((CallSite)((Object)(parsed[0] + ":" + parsed[1])));
                    }
                }
                if (!pool.isEmpty()) {
                    bestKey = (String)pool.get(new Random().nextInt(pool.size()));
                }
            }
            if (bestKey != null) {
                String[] parts = bestKey.split(":", 2);
                QueueManager.joinQueue(player, parts[0], parts[1], QueueEntry.MatchMode.COMPETITIVE);
            } else {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.quickqueue-empty")));
            }
        }
    }

    static {
        queuedByGamemode = new ConcurrentHashMap<String, Integer>();
        TIER_SUFFIX = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus");
    }
}

