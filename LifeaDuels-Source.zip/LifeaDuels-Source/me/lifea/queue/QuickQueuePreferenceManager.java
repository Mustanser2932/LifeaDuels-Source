/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.queue;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.storage.AsyncQueue;
import me.lifea.storage.DataPool;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class QuickQueuePreferenceManager {
    private static final Set<UUID> loaded = ConcurrentHashMap.newKeySet();
    private static final ConcurrentHashMap<UUID, Set<String>> disabled = new ConcurrentHashMap();

    private QuickQueuePreferenceManager() {
    }

    public static void loadAsync(UUID uuid, Runnable callback) {
        if (loaded.contains(uuid)) {
            if (callback != null) {
                callback.run();
            }
            return;
        }
        AsyncQueue.execute(() -> {
            ConcurrentHashMap.KeySetView values = ConcurrentHashMap.newKeySet();
            try (Connection connection = DataPool.getConnection();
                 PreparedStatement ps = connection.prepareStatement("SELECT tier, gamemode FROM quick_queue_disabled WHERE uuid=?");){
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery();){
                    while (rs.next()) {
                        values.add(QuickQueuePreferenceManager.key(rs.getString("tier"), rs.getString("gamemode")));
                    }
                }
            }
            catch (Exception e) {
                Lifea.getInstance().getLogger().warning("Could not load Quick Queue preferences: " + e.getMessage());
            }
            disabled.put(uuid, values);
            loaded.add(uuid);
            if (callback != null) {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), callback);
            }
        });
    }

    public static boolean isEnabled(UUID uuid, String tier, String gamemode) {
        return !disabled.getOrDefault(uuid, Collections.emptySet()).contains(QuickQueuePreferenceManager.key(tier, gamemode));
    }

    public static boolean isLoaded(UUID uuid) {
        return loaded.contains(uuid);
    }

    public static void toggle(UUID uuid, String tier, String gamemode) {
        String key = QuickQueuePreferenceManager.key(tier, gamemode);
        Set values = disabled.computeIfAbsent(uuid, ignored -> ConcurrentHashMap.newKeySet());
        if (!values.add(key)) {
            values.remove(key);
            AsyncQueue.executeUpdate("DELETE FROM quick_queue_disabled WHERE uuid=? AND tier=? AND gamemode=?", uuid.toString(), tier, gamemode);
        } else {
            AsyncQueue.executeUpdate("INSERT OR IGNORE INTO quick_queue_disabled (uuid, tier, gamemode) VALUES (?, ?, ?)", uuid.toString(), tier, gamemode);
        }
        loaded.add(uuid);
    }

    private static String key(String tier, String gamemode) {
        return tier + ":" + gamemode;
    }
}

