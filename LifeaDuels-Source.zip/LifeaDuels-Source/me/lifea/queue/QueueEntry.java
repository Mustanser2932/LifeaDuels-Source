/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package me.lifea.queue;

import org.bukkit.entity.Player;

public class QueueEntry {
    private final Player player;
    private final String tier;
    private final String gamemode;
    private final long joinTime;
    private final MatchMode matchMode;

    public QueueEntry(Player player, String tier, String gamemode, MatchMode matchMode) {
        this.player = player;
        this.tier = tier;
        this.gamemode = gamemode;
        this.matchMode = matchMode;
        this.joinTime = System.currentTimeMillis();
    }

    public Player getPlayer() {
        return this.player;
    }

    public String getTier() {
        return this.tier;
    }

    public String getGamemode() {
        return this.gamemode;
    }

    public MatchMode getMatchMode() {
        return this.matchMode;
    }

    public long getJoinTime() {
        return this.joinTime;
    }

    public String getKey() {
        return this.tier + ":" + this.gamemode;
    }

    public String getFormattedTime() {
        long seconds = (System.currentTimeMillis() - this.joinTime) / 1000L;
        long mins = seconds / 60L;
        long secs = seconds % 60L;
        return mins > 0L ? mins + "m " + secs + "s" : secs + "s";
    }

    public static final class MatchMode
    extends Enum<MatchMode> {
        public static final /* enum */ MatchMode CASUAL = new MatchMode();
        public static final /* enum */ MatchMode BOTH = new MatchMode();
        public static final /* enum */ MatchMode COMPETITIVE = new MatchMode();
        private static final /* synthetic */ MatchMode[] $VALUES;

        public static MatchMode[] values() {
            return (MatchMode[])$VALUES.clone();
        }

        public static MatchMode valueOf(String name) {
            return Enum.valueOf(MatchMode.class, name);
        }

        private static MatchMode[] $values() {
            return new MatchMode[]{CASUAL, BOTH, COMPETITIVE};
        }

        private static MatchMode[] $values$() {
            return new MatchMode[]{CASUAL, BOTH, COMPETITIVE};
        }

        private static /* synthetic */ MatchMode[] $values$$() {
            return new MatchMode[]{CASUAL, BOTH, COMPETITIVE};
        }

        static {
            $VALUES = MatchMode.$values$$();
        }
    }
}

