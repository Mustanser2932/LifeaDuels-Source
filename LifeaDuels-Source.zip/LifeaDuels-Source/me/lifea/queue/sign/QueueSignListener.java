/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.EquipmentSlot
 */
package me.lifea.queue.sign;

import me.lifea.gui.GUIManager;
import me.lifea.match.MatchManager;
import me.lifea.queue.sign.QueueSignManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.util.SoundUtil;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class QueueSignListener
implements Listener {
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent e) {
        Block b;
        if (e.getHand() == EquipmentSlot.HAND && e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null && SpawnManager.isMainWorld(e.getPlayer()) && !MatchManager.inMatch(e.getPlayer().getUniqueId()) && (b = e.getClickedBlock()).getState() instanceof Sign) {
            QueueSignManager.get(b.getLocation()).ifPresent(queueKey -> {
                e.setCancelled(true);
                SoundUtil.playClick(e.getPlayer());
                GUIManager.openQueueMainMenu(e.getPlayer());
            });
        }
    }
}

