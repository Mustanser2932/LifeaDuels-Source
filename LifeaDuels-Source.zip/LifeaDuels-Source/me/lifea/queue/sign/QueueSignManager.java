/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package me.lifea.queue.sign;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import me.lifea.storage.DatabaseManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class QueueSignManager {
    private static final Map<String, String> signs = new HashMap<String, String>();

    private QueueSignManager() {
    }

    public static void load() {
        signs.clear();
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement st = conn.prepareStatement("SELECT * FROM queue_signs");
             ResultSet rs = st.executeQuery();){
            while (rs.next()) {
                String world = rs.getString("world");
                int x = rs.getInt("x");
                int y = rs.getInt("y");
                int z = rs.getInt("z");
                String queueKey = rs.getString("queue_key");
                signs.put(QueueSignManager.locKey(world, x, y, z), queueKey);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load queue signs", e);
        }
    }

    public static Map<String, String> getAll() {
        return Collections.unmodifiableMap(signs);
    }

    public static void set(Location loc, String queueKey) {
        if (loc != null && loc.getWorld() != null) {
            String world = loc.getWorld().getName();
            int x = loc.getBlockX();
            int y = loc.getBlockY();
            int z = loc.getBlockZ();
            String key = QueueSignManager.locKey(world, x, y, z);
            signs.put(key, queueKey);
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement st = conn.prepareStatement("INSERT OR REPLACE INTO queue_signs (world, x, y, z, queue_key) VALUES (?, ?, ?, ?, ?)");){
                st.setString(1, world);
                st.setInt(2, x);
                st.setInt(3, y);
                st.setInt(4, z);
                st.setString(5, queueKey);
                st.executeUpdate();
            }
            catch (SQLException e) {
                throw new RuntimeException("Failed to save queue sign", e);
            }
        }
    }

    public static boolean remove(Location loc) {
        if (loc != null && loc.getWorld() != null) {
            int z;
            int y;
            int x;
            String world = loc.getWorld().getName();
            String key = QueueSignManager.locKey(world, x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ());
            if (!signs.containsKey(key)) {
                return false;
            }
            signs.remove(key);
            try {
                try (Connection conn = DatabaseManager.connection();
                     PreparedStatement st = conn.prepareStatement("DELETE FROM queue_signs WHERE world=? AND x=? AND y=? AND z=?");){
                    st.setString(1, world);
                    st.setInt(2, x);
                    st.setInt(3, y);
                    st.setInt(4, z);
                    st.executeUpdate();
                }
                return true;
            }
            catch (SQLException e) {
                throw new RuntimeException("Failed to delete queue sign", e);
            }
        }
        return false;
    }

    public static Optional<String> get(Location loc) {
        return loc != null && loc.getWorld() != null ? Optional.ofNullable(signs.get(QueueSignManager.locKey(loc.getWorld().getName(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()))) : Optional.empty();
    }

    private static String locKey(String world, int x, int y, int z) {
        return world + ":" + x + ":" + y + ":" + z;
    }

    public static Location parseKeyToLocation(String key) {
        try {
            String[] parts = key.split(":");
            if (parts.length != 4) {
                return null;
            }
            World w = Bukkit.getWorld((String)parts[0]);
            return w == null ? null : new Location(w, (double)Integer.parseInt(parts[1]), (double)Integer.parseInt(parts[2]), (double)Integer.parseInt(parts[3]));
        }
        catch (Exception var3) {
            return null;
        }
    }
}

