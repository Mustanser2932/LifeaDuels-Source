/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.ShadowColor
 *  net.kyori.adventure.util.ARGBLike
 *  org.bukkit.Bukkit
 *  org.bukkit.Statistic
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.scoreboard;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.config.PerformanceConfig;
import me.lifea.duel.DuelSession;
import me.lifea.libs.fastboard.adventure.FastBoard;
import me.lifea.match.Match;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.party.match.PartyMatchType;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.spectate.SpectateSession;
import me.lifea.util.ColorUtil;
import me.lifea.util.NametagManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.ShadowColor;
import net.kyori.adventure.util.ARGBLike;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class ScoreboardManager {
    private static final ShadowColor SCOREBOARD_SHADOW = ShadowColor.shadowColor((int)-1090519040);
    private static final Map<UUID, FastBoard> boards = new ConcurrentHashMap<UUID, FastBoard>();
    private static final Map<UUID, Type> types = new ConcurrentHashMap<UUID, Type>();
    private static final Map<UUID, Map<String, String>> placeholders = new ConcurrentHashMap<UUID, Map<String, String>>();
    private static final Map<UUID, Integer> lastHash = new ConcurrentHashMap<UUID, Integer>();
    private static final Map<UUID, List<Component>> lastLines = new ConcurrentHashMap<UUID, List<Component>>();
    private static ConfigurationSection scoreboardCfg;
    private static final Map<String, String> titleTmpl;
    private static final Map<String, List<String>> linesTmpl;
    private static String cachedDateString;
    private static long cachedDateRefresh;
    private static final long DATE_REFRESH_INTERVAL = 1000L;
    private static final ThreadLocal<HashMap<String, String>> PLACEHOLDER_POOL;
    private static final int MAX_CACHED_STATS = 200;
    private static final Map<UUID, Integer> cachedPing;
    private static final Map<UUID, Integer> cachedStatsKills;
    private static final Map<UUID, Integer> cachedStatsDeaths;
    private static long statsRefreshTime;
    private static final long STATS_REFRESH_INTERVAL = 200L;
    private static final Set<UUID> trackedPlayers;
    private static volatile boolean isShutdown;

    private static String playerHead(Player player) {
        return player == null ? "<head:entity/player/wide/steve>" : "<head:" + player.getName() + ">";
    }

    public static void start() {
        scoreboardCfg = ConfigManager.scoreboard();
        titleTmpl.clear();
        linesTmpl.clear();
        long interval = Math.max(20L, (long)PerformanceConfig.getScoreboardUpdateInterval());
        Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), () -> {
            if (!boards.isEmpty()) {
                Iterator<Map.Entry<UUID, FastBoard>> it = boards.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<UUID, FastBoard> entry = it.next();
                    UUID uuid = entry.getKey();
                    Player player = Bukkit.getPlayer((UUID)uuid);
                    if (player != null && player.isOnline()) {
                        ScoreboardManager.update(player);
                        continue;
                    }
                    FastBoard board = entry.getValue();
                    if (!board.isDeleted()) {
                        board.delete();
                    }
                    it.remove();
                    types.remove(uuid);
                    placeholders.remove(uuid);
                    lastHash.remove(uuid);
                    lastLines.remove(uuid);
                }
            }
        }, interval, interval);
    }

    public static void create(Player player) {
        ScoreboardManager.remove(player);
        FastBoard board = new FastBoard(player);
        boards.put(player.getUniqueId(), board);
        placeholders.put(player.getUniqueId(), new HashMap());
        ScoreboardManager.update(player);
        NametagManager.refresh(player);
    }

    public static void setType(Player player, Type type, Map<String, String> extra) {
        UUID uuid = player.getUniqueId();
        types.put(uuid, type);
        lastHash.remove(uuid);
        lastLines.remove(uuid);
        if (extra != null) {
            placeholders.put(uuid, extra);
        }
        ScoreboardManager.update(player);
    }

    public static void update(Player player) {
        FastBoard board = boards.get(player.getUniqueId());
        if (board != null && !board.isDeleted()) {
            UUID uuid = player.getUniqueId();
            Type type = types.get(uuid);
            if (type == null) {
                type = ScoreboardManager.resolveType(uuid);
                types.put(uuid, type);
            }
            if (scoreboardCfg != null) {
                String key = ScoreboardManager.typeToKey(type);
                ScoreboardManager.refreshCachedStatsIfNeeded();
                Map<String, String> resolved = ScoreboardManager.resolvePlaceholders(player, uuid, type);
                int hash = ScoreboardManager.computeHashFromResolved(resolved);
                Integer cached = lastHash.get(uuid);
                if (cached == null || cached != hash) {
                    Component titleComponent = ScoreboardManager.resolveComponent(key + ".title", resolved);
                    List<Component> lines = ScoreboardManager.resolveLines(key, resolved);
                    lastHash.put(uuid, hash);
                    lastLines.put(uuid, lines);
                    board.updateTitle(titleComponent);
                    board.updateLines(lines);
                }
            }
        }
    }

    private static void refreshCachedStatsIfNeeded() {
        long now = System.currentTimeMillis();
        if (now - statsRefreshTime > 200L) {
            cachedPing.clear();
            cachedStatsKills.clear();
            cachedStatsDeaths.clear();
            statsRefreshTime = now;
        }
    }

    private static int getCachedPing(Player player) {
        return cachedPing.computeIfAbsent(player.getUniqueId(), k -> player.getPing());
    }

    private static int getCachedStatKills(Player player) {
        return cachedStatsKills.computeIfAbsent(player.getUniqueId(), k -> player.getStatistic(Statistic.PLAYER_KILLS));
    }

    private static int getCachedStatDeaths(Player player) {
        return cachedStatsDeaths.computeIfAbsent(player.getUniqueId(), k -> player.getStatistic(Statistic.DEATHS));
    }

    private static String getCachedDateString() {
        long now = System.currentTimeMillis();
        if (now - cachedDateRefresh > 1000L || cachedDateString.isEmpty()) {
            cachedDateString = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
            cachedDateRefresh = now;
        }
        return cachedDateString;
    }

    private static int computeHashFromResolved(Map<String, String> resolved) {
        int result = 0;
        for (Map.Entry<String, String> entry : resolved.entrySet()) {
            result ^= entry.getKey().hashCode() * 31 + entry.getValue().hashCode();
        }
        return result;
    }

    private static Component resolveComponent(String path, Map<String, String> resolved) {
        String tmpl = titleTmpl.get(path);
        if (tmpl == null) {
            tmpl = scoreboardCfg.getString(path, "&#FFD700Lifea");
            titleTmpl.put(path, tmpl);
        }
        return ColorUtil.parse(ScoreboardManager.applyStringPlaceholders(tmpl, resolved)).shadowColor((ARGBLike)SCOREBOARD_SHADOW);
    }

    private static List<Component> resolveLines(String key, Map<String, String> resolved) {
        List tmpls = linesTmpl.get(key);
        if (tmpls == null) {
            tmpls = scoreboardCfg.getStringList(key + ".lines");
            linesTmpl.put(key, tmpls);
        }
        ArrayList<Component> result = new ArrayList<Component>(tmpls.size());
        for (String tmpl : tmpls) {
            result.add(ColorUtil.parse(ScoreboardManager.applyStringPlaceholders(tmpl, resolved)).shadowColor((ARGBLike)SCOREBOARD_SHADOW));
        }
        return result;
    }

    private static String applyStringPlaceholders(String template, Map<String, String> placeholders) {
        String result = template;
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            result = result.replace(entry.getKey(), entry.getValue());
        }
        return result;
    }

    private static void fillPartyPlaceholders(Map<String, String> m, PartyDuelSession pms, UUID perspectiveId) {
        int t0 = pms.getTeamTotal(0);
        int t1 = pms.getTeamTotal(1);
        int playerTeam = pms.getPlayerTeamIndex(perspectiveId);
        int oppTeam = 1 - playerTeam;
        m.put("%arena_name%", pms.getArena().getName());
        m.put("%total_players%", String.valueOf(pms.getTotalPlayers()));
        m.put("%alive_players%", String.valueOf(pms.getAlivePlayers()));
        m.put("%team_A_total_players%", String.valueOf(t0));
        m.put("%team_B_total_players%", String.valueOf(t1));
        m.put("%team_A_alive_players%", String.valueOf(pms.getTeamAlive(0)));
        m.put("%team_B_alive_players%", String.valueOf(pms.getTeamAlive(1)));
        m.put("%team_A_score%", String.valueOf(pms.getTeamScore(0)));
        m.put("%team_B_score%", String.valueOf(pms.getTeamScore(1)));
        m.put("%team_A_color%", t0 > 0 ? "&#007BFB" : "&f");
        m.put("%team_B_color%", t1 > 0 ? "&#FB0000" : "&f");
        m.put("%team_score_B%", String.valueOf(pms.getTeamScore(0)));
        m.put("%team_score_R%", String.valueOf(pms.getTeamScore(1)));
        m.put("%your_party_score%", String.valueOf(pms.getTeamScore(playerTeam)));
        m.put("%their_party_score%", String.valueOf(pms.getTeamScore(oppTeam)));
        m.put("%party_team_alive%", String.valueOf(pms.getTeamAlive(playerTeam)));
        m.put("%party_alive%", String.valueOf(pms.getTeamAlive(playerTeam)));
        m.put("%party_streak%", String.valueOf(pms.getPartyKillStreak(perspectiveId)));
        m.put("%party_spectators%", String.valueOf(SpectateManager.getSpectatorsForArena(pms.getArena().getName()).size()));
        m.put("%spectators%", m.get("%party_spectators%"));
        Player perspective = Bukkit.getPlayer((UUID)perspectiveId);
        if (perspective != null) {
            for (UUID uuid : pms.getParticipants()) {
                Player opponent = Bukkit.getPlayer((UUID)uuid);
                if (opponent == null || !opponent.isOnline() || pms.isSameTeam(perspective, opponent)) continue;
                m.put("%ping_opp%", String.valueOf(Math.max(0, opponent.getPing())));
                break;
            }
        }
    }

    private static Map<String, String> resolvePlaceholders(Player player, UUID uuid, Type type) {
        SpectateSession specSession;
        Party party;
        Map m = PLACEHOLDER_POOL.get();
        m.clear();
        boolean isDuel = type == Type.DUEL;
        boolean isPartyMatch = type == Type.PARTY_FFA || type == Type.PARTY_SPLIT || type == Type.PARTY_DUEL;
        m.put("%player%", player.getName());
        m.put("%statistic_player_kills%", String.valueOf(ScoreboardManager.getCachedStatKills(player)));
        m.put("%statistic_deaths%", String.valueOf(ScoreboardManager.getCachedStatDeaths(player)));
        m.put("%server_date_dd/MM/yyyy%", ScoreboardManager.getCachedDateString());
        m.put("%ping%", String.valueOf(ScoreboardManager.getCachedPing(player)));
        m.put("%ping_opp%", "0");
        m.put("%wins%", String.valueOf(StatsManager.getCachedWins(uuid)));
        m.put("%losses%", String.valueOf(StatsManager.getCachedLosses(uuid)));
        m.put("%streak%", String.valueOf(StatsManager.getCachedWinStreak(uuid)));
        m.put("%winstreak%", String.valueOf(StatsManager.getCachedWinStreak(uuid)));
        m.put("%beststreak%", String.valueOf(StatsManager.getCachedBestStreak(uuid)));
        m.put("%kdr%", String.valueOf(StatsManager.getCachedKDR(uuid)));
        m.put("%matches%", String.valueOf(StatsManager.getCachedMatches(uuid)));
        boolean inParty = PartyManager.inParty(uuid);
        if (inParty && (party = PartyManager.getParty(uuid)) != null) {
            Player leader = Bukkit.getPlayer((UUID)party.getLeader());
            m.put("%party_leader%", leader != null ? leader.getName() : "Offline");
            m.put("%party_size%", String.valueOf(party.size()));
            m.put("%party_state%", party.isPublic() ? "Public" : "Private");
        }
        if ((specSession = SpectateManager.getSession(uuid)) != null) {
            UUID targetId = specSession.getTargetId();
            DuelSession targetDuel = DuelSession.getSession(targetId);
            if (targetDuel != null) {
                Match match = targetDuel.getMatch();
                if (match != null) {
                    m.put("%arena_name%", targetDuel.getArena().getName());
                    m.put("%duration%", targetDuel.getDurationString());
                    int p1Score = match.getWins(targetId);
                    UUID opponentUUID = match.getOpponent(targetId);
                    int oppScore = match.getWins(opponentUUID);
                    Player opponent = Bukkit.getPlayer((UUID)opponentUUID);
                    m.put("%score%", String.valueOf(p1Score));
                    m.put("%score_opp%", String.valueOf(oppScore));
                    m.put("%player_head%", ScoreboardManager.playerHead(Bukkit.getPlayer((UUID)targetId)));
                    m.put("%opponent_head%", ScoreboardManager.playerHead(opponent));
                    m.put("%team_color%", "&f");
                    m.put("%team_color_opp%", "&f");
                    m.put("%opponent%", opponent != null ? opponent.getName() : "Unknown");
                    m.put("%ping_opp%", opponent != null ? String.valueOf(Math.max(0, opponent.getPing())) : "0");
                    m.put("%spectators%", String.valueOf(match.getSpectators().size()));
                }
            } else {
                PartyDuelSession targetParty = PartyDuelSession.getSession(targetId);
                if (targetParty != null) {
                    ScoreboardManager.fillPartyPlaceholders(m, targetParty, targetId);
                }
            }
        } else {
            DuelSession duelSession = DuelSession.getSession(uuid);
            if (duelSession != null) {
                m.put("%arena_name%", duelSession.getArena().getName());
                m.put("%duration%", duelSession.getDurationString());
                Match match = duelSession.getMatch();
                if (match != null) {
                    int playerScore = match.getWins(uuid);
                    UUID opponentUUID = match.getOpponent(uuid);
                    int opponentScore = match.getWins(opponentUUID);
                    Player opponent = Bukkit.getPlayer((UUID)opponentUUID);
                    m.put("%score%", String.valueOf(playerScore));
                    m.put("%score_opp%", String.valueOf(opponentScore));
                    m.put("%player_head%", ScoreboardManager.playerHead(player));
                    m.put("%opponent_head%", ScoreboardManager.playerHead(opponent));
                    boolean isPlayer1 = match.getPlayer1().equals(uuid);
                    m.put("%team_color%", isPlayer1 ? "&#007BFB" : "&#FB0000");
                    m.put("%team_color_opp%", isPlayer1 ? "&#FB0000" : "&#007BFB");
                    m.put("%opponent%", opponent != null ? opponent.getName() : "Unknown");
                    m.put("%ping_opp%", opponent != null ? String.valueOf(Math.max(0, opponent.getPing())) : "0");
                    m.put("%spectators%", String.valueOf(match.getSpectators().size()));
                }
            } else {
                PartyDuelSession partySession = PartyDuelSession.getSession(uuid);
                if (partySession != null) {
                    m.put("%arena_name%", partySession.getArena().getName());
                }
            }
        }
        if (!m.containsKey("%arena_name%")) {
            m.put("%arena_name%", "None");
        }
        if (!m.containsKey("%duration%")) {
            m.put("%duration%", "00:00");
        }
        if (!m.containsKey("%score%")) {
            m.put("%score%", "0");
        }
        if (!m.containsKey("%score_opp%")) {
            m.put("%score_opp%", "0");
        }
        if (!m.containsKey("%player_head%")) {
            m.put("%player_head%", ScoreboardManager.playerHead(null));
        }
        if (!m.containsKey("%opponent_head%")) {
            m.put("%opponent_head%", ScoreboardManager.playerHead(null));
        }
        if (!m.containsKey("%team_color%")) {
            m.put("%team_color%", "&f");
        }
        if (!m.containsKey("%team_color_opp%")) {
            m.put("%team_color_opp%", "&f");
        }
        if (!m.containsKey("%opponent%")) {
            m.put("%opponent%", "None");
        }
        if (!m.containsKey("%spectators%")) {
            m.put("%spectators%", "0");
        }
        if (isPartyMatch) {
            SpectateSession ss;
            PartyDuelSession pms = PartyDuelSession.getSession(uuid);
            if (pms == null && (ss = SpectateManager.getSession(uuid)) != null) {
                pms = PartyDuelSession.getSession(ss.getTargetId());
            }
            if (pms != null) {
                UUID perspectiveId = pms.isParticipant(uuid) ? uuid : pms.getAnyParticipantId();
                ScoreboardManager.fillPartyPlaceholders(m, pms, perspectiveId);
            }
        }
        Map extra = placeholders.getOrDefault(uuid, Collections.emptyMap());
        for (Map.Entry entry : extra.entrySet()) {
            m.put((String)entry.getKey(), (String)entry.getValue());
        }
        return m;
    }

    public static void updatePlayer(Player player) {
        types.remove(player.getUniqueId());
        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> ScoreboardManager.update(player));
    }

    public static void remove(Player player) {
        UUID uuid = player.getUniqueId();
        FastBoard board = boards.remove(uuid);
        types.remove(uuid);
        placeholders.remove(uuid);
        lastHash.remove(uuid);
        lastLines.remove(uuid);
        cachedPing.remove(uuid);
        cachedStatsKills.remove(uuid);
        cachedStatsDeaths.remove(uuid);
        if (board != null && !board.isDeleted()) {
            board.delete();
        }
    }

    private static Type resolveType(UUID uuid) {
        Player player;
        if (DuelSession.inSession(uuid)) {
            return Type.DUEL;
        }
        PartyDuelSession partySession = PartyDuelSession.getSession(uuid);
        if (partySession != null) {
            return switch (partySession.getMatchType()) {
                case PartyMatchType.FFA -> Type.PARTY_FFA;
                case PartyMatchType.SPLIT -> Type.PARTY_SPLIT;
                case PartyMatchType.DUEL -> Type.PARTY_DUEL;
                default -> throw new IllegalStateException("Unknown party match type");
            };
        }
        SpectateSession specSession = SpectateManager.getSession(uuid);
        if (specSession != null) {
            UUID targetId = specSession.getTargetId();
            if (DuelSession.inSession(targetId)) {
                return Type.DUEL;
            }
            PartyDuelSession targetParty = PartyDuelSession.getSession(targetId);
            if (targetParty != null) {
                switch (targetParty.getMatchType()) {
                    case FFA: {
                        return Type.PARTY_FFA;
                    }
                    case SPLIT: {
                        return Type.PARTY_SPLIT;
                    }
                    case DUEL: {
                        return Type.PARTY_DUEL;
                    }
                }
                return Type.OVERALL;
            }
        }
        if ((player = Bukkit.getPlayer((UUID)uuid)) != null && QueueManager.inQueue(player)) {
            return Type.QUEUE;
        }
        return PartyManager.inParty(uuid) ? Type.PARTY : Type.OVERALL;
    }

    private static String typeToKey(Type type) {
        return switch (type.ordinal()) {
            case 1 -> "duel";
            case 2 -> "queue";
            case 3 -> "party";
            case 4 -> "party-ffa";
            case 5 -> "party-split";
            case 6 -> "party-duel";
            default -> "overall";
        };
    }

    static {
        titleTmpl = new ConcurrentHashMap<String, String>();
        linesTmpl = new ConcurrentHashMap<String, List<String>>();
        cachedDateString = "";
        cachedDateRefresh = 0L;
        PLACEHOLDER_POOL = ThreadLocal.withInitial(HashMap::new);
        cachedPing = new ConcurrentHashMap<UUID, Integer>();
        cachedStatsKills = new ConcurrentHashMap<UUID, Integer>();
        cachedStatsDeaths = new ConcurrentHashMap<UUID, Integer>();
        statsRefreshTime = 0L;
        trackedPlayers = ConcurrentHashMap.newKeySet();
        isShutdown = false;
    }

    public static final class Type
    extends Enum<Type> {
        public static final /* enum */ Type OVERALL = new Type();
        public static final /* enum */ Type DUEL = new Type();
        public static final /* enum */ Type QUEUE = new Type();
        public static final /* enum */ Type PARTY = new Type();
        public static final /* enum */ Type PARTY_FFA = new Type();
        public static final /* enum */ Type PARTY_SPLIT = new Type();
        public static final /* enum */ Type PARTY_DUEL = new Type();
        private static final /* synthetic */ Type[] $VALUES;

        public static Type[] values() {
            return (Type[])$VALUES.clone();
        }

        public static Type valueOf(String name) {
            return Enum.valueOf(Type.class, name);
        }

        private static Type[] $values() {
            return new Type[]{OVERALL, DUEL, QUEUE, PARTY, PARTY_FFA, PARTY_SPLIT, PARTY_DUEL};
        }

        private static Type[] $values$() {
            return new Type[]{OVERALL, DUEL, QUEUE, PARTY, PARTY_FFA, PARTY_SPLIT, PARTY_DUEL};
        }

        private static /* synthetic */ Type[] $values$$() {
            return new Type[]{OVERALL, DUEL, QUEUE, PARTY, PARTY_FFA, PARTY_SPLIT, PARTY_DUEL};
        }

        static {
            $VALUES = Type.$values$$();
        }
    }
}

