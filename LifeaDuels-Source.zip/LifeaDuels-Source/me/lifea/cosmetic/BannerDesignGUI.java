/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.DyeColor
 *  org.bukkit.Material
 *  org.bukkit.block.banner.Pattern
 *  org.bukkit.block.banner.PatternType
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.BannerMeta
 *  org.bukkit.inventory.meta.ItemMeta
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import me.lifea.cosmetic.BannerColorGUI;
import me.lifea.cosmetic.BannerGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.ItemMeta;

public class BannerDesignGUI {
    public static void open(Player player) {
        FileConfiguration cfg = BannerGUI.loadCosmetics();
        String base = "banner-design";
        String title = cfg.getString(base + ".title", "Select Design");
        int rows = BannerDesignGUI.parseRows(cfg.getString(base + ".size", "chest-6"));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(BannerDesignGUI.noItalic(title))).rows(rows)).disableAllInteractions()).create();
        for (String key : BannerDesignGUI.keys(cfg, base)) {
            int slot;
            try {
                slot = Integer.parseInt(key);
            }
            catch (NumberFormatException var17) {
                continue;
            }
            String path = base + ".items." + key;
            String matName = cfg.getString(path + ".material", "");
            Material mat = Material.matchMaterial((String)matName);
            if (mat == null) continue;
            String name = cfg.getString(path + ".name", "");
            List lore = cfg.getStringList(path + ".lore");
            String patternKey = cfg.getString(path + ".pattern", (String)null);
            if (patternKey != null) {
                PatternType patternType = BannerDesignGUI.resolvePattern(patternKey);
                if (patternType == null) continue;
                ItemStack bannerItem = BannerDesignGUI.buildPreviewBanner(patternType);
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(bannerItem).name(BannerDesignGUI.noItalic(name))).lore(BannerDesignGUI.toLore(lore))).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    BannerColorGUI.open(player, patternType);
                }));
                continue;
            }
            if (mat == Material.ARROW) {
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(BannerDesignGUI.noItalic(name))).lore(BannerDesignGUI.toLore(lore))).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    BannerGUI.open(player);
                }));
                continue;
            }
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(BannerDesignGUI.noItalic(name.isEmpty() ? " " : name))).lore(BannerDesignGUI.toLore(lore))).flags(ItemFlag.values())).asGuiItem());
        }
        gui.open((HumanEntity)player);
    }

    private static ItemStack buildPreviewBanner(PatternType patternType) {
        ItemStack item = new ItemStack(Material.WHITE_BANNER);
        BannerMeta meta = (BannerMeta)item.getItemMeta();
        if (meta != null) {
            meta.addPattern(new Pattern(DyeColor.BLACK, patternType));
            item.setItemMeta((ItemMeta)meta);
        }
        return item;
    }

    private static PatternType resolvePattern(String key) {
        try {
            return PatternType.valueOf((String)key.toUpperCase());
        }
        catch (IllegalArgumentException var2) {
            return null;
        }
    }

    private static List<Component> toLore(List<String> lines) {
        ArrayList<Component> list = new ArrayList<Component>();
        for (String line : lines) {
            list.add(BannerDesignGUI.noItalic(line));
        }
        return list;
    }

    private static Set<String> keys(FileConfiguration cfg, String base) {
        ConfigurationSection section = cfg.getConfigurationSection(base + ".items");
        return section != null ? section.getKeys(false) : Set.of();
    }

    private static int parseRows(String size) {
        return switch (size) {
            case "chest-1" -> 1;
            case "chest-2" -> 2;
            case "chest-3" -> 3;
            case "chest-4" -> 4;
            case "chest-5" -> 5;
            default -> 6;
        };
    }

    static Component noItalic(String text) {
        return text != null && !text.isEmpty() ? ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty();
    }
}

