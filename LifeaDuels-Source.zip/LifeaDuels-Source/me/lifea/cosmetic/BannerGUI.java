/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.BannerMeta
 *  org.bukkit.inventory.meta.ItemMeta
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import me.lifea.config.ConfigManager;
import me.lifea.cosmetic.BannerBaseGUI;
import me.lifea.cosmetic.BannerDesignGUI;
import me.lifea.cosmetic.BannerManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.ItemMeta;

public class BannerGUI {
    public static void open(Player player) {
        FileConfiguration cfg = BannerGUI.loadCosmetics();
        String base = "banner";
        String title = cfg.getString(base + ".title", "Banners");
        int rows = BannerGUI.parseRows(cfg.getString(base + ".size", "chest-3"));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(BannerGUI.noItalic(title))).rows(rows)).disableAllInteractions()).create();
        Set<String> keys = BannerGUI.keys(cfg, base);
        BannerManager.BannerState state = BannerManager.get(player.getUniqueId());
        for (String key : keys) {
            int slot;
            try {
                slot = Integer.parseInt(key);
            }
            catch (NumberFormatException var161) {
                continue;
            }
            String path = base + ".items." + key;
            if (slot == 10) {
                gui.setItem(slot, BannerGUI.buildPreviewItem(cfg, path, state));
                continue;
            }
            String matName = cfg.getString(path + ".material", "");
            Material mat = Material.matchMaterial((String)matName);
            if (mat == null) continue;
            String name = cfg.getString(path + ".name", "");
            List lore = cfg.getStringList(path + ".lore");
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(BannerGUI.noItalic(name.isEmpty() ? " " : name))).lore(BannerGUI.toLoreComponents(lore))).flags(ItemFlag.values())).asGuiItem(ex -> {
                SoundUtil.playClick(player);
                BannerGUI.handleClick(player, slot);
            }));
        }
        gui.open((HumanEntity)player);
    }

    private static GuiItem buildPreviewItem(FileConfiguration cfg, String path, BannerManager.BannerState state) {
        cfg.getString(path + ".material", "WHITE_BANNER");
        String baseBannerMat = state.base().name() + "_BANNER";
        Material mat = Material.matchMaterial((String)baseBannerMat);
        if (mat == null) {
            mat = Material.WHITE_BANNER;
        }
        String name = cfg.getString(path + ".name", "");
        List loreTemplate = cfg.getStringList(path + ".lore");
        ItemStack item = new ItemStack(mat);
        BannerMeta meta = (BannerMeta)item.getItemMeta();
        if (meta != null) {
            meta.setPatterns(state.layers());
            item.setItemMeta((ItemMeta)meta);
        }
        ArrayList<Component> lore = new ArrayList<Component>();
        for (String line : loreTemplate) {
            String resolved = line.replace("%base%", "1").replace("%layers%", String.valueOf(state.layers().size()));
            lore.add(BannerGUI.noItalic(resolved));
        }
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(item).name(BannerGUI.noItalic(name))).lore(lore)).flags(ItemFlag.values())).asGuiItem();
    }

    private static void handleClick(Player player, int slot) {
        switch (slot) {
            case 12: {
                BannerBaseGUI.open(player);
                break;
            }
            case 13: {
                BannerDesignGUI.open(player);
                break;
            }
            case 14: {
                BannerManager.BannerState layerState = BannerManager.get(player.getUniqueId());
                BannerManager.set(player.getUniqueId(), layerState.withTopLayerRemoved());
                BannerGUI.open(player);
                break;
            }
            case 15: {
                BannerManager.BannerState resetState = BannerManager.get(player.getUniqueId());
                BannerManager.set(player.getUniqueId(), resetState.reset());
                BannerGUI.open(player);
                break;
            }
            case 16: {
                player.sendMessage(ColorUtil.parse("&aBanner saved!"));
                player.closeInventory();
            }
        }
    }

    private static List<Component> toLoreComponents(List<String> lines) {
        ArrayList<Component> list = new ArrayList<Component>();
        for (String line : lines) {
            list.add(BannerGUI.noItalic(line));
        }
        return list;
    }

    private static Set<String> keys(FileConfiguration cfg, String base) {
        ConfigurationSection section = cfg.getConfigurationSection(base + ".items");
        return section != null ? section.getKeys(false) : Set.of();
    }

    private static int parseRows(String size) {
        return switch (size) {
            case "chest-1" -> 1;
            case "chest-2" -> 2;
            case "chest-4" -> 4;
            case "chest-5" -> 5;
            case "chest-6" -> 6;
            default -> 3;
        };
    }

    static Component noItalic(String text) {
        return text != null && !text.isEmpty() ? ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty();
    }

    static FileConfiguration loadCosmetics() {
        return ConfigManager.cosmetics();
    }
}

