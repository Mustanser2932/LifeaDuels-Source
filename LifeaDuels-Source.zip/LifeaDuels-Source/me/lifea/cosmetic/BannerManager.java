/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.DyeColor
 *  org.bukkit.Material
 *  org.bukkit.block.Banner
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.banner.Pattern
 *  org.bukkit.block.banner.PatternType
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.BannerMeta
 *  org.bukkit.inventory.meta.BlockStateMeta
 *  org.bukkit.inventory.meta.ItemMeta
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.block.Banner;
import org.bukkit.block.BlockState;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;

public final class BannerManager {
    private static final Map<UUID, BannerState> states = new ConcurrentHashMap<UUID, BannerState>();

    private BannerManager() {
    }

    public static BannerState get(UUID uuid) {
        return states.computeIfAbsent(uuid, k -> new BannerState(DyeColor.WHITE, new ArrayList<Pattern>()));
    }

    public static void set(UUID uuid, BannerState state) {
        states.put(uuid, state);
    }

    public static void remove(UUID uuid) {
        states.remove(uuid);
    }

    public static void applyBanner(Player player) {
        BannerState state = states.get(player.getUniqueId());
        if (state != null) {
            PlayerInventory inv;
            ItemStack offhand;
            ItemStack shield;
            BlockStateMeta shieldMeta;
            ItemStack banner;
            BannerMeta bannerMeta;
            String bannerMatName = state.base().name() + "_BANNER";
            Material bannerMat = Material.matchMaterial((String)bannerMatName);
            if (bannerMat == null) {
                bannerMat = Material.WHITE_BANNER;
            }
            if ((bannerMeta = (BannerMeta)(banner = new ItemStack(bannerMat)).getItemMeta()) != null) {
                bannerMeta.setPatterns(state.layers());
                banner.setItemMeta((ItemMeta)bannerMeta);
            }
            if ((shieldMeta = (BlockStateMeta)(shield = new ItemStack(Material.SHIELD)).getItemMeta()) != null) {
                Banner shieldBanner = (Banner)shieldMeta.getBlockState();
                shieldBanner.setBaseColor(state.base());
                shieldBanner.setPatterns(state.layers());
                shieldMeta.setBlockState((BlockState)shieldBanner);
                shield.setItemMeta((ItemMeta)shieldMeta);
            }
            if ((offhand = (inv = player.getInventory()).getItemInOffHand()).getType() == Material.SHIELD) {
                inv.setItemInOffHand(BannerManager.applyEnchantments(offhand, shield));
            } else {
                for (int i = 0; i < 36; ++i) {
                    ItemStack item = inv.getItem(i);
                    if (item == null || item.getType() != Material.SHIELD) continue;
                    inv.setItem(i, BannerManager.applyEnchantments(item, shield));
                    return;
                }
            }
        }
    }

    private static ItemStack applyEnchantments(ItemStack source, ItemStack target) {
        source.getEnchantments().forEach((ench, level) -> target.addUnsafeEnchantment(ench, level.intValue()));
        return target;
    }

    public record BannerState(DyeColor base, List<Pattern> layers) {
        public BannerState withBase(DyeColor newBase) {
            return new BannerState(newBase, new ArrayList<Pattern>(this.layers));
        }

        public BannerState withLayerAdded(PatternType type, DyeColor color) {
            ArrayList<Pattern> copy = new ArrayList<Pattern>(this.layers);
            copy.add(new Pattern(color, type));
            return new BannerState(this.base, copy);
        }

        public BannerState withTopLayerRemoved() {
            if (this.layers.isEmpty()) {
                return this;
            }
            ArrayList<Pattern> copy = new ArrayList<Pattern>(this.layers);
            copy.remove(copy.size() - 1);
            return new BannerState(this.base, copy);
        }

        public BannerState reset() {
            return new BannerState(DyeColor.WHITE, new ArrayList<Pattern>());
        }
    }
}

