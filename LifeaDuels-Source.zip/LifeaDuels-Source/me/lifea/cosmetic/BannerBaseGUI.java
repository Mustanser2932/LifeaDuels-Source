/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.DyeColor
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import me.lifea.cosmetic.BannerGUI;
import me.lifea.cosmetic.BannerManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class BannerBaseGUI {
    public static void open(Player player) {
        FileConfiguration cfg = BannerGUI.loadCosmetics();
        String base = "banners-base";
        String title = cfg.getString(base + ".title", "Select Base");
        int rows = BannerBaseGUI.parseRows(cfg.getString(base + ".size", "chest-3"));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(BannerBaseGUI.noItalic(title))).rows(rows)).disableAllInteractions()).create();
        for (String key : BannerBaseGUI.keys(cfg, base)) {
            int slot;
            try {
                slot = Integer.parseInt(key);
            }
            catch (NumberFormatException var15) {
                continue;
            }
            String path = base + ".items." + key;
            String matName = cfg.getString(path + ".material", "");
            Material mat = Material.matchMaterial((String)matName);
            if (mat == null) continue;
            String name = cfg.getString(path + ".name", "");
            List lore = cfg.getStringList(path + ".lore");
            DyeColor dyeColor = BannerBaseGUI.bannerToDye(mat);
            if (dyeColor != null) {
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(BannerBaseGUI.noItalic(name))).lore(BannerBaseGUI.toLore(lore))).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    BannerManager.BannerState s = BannerManager.get(player.getUniqueId());
                    BannerManager.set(player.getUniqueId(), s.withBase(dyeColor));
                    BannerGUI.open(player);
                }));
                continue;
            }
            if (mat == Material.ARROW) {
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(BannerBaseGUI.noItalic(name))).lore(BannerBaseGUI.toLore(lore))).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    BannerGUI.open(player);
                }));
                continue;
            }
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(BannerBaseGUI.noItalic(name.isEmpty() ? " " : name))).lore(BannerBaseGUI.toLore(lore))).flags(ItemFlag.values())).asGuiItem());
        }
        gui.open((HumanEntity)player);
    }

    private static DyeColor bannerToDye(Material mat) {
        String name = mat.name();
        if (!name.endsWith("_BANNER")) {
            return null;
        }
        String colorName = name.replace("_BANNER", "");
        try {
            return DyeColor.valueOf((String)colorName);
        }
        catch (IllegalArgumentException var4) {
            return null;
        }
    }

    private static List<Component> toLore(List<String> lines) {
        ArrayList<Component> list = new ArrayList<Component>();
        for (String line : lines) {
            list.add(BannerBaseGUI.noItalic(line));
        }
        return list;
    }

    private static Set<String> keys(FileConfiguration cfg, String base) {
        ConfigurationSection section = cfg.getConfigurationSection(base + ".items");
        return section != null ? section.getKeys(false) : Set.of();
    }

    private static int parseRows(String size) {
        return switch (size) {
            case "chest-1" -> 1;
            case "chest-2" -> 2;
            case "chest-4" -> 4;
            case "chest-5" -> 5;
            case "chest-6" -> 6;
            default -> 3;
        };
    }

    static Component noItalic(String text) {
        return text != null && !text.isEmpty() ? ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty();
    }
}

