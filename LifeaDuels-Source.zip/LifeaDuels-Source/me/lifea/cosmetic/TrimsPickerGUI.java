/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.cosmetic.TrimsMaterialGUI;
import me.lifea.cosmetic.TrimsSlotGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class TrimsPickerGUI {
    public static void open(Player player, String armorSlot) {
        FileConfiguration config = ConfigManager.config();
        String base = "trims-selection";
        String title = config.getString(base + ".title", "Trim Patterns");
        String lockedState = config.getString(base + ".locked-state", "&cLOCKED");
        String unlockedState = config.getString(base + ".unlocked-state", "&aUNLOCKED");
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(TrimsPickerGUI.noItalic(title))).rows(5)).disableAllInteractions()).create();
        for (String key : config.getConfigurationSection(base + ".items") != null ? config.getConfigurationSection(base + ".items").getKeys(false) : Collections.emptySet()) {
            int slot;
            String path = base + ".items." + key;
            try {
                slot = Integer.parseInt(key);
            }
            catch (NumberFormatException var20) {
                continue;
            }
            String matName = config.getString(path + ".material", "");
            Material mat = Material.matchMaterial((String)matName);
            if (mat == null) continue;
            String name = config.getString(path + ".name", "");
            List lore = config.getStringList(path + ".lore");
            String patternName = TrimsPickerGUI.extractPatternName(mat);
            if (patternName != null) {
                String var10001 = patternName.toLowerCase();
                boolean hasPermission = player.hasPermission("lifea.cosmetics." + var10001);
                ArrayList<Component> loreComponents = new ArrayList<Component>();
                loreComponents.add((Component)Component.empty());
                loreComponents.add(TrimsPickerGUI.noItalic(hasPermission ? unlockedState : lockedState));
                if (hasPermission) {
                    loreComponents.add((Component)Component.empty());
                    loreComponents.add(TrimsPickerGUI.noItalic("&fClick to select"));
                }
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsPickerGUI.noItalic(name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    if (hasPermission) {
                        TrimsMaterialGUI.open(player, armorSlot, patternName);
                    }
                }));
                continue;
            }
            ArrayList<Component> loreComponents = new ArrayList<Component>();
            for (String line : lore) {
                loreComponents.add(TrimsPickerGUI.noItalic(line));
            }
            if (mat == Material.ARROW) {
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsPickerGUI.noItalic(name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    TrimsSlotGUI.open(player);
                }));
                continue;
            }
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsPickerGUI.noItalic(name.isEmpty() ? " " : name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem());
        }
        gui.open((HumanEntity)player);
    }

    static String extractPatternName(Material mat) {
        String name = mat.name();
        return !name.endsWith("_ARMOR_TRIM_SMITHING_TEMPLATE") ? null : name.replace("_ARMOR_TRIM_SMITHING_TEMPLATE", "");
    }

    static Component noItalic(String text) {
        return text != null && !text.isEmpty() ? ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty();
    }
}

