/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.cosmetic.TrimManager;
import me.lifea.cosmetic.TrimsPickerGUI;
import me.lifea.cosmetic.TrimsSlotGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class TrimsMaterialGUI {
    private static String toTrimMaterialName(Material mat) {
        return switch (mat) {
            case Material.COPPER_INGOT -> "COPPER";
            case Material.IRON_INGOT -> "IRON";
            case Material.GOLD_INGOT -> "GOLD";
            case Material.NETHERITE_INGOT -> "NETHERITE";
            case Material.EMERALD -> "EMERALD";
            case Material.DIAMOND -> "DIAMOND";
            case Material.LAPIS_LAZULI -> "LAPIS_LAZULI";
            case Material.REDSTONE -> "REDSTONE";
            case Material.QUARTZ -> "QUARTZ";
            case Material.AMETHYST_SHARD -> "AMETHYST";
            default -> null;
        };
    }

    public static void open(Player player, String armorSlot, String patternName) {
        FileConfiguration config = ConfigManager.config();
        String base = "select-material";
        String title = config.getString(base + ".title", "Select Material");
        String materialLore = config.getString(base + ".material-lore", "&fClick to Select");
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(TrimsMaterialGUI.noItalic(title))).rows(4)).disableAllInteractions()).create();
        for (String key : config.getConfigurationSection(base + ".items") != null ? config.getConfigurationSection(base + ".items").getKeys(false) : Collections.emptySet()) {
            ArrayList<Component> loreComponents;
            int slot;
            String path = base + ".items." + key;
            try {
                slot = Integer.parseInt(key);
            }
            catch (NumberFormatException var20) {
                continue;
            }
            String matName = config.getString(path + ".material", "");
            Material mat = Material.matchMaterial((String)matName);
            if (mat == null) continue;
            String name = config.getString(path + ".name", "");
            List lore = config.getStringList(path + ".lore");
            String trimMaterialName = TrimsMaterialGUI.toTrimMaterialName(mat);
            if (trimMaterialName != null) {
                loreComponents = new ArrayList<Component>();
                loreComponents.add((Component)Component.empty());
                loreComponents.add(TrimsMaterialGUI.noItalic(materialLore));
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsMaterialGUI.noItalic(name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    TrimManager.setTrim(player.getUniqueId(), armorSlot, patternName, trimMaterialName);
                    TrimsSlotGUI.open(player);
                }));
                continue;
            }
            loreComponents = new ArrayList();
            for (String line : lore) {
                loreComponents.add(TrimsMaterialGUI.noItalic(line));
            }
            if (mat == Material.ARROW) {
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsMaterialGUI.noItalic(name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    TrimsPickerGUI.open(player, armorSlot);
                }));
                continue;
            }
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsMaterialGUI.noItalic(name.isEmpty() ? " " : name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem());
        }
        gui.open((HumanEntity)player);
    }

    static Component noItalic(String text) {
        return text != null && !text.isEmpty() ? ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty();
    }
}

