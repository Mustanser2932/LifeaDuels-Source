/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.cosmetic;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import me.lifea.config.ConfigManager;
import me.lifea.cosmetic.TrimManager;
import me.lifea.cosmetic.TrimsPickerGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class TrimsSlotGUI {
    public static void open(Player player) {
        FileConfiguration config = ConfigManager.config();
        String base = "trims-gui";
        String title = config.getString(base + ".title", "Custom Trims");
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(TrimsSlotGUI.noItalic(title))).rows(6)).disableAllInteractions()).create();
        Set keys = config.getConfigurationSection(base + ".items") != null ? config.getConfigurationSection(base + ".items").getKeys(false) : Set.of();
        List autoLore = config.getStringList(base + ".trim-auto-lore");
        for (String key : keys) {
            int slot;
            String path = base + ".items." + key;
            try {
                slot = Integer.parseInt(key);
            }
            catch (NumberFormatException var211) {
                continue;
            }
            String matName = config.getString(path + ".material", "");
            Material mat = Material.matchMaterial((String)matName);
            if (mat == null) continue;
            String name = config.getString(path + ".name", "");
            List lore = config.getStringList(path + ".lore");
            String armorSlot = TrimsSlotGUI.detectArmorSlot(mat);
            if (armorSlot != null) {
                TrimManager.TrimEntry current = TrimManager.getTrim(player.getUniqueId(), armorSlot);
                ArrayList<Component> loreComponents = new ArrayList<Component>();
                for (String line : autoLore) {
                    String currentTrimName = current != null ? current.pattern() : "None";
                    loreComponents.add(TrimsSlotGUI.noItalic(line.replace("%current_trim%", currentTrimName)));
                }
                GuiItem guiItem = ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsSlotGUI.noItalic(name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    if (ex.isRightClick() && current != null) {
                        TrimManager.removeTrim(player.getUniqueId(), armorSlot);
                        TrimsSlotGUI.open(player);
                    } else {
                        TrimsPickerGUI.open(player, armorSlot);
                    }
                });
                gui.setItem(slot, guiItem);
                continue;
            }
            ArrayList<Component> loreComponents = new ArrayList<Component>();
            for (String line : lore) {
                loreComponents.add(TrimsSlotGUI.noItalic(line));
            }
            if (mat == Material.ARROW) {
                gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsSlotGUI.noItalic(name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem(ex -> {
                    SoundUtil.playClick(player);
                    player.closeInventory();
                }));
                continue;
            }
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(TrimsSlotGUI.noItalic(name.isEmpty() ? " " : name))).lore(loreComponents)).flags(ItemFlag.values())).asGuiItem());
        }
        gui.open((HumanEntity)player);
    }

    private static String detectArmorSlot(Material mat) {
        String name = mat.name();
        if (name.endsWith("_HELMET")) {
            return "helmet";
        }
        if (name.endsWith("_CHESTPLATE")) {
            return "chestplate";
        }
        if (name.endsWith("_LEGGINGS")) {
            return "leggings";
        }
        return name.endsWith("_BOOTS") ? "boots" : null;
    }

    static Component noItalic(String text) {
        return text != null && !text.isEmpty() ? ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty();
    }
}

