/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ArmorMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.trim.ArmorTrim
 *  org.bukkit.inventory.meta.trim.TrimMaterial
 *  org.bukkit.inventory.meta.trim.TrimPattern
 */
package me.lifea.cosmetic;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import me.lifea.storage.DatabaseManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;

public final class TrimManager {
    public static final String SLOT_HELMET = "helmet";
    public static final String SLOT_CHESTPLATE = "chestplate";
    public static final String SLOT_LEGGINGS = "leggings";
    public static final String SLOT_BOOTS = "boots";

    private TrimManager() {
    }

    public static void setTrim(UUID uuid, String slot, String pattern, String material) {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO player_trims(uuid, slot, pattern, material) VALUES(?,?,?,?) ON CONFLICT(uuid, slot) DO UPDATE SET pattern=excluded.pattern, material=excluded.material");){
            ps.setString(1, uuid.toString());
            ps.setString(2, slot);
            ps.setString(3, pattern);
            ps.setString(4, material);
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to save trim", e);
        }
    }

    public static void removeTrim(UUID uuid, String slot) {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM player_trims WHERE uuid=? AND slot=?");){
            ps.setString(1, uuid.toString());
            ps.setString(2, slot);
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to remove trim", e);
        }
    }

    public static Map<String, TrimEntry> getTrims(UUID uuid) {
        HashMap<String, TrimEntry> result = new HashMap<String, TrimEntry>();
        try {
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement ps = conn.prepareStatement("SELECT slot, pattern, material FROM player_trims WHERE uuid=?");){
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery();){
                    while (rs.next()) {
                        result.put(rs.getString("slot"), new TrimEntry(rs.getString("pattern"), rs.getString("material")));
                    }
                }
            }
            return result;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load trims", e);
        }
    }

    public static TrimEntry getTrim(UUID uuid, String slot) {
        try {
            TrimEntry var5;
            block21: {
                block20: {
                    try (Connection conn = DatabaseManager.connection();
                         PreparedStatement ps = conn.prepareStatement("SELECT pattern, material FROM player_trims WHERE uuid=? AND slot=?");){
                        ps.setString(1, uuid.toString());
                        ps.setString(2, slot);
                        try (ResultSet rs = ps.executeQuery();){
                            if (!rs.next()) break block20;
                            var5 = new TrimEntry(rs.getString("pattern"), rs.getString("material"));
                            break block21;
                        }
                    }
                }
                return null;
            }
            return var5;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to get trim", e);
        }
    }

    public static void applyTrims(Player player) {
        Map<String, TrimEntry> trims = TrimManager.getTrims(player.getUniqueId());
        if (!trims.isEmpty()) {
            ItemStack[] armor = player.getInventory().getArmorContents();
            TrimManager.applyTrimToSlot(player, armor, 3, trims.get(SLOT_HELMET));
            TrimManager.applyTrimToSlot(player, armor, 2, trims.get(SLOT_CHESTPLATE));
            TrimManager.applyTrimToSlot(player, armor, 1, trims.get(SLOT_LEGGINGS));
            TrimManager.applyTrimToSlot(player, armor, 0, trims.get(SLOT_BOOTS));
            player.getInventory().setArmorContents(armor);
        }
    }

    private static void applyTrimToSlot(Player player, ItemStack[] armor, int index, TrimEntry entry) {
        ItemMeta var6;
        ItemStack item;
        if (entry != null && (item = armor[index]) != null && item.getType() != Material.AIR && (var6 = item.getItemMeta()) instanceof ArmorMeta) {
            ArmorMeta meta = (ArmorMeta)var6;
            if (player.hasPermission("lifea.cosmetics." + entry.pattern().toLowerCase())) {
                TrimPattern pattern = TrimManager.resolvePattern(entry.pattern());
                TrimMaterial material = TrimManager.resolveMaterial(entry.material());
                if (pattern != null && material != null) {
                    meta.setTrim(new ArmorTrim(material, pattern));
                    item.setItemMeta((ItemMeta)meta);
                }
            }
        }
    }

    public static TrimPattern resolvePattern(String name) {
        try {
            Field field = TrimPattern.class.getField(name.toUpperCase());
            return (TrimPattern)field.get(null);
        }
        catch (Exception var2) {
            return null;
        }
    }

    public static TrimMaterial resolveMaterial(String name) {
        try {
            Field field = TrimMaterial.class.getField(name.toUpperCase());
            return (TrimMaterial)field.get(null);
        }
        catch (Exception var2) {
            return null;
        }
    }

    public record TrimEntry(String pattern, String material) {
    }
}

