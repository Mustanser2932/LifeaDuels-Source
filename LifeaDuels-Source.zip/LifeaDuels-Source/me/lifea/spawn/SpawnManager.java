/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package me.lifea.spawn;

import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class SpawnManager {
    public static void setSpawn(Location loc) {
        ConfigManager.config().set("spawn.world", (Object)loc.getWorld().getName());
        ConfigManager.config().set("spawn.x", (Object)loc.getX());
        ConfigManager.config().set("spawn.y", (Object)loc.getY());
        ConfigManager.config().set("spawn.z", (Object)loc.getZ());
        ConfigManager.config().set("spawn.yaw", (Object)Float.valueOf(loc.getYaw()));
        ConfigManager.config().set("spawn.pitch", (Object)Float.valueOf(loc.getPitch()));
        Lifea.getInstance().saveConfig();
    }

    public static Location getSpawn() {
        String worldName = ConfigManager.config().getString("spawn.world", "");
        World world = Bukkit.getWorld((String)worldName);
        if (world == null && !Bukkit.getWorlds().isEmpty()) {
            world = (World)Bukkit.getWorlds().get(0);
        }
        if (world == null) {
            Lifea.getInstance().getLogger().warning("No world available for spawn teleport!");
            return new Location((World)null, 0.0, 64.0, 0.0);
        }
        return new Location(world, ConfigManager.config().getDouble("spawn.x", 0.0), ConfigManager.config().getDouble("spawn.y", 64.0), ConfigManager.config().getDouble("spawn.z", 0.0), (float)ConfigManager.config().getDouble("spawn.yaw", 0.0), (float)ConfigManager.config().getDouble("spawn.pitch", 0.0));
    }

    public static String getMainWorld() {
        String world = ConfigManager.config().getString("spawn.world", "");
        if (!world.isEmpty()) {
            return world;
        }
        return !Bukkit.getWorlds().isEmpty() ? ((World)Bukkit.getWorlds().get(0)).getName() : "world";
    }

    public static boolean isMainWorld(Player player) {
        return player.getWorld().getName().equals(SpawnManager.getMainWorld());
    }

    public static void teleportToSpawn(Player player) {
        Location spawn = SpawnManager.getSpawn();
        if (spawn.getWorld() == null) {
            if (!Bukkit.getWorlds().isEmpty()) {
                player.teleport(((World)Bukkit.getWorlds().get(0)).getSpawnLocation());
            }
        } else {
            player.teleport(spawn);
            player.setFallDistance(0.0f);
            player.setFireTicks(0);
        }
    }
}

