/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.spawn;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.hotbar.HotbarManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class SpawnElytraManager {
    private static final Map<UUID, Integer> pendingRefillSlot = new ConcurrentHashMap<UUID, Integer>();

    public static void give(Player player) {
        ItemStack elytra = new ItemStack(Material.ELYTRA);
        elytra.editMeta(meta -> meta.setUnbreakable(true));
        player.getInventory().setChestplate(elytra);
        player.getInventory().setItemInOffHand(new ItemStack(Material.WIND_CHARGE, 64));
    }

    public static void removeWindCharge(Player player) {
        pendingRefillSlot.remove(player.getUniqueId());
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand.getType() == Material.WIND_CHARGE) {
            player.getInventory().setItemInOffHand((ItemStack)null);
        }
    }

    public static void refillWindCharge(Player player) {
        pendingRefillSlot.put(player.getUniqueId(), 1);
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (!player.isOnline()) {
                pendingRefillSlot.remove(player.getUniqueId());
            } else if (pendingRefillSlot.remove(player.getUniqueId()) != null && !HotbarManager.isHotbarSlot(player, player.getInventory().getHeldItemSlot())) {
                player.getInventory().setItemInOffHand(new ItemStack(Material.WIND_CHARGE, 64));
            }
        }, 1L);
    }

    public static void clearPendingRefill(UUID uuid) {
        pendingRefillSlot.remove(uuid);
    }

    public static boolean hasSpawnElytra(Player player) {
        ItemStack chest = player.getInventory().getChestplate();
        return chest != null && chest.getType() == Material.ELYTRA;
    }
}

