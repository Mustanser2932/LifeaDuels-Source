/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.lifea.storage.DataPool;

public final class AsyncQueue {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final ExecutorService executor = new ThreadPoolExecutor(4, 4, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(8192), r -> {
        Thread t = new Thread(r, "Lifea-AsyncQueue");
        t.setDaemon(true);
        return t;
    }, (r, executor) -> {
        LOG.warning("[AsyncQueue] Task queue is full (8192) - executing in caller thread. DB writes may be congested.");
        if (!executor.isShutdown()) {
            try {
                r.run();
            }
            catch (Exception e) {
                LOG.log(Level.WARNING, "[AsyncQueue] Rejected task failed", e);
            }
        }
    });
    private static final int CORE_POOL_SIZE = 4;
    private static final int MAX_QUEUED_TASKS = 8192;

    private AsyncQueue() {
    }

    public static void init() {
    }

    public static void shutdown() {
        try {
            executor.shutdown();
            if (!executor.awaitTermination(10L, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        }
        catch (InterruptedException var1) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    public static void execute(Runnable task) {
        executor.execute(() -> {
            try {
                task.run();
            }
            catch (Exception e) {
                LOG.log(Level.WARNING, "[AsyncQueue] Task failed", e);
            }
        });
    }

    public static <T> void execute(Callable<T> task, Consumer<T> callback) {
        executor.execute(() -> {
            try {
                Object result = task.call();
                if (callback != null) {
                    callback.accept(result);
                }
            }
            catch (Exception e) {
                LOG.log(Level.WARNING, "[AsyncQueue] Task failed", e);
            }
        });
    }

    public static void executeBulk(Runnable task) {
        AsyncQueue.execute(() -> {
            try (Connection conn = DataPool.getConnection();){
                conn.setAutoCommit(false);
                try {
                    task.run();
                    conn.commit();
                }
                catch (Exception e) {
                    try {
                        conn.rollback();
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    throw e;
                }
                finally {
                    try {
                        conn.setAutoCommit(true);
                    }
                    catch (SQLException sQLException) {}
                }
            }
            catch (SQLException e) {
                throw new RuntimeException("Database bulk write failed", e);
            }
        });
    }

    public static void executeUpdate(String sql, Object ... params) {
        AsyncQueue.execute(() -> {
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);){
                for (int i = 0; i < params.length; ++i) {
                    ps.setObject(i + 1, params[i]);
                }
                ps.executeUpdate();
            }
            catch (SQLException e) {
                LOG.log(Level.WARNING, "[AsyncQueue] Update failed: " + sql, e);
            }
        });
    }

    public static void executeReplace(String table, Map<String, Object> values) {
        if (!values.isEmpty()) {
            StringBuilder sql = new StringBuilder("INSERT OR REPLACE INTO ").append(table).append(" (");
            StringBuilder placeholders = new StringBuilder("VALUES (");
            int i = 0;
            for (String key : values.keySet()) {
                if (i > 0) {
                    sql.append(", ");
                    placeholders.append(", ");
                }
                sql.append(key);
                placeholders.append("?");
                ++i;
            }
            sql.append(") ").append((CharSequence)placeholders).append(")");
            String finalSql = sql.toString();
            Object[] finalValues = values.values().toArray();
            AsyncQueue.execute(() -> {
                try (Connection conn = DataPool.getConnection();
                     PreparedStatement ps = conn.prepareStatement(finalSql);){
                    for (int idx = 0; idx < finalValues.length; ++idx) {
                        ps.setObject(idx + 1, finalValues[idx]);
                    }
                    ps.executeUpdate();
                }
                catch (SQLException e) {
                    LOG.log(Level.WARNING, "[AsyncQueue] Replace failed: " + finalSql, e);
                }
            });
        }
    }
}

