/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.util.io.BukkitObjectInputStream
 *  org.bukkit.util.io.BukkitObjectOutputStream
 */
package me.lifea.storage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

public final class ItemStackSerializer {
    private ItemStackSerializer() {
    }

    public static byte[] serialize(ItemStack[] items) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try (BukkitObjectOutputStream out = new BukkitObjectOutputStream((OutputStream)bos);){
                out.writeInt(items.length);
                for (ItemStack item : items) {
                    out.writeObject((Object)item);
                }
            }
            return bos.toByteArray();
        }
        catch (IOException e) {
            throw new RuntimeException("Failed to serialize ItemStack[]", e);
        }
    }

    public static ItemStack[] deserialize(byte[] bytes) {
        try {
            ItemStack[] var10;
            ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
            try (BukkitObjectInputStream in = new BukkitObjectInputStream((InputStream)bis);){
                int len = in.readInt();
                ItemStack[] items = new ItemStack[len];
                for (int i = 0; i < len; ++i) {
                    Object obj = in.readObject();
                    items[i] = obj instanceof ItemStack ? (ItemStack)obj : null;
                }
                var10 = items;
            }
            return var10;
        }
        catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException("Failed to deserialize ItemStack[]", e);
        }
    }
}

