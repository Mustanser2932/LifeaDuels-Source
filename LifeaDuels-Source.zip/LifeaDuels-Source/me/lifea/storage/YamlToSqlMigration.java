/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package me.lifea.storage;

import java.io.File;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class YamlToSqlMigration {
    public static void migrateArenas() {
        File arenasFile = new File(Lifea.getInstance().getDataFolder(), "arenas.yml");
        if (arenasFile.exists()) {
            YamlConfiguration data = YamlConfiguration.loadConfiguration((File)arenasFile);
            int count = 0;
            for (String name : data.getKeys(false)) {
                Arena arena = new Arena(name);
                arena.setEnabled(data.getBoolean(name + ".enabled", false));
                if (data.contains(name + ".spawn1")) {
                    arena.setSpawn1(YamlToSqlMigration.loadLocation((FileConfiguration)data, name + ".spawn1"));
                }
                if (data.contains(name + ".spawn2")) {
                    arena.setSpawn2(YamlToSqlMigration.loadLocation((FileConfiguration)data, name + ".spawn2"));
                }
                arena.setRegion(data.getInt(name + ".region.minX"), 0, data.getInt(name + ".region.minZ"), data.getInt(name + ".region.maxX"), 0, data.getInt(name + ".region.maxZ"));
                ArenaManager.saveArena(arena);
                ++count;
            }
            File backup = new File(Lifea.getInstance().getDataFolder(), "arenas.yml.backup");
            arenasFile.renameTo(backup);
        }
    }

    private static Location loadLocation(FileConfiguration data, String path) {
        return new Location(Bukkit.getWorld((String)data.getString(path + ".world", "world")), data.getDouble(path + ".x"), data.getDouble(path + ".y"), data.getDouble(path + ".z"), (float)data.getDouble(path + ".yaw"), (float)data.getDouble(path + ".pitch"));
    }
}

