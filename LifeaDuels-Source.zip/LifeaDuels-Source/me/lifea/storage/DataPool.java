/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.storage;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.libs.hikari.HikariConfig;
import me.lifea.libs.hikari.HikariDataSource;

public final class DataPool {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static HikariDataSource dataSource;
    private static final int MAX_POOL_SIZE = 4;

    private DataPool() {
    }

    public static void init() {
        if (dataSource == null) {
            File dbDir = new File(Lifea.getInstance().getDataFolder(), "DATABASE");
            dbDir.mkdirs();
            File dbFile = new File(dbDir, "lifea.db");
            String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(url);
            config.setMaximumPoolSize(4);
            config.setMinimumIdle(1);
            config.setConnectionTimeout(5000L);
            config.setIdleTimeout(300000L);
            config.setMaxLifetime(600000L);
            config.setPoolName("Lifea-SQLite");
            config.setConnectionTestQuery("SELECT 1");
            try {
                dataSource = new HikariDataSource(config);
            }
            catch (Exception e) {
                LOG.severe("[DataPool] Failed to initialize pool, attempting database recovery: " + e.getMessage());
                DataPool.recoverCorruptDatabase(dbFile);
                dataSource = new HikariDataSource(config);
            }
            try (Connection conn = dataSource.getConnection();
                 Statement st = conn.createStatement();){
                st.execute("PRAGMA journal_mode = WAL");
                st.execute("PRAGMA synchronous = NORMAL");
                st.execute("PRAGMA cache_size = -64000");
                st.execute("PRAGMA temp_store = MEMORY");
                st.execute("PRAGMA mmap_size = 268435456");
            }
            catch (SQLException e) {
                throw new RuntimeException("Failed to configure SQLite PRAGMAs", e);
            }
        }
    }

    private static void recoverCorruptDatabase(File dbFile) {
        if (!dbFile.exists()) {
            LOG.warning("[DataPool] Database file does not exist, creating fresh database");
        } else {
            String timestamp = String.valueOf(System.currentTimeMillis());
            File backupFile = new File(dbFile.getParentFile(), "lifea.db.corrupt-" + timestamp);
            try {
                Files.copy(dbFile.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                LOG.info("[DataPool] Backed up corrupt database to: " + backupFile.getName());
            }
            catch (Exception e) {
                LOG.severe("[DataPool] Failed to back up corrupt database: " + e.getMessage());
            }
            File recoveredFile = new File(dbFile.getParentFile(), "lifea.db.recovered-" + timestamp);
            boolean recovered = DataPool.attemptJdbcRecovery(dbFile, recoveredFile);
            if (recovered && recoveredFile.exists() && recoveredFile.length() > 0L) {
                try {
                    Files.move(recoveredFile.toPath(), dbFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    LOG.info("[DataPool] Successfully recovered database data");
                }
                catch (Exception e) {
                    LOG.severe("[DataPool] Failed to replace corrupt database with recovered one: " + e.getMessage());
                }
            } else {
                LOG.warning("[DataPool] Could not recover data, creating fresh database (arenas/kits will need re-import)");
                if (!dbFile.delete()) {
                    LOG.severe("[DataPool] Could not delete corrupt database file: " + dbFile.getAbsolutePath());
                }
            }
            new File(dbFile.getParentFile(), "lifea.db-wal").delete();
            new File(dbFile.getParentFile(), "lifea.db-shm").delete();
        }
    }

    private static boolean attemptJdbcRecovery(File corruptFile, File recoveredFile) {
        return DataPool.attemptSqlite3Recovery(corruptFile, recoveredFile) ? true : DataPool.attemptJdbcDumpAndReplay(corruptFile, recoveredFile);
    }

    private static boolean attemptSqlite3Recovery(File corruptFile, File recoveredFile) {
        try {
            Process checkProc = new ProcessBuilder("sqlite3", "--version").redirectErrorStream(true).start();
            int checkExit = checkProc.waitFor();
            if (checkExit != 0) {
                return false;
            }
            String corruptPath = corruptFile.getAbsolutePath();
            String recoveredPath = recoveredFile.getAbsolutePath();
            if (!(corruptPath.contains("'") || corruptPath.contains("\"") || corruptPath.contains("\n") || recoveredPath.contains("'") || recoveredPath.contains("\"") || recoveredPath.contains("\n"))) {
                File sqlDumpFile = new File(corruptFile.getParentFile(), "recovery-" + System.currentTimeMillis() + ".sql");
                ProcessBuilder recoverPb = new ProcessBuilder("sqlite3", corruptPath, ".recover");
                recoverPb.redirectOutput(sqlDumpFile);
                recoverPb.redirectErrorStream(true);
                Process recoverProc = recoverPb.start();
                int recoverExit = recoverProc.waitFor();
                if (recoverExit == 0 && sqlDumpFile.exists() && sqlDumpFile.length() != 0L) {
                    LOG.info("[DataPool] sqlite3 .recover produced " + sqlDumpFile.length() + " bytes of SQL");
                    ProcessBuilder importPb = new ProcessBuilder("sqlite3", recoveredPath);
                    importPb.redirectInput(sqlDumpFile);
                    importPb.redirectErrorStream(true);
                    Process importProc = importPb.start();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(importProc.getInputStream()));){
                        while (reader.readLine() != null) {
                        }
                    }
                    int importExit = importProc.waitFor();
                    sqlDumpFile.delete();
                    if (importExit == 0 && recoveredFile.exists() && recoveredFile.length() > 0L) {
                        LOG.info("[DataPool] Successfully recovered database using sqlite3 .recover");
                        return true;
                    }
                    LOG.warning("[DataPool] sqlite3 import failed");
                    return false;
                }
                LOG.warning("[DataPool] sqlite3 .recover failed or produced no output");
                sqlDumpFile.delete();
                return false;
            }
            LOG.warning("[DataPool] Database path contains unsafe characters, skipping sqlite3 recovery");
            return false;
        }
        catch (Exception e) {
            LOG.warning("[DataPool] sqlite3 recovery not available: " + e.getMessage());
            return false;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static boolean attemptJdbcDumpAndReplay(File corruptFile, File recoveredFile) {
        Connection corruptConn = null;
        Connection freshConn = null;
        try {
            String corruptUrl = "jdbc:sqlite:" + corruptFile.getAbsolutePath();
            corruptConn = DriverManager.getConnection(corruptUrl);
            Statement st = corruptConn.createStatement();
            try {
                st.execute("PRAGMA journal_mode = DELETE");
                st.execute("PRAGMA cache_size = -2000");
            }
            catch (SQLException sQLException) {
                // empty catch block
            }
            ResultSet tables = st.executeQuery("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
            ArrayList<String> tableNames = new ArrayList<String>();
            HashMap<String, String> tableSchemas = new HashMap<String, String>();
            while (tables.next()) {
                String name = tables.getString("name");
                String sql = tables.getString("sql");
                if (name == null || sql == null) continue;
                tableNames.add(name);
                tableSchemas.put(name, sql);
            }
            tables.close();
            st.close();
            if (!tableNames.isEmpty()) {
                boolean bl;
                Logger var10000 = LOG;
                int var10001 = tableNames.size();
                var10000.info("[DataPool] Found " + var10001 + " tables to recover: " + String.join((CharSequence)", ", tableNames));
                String freshUrl = "jdbc:sqlite:" + recoveredFile.getAbsolutePath();
                freshConn = DriverManager.getConnection(freshUrl);
                Statement freshSt = freshConn.createStatement();
                for (String string : tableNames) {
                    String createSql = (String)tableSchemas.get(string);
                    try {
                        freshSt.execute(createSql);
                        LOG.info("[DataPool] Recreated table: " + string);
                    }
                    catch (SQLException e) {
                        LOG.warning("[DataPool] Failed to create table " + string + ": " + e.getMessage());
                    }
                }
                int totalRowsRecovered = 0;
                for (String tableName : tableNames) {
                    int rows = DataPool.copyTableData(corruptConn, freshConn, tableName);
                    if (rows <= 0) continue;
                    LOG.info("[DataPool] Recovered " + rows + " rows from table: " + tableName);
                    totalRowsRecovered += rows;
                }
                try {
                    Statement statement = corruptConn.createStatement();
                    ResultSet indexes = statement.executeQuery("SELECT sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL");
                    while (indexes.next()) {
                        String idxSql = indexes.getString("sql");
                        if (idxSql == null) continue;
                        try {
                            freshSt.execute(idxSql);
                        }
                        catch (SQLException sQLException) {}
                    }
                    indexes.close();
                    statement.close();
                }
                catch (SQLException sQLException) {
                    // empty catch block
                }
                freshSt.close();
                freshConn.close();
                corruptConn.close();
                if (totalRowsRecovered > 0) {
                    boolean bl2;
                    LOG.info("[DataPool] Total rows recovered: " + totalRowsRecovered);
                    boolean bl3 = bl2 = true;
                    return bl3;
                }
                LOG.warning("[DataPool] No rows could be recovered from corrupt database");
                boolean bl4 = bl = false;
                return bl4;
            }
            LOG.warning("[DataPool] No tables found in corrupt database");
            boolean bl = false;
            return bl;
        }
        catch (Exception e) {
            boolean st;
            LOG.severe("[DataPool] JDBC recovery failed: " + e.getMessage());
            boolean bl = st = false;
            return bl;
        }
        finally {
            try {
                if (freshConn != null) {
                    freshConn.close();
                }
            }
            catch (Exception exception) {}
            try {
                if (corruptConn != null) {
                    corruptConn.close();
                }
            }
            catch (Exception exception) {}
        }
    }

    private static int copyTableData(Connection srcConn, Connection dstConn, String tableName) {
        int rowCount = 0;
        try {
            Statement srcSt = srcConn.createStatement();
            ResultSet rs = srcSt.executeQuery("SELECT * FROM \"" + tableName + "\"");
            ResultSetMetaData meta = rs.getMetaData();
            int columnCount = meta.getColumnCount();
            StringBuilder sb = new StringBuilder();
            sb.append("INSERT OR IGNORE INTO \"").append(tableName).append("\" VALUES (");
            for (int i = 0; i < columnCount; ++i) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append("?");
            }
            sb.append(")");
            String insertSql = sb.toString();
            PreparedStatement ps = dstConn.prepareStatement(insertSql);
            dstConn.setAutoCommit(false);
            int batchCount = 0;
            while (rs.next()) {
                for (int i = 1; i <= columnCount; ++i) {
                    Object value = rs.getObject(i);
                    if (value == null) {
                        ps.setNull(i, meta.getColumnType(i));
                        continue;
                    }
                    if (value instanceof byte[]) {
                        ps.setBytes(i, (byte[])value);
                        continue;
                    }
                    ps.setObject(i, value);
                }
                ps.addBatch();
                ++rowCount;
                if (++batchCount < 100) continue;
                ps.executeBatch();
                dstConn.commit();
                batchCount = 0;
            }
            if (batchCount > 0) {
                ps.executeBatch();
                dstConn.commit();
            }
            dstConn.setAutoCommit(true);
            ps.close();
            rs.close();
            srcSt.close();
        }
        catch (SQLException e) {
            LOG.warning("[DataPool] Error copying table " + tableName + ": " + e.getMessage());
            try {
                dstConn.commit();
            }
            catch (SQLException sQLException) {
                // empty catch block
            }
            try {
                dstConn.setAutoCommit(true);
            }
            catch (SQLException sQLException) {
                // empty catch block
            }
        }
        return rowCount;
    }

    public static Connection getConnection() throws SQLException {
        if (dataSource == null) {
            throw new IllegalStateException("DataPool not initialized");
        }
        return dataSource.getConnection();
    }

    public static void close() {
        if (dataSource != null) {
            dataSource.close();
            dataSource = null;
        }
    }
}

