/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;
import me.lifea.storage.DataPool;

public final class DatabaseManager {
    private static volatile boolean initialized;

    private DatabaseManager() {
    }

    public static void init() {
        if (!initialized) {
            DataPool.init();
            try (Connection connection = DataPool.getConnection();){
                try (Statement st = connection.createStatement();){
                    String[] regenHoldColumns;
                    String[] centerColumns;
                    String[] bedFacingColumns;
                    String[] bedColumns;
                    st.execute("PRAGMA journal_mode = WAL");
                    st.execute("PRAGMA synchronous = NORMAL");
                    st.execute("PRAGMA cache_size = -64000");
                    st.execute("PRAGMA temp_store = MEMORY");
                    st.execute("PRAGMA mmap_size = 268435456");
                    st.execute("CREATE TABLE IF NOT EXISTS stats (\n    uuid TEXT PRIMARY KEY,\n    wins INTEGER NOT NULL DEFAULT 0,\n    losses INTEGER NOT NULL DEFAULT 0,\n    winstreak INTEGER NOT NULL DEFAULT 0,\n    beststreak INTEGER NOT NULL DEFAULT 0,\n    matches INTEGER NOT NULL DEFAULT 0\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS kits (\n    uuid TEXT NOT NULL,\n    tier TEXT NOT NULL,\n    gamemode TEXT NOT NULL,\n    is_base INTEGER NOT NULL,\n    content BLOB NOT NULL,\n    PRIMARY KEY(uuid, tier, gamemode, is_base)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS ffa_kits (\n    name  TEXT PRIMARY KEY,\n    items BLOB\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS kit_rules (\n    kit_name TEXT NOT NULL,\n    rule_key TEXT NOT NULL,\n    enabled INTEGER NOT NULL DEFAULT 0,\n    PRIMARY KEY(kit_name, rule_key)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS arenas (\n    name TEXT PRIMARY KEY,\n    world TEXT NOT NULL,\n    spawn1_x REAL NOT NULL,\n    spawn1_y REAL NOT NULL,\n    spawn1_z REAL NOT NULL,\n    spawn1_yaw REAL NOT NULL,\n    spawn1_pitch REAL NOT NULL,\n    spawn2_x REAL NOT NULL,\n    spawn2_y REAL NOT NULL,\n    spawn2_z REAL NOT NULL,\n    spawn2_yaw REAL NOT NULL,\n    spawn2_pitch REAL NOT NULL,\n    region_min_x INTEGER NOT NULL DEFAULT 0,\n    region_min_y INTEGER NOT NULL DEFAULT 0,\n    region_min_z INTEGER NOT NULL DEFAULT 0,\n    region_max_x INTEGER NOT NULL DEFAULT 0,\n    region_max_y INTEGER NOT NULL DEFAULT 0,\n    region_max_z INTEGER NOT NULL DEFAULT 0,\n    blue_bed_x INTEGER,\n    blue_bed_y INTEGER,\n    blue_bed_z INTEGER,\n    red_bed_x INTEGER,\n    red_bed_y INTEGER,\n    red_bed_z INTEGER,\n    blue_bed_facing TEXT,\n    red_bed_facing TEXT,\n    center_x REAL,\n    center_y REAL,\n    center_z REAL,\n    enabled INTEGER NOT NULL DEFAULT 0,\n    regeneration INTEGER NOT NULL DEFAULT 1,\n    allowed_kits TEXT NOT NULL DEFAULT ''\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS player_settings (\n    uuid TEXT PRIMARY KEY,\n    duel_requests INTEGER NOT NULL DEFAULT 1,\n    scoreboard INTEGER NOT NULL DEFAULT 1,\n    auto_gg INTEGER NOT NULL DEFAULT 0,\n    private_messages INTEGER NOT NULL DEFAULT 1,\n    chat_mentions INTEGER NOT NULL DEFAULT 1,\n    party_invites INTEGER NOT NULL DEFAULT 1,\n    health_indicator INTEGER NOT NULL DEFAULT 1,\n    elytra INTEGER NOT NULL DEFAULT 1,\n    chat_isolation INTEGER NOT NULL DEFAULT 0,\n    time_of_day TEXT NOT NULL DEFAULT 'DEFAULT',\n    ping_display INTEGER NOT NULL DEFAULT 0,\n    ping_range TEXT NOT NULL DEFAULT 'ALL'\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS quick_queue_disabled (\n    uuid TEXT NOT NULL,\n    tier TEXT NOT NULL,\n    gamemode TEXT NOT NULL,\n    PRIMARY KEY(uuid, tier, gamemode)\n)\n");
                    st.execute("INSERT OR IGNORE INTO quick_queue_disabled (uuid, tier, gamemode) SELECT uuid, 'Extra', gamemode FROM quick_queue_disabled WHERE tier='MCTiers' AND gamemode='BedPvP'");
                    st.execute("DELETE FROM quick_queue_disabled WHERE tier='MCTiers' AND gamemode='BedPvP'");
                    st.execute("CREATE TABLE IF NOT EXISTS gamemode_potions (\n    gamemode_key TEXT NOT NULL,\n    effect TEXT NOT NULL,\n    amplifier INTEGER NOT NULL,\n    duration INTEGER NOT NULL DEFAULT -1,\n    PRIMARY KEY(gamemode_key, effect)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS queue_signs (\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n    queue_key TEXT NOT NULL,\n    PRIMARY KEY(world, x, y, z)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS arena_snapshots (\n    arena_name TEXT PRIMARY KEY,\n    world TEXT NOT NULL,\n    min_x INTEGER NOT NULL,\n    min_y INTEGER NOT NULL,\n    min_z INTEGER NOT NULL,\n    max_x INTEGER NOT NULL,\n    max_y INTEGER NOT NULL,\n    max_z INTEGER NOT NULL,\n    data BLOB NOT NULL\n)\n");
                    try {
                        st.execute("ALTER TABLE arenas ADD COLUMN allowed_kits TEXT NOT NULL DEFAULT ''");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE arenas ADD COLUMN regeneration INTEGER NOT NULL DEFAULT 1");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE arenas ADD COLUMN region_min_y INTEGER NOT NULL DEFAULT 0");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE arenas ADD COLUMN region_max_y INTEGER NOT NULL DEFAULT 0");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE arenas ADD COLUMN build_limit_y INTEGER");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    for (String column : bedColumns = new String[]{"blue_bed_x", "blue_bed_y", "blue_bed_z", "red_bed_x", "red_bed_y", "red_bed_z"}) {
                        try {
                            st.execute("ALTER TABLE arenas ADD COLUMN " + column + " INTEGER");
                        }
                        catch (SQLException sQLException) {
                            // empty catch block
                        }
                    }
                    for (String column : bedFacingColumns = new String[]{"blue_bed_facing", "red_bed_facing"}) {
                        try {
                            st.execute("ALTER TABLE arenas ADD COLUMN " + column + " TEXT");
                        }
                        catch (SQLException sQLException) {
                            // empty catch block
                        }
                    }
                    for (String column : centerColumns = new String[]{"center_x", "center_y", "center_z"}) {
                        try {
                            st.execute("ALTER TABLE arenas ADD COLUMN " + column + " REAL");
                        }
                        catch (SQLException sQLException) {
                            // empty catch block
                        }
                    }
                    for (String column : regenHoldColumns = new String[]{"regen_hold1_x", "regen_hold1_y", "regen_hold1_z", "regen_hold2_x", "regen_hold2_y", "regen_hold2_z"}) {
                        try {
                            st.execute("ALTER TABLE arenas ADD COLUMN " + column + " REAL");
                        }
                        catch (SQLException sQLException) {
                            // empty catch block
                        }
                    }
                    try {
                        st.execute("ALTER TABLE stats ADD COLUMN kills INTEGER NOT NULL DEFAULT 0");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE stats ADD COLUMN deaths INTEGER NOT NULL DEFAULT 0");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE gamemode_potions ADD COLUMN duration INTEGER NOT NULL DEFAULT -1");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE player_settings ADD COLUMN health_indicator INTEGER NOT NULL DEFAULT 1");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE player_settings ADD COLUMN elytra INTEGER NOT NULL DEFAULT 1");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE player_settings ADD COLUMN chat_isolation INTEGER NOT NULL DEFAULT 0");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE player_settings ADD COLUMN time_of_day TEXT NOT NULL DEFAULT 'DEFAULT'");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE player_settings ADD COLUMN ping_display INTEGER NOT NULL DEFAULT 0");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    try {
                        st.execute("ALTER TABLE player_settings ADD COLUMN ping_range TEXT NOT NULL DEFAULT 'ALL'");
                    }
                    catch (SQLException sQLException) {
                        // empty catch block
                    }
                    st.execute("CREATE TABLE IF NOT EXISTS kit_primary (\n    uuid TEXT NOT NULL,\n    tier TEXT NOT NULL,\n    gamemode TEXT NOT NULL,\n    kit_slot INTEGER NOT NULL DEFAULT 1,\n    PRIMARY KEY(uuid, tier, gamemode)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS kit_block_whitelist (\n    kit_name TEXT NOT NULL,\n    material TEXT NOT NULL,\n    PRIMARY KEY(kit_name, material)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS custom_kits (\n    uuid TEXT NOT NULL,\n    slot INTEGER NOT NULL,\n    content BLOB NOT NULL,\n    potion_data TEXT DEFAULT '',\n    settings TEXT DEFAULT '',\n    armor_helmet TEXT DEFAULT '',\n    armor_chestplate TEXT DEFAULT '',\n    armor_leggings TEXT DEFAULT '',\n    armor_boots TEXT DEFAULT '',\n    PRIMARY KEY(uuid, slot)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS custom_kit_block_whitelist (\n    material TEXT NOT NULL PRIMARY KEY\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS arena_custom_kit_blocks (\n    arena_name TEXT NOT NULL,\n    material TEXT NOT NULL,\n    PRIMARY KEY(arena_name, material)\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS shared_kits (\n    code TEXT PRIMARY KEY,\n    content BLOB NOT NULL,\n    settings TEXT NOT NULL DEFAULT '{}',\n    potions TEXT NOT NULL DEFAULT '{}',\n    created_at INTEGER NOT NULL\n)\n");
                    st.execute("CREATE TABLE IF NOT EXISTS player_trims (\n    uuid TEXT NOT NULL,\n    slot TEXT NOT NULL,\n    pattern TEXT NOT NULL,\n    material TEXT NOT NULL,\n    PRIMARY KEY(uuid, slot)\n)\n");
                }
                initialized = true;
            }
            catch (SQLException e) {
                throw new RuntimeException("Failed to initialize SQLite database", e);
            }
        }
    }

    public static Connection connection() {
        try {
            return DataPool.getConnection();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to obtain database connection", e);
        }
    }

    public static void close() {
        initialized = false;
        DataPool.close();
    }

    public static boolean getKitRule(String kitName, String ruleKey) {
        try {
            boolean var5;
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement st = conn.prepareStatement("SELECT enabled FROM kit_rules WHERE kit_name=? AND rule_key=?");){
                st.setString(1, kitName);
                st.setString(2, ruleKey);
                try (ResultSet rs = st.executeQuery();){
                    var5 = rs.next() && rs.getInt(1) == 1;
                }
            }
            return var5;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to get kit rule", e);
        }
    }

    public static void setKitRule(String kitName, String ruleKey, boolean enabled) {
        try (Connection conn = DataPool.getConnection();
             PreparedStatement st = conn.prepareStatement("INSERT OR REPLACE INTO kit_rules (kit_name, rule_key, enabled) VALUES (?, ?, ?)");){
            st.setString(1, kitName);
            st.setString(2, ruleKey);
            st.setInt(3, enabled ? 1 : 0);
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to set kit rule", e);
        }
    }

    public static Set<String> getKitBlockWhitelist(String kitName) {
        HashSet<String> materials = new HashSet<String>();
        try {
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement st = conn.prepareStatement("SELECT material FROM kit_block_whitelist WHERE kit_name=?");){
                st.setString(1, kitName);
                try (ResultSet rs = st.executeQuery();){
                    while (rs.next()) {
                        materials.add(rs.getString("material"));
                    }
                }
            }
            return materials;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to get kit block whitelist", e);
        }
    }

    public static void addKitBlockWhitelist(String kitName, String material) {
        try (Connection conn = DataPool.getConnection();
             PreparedStatement st = conn.prepareStatement("INSERT OR IGNORE INTO kit_block_whitelist (kit_name, material) VALUES (?, ?)");){
            st.setString(1, kitName);
            st.setString(2, material);
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to add kit block whitelist", e);
        }
    }

    public static void removeKitBlockWhitelist(String kitName, String material) {
        try (Connection conn = DataPool.getConnection();
             PreparedStatement st = conn.prepareStatement("DELETE FROM kit_block_whitelist WHERE kit_name=? AND material=?");){
            st.setString(1, kitName);
            st.setString(2, material);
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to remove kit block whitelist", e);
        }
    }

    public static boolean isInKitBlockWhitelist(String kitName, String material) {
        try {
            boolean var5;
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement st = conn.prepareStatement("SELECT 1 FROM kit_block_whitelist WHERE kit_name=? AND material=?");){
                st.setString(1, kitName);
                st.setString(2, material);
                try (ResultSet rs = st.executeQuery();){
                    var5 = rs.next();
                }
            }
            return var5;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to check kit block whitelist", e);
        }
    }

    public static Set<String> getArenaCustomKitBlocks(String arenaName) {
        HashSet<String> materials = new HashSet<String>();
        try {
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement st = conn.prepareStatement("SELECT material FROM arena_custom_kit_blocks WHERE arena_name=?");){
                st.setString(1, arenaName);
                try (ResultSet rs = st.executeQuery();){
                    while (rs.next()) {
                        materials.add(rs.getString("material"));
                    }
                }
            }
            return materials;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to get arena custom kit blocks", e);
        }
    }

    public static void addArenaCustomKitBlock(String arenaName, String material) {
        try (Connection conn = DataPool.getConnection();
             PreparedStatement st = conn.prepareStatement("INSERT OR IGNORE INTO arena_custom_kit_blocks (arena_name, material) VALUES (?, ?)");){
            st.setString(1, arenaName);
            st.setString(2, material);
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to add arena custom kit block", e);
        }
    }

    public static void removeArenaCustomKitBlock(String arenaName, String material) {
        try (Connection conn = DataPool.getConnection();
             PreparedStatement st = conn.prepareStatement("DELETE FROM arena_custom_kit_blocks WHERE arena_name=? AND material=?");){
            st.setString(1, arenaName);
            st.setString(2, material);
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to remove arena custom kit block", e);
        }
    }

    public static boolean isInArenaCustomKitBlocks(String arenaName, String material) {
        try {
            boolean var5;
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement st = conn.prepareStatement("SELECT 1 FROM arena_custom_kit_blocks WHERE arena_name=? AND material=?");){
                st.setString(1, arenaName);
                st.setString(2, material);
                try (ResultSet rs = st.executeQuery();){
                    var5 = rs.next();
                }
            }
            return var5;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to check arena custom kit block", e);
        }
    }
}

