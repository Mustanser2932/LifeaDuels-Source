/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.party.JuggernautOthersGUI;
import me.lifea.gui.party.JuggernautRoundGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.MaterialSpriteUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class JuggernautOthersSectionGUI {
    private final List<UUID> juggernauts;
    private final String jugTier;
    private final String jugGamemode;
    private final String section;

    public JuggernautOthersSectionGUI(List<UUID> juggernauts, String jugTier, String jugGamemode, String section) {
        this.juggernauts = juggernauts;
        this.jugTier = jugTier;
        this.jugGamemode = jugGamemode;
        this.section = section;
    }

    public void open(Player leader) {
        ConfigurationSection sec = ConfigManager.duelGui().getConfigurationSection(this.section);
        if (sec == null) {
            new JuggernautOthersGUI(this.juggernauts, this.jugTier, this.jugGamemode).open(leader);
        } else {
            int rows = JuggernautOthersSectionGUI.parseRows(sec.getString("size", "chest-4"));
            String kitFormat = sec.getString("kit-format", "");
            String title = sec.getString("title", this.section);
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
            ConfigurationSection items = sec.getConfigurationSection("items");
            if (items != null) {
                for (String key : items.getKeys(false)) {
                    int slot;
                    try {
                        slot = Integer.parseInt(key.trim());
                    }
                    catch (NumberFormatException numberFormatException) {
                        continue;
                    }
                    ConfigurationSection it = items.getConfigurationSection(key);
                    if (it != null && !it.getBoolean("party", true) || it == null) continue;
                    Material mat = Material.matchMaterial((String)it.getString("material", "STONE"));
                    if (mat == null) {
                        mat = Material.STONE;
                    }
                    String name = it.getString("name", "");
                    String kit = it.getString("kit");
                    String opens = it.getString("opens");
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, it).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                    List<Component> lore = LoreUtil.read(it, "lore");
                    if (!lore.isEmpty()) {
                        builder.lore(lore);
                    }
                    if (kit != null && !kit.isBlank()) {
                        builder.name(ColorUtil.parse(MaterialSpriteUtil.prefix(leader, mat, name)));
                        String[] tg = DuelMenuGUI.resolveKit(kit, kitFormat);
                        String tier = tg[0];
                        String gamemode = tg[1];
                        gui.setItem(slot, builder.asGuiItem(ex -> {
                            SoundUtil.playClick(leader);
                            List<UUID> others = this.getOthers(leader);
                            if (others.isEmpty()) {
                                leader.sendMessage(ColorUtil.parse("&cThere must be at least 1 player on the other side."));
                            } else {
                                PartyMatchContext.setJuggernaut(leader.getUniqueId(), this.juggernauts, others);
                                PartyMatchContext.setJuggernautOthersKit(leader.getUniqueId(), tier, gamemode);
                                new JuggernautRoundGUI(this.juggernauts, this.jugTier, this.jugGamemode, tier, gamemode).open(leader);
                            }
                        }));
                        continue;
                    }
                    if (!"back".equalsIgnoreCase(opens) && !"close".equalsIgnoreCase(opens)) {
                        gui.setItem(slot, builder.asGuiItem());
                        continue;
                    }
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(leader);
                        new JuggernautOthersGUI(this.juggernauts, this.jugTier, this.jugGamemode).open(leader);
                    }));
                }
            }
            gui.open((HumanEntity)leader);
        }
    }

    private List<UUID> getOthers(Player leader) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            return List.of();
        }
        ArrayList<UUID> others = new ArrayList<UUID>();
        for (UUID uuid : party.getMembers()) {
            if (this.juggernauts.contains(uuid)) continue;
            others.add(uuid);
        }
        return others;
    }

    private static int parseRows(String size) {
        if (size != null && size.startsWith("chest-")) {
            try {
                return Integer.parseInt(size.substring("chest-".length()).trim());
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return 4;
    }
}

