/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.GUIManager;
import me.lifea.gui.party.JuggernautOthersGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class JuggernautRoundGUI {
    private final List<UUID> juggernauts;
    private final String jugTier;
    private final String jugGamemode;
    private final String othersTier;
    private final String othersGamemode;
    private final int rounds;

    public JuggernautRoundGUI(List<UUID> juggernauts, String jugTier, String jugGamemode, String othersTier, String othersGamemode) {
        this(juggernauts, jugTier, jugGamemode, othersTier, othersGamemode, 1);
    }

    public JuggernautRoundGUI(List<UUID> juggernauts, String jugTier, String jugGamemode, String othersTier, String othersGamemode, int rounds) {
        this.juggernauts = juggernauts;
        this.jugTier = jugTier;
        this.jugGamemode = jugGamemode;
        this.othersTier = othersTier;
        this.othersGamemode = othersGamemode;
        this.rounds = rounds;
    }

    public void open(Player leader) {
        ConfigurationSection cfg = ConfigManager.config().getConfigurationSection("round-gui");
        if (cfg == null) {
            cfg = ConfigManager.config().getConfigurationSection("gui.round-gui");
        }
        String title = ConfigManager.partyGuiTitle("round", new String[0]);
        int size = cfg != null ? cfg.getInt("size", 27) : 27;
        int rows = size / 9;
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        if (cfg == null) {
            gui.open((HumanEntity)leader);
        } else {
            ConfigurationSection items;
            ConfigurationSection closeSec;
            ConfigurationSection fillerSec = cfg.getConfigurationSection("fillers");
            if (fillerSec != null) {
                Material fillerMat = Material.matchMaterial((String)fillerSec.getString("material", "GRAY_STAINED_GLASS_PANE"));
                if (fillerMat == null) {
                    fillerMat = Material.GRAY_STAINED_GLASS_PANE;
                }
                GuiItem fillerItem = ((ItemBuilder)((ItemBuilder)HeadUtil.from(fillerMat, fillerSec).name(ColorUtil.parse(fillerSec.getString("name", " ")))).flags(ItemFlag.values())).asGuiItem();
                for (String s : fillerSec.getString("slots", "").split(",")) {
                    try {
                        gui.setItem(Integer.parseInt(s.trim()) - 1, fillerItem);
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            if ((closeSec = cfg.getConfigurationSection("close-item")) != null) {
                int closeSlot = closeSec.getInt("slot", 23) - 1;
                Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                if (closeMat == null) {
                    closeMat = Material.BARRIER;
                }
                List<Component> closeLore = this.buildLore(closeSec.getStringList("lore"), this.rounds, leader);
                gui.setItem(closeSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(this.replacePlaceholders(closeSec.getString("name", "&cClose"), leader)))).lore(closeLore)).flags(ItemFlag.values())).asGuiItem(e -> {
                    SoundUtil.playClick(leader);
                    new JuggernautOthersGUI(this.juggernauts, this.jugTier, this.jugGamemode).open(leader);
                }));
            }
            if ((items = cfg.getConfigurationSection("items")) == null) {
                gui.open((HumanEntity)leader);
            } else {
                ConfigurationSection sendSec;
                ConfigurationSection roundsSec;
                ConfigurationSection infoSec = items.getConfigurationSection("Information");
                if (infoSec != null) {
                    int slot = infoSec.getInt("slot", 11) - 1;
                    Material mat = Material.matchMaterial((String)infoSec.getString("material", "PAINTING"));
                    if (mat == null) {
                        mat = Material.PAINTING;
                    }
                    List<Component> lore = this.buildLore(infoSec.getStringList("lore"), this.rounds, leader);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, infoSec).name(ColorUtil.parse(this.replacePlaceholders(infoSec.getString("name", "&fInfo"), leader)))).lore(lore)).flags(ItemFlag.values())).asGuiItem());
                }
                if ((roundsSec = items.getConfigurationSection("Rounds")) != null) {
                    int slot = roundsSec.getInt("slot", 12) - 1;
                    Material mat = Material.matchMaterial((String)roundsSec.getString("material", "CLOCK"));
                    if (mat == null) {
                        mat = Material.CLOCK;
                    }
                    List<Component> lore = this.buildLore(roundsSec.getStringList("lore"), this.rounds, leader);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, roundsSec).name(ColorUtil.parse(this.replacePlaceholders(roundsSec.getString("name", "&eRounds"), leader)))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                        int newRounds = this.rounds;
                        if (e.isLeftClick()) {
                            newRounds = Math.min(this.rounds + 1, 10);
                        } else if (e.isRightClick()) {
                            newRounds = Math.max(this.rounds - 1, 1);
                        }
                        if (newRounds != this.rounds) {
                            SoundUtil.playClick(leader);
                            new JuggernautRoundGUI(this.juggernauts, this.jugTier, this.jugGamemode, this.othersTier, this.othersGamemode, newRounds).open(leader);
                        }
                    }));
                }
                if ((sendSec = items.getConfigurationSection("Send-Request")) != null) {
                    int slot = sendSec.getInt("slot", 16) - 1;
                    Material mat = Material.matchMaterial((String)sendSec.getString("material", "LIME_STAINED_GLASS_PANE"));
                    if (mat == null) {
                        mat = Material.LIME_STAINED_GLASS_PANE;
                    }
                    List<Component> lore = this.buildLore(sendSec.getStringList("lore"), this.rounds, leader);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sendSec).name(ColorUtil.parse(this.replacePlaceholders(sendSec.getString("name", "&aStart Match"), leader)))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                        SoundUtil.playClick(leader);
                        leader.closeInventory();
                        this.startJuggernautMatch(leader, this.rounds);
                    }));
                }
                gui.open((HumanEntity)leader);
            }
        }
    }

    private void startJuggernautMatch(Player leader, int rounds) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else {
            ArrayList<UUID> others = new ArrayList<UUID>();
            for (UUID uuid : party.getMembers()) {
                if (this.juggernauts.contains(uuid)) continue;
                others.add(uuid);
            }
            if (others.isEmpty()) {
                leader.sendMessage(ColorUtil.parse("&cThere must be at least 1 player on the other side."));
            } else {
                ArrayList<List<UUID>> teams = new ArrayList<List<UUID>>();
                teams.add(new ArrayList<UUID>(this.juggernauts));
                teams.add(others);
                PartyDuelSession.startJuggernaut(teams, this.jugTier, this.jugGamemode, this.othersTier, this.othersGamemode, rounds, GUIManager.getSelectedArena(leader.getUniqueId()));
            }
        }
    }

    private List<Component> buildLore(List<String> templates, int rounds, Player leader) {
        ArrayList<Component> lore = new ArrayList<Component>();
        for (String line : templates) {
            lore.add(ColorUtil.parse(this.replacePlaceholders(line, leader).replace("%rounds%", String.valueOf(rounds))));
        }
        return lore;
    }

    private String replacePlaceholders(String text, Player leader) {
        return text.replace("%rounds%", String.valueOf(this.rounds)).replace("%kit%", this.jugGamemode != null ? this.jugGamemode : "").replace("%opponent%", this.othersGamemode != null ? this.othersGamemode : "").replace("%sender%", leader != null ? leader.getName() : "");
    }
}

