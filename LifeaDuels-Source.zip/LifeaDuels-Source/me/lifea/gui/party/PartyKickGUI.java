/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class PartyKickGUI {
    public void open(Player leader, Party party) {
        int memberCount = party.size() - 1;
        int rows = Math.min(6, Math.max(1, (int)Math.ceil((double)memberCount / 9.0)));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(ConfigManager.partyGuiTitle("kick", new String[0])))).rows(rows)).disableAllInteractions()).create();
        int slot = 0;
        for (UUID uuid : party.getMembers()) {
            if (party.isLeader(uuid)) continue;
            Player member = Bukkit.getPlayer((UUID)uuid);
            String name = member != null ? member.getName() : Bukkit.getOfflinePlayer((UUID)uuid).getName();
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.PLAYER_HEAD).name(ColorUtil.parse("&e" + name))).lore(ColorUtil.parse("&cClick to kick"))).flags(ItemFlag.values())).asGuiItem(e -> {
                SoundUtil.playClick(leader);
                leader.closeInventory();
                Player target = Bukkit.getPlayer((UUID)uuid);
                if (target != null) {
                    PartyManager.kickMember(leader, target);
                } else {
                    leader.sendMessage(ColorUtil.parse("&cThat player is no longer online."));
                }
            }));
            ++slot;
        }
        gui.open((HumanEntity)leader);
    }
}

