/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.Iterator;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.party.PartyRoundGUI;
import me.lifea.gui.party.PartyTierGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.party.match.PartyMatchType;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.MaterialSpriteUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class PartyGamemodeGUI {
    private final String tier;

    public PartyGamemodeGUI(String tier) {
        this.tier = tier;
    }

    public void open(Player player) {
        ConfigurationSection items;
        ConfigurationSection sec = DuelMenuGUI.tierSection(this.tier);
        int rows = PartyGamemodeGUI.parseRows(sec != null ? sec.getString("size", "chest-4") : "chest-4");
        String kitFormat = sec != null ? sec.getString("kit-format", "") : "";
        PartyMatchContext.Context matchContext = PartyMatchContext.get(player.getUniqueId());
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(ConfigManager.partyGuiTitle("gamemode", "{tier}", this.tier)))).rows(rows)).disableAllInteractions()).create();
        ConfigurationSection configurationSection = items = sec != null ? sec.getConfigurationSection("items") : null;
        if (items != null) {
            Iterator var7 = items.getKeys(false).iterator();
            while (true) {
                int slot;
                if (!var7.hasNext()) {
                    gui.open((HumanEntity)player);
                    return;
                }
                String key = (String)var7.next();
                try {
                    slot = Integer.parseInt(key.trim());
                }
                catch (NumberFormatException numberFormatException) {
                    continue;
                }
                ConfigurationSection it = items.getConfigurationSection(key);
                if (it != null && !it.getBoolean("party", true) || it != null && matchContext != null && matchContext.type() == PartyMatchType.FFA && !it.getBoolean("party-ffa", true) || it == null) continue;
                Material mat = Material.matchMaterial((String)it.getString("material", "STONE"));
                if (mat == null) {
                    mat = Material.STONE;
                }
                String name = it.getString("name", "");
                String kit = it.getString("kit");
                String opens = it.getString("opens");
                ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, it).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                List<Component> lore = LoreUtil.read(it, "lore");
                if (!lore.isEmpty()) {
                    builder.lore(lore);
                }
                if (kit != null && !kit.isBlank()) {
                    builder.name(ColorUtil.parse(MaterialSpriteUtil.prefix(player, mat, name)));
                    String gamemode = DuelMenuGUI.resolveKit(kit, kitFormat)[1];
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(player);
                        new PartyRoundGUI(this.tier, gamemode).open(player);
                    }));
                    continue;
                }
                if ("back".equalsIgnoreCase(opens)) {
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(player);
                        new PartyTierGUI().open(player);
                    }));
                    continue;
                }
                gui.setItem(slot, builder.asGuiItem());
            }
        }
        gui.open((HumanEntity)player);
    }

    private static int parseRows(String size) {
        if (size != null && size.startsWith("chest-")) {
            try {
                return Integer.parseInt(size.substring("chest-".length()).trim());
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return 4;
    }
}

