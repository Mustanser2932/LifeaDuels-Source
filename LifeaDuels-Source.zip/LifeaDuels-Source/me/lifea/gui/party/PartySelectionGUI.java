/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.SkullMeta
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.PartyMatchGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.match.MatchManager;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelRequestManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class PartySelectionGUI {
    public void open(Player player) {
        ConfigurationSection backSec;
        ConfigurationSection cfg = ConfigManager.config().getConfigurationSection("gui.party-selection-gui");
        int rows = cfg != null ? cfg.getInt("rows", 5) : 5;
        String title = ConfigManager.partyGuiTitle("selection", new String[0]);
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        if (cfg != null) {
            FillerUtil.fill(gui, cfg.getConfigurationSection("fillers"));
        }
        Material backMat = Material.ARROW;
        String backName = "&fBack";
        int backSlot = 0;
        String backTexture = null;
        List<Component> backLore = List.of();
        if (cfg != null && (backSec = cfg.getConfigurationSection("back")) != null) {
            Material m = Material.matchMaterial((String)backSec.getString("material", "ARROW"));
            if (m != null) {
                backMat = m;
            }
            backName = backSec.getString("name", backName);
            backSlot = backSec.getInt("slot", backSlot);
            backTexture = backSec.getString("texture");
            backLore = LoreUtil.read(backSec, "lore");
        }
        ItemBuilder backBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(backMat, backTexture).name(ColorUtil.parse(backName))).flags(ItemFlag.values());
        if (!backLore.isEmpty()) {
            backBuilder.lore(backLore);
        }
        gui.setItem(backSlot, backBuilder.asGuiItem(e -> {
            SoundUtil.playClick(player);
            new PartyMatchGUI().open(player);
        }));
        String partyItemName = cfg != null ? cfg.getString("party-item-name", "&e%leader%'s Party") : "&e%leader%'s Party";
        List<String> partyItemLoreRaw = cfg != null ? cfg.getStringList("party-item-lore") : List.of("&fLeader: &e%leader%", "&fSize: &e%size%", "&aClick to send a party duel request");
        Party ownParty = PartyManager.getParty(player.getUniqueId());
        int slot = 10;
        for (Party party : PartyManager.getParties()) {
            Player leader;
            if (ownParty == null || party == ownParty || this.isUnavailable(party) || (leader = Bukkit.getPlayer((UUID)party.getLeader())) == null || !leader.isOnline()) continue;
            ArrayList<Component> lore = new ArrayList<Component>();
            for (String line : partyItemLoreRaw) {
                lore.add(ColorUtil.parse(line.replace("%leader%", leader.getName()).replace("%size%", String.valueOf(party.size()))));
            }
            lore.add(ColorUtil.parse(party.isPublic() ? "  &#FB0000[Public]" : "  &#FB0000[Private]"));
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.headFor(leader)).name(ColorUtil.parse(partyItemName.replace("%leader%", leader.getName())))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                SoundUtil.playClick(player);
                player.closeInventory();
                PartyDuelRequestManager.sendRequest(player, leader);
            }));
            if (++slot % 9 == 8) {
                slot += 2;
            }
            if (slot < 53) continue;
            break;
        }
        gui.open((HumanEntity)player);
    }

    private boolean isUnavailable(Party party) {
        if (PartyDuelSession.isPartyInSession(party)) {
            return true;
        }
        for (UUID uuid : party.getMembers()) {
            if (!MatchManager.inMatch(uuid)) continue;
            return true;
        }
        return false;
    }

    private ItemStack headFor(Player player) {
        ItemStack stack = new ItemStack(Material.PLAYER_HEAD);
        stack.editMeta(meta -> {
            if (meta instanceof SkullMeta) {
                SkullMeta skullMeta = (SkullMeta)meta;
                skullMeta.setOwningPlayer((OfflinePlayer)player);
            }
        });
        return stack;
    }
}

