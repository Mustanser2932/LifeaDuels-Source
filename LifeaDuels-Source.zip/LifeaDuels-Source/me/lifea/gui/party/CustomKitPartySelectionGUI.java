/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.PartyRoundGUI;
import me.lifea.gui.party.PartyTierGUI;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class CustomKitPartySelectionGUI {
    public void open(Player player) {
        if (!CustomKitManager.isEnabled()) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
        } else {
            ConfigurationSection section = ConfigManager.customKits().getConfigurationSection("Custom-Kits");
            if (section == null) {
                player.sendMessage(ColorUtil.parse("&#FB0000Custom kits config not found!"));
            } else {
                ConfigurationSection statsSec;
                int size = section.getInt("size", 45);
                int rows = size / 9;
                String title = ConfigManager.partyGuiTitle("custom-kit", new String[0]);
                Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
                FillerUtil.fill(gui, section.getConfigurationSection("Fillers"));
                ConfigurationSection closeSec = section.getConfigurationSection("close-item");
                if (closeSec != null) {
                    Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                    if (closeMat == null) {
                        closeMat = Material.BARRIER;
                    }
                    int closeSlot = closeSec.getInt("slot", 41);
                    List<Component> closeLore = LoreUtil.read(closeSec, "lore");
                    ItemBuilder closeBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cBack")))).flags(ItemFlag.values());
                    if (!closeLore.isEmpty()) {
                        closeBuilder.lore(closeLore);
                    }
                    gui.setItem(closeSlot, closeBuilder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        new PartyTierGUI().open(player);
                    }));
                }
                if ((statsSec = section.getConfigurationSection("Items.Stats")) != null) {
                    Material mat = Material.matchMaterial((String)statsSec.getString("material", "STONE"));
                    if (mat == null) {
                        mat = Material.STONE;
                    }
                    String name = statsSec.getString("name", "");
                    int slot = statsSec.getInt("slot", 0);
                    List<Component> lore = LoreUtil.read(statsSec, "lore");
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, statsSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                    if (!lore.isEmpty()) {
                        builder.lore(lore);
                    }
                    gui.setItem(slot, builder.asGuiItem());
                }
                List<Integer> occupiedSlots = CustomKitManager.getOccupiedSlots(player.getUniqueId());
                int startSlot = section.getInt("kit-start-slot", 20);
                int slotIndex = 0;
                for (int kitSlot : occupiedSlots) {
                    int guiSlot = startSlot + slotIndex;
                    if (guiSlot >= size) break;
                    Object kitName = "Kit " + kitSlot;
                    CustomKit kit = CustomKitManager.getKit(player.getUniqueId(), kitSlot);
                    if (kit == null) continue;
                    String n = kit.getSettings().get("kit-name");
                    if (n != null && !n.isBlank()) {
                        kitName = n;
                    }
                    ArrayList<Component> lore = new ArrayList<Component>();
                    lore.add(ColorUtil.parse("&f[Kit " + kitSlot + "]"));
                    lore.add(ColorUtil.parse("&fName: &f" + (String)kitName));
                    lore.add(ColorUtil.parse("&fClick to start party duel with this kit"));
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BOOK).name(ColorUtil.parse("&#FBDA00" + (String)kitName))).flags(ItemFlag.values())).lore(lore);
                    gui.setItem(guiSlot, builder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        PartyMatchContext.setCustomKit(player.getUniqueId(), player.getUniqueId(), kitSlot);
                        new PartyRoundGUI("CustomKits", "Custom Kit").open(player);
                    }));
                    ++slotIndex;
                }
                gui.open((HumanEntity)player);
            }
        }
    }
}

