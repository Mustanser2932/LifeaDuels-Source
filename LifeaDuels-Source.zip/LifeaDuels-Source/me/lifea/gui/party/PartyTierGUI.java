/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.party.CustomKitPartySelectionGUI;
import me.lifea.gui.party.PartyGamemodeGUI;
import me.lifea.gui.party.PartyMatchGUI;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class PartyTierGUI {
    public void open(Player player) {
        ConfigurationSection items;
        ConfigurationSection root = ConfigManager.duelGui().getConfigurationSection("Duel-menu");
        int rows = PartyTierGUI.parseRows(root != null ? root.getString("size", "chest-3") : "chest-3");
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(ConfigManager.partyGuiTitle("tier", new String[0])))).rows(rows)).disableAllInteractions()).create();
        ConfigurationSection configurationSection = items = root != null ? root.getConfigurationSection("items") : null;
        if (items != null) {
            for (String key : items.getKeys(false)) {
                int slot;
                try {
                    slot = Integer.parseInt(key.trim());
                }
                catch (NumberFormatException numberFormatException) {
                    continue;
                }
                ConfigurationSection sec = items.getConfigurationSection(key);
                if (sec == null) continue;
                Material mat = Material.matchMaterial((String)sec.getString("material", "STONE"));
                if (mat == null) {
                    mat = Material.STONE;
                }
                String name = sec.getString("name", "");
                String opens = sec.getString("opens");
                ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                List<Component> lore = LoreUtil.read(sec, "lore");
                if (!lore.isEmpty()) {
                    builder.lore(lore);
                }
                if (opens != null && !opens.isBlank()) {
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(player);
                        switch (opens.toLowerCase()) {
                            case "close": 
                            case "back": {
                                new PartyMatchGUI().open(player);
                                break;
                            }
                            case "custom": {
                                if (!CustomKitManager.isEnabled()) {
                                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
                                    break;
                                }
                                new CustomKitPartySelectionGUI().open(player);
                                break;
                            }
                            default: {
                                new PartyGamemodeGUI(DuelMenuGUI.tierForSection(opens)).open(player);
                            }
                        }
                    }));
                    continue;
                }
                gui.setItem(slot, builder.asGuiItem());
            }
        }
        gui.open((HumanEntity)player);
    }

    private static int parseRows(String size) {
        if (size != null && size.startsWith("chest-")) {
            try {
                return Integer.parseInt(size.substring("chest-".length()).trim());
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return 3;
    }
}

