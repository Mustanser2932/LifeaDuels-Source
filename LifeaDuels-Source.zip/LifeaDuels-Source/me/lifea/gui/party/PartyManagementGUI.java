/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.SkullMeta
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.PartyMatchGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class PartyManagementGUI {
    private static final int[] MEMBER_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private static final int[] BORDER_SLOTS = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 53};
    private static final int SLOTS_PER_PAGE = MEMBER_SLOTS.length;
    private static final int LEADER_SLOT = 4;
    private static final int PUBLIC_SLOT = 47;
    private static final int PREV_SLOT = 45;
    private static final int START_MATCH_SLOT = 49;
    private static final int DISBAND_SLOT = 51;
    private static final int NEXT_SLOT = 53;
    private final Player player;
    private final Party party;
    private final int page;

    public PartyManagementGUI(Player player, Party party, int page) {
        this.player = player;
        this.party = party;
        this.page = page;
    }

    public void open() {
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        String title = ConfigManager.partyGuiTitle("management", new String[0]);
        int rows = cfg != null ? cfg.getInt("rows", 6) : 6;
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        this.fillEmptySlots(gui);
        this.setLeader(gui);
        this.setPublicToggle(gui);
        this.populateMembers(gui);
        this.setNavigation(gui);
        this.setStartMatch(gui);
        this.setDisband(gui);
        gui.open((HumanEntity)this.player);
    }

    private void fillEmptySlots(Gui gui) {
        int[] slots;
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui.border-filler");
        String matStr = cfg != null ? cfg.getString("material", "GRAY_STAINED_GLASS_PANE") : "GRAY_STAINED_GLASS_PANE";
        String name = cfg != null ? cfg.getString("name", " ") : " ";
        Material mat = Material.matchMaterial((String)matStr);
        if (mat == null) {
            mat = Material.GRAY_STAINED_GLASS_PANE;
        }
        GuiItem filler = ((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, cfg).name(ColorUtil.parse(name))).flags(ItemFlag.values())).asGuiItem();
        List borderSlots = ConfigManager.party().getIntegerList("management-gui.border-slots");
        for (int slot : slots = borderSlots.isEmpty() ? BORDER_SLOTS : borderSlots.stream().mapToInt(Integer::intValue).toArray()) {
            if (gui.getGuiItem(slot) != null) continue;
            gui.setItem(slot, filler);
        }
    }

    private void setLeader(Gui gui) {
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        ConfigurationSection slotsCfg = cfg != null ? cfg.getConfigurationSection("slots") : null;
        ConfigurationSection leaderCfg = cfg != null ? cfg.getConfigurationSection("leader-item") : null;
        int slot = slotsCfg != null ? slotsCfg.getInt("leader", 4) : 4;
        String lore = leaderCfg != null ? leaderCfg.getString("lore", "  &fLeader") : "  &fLeader";
        Player leader = Bukkit.getPlayer((UUID)this.party.getLeader());
        String name = leader != null ? leader.getName() : Bukkit.getOfflinePlayer((UUID)this.party.getLeader()).getName();
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        head.editMeta(meta -> {
            if (meta instanceof SkullMeta) {
                SkullMeta skullMeta = (SkullMeta)meta;
                if (leader != null) {
                    skullMeta.setOwningPlayer((OfflinePlayer)leader);
                }
            }
            meta.displayName(ColorUtil.parse("&e&l" + name));
            meta.lore(List.of(ColorUtil.parse(lore)));
            meta.addItemFlags(ItemFlag.values());
        });
        gui.setItem(slot, new GuiItem(head));
    }

    private void setPublicToggle(Gui gui) {
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        ConfigurationSection slotsCfg = cfg != null ? cfg.getConfigurationSection("slots") : null;
        ConfigurationSection toggleCfg = cfg != null ? cfg.getConfigurationSection("public-toggle") : null;
        int slot = slotsCfg != null ? slotsCfg.getInt("public-toggle", 47) : 47;
        boolean isPublic = this.party.isPublic();
        String matPublic = toggleCfg != null ? toggleCfg.getString("material-public", "LIME_DYE") : "LIME_DYE";
        String matPrivate = toggleCfg != null ? toggleCfg.getString("material-private", "GRAY_DYE") : "GRAY_DYE";
        String name = toggleCfg != null ? toggleCfg.getString("name", "&a&lPublic Party") : "&a&lPublic Party";
        String lorePub = toggleCfg != null ? toggleCfg.getString("lore-public", "  &#FB0000Public") : "  &#FB0000Public";
        String lorePriv = toggleCfg != null ? toggleCfg.getString("lore-private", "  &#FB0000Private") : "  &#FB0000Private";
        Material mat = Material.matchMaterial((String)(isPublic ? matPublic : matPrivate));
        if (mat == null) {
            mat = Material.TOTEM_OF_UNDYING;
        }
        gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, toggleCfg).name(ColorUtil.parse(name))).lore(ColorUtil.parse(isPublic ? lorePub : lorePriv))).flags(ItemFlag.values())).asGuiItem(e -> {
            SoundUtil.playClick(this.player);
            PartyManager.togglePublic(this.player);
            new PartyManagementGUI(this.player, PartyManager.getParty(this.player.getUniqueId()), this.page).open();
        }));
    }

    private void populateMembers(Gui gui) {
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        String memberLore = cfg != null ? cfg.getString("member-item.lore", "&cClick to kick") : "&cClick to kick";
        List memberSlotList = ConfigManager.party().getIntegerList("management-gui.member-slots");
        int[] slots = memberSlotList.isEmpty() ? MEMBER_SLOTS : memberSlotList.stream().mapToInt(Integer::intValue).toArray();
        int slotsPerPage = slots.length;
        ArrayList<UUID> members = new ArrayList<UUID>(this.party.getMembers());
        members.remove(this.party.getLeader());
        int totalPages = Math.max(1, (int)Math.ceil((double)members.size() / (double)slotsPerPage));
        int currentPage = Math.min(this.page, totalPages - 1);
        int start = currentPage * slotsPerPage;
        int end = Math.min(start + slotsPerPage, members.size());
        List pageMembers = members.subList(start, end);
        for (int i = 0; i < pageMembers.size(); ++i) {
            UUID uuid = (UUID)pageMembers.get(i);
            Player member = Bukkit.getPlayer((UUID)uuid);
            String name = member != null ? member.getName() : Bukkit.getOfflinePlayer((UUID)uuid).getName();
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            head.editMeta(meta -> {
                if (meta instanceof SkullMeta) {
                    SkullMeta skullMeta = (SkullMeta)meta;
                    if (member != null) {
                        skullMeta.setOwningPlayer((OfflinePlayer)member);
                    }
                }
                meta.displayName(ColorUtil.parse("&e" + name));
                meta.lore(List.of(ColorUtil.parse(memberLore)));
                meta.addItemFlags(ItemFlag.values());
            });
            gui.setItem(slots[i], new GuiItem(head, e -> {
                SoundUtil.playClick(this.player);
                Player target = Bukkit.getPlayer((UUID)uuid);
                if (target != null) {
                    PartyManager.kickMember(this.player, target);
                    new PartyManagementGUI(this.player, PartyManager.getParty(this.player.getUniqueId()), currentPage).open();
                } else {
                    this.player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("player-offline")));
                }
            }));
        }
    }

    private void setNavigation(Gui gui) {
        List memberSlotList;
        Material next;
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        ConfigurationSection slotsCfg = cfg != null ? cfg.getConfigurationSection("slots") : null;
        ConfigurationSection prevCfg = cfg != null ? cfg.getConfigurationSection("prev-page") : null;
        ConfigurationSection nextCfg = cfg != null ? cfg.getConfigurationSection("next-page") : null;
        int prevSlot = slotsCfg != null ? slotsCfg.getInt("prev-page", 45) : 45;
        int nextSlot = slotsCfg != null ? slotsCfg.getInt("next-page", 53) : 53;
        String prevMat = prevCfg != null ? prevCfg.getString("material", "ARROW") : "ARROW";
        String nextMat = nextCfg != null ? nextCfg.getString("material", "ARROW") : "ARROW";
        String prevName = prevCfg != null ? prevCfg.getString("name", "&#FB0000Previous Page") : "&#FB0000Previous Page";
        String nextName = nextCfg != null ? nextCfg.getString("name", "&#FB0000Next Page") : "&#FB0000Next Page";
        String prevLore = prevCfg != null ? prevCfg.getString("lore", "") : "";
        String nextLore = nextCfg != null ? nextCfg.getString("lore", "") : "";
        Material prev = Material.matchMaterial((String)prevMat);
        if (prev == null) {
            prev = Material.ARROW;
        }
        if ((next = Material.matchMaterial((String)nextMat)) == null) {
            next = Material.ARROW;
        }
        int slotsPerPage = (memberSlotList = ConfigManager.party().getIntegerList("management-gui.member-slots")).isEmpty() ? MEMBER_SLOTS.length : memberSlotList.size();
        ArrayList<UUID> members = new ArrayList<UUID>(this.party.getMembers());
        members.remove(this.party.getLeader());
        int totalPages = Math.max(1, (int)Math.ceil((double)members.size() / (double)slotsPerPage));
        int currentPage = Math.min(this.page, totalPages - 1);
        boolean hasPrev = currentPage > 0;
        boolean hasNext = currentPage < totalPages - 1;
        ItemBuilder prevBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(prev, prevCfg).name(ColorUtil.parse(prevName))).flags(ItemFlag.values());
        if (!prevLore.isEmpty()) {
            prevBuilder.lore(ColorUtil.parse(prevLore));
        }
        gui.setItem(prevSlot, prevBuilder.asGuiItem(e -> {
            SoundUtil.playClick(this.player);
            if (!hasPrev) {
                this.player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-prev-page")));
            } else {
                new PartyManagementGUI(this.player, this.party, currentPage - 1).open();
            }
        }));
        ItemBuilder nextBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(next, nextCfg).name(ColorUtil.parse(nextName))).flags(ItemFlag.values());
        if (!nextLore.isEmpty()) {
            nextBuilder.lore(ColorUtil.parse(nextLore));
        }
        gui.setItem(nextSlot, nextBuilder.asGuiItem(e -> {
            SoundUtil.playClick(this.player);
            if (!hasNext) {
                this.player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-next-page")));
            } else {
                new PartyManagementGUI(this.player, this.party, currentPage + 1).open();
            }
        }));
    }

    private void setStartMatch(Gui gui) {
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        ConfigurationSection slotsCfg = cfg != null ? cfg.getConfigurationSection("slots") : null;
        ConfigurationSection startCfg = cfg != null ? cfg.getConfigurationSection("start-match") : null;
        int slot = slotsCfg != null ? slotsCfg.getInt("start-match", 49) : 49;
        String matStr = startCfg != null ? startCfg.getString("material", "GREEN_CONCRETE") : "GREEN_CONCRETE";
        String name = startCfg != null ? startCfg.getString("name", "&a&lStart Match") : "&a&lStart Match";
        String lore = startCfg != null ? startCfg.getString("lore", "") : "";
        Material mat = Material.matchMaterial((String)matStr);
        if (mat == null) {
            mat = Material.REPEATER;
        }
        ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, startCfg).name(ColorUtil.parse(name))).flags(ItemFlag.values());
        if (!lore.isEmpty()) {
            builder.lore(ColorUtil.parse(lore));
        }
        gui.setItem(slot, builder.asGuiItem(e -> {
            SoundUtil.playClick(this.player);
            this.player.closeInventory();
            new PartyMatchGUI().open(this.player);
        }));
    }

    private void setDisband(Gui gui) {
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("management-gui");
        ConfigurationSection slotsCfg = cfg != null ? cfg.getConfigurationSection("slots") : null;
        ConfigurationSection disbandCfg = cfg != null ? cfg.getConfigurationSection("disband-party") : null;
        int slot = slotsCfg != null ? slotsCfg.getInt("disband-party", 51) : 51;
        String matStr = disbandCfg != null ? disbandCfg.getString("material", "REDSTONE_BLOCK") : "REDSTONE_BLOCK";
        String name = disbandCfg != null ? disbandCfg.getString("name", "&#FB0000Disband Party") : "&#FB0000Disband Party";
        String lore = disbandCfg != null ? disbandCfg.getString("lore", "") : "";
        Material mat = Material.matchMaterial((String)matStr);
        if (mat == null) {
            mat = Material.REDSTONE_BLOCK;
        }
        ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, disbandCfg).name(ColorUtil.parse(name))).flags(ItemFlag.values());
        if (!lore.isEmpty()) {
            builder.lore(ColorUtil.parse(lore));
        }
        gui.setItem(slot, builder.asGuiItem(e -> {
            SoundUtil.playClick(this.player);
            this.player.closeInventory();
            PartyManager.disbandParty(this.player);
        }));
    }
}

