/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.SkullMeta
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.PartyMatchGUI;
import me.lifea.gui.party.PartyTierGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.components.GuiAction;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.party.Party;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class PartySplitGUI {
    private static final int[] BLUE_SLOTS = new int[]{10, 11, 12, 19, 20, 21, 28, 29, 30, 37, 38, 39};
    private static final int[] RED_SLOTS = new int[]{15, 16, 23, 24, 25, 32, 33, 34, 41, 42, 43};
    private static final int SLOT_PREV = 3;
    private static final int SLOT_START = 4;
    private static final int SLOT_NEXT = 5;
    private static final int SLOT_SHUFFLE = 31;
    private static final int SLOT_CLOSE = 49;
    private final Map<UUID, Team> teamMap = new HashMap<UUID, Team>();

    public void open(Player leader, Party party) {
        this.open(leader, party, 0);
    }

    public void open(Player leader, Party party, int page) {
        String title = ConfigManager.partyGuiTitle("split", new String[0]);
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(this.noItalic(title))).rows(6)).disableAllInteractions()).create();
        ConfigurationSection cfg = ConfigManager.party().getConfigurationSection("party-split.items");
        if (cfg != null) {
            for (String key : cfg.getKeys(false)) {
                Material mat;
                ConfigurationSection item;
                int slot;
                try {
                    slot = Integer.parseInt(key);
                }
                catch (NumberFormatException e2) {
                    continue;
                }
                if (slot == 3 || slot == 4 || slot == 5 || slot == 31 || slot == 49 || this.isPlayerSlot(slot) || (item = cfg.getConfigurationSection(key)) == null || (mat = Material.matchMaterial((String)item.getString("material", ""))) == null) continue;
                String name = item.getString("name", " ");
                List lore = item.getStringList("lore");
                gui.setItem(slot, this.buildStatic(mat, name, lore, item.getString("texture")));
            }
        }
        List<UUID> members = party.getMembers();
        if (this.teamMap.isEmpty()) {
            ArrayList<UUID> shuffled = new ArrayList<UUID>(members);
            Collections.shuffle(shuffled);
            int mid = shuffled.size() / 2;
            for (int i = 0; i < shuffled.size(); ++i) {
                this.teamMap.put((UUID)shuffled.get(i), i < mid ? Team.BLUE : Team.RED);
            }
        }
        ArrayList<UUID> blueTeam = new ArrayList<UUID>();
        ArrayList<UUID> redTeam = new ArrayList<UUID>();
        for (UUID uuid : members) {
            if (this.teamMap.getOrDefault(uuid, Team.BLUE) == Team.BLUE) {
                blueTeam.add(uuid);
                continue;
            }
            redTeam.add(uuid);
        }
        int perPageBlue = BLUE_SLOTS.length;
        int perPageRed = RED_SLOTS.length;
        int maxPages = Math.max((int)Math.ceil((double)blueTeam.size() / (double)perPageBlue), (int)Math.ceil((double)redTeam.size() / (double)perPageRed));
        if (maxPages < 1) {
            maxPages = 1;
        }
        int currentPage = Math.max(0, Math.min(page, maxPages - 1));
        int blueStart = currentPage * perPageBlue;
        for (int i = 0; i < BLUE_SLOTS.length; ++i) {
            UUID uuid;
            Player member;
            int idx = blueStart + i;
            if (idx >= blueTeam.size() || (member = Bukkit.getPlayer((UUID)(uuid = (UUID)blueTeam.get(idx)))) == null) continue;
            gui.setItem(BLUE_SLOTS[i], ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.headFor(member)).name(this.noItalic("&#00BFFB\u1d1b\u1d07\u1d00\u1d0d \u0299 &8- &#00BFFB" + member.getName()))).lore(this.noItalicLore("&7\u2139 Click to move to Red Team"))).flags(ItemFlag.values())).asGuiItem(e -> {
                SoundUtil.playClick(leader);
                this.teamMap.put(uuid, Team.RED);
                this.open(leader, party, currentPage);
            }));
        }
        int redStart = currentPage * perPageRed;
        for (int i = 0; i < RED_SLOTS.length; ++i) {
            UUID uuid;
            Player member;
            int idx = redStart + i;
            if (idx >= redTeam.size() || (member = Bukkit.getPlayer((UUID)(uuid = (UUID)redTeam.get(idx)))) == null) continue;
            gui.setItem(RED_SLOTS[i], ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.headFor(member)).name(this.noItalic("&#FB0000\u1d1b\u1d07\u1d00\u1d0d \u0280 &8- &#FB0000" + member.getName()))).lore(this.noItalicLore("&7\u2139 Click to move to Blue Team"))).flags(ItemFlag.values())).asGuiItem(e -> {
                SoundUtil.playClick(leader);
                this.teamMap.put(uuid, Team.BLUE);
                this.open(leader, party, currentPage);
            }));
        }
        boolean hasPrev = currentPage > 0;
        gui.setItem(3, this.buildButton(cfg, "3", Material.OAK_SIGN, hasPrev ? e -> {
            SoundUtil.playClick(leader);
            this.open(leader, party, currentPage - 1);
        } : null));
        boolean hasNext = currentPage < maxPages - 1;
        gui.setItem(5, this.buildButton(cfg, "5", Material.OAK_SIGN, hasNext ? e -> {
            SoundUtil.playClick(leader);
            this.open(leader, party, currentPage + 1);
        } : null));
        String emptyTeamMsg = ConfigManager.partyMsg("split-empty-team");
        gui.setItem(4, this.buildButton(cfg, "4", Material.GOAT_HORN, e -> {
            SoundUtil.playClick(leader);
            ArrayList<UUID> a = new ArrayList<UUID>();
            ArrayList<UUID> b = new ArrayList<UUID>();
            for (UUID uuid : members) {
                if (this.teamMap.getOrDefault(uuid, Team.BLUE) == Team.RED) {
                    b.add(uuid);
                    continue;
                }
                a.add(uuid);
            }
            if (!a.isEmpty() && !b.isEmpty()) {
                PartyMatchContext.setSplit(leader.getUniqueId(), a, b);
                new PartyTierGUI().open(leader);
            } else {
                leader.sendMessage(ColorUtil.parse(emptyTeamMsg));
            }
        }));
        gui.setItem(31, this.buildButton(cfg, "31", Material.NAME_TAG, e -> {
            SoundUtil.playClick(leader);
            ArrayList all = new ArrayList(members);
            Collections.shuffle(all);
            this.teamMap.clear();
            for (int i = 0; i < all.size(); ++i) {
                this.teamMap.put((UUID)all.get(i), i % 2 == 0 ? Team.BLUE : Team.RED);
            }
            this.open(leader, party, 0);
        }));
        gui.setItem(49, this.buildButton(cfg, "49", Material.ARROW, e -> {
            SoundUtil.playClick(leader);
            new PartyMatchGUI().open(leader);
        }));
        gui.open((HumanEntity)leader);
    }

    private GuiItem buildButton(ConfigurationSection cfg, String key, Material fallback, GuiAction<InventoryClickEvent> action) {
        ConfigurationSection sec;
        if (cfg != null && cfg.contains(key) && (sec = cfg.getConfigurationSection(key)) != null) {
            Material mat = Material.matchMaterial((String)sec.getString("material", ""));
            if (mat == null) {
                mat = fallback;
            }
            String name = sec.getString("name", " ");
            List lore = sec.getStringList("lore");
            ItemBuilder builder = (ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(mat)).name(this.noItalic(name))).lore(this.noItalicLore(lore))).flags(ItemFlag.values());
            return action != null ? builder.asGuiItem(action) : builder.asGuiItem();
        }
        ItemBuilder builder = (ItemBuilder)((ItemBuilder)ItemBuilder.from(new ItemStack(fallback)).name((Component)Component.empty())).flags(ItemFlag.values());
        return action != null ? builder.asGuiItem(action) : builder.asGuiItem();
    }

    private GuiItem buildStatic(Material mat, String name, List<String> lore, String texture) {
        ItemStack stack = new ItemStack(mat);
        if (texture != null && !texture.isBlank()) {
            HeadUtil.applyTexture(stack, texture);
        }
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(stack).name(this.noItalic(name))).lore(this.noItalicLore(lore))).flags(ItemFlag.values())).asGuiItem();
    }

    private boolean isPlayerSlot(int slot) {
        for (int s : BLUE_SLOTS) {
            if (s != slot) continue;
            return true;
        }
        for (int s : RED_SLOTS) {
            if (s != slot) continue;
            return true;
        }
        return false;
    }

    private List<Component> noItalicLore(String line) {
        return List.of(this.noItalic(line));
    }

    private List<Component> noItalicLore(List<String> lines) {
        ArrayList<Component> list = new ArrayList<Component>();
        for (String line : lines) {
            list.add(this.noItalic(line));
        }
        return list;
    }

    private Component noItalic(String text) {
        return text == null || text.isBlank() ? Component.empty() : ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack headFor(Player player) {
        ItemStack stack = new ItemStack(Material.PLAYER_HEAD);
        stack.editMeta(meta -> {
            if (meta instanceof SkullMeta) {
                SkullMeta skullMeta = (SkullMeta)meta;
                skullMeta.setOwningPlayer((OfflinePlayer)player);
            }
        });
        return stack;
    }

    private static enum Team {
        BLUE,
        RED;

    }
}

