/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.PartySelectionGUI;
import me.lifea.gui.party.PartySplitGUI;
import me.lifea.gui.party.PartyTierGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.components.GuiAction;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;

public class PartyMatchGUI {
    public void open(Player player) {
        Party party = PartyManager.getParty(player.getUniqueId());
        if (party == null) {
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (!party.isLeader(player.getUniqueId())) {
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        } else {
            ConfigurationSection cfg = ConfigManager.config().getConfigurationSection("gui.party-match-gui");
            int rows = cfg != null ? cfg.getInt("rows", 3) : 3;
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(ConfigManager.partyGuiTitle("match", new String[0])))).rows(rows)).disableAllInteractions()).create();
            FillerUtil.fill(gui, ConfigManager.config().getConfigurationSection("gui.fillers.party-match"));
            if (cfg != null) {
                this.placeItem(gui, cfg.getConfigurationSection("party-split"), player, e -> {
                    SoundUtil.playClick(player);
                    Party p = PartyManager.getParty(player.getUniqueId());
                    if (p == null) {
                        player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
                    } else {
                        new PartySplitGUI().open(player, p);
                    }
                });
                this.placeItem(gui, cfg.getConfigurationSection("party-ffa"), player, e -> {
                    SoundUtil.playClick(player);
                    Party p = PartyManager.getParty(player.getUniqueId());
                    if (p == null) {
                        player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
                    } else if (p.size() < 2) {
                        player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-enough-for-ffa")));
                    } else {
                        PartyMatchContext.setFfa(player.getUniqueId());
                        new PartyTierGUI().open(player);
                    }
                });
                this.placeItem(gui, cfg.getConfigurationSection("party-duel"), player, e -> {
                    SoundUtil.playClick(player);
                    new PartySelectionGUI().open(player);
                });
            }
            gui.open((HumanEntity)player);
        }
    }

    private void placeItem(Gui gui, ConfigurationSection sec, Player player, GuiAction<InventoryClickEvent> action) {
        if (sec != null) {
            Material mat = Material.matchMaterial((String)sec.getString("material", "STONE"));
            if (mat == null) {
                mat = Material.STONE;
            }
            String name = sec.getString("name", " ");
            int slot = sec.getInt("slot", 0);
            List<Component> lore = LoreUtil.read(sec, "lore");
            ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
            if (!lore.isEmpty()) {
                builder.lore(lore);
            }
            gui.setItem(slot, builder.asGuiItem(action));
        }
    }
}

