/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.party;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.ArenaSelectGUI;
import me.lifea.gui.GUIManager;
import me.lifea.gui.RoundSelectionDialog;
import me.lifea.gui.party.PartyGamemodeGUI;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.match.MatchManager;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.party.match.PartyMatchType;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class PartyRoundGUI {
    private static final int MIN_ROUNDS = 1;
    private static final int MAX_ROUNDS = 10;
    private final String tier;
    private final String gamemode;
    private final int rounds;

    public PartyRoundGUI(String tier, String gamemode) {
        this(tier, gamemode, 1);
    }

    public PartyRoundGUI(String tier, String gamemode, int rounds) {
        this.tier = tier;
        this.gamemode = gamemode;
        this.rounds = rounds;
    }

    public void open(Player player) {
        if (!RoundSelectionDialog.supports(player)) {
            this.openLegacy(player);
            return;
        }
        String selectedArena = GUIManager.getSelectedArena(player.getUniqueId());
        RoundSelectionDialog.open(player, GamemodeRegistry.getDisplayName(this.tier, this.gamemode), "Party", selectedArena != null ? selectedArena : "Random", this.rounds, selectedRounds -> player.sendMessage(ColorUtil.parse("&7Advanced options are not available for party matches yet.")), selectedRounds -> {
            RoundSelectionDialog.close(player);
            ArenaSelectGUI.open(player, KitManager.buildKitKey(this.tier, this.gamemode), () -> new PartyRoundGUI(this.tier, this.gamemode, (int)selectedRounds).open(player));
        }, selectedRounds -> {
            RoundSelectionDialog.close(player);
            this.startPartyMatch(player, (int)selectedRounds);
        }, () -> {});
    }

    private void openLegacy(Player player) {
        ConfigurationSection cfg = ConfigManager.config().getConfigurationSection("round-gui");
        if (cfg == null) {
            cfg = ConfigManager.config().getConfigurationSection("gui.round-gui");
        }
        if (cfg != null) {
            cfg.getString("name", "Round Selection");
        } else {
            String string = "Round Selection";
        }
        String title = ConfigManager.partyGuiTitle("round", new String[0]);
        int size = cfg != null ? cfg.getInt("size", 27) : 27;
        int rows = size / 9;
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        if (cfg == null) {
            gui.open((HumanEntity)player);
        } else {
            ConfigurationSection items;
            ConfigurationSection closeSec;
            ConfigurationSection fillerSec = cfg.getConfigurationSection("fillers");
            if (fillerSec != null) {
                Material fillerMat = Material.matchMaterial((String)fillerSec.getString("material", "GRAY_STAINED_GLASS_PANE"));
                if (fillerMat == null) {
                    fillerMat = Material.GRAY_STAINED_GLASS_PANE;
                }
                String fillerName = fillerSec.getString("name", " ");
                String slotsStr = fillerSec.getString("slots", "");
                GuiItem fillerItem = ((ItemBuilder)((ItemBuilder)HeadUtil.from(fillerMat, fillerSec).name(ColorUtil.parse(fillerName))).flags(ItemFlag.values())).asGuiItem();
                for (String s : slotsStr.split(",")) {
                    try {
                        gui.setItem(Integer.parseInt(s.trim()) - 1, fillerItem);
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            if ((closeSec = cfg.getConfigurationSection("close-item")) != null) {
                int closeSlot = closeSec.getInt("slot", 23) - 1;
                Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                if (closeMat == null) {
                    closeMat = Material.BARRIER;
                }
                List<Component> closeLore = this.buildLore(closeSec.getStringList("lore"), this.rounds, player, null);
                gui.setItem(closeSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(this.replacePlaceholders(closeSec.getString("name", "&cClose"), player, null)))).lore(closeLore)).flags(ItemFlag.values())).asGuiItem(e -> {
                    SoundUtil.playClick(player);
                    new PartyGamemodeGUI(this.tier).open(player);
                }));
            }
            if ((items = cfg.getConfigurationSection("items")) == null) {
                gui.open((HumanEntity)player);
            } else {
                ConfigurationSection sendSec;
                ConfigurationSection mapSec;
                ConfigurationSection roundsSec;
                ConfigurationSection infoSec = items.getConfigurationSection("Information");
                if (infoSec != null) {
                    int slot = infoSec.getInt("slot", 11) - 1;
                    Material mat = Material.matchMaterial((String)infoSec.getString("material", "PAINTING"));
                    if (mat == null) {
                        mat = Material.PAINTING;
                    }
                    List<Component> lore = this.buildLore(infoSec.getStringList("lore"), this.rounds, player, null);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, infoSec).name(ColorUtil.parse(this.replacePlaceholders(infoSec.getString("name", "&fInfo"), player, null)))).lore(lore)).flags(ItemFlag.values())).asGuiItem());
                }
                if ((roundsSec = items.getConfigurationSection("Rounds")) != null) {
                    int slot = roundsSec.getInt("slot", 12) - 1;
                    Material mat = Material.matchMaterial((String)roundsSec.getString("material", "CLOCK"));
                    if (mat == null) {
                        mat = Material.CLOCK;
                    }
                    List<Component> lore = this.buildLore(roundsSec.getStringList("lore"), this.rounds, player, null);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, roundsSec).name(ColorUtil.parse(this.replacePlaceholders(roundsSec.getString("name", "&eRounds"), player, null)))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                        int newRounds = this.rounds;
                        if (e.isLeftClick()) {
                            newRounds = Math.min(this.rounds + 1, 10);
                        } else if (e.isRightClick()) {
                            newRounds = Math.max(this.rounds - 1, 1);
                        }
                        if (newRounds != this.rounds) {
                            SoundUtil.playClick(player);
                            new PartyRoundGUI(this.tier, this.gamemode, newRounds).open(player);
                        }
                    }));
                }
                if ((mapSec = items.getConfigurationSection("Map-Selection")) != null) {
                    String arenaSelect;
                    int slot = mapSec.getInt("slot", 13) - 1;
                    Material mat = Material.matchMaterial((String)mapSec.getString("material", "MAP"));
                    if (mat == null) {
                        mat = Material.MAP;
                    }
                    List loreTemplate = (arenaSelect = GUIManager.getSelectedArena(player.getUniqueId())) != null ? mapSec.getStringList("selected-lore") : mapSec.getStringList("lore");
                    String arenaName = arenaSelect != null ? arenaSelect : "Random";
                    List<Component> lore = this.buildLore(loreTemplate, this.rounds, player, arenaName);
                    ItemBuilder mapBuilder = (ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, mapSec).name(ColorUtil.parse(this.replacePlaceholders(mapSec.getString("name", "&fMap"), player, arenaName)))).lore(lore)).flags(ItemFlag.values());
                    if (arenaSelect != null) {
                        mapBuilder.glow();
                    }
                    gui.setItem(slot, mapBuilder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        ArenaSelectGUI.open(player, KitManager.buildKitKey(this.tier, this.gamemode), () -> new PartyRoundGUI(this.tier, this.gamemode, this.rounds).open(player));
                    }));
                }
                if ((sendSec = items.getConfigurationSection("Send-Request")) != null) {
                    int slot = sendSec.getInt("slot", 16) - 1;
                    Material mat = Material.matchMaterial((String)sendSec.getString("material", "LIME_STAINED_GLASS_PANE"));
                    if (mat == null) {
                        mat = Material.LIME_STAINED_GLASS_PANE;
                    }
                    List<Component> lore = this.buildLore(sendSec.getStringList("lore"), this.rounds, player, null);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sendSec).name(ColorUtil.parse(this.replacePlaceholders(sendSec.getString("name", "&aStart Match"), player, null)))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        player.closeInventory();
                        this.startPartyMatch(player, this.rounds);
                    }));
                }
                gui.open((HumanEntity)player);
            }
        }
    }

    private List<Component> buildLore(List<String> templates, int rounds, Player player, String arena) {
        ArrayList<Component> lore = new ArrayList<Component>();
        for (String line : templates) {
            lore.add(ColorUtil.parse(this.replacePlaceholders(line, player, arena).replace("%rounds%", String.valueOf(rounds))));
        }
        return lore;
    }

    private String replacePlaceholders(String text, Player player, String arena) {
        return text.replace("%rounds%", String.valueOf(this.rounds)).replace("%kit%", this.gamemode != null ? this.gamemode : "").replace("%opponent%", "Party").replace("%sender%", player != null ? player.getName() : "").replace("%arena%", arena != null ? arena : "Random");
    }

    private void startPartyMatch(Player player, int rounds) {
        PartyMatchContext.Context context = PartyMatchContext.remove(player.getUniqueId());
        if (context == null) {
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-match-setup")));
        } else {
            ArrayList<List<UUID>> teams = new ArrayList<List<UUID>>();
            if (context.type() == PartyMatchType.FFA) {
                Party party = PartyManager.getParty(player.getUniqueId());
                if (party == null) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
                } else {
                    for (UUID uuid : new ArrayList<UUID>(party.getMembers())) {
                        Player p = Bukkit.getPlayer((UUID)uuid);
                        if (p == null || !p.isOnline() || MatchManager.inMatch(uuid)) continue;
                        ArrayList<UUID> singlePlayerTeam = new ArrayList<UUID>();
                        singlePlayerTeam.add(uuid);
                        teams.add(singlePlayerTeam);
                    }
                    if (teams.size() < 2) {
                        player.sendMessage(ColorUtil.parse("&cNeed at least 2 players for FFA"));
                    } else if (PartyMatchContext.hasCustomKit(player.getUniqueId())) {
                        UUID ckOwner = PartyMatchContext.getCustomKitOwner(player.getUniqueId());
                        int ckSlot = PartyMatchContext.getCustomKitSlot(player.getUniqueId());
                        PartyMatchContext.clearCustomKit(player.getUniqueId());
                        PartyDuelSession.startCustomKit(teams, this.tier, this.gamemode, rounds, context.type(), ckOwner, ckSlot, GUIManager.getSelectedArena(player.getUniqueId()));
                    } else {
                        PartyDuelSession.start(teams, this.tier, this.gamemode, rounds, PartyMatchType.FFA, GUIManager.getSelectedArena(player.getUniqueId()));
                    }
                }
            } else {
                ArrayList<UUID> teamA = new ArrayList<UUID>();
                ArrayList<UUID> teamB = new ArrayList<UUID>();
                if (context.type() == PartyMatchType.DUEL) {
                    Party target;
                    Party own = PartyManager.getParty(player.getUniqueId());
                    Party party = target = context.opponentLeader() != null ? PartyManager.getParty(context.opponentLeader()) : null;
                    if (own == null || target == null) {
                        player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("party-no-longer-exists")));
                        return;
                    }
                    teamA.addAll(own.getMembers());
                    teamB.addAll(target.getMembers());
                } else if (context.type() != PartyMatchType.SPLIT && context.type() != PartyMatchType.JUGGERNAUT) {
                    teamA.addAll(context.teamA());
                    teamB.addAll(context.teamB());
                } else {
                    teamA.addAll(context.teamA());
                    teamB.addAll(context.teamB());
                }
                if (!teamA.isEmpty() && !teamB.isEmpty()) {
                    teams.add(teamA);
                    teams.add(teamB);
                    String arenaBaseName = GUIManager.getSelectedArena(player.getUniqueId());
                    if (context.type() == PartyMatchType.JUGGERNAUT) {
                        String[] othersKit = PartyMatchContext.getJugOthersKit(player.getUniqueId());
                        String othersTier = othersKit != null ? othersKit[0] : this.tier;
                        String othersGamemode = othersKit != null ? othersKit[1] : this.gamemode;
                        PartyDuelSession.startJuggernaut(teams, this.tier, this.gamemode, othersTier, othersGamemode, rounds, arenaBaseName);
                    } else if (PartyMatchContext.hasCustomKit(player.getUniqueId())) {
                        UUID customKitOwner = PartyMatchContext.getCustomKitOwner(player.getUniqueId());
                        int customKitSlot = PartyMatchContext.getCustomKitSlot(player.getUniqueId());
                        PartyMatchContext.clearCustomKit(player.getUniqueId());
                        PartyDuelSession.startCustomKit(teams, this.tier, this.gamemode, rounds, context.type(), customKitOwner, customKitSlot, arenaBaseName);
                    } else {
                        PartyDuelSession.start(teams, this.tier, this.gamemode, rounds, context.type(), arenaBaseName);
                    }
                } else {
                    player.sendMessage(ColorUtil.parse("&cBoth teams need players"));
                }
            }
        }
    }
}

