/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package me.lifea.gui;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelRequestManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class DuelRequestGUI
implements Listener {
    private static final Map<Inventory, UUID> openInventories = new ConcurrentHashMap<Inventory, UUID>();
    private final Player sender;
    private final String tier;
    private final String gamemode;

    public DuelRequestGUI(Player sender, String tier, String gamemode) {
        this.sender = sender;
        this.tier = tier;
        this.gamemode = gamemode;
    }

    public void open(Player target) {
        Material declineMat;
        Material acceptMat;
        String title = ConfigManager.guiTitle("request", "{sender}", this.sender.getName(), "{tier}", this.tier, "{gamemode}", this.gamemode);
        ConfigurationSection acceptSec = ConfigManager.config().getConfigurationSection("gui.request-gui.accept");
        ConfigurationSection declineSec = ConfigManager.config().getConfigurationSection("gui.request-gui.decline");
        Material material = acceptMat = acceptSec != null ? Material.matchMaterial((String)acceptSec.getString("material", "LIME_CONCRETE")) : null;
        if (acceptMat == null) {
            acceptMat = Material.LIME_CONCRETE;
        }
        String acceptName = acceptSec != null ? acceptSec.getString("name", "&aAccept") : "&aAccept";
        List<Component> acceptLore = acceptSec != null ? LoreUtil.read(acceptSec, "lore") : List.of();
        int acceptSlot = acceptSec != null ? acceptSec.getInt("slot", 2) - 1 : 1;
        Material material2 = declineMat = declineSec != null ? Material.matchMaterial((String)declineSec.getString("material", "RED_CONCRETE")) : null;
        if (declineMat == null) {
            declineMat = Material.RED_CONCRETE;
        }
        String declineName = declineSec != null ? declineSec.getString("name", "&cDecline") : "&cDecline";
        List<Component> declineLore = declineSec != null ? LoreUtil.read(declineSec, "lore") : List.of();
        int declineSlot = declineSec != null ? declineSec.getInt("slot", 4) - 1 : 3;
        Inventory hopper = Bukkit.createInventory((InventoryHolder)null, (InventoryType)InventoryType.HOPPER, (Component)ColorUtil.parse(title));
        ItemStack filler = DuelRequestGUI.buildItem(Material.GRAY_STAINED_GLASS_PANE, null, ColorUtil.parse(" "), List.of());
        for (int s : new int[]{0, 2, 4}) {
            if (s == acceptSlot || s == declineSlot) continue;
            hopper.setItem(s, filler);
        }
        hopper.setItem(acceptSlot, DuelRequestGUI.buildItem(acceptMat, acceptSec != null ? acceptSec.getString("texture") : null, ColorUtil.parse(acceptName), acceptLore));
        hopper.setItem(declineSlot, DuelRequestGUI.buildItem(declineMat, declineSec != null ? declineSec.getString("texture") : null, ColorUtil.parse(declineName), declineLore));
        openInventories.put(hopper, target.getUniqueId());
        target.openInventory(hopper);
    }

    private static ItemStack buildItem(Material mat, String texture, Component name, List<Component> lore) {
        ItemStack item = new ItemStack(mat);
        HeadUtil.applyTexture(item, texture);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(name);
        if (!lore.isEmpty()) {
            meta.lore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        HumanEntity var3 = e.getWhoClicked();
        if (var3 instanceof Player) {
            Player player = (Player)var3;
            Inventory var10 = e.getView().getTopInventory();
            if (openInventories.containsKey(var10)) {
                e.setCancelled(true);
                if (e.getClickedInventory() == var10) {
                    int slot = e.getSlot();
                    UUID targetId = openInventories.get(var10);
                    if (player.getUniqueId().equals(targetId)) {
                        ConfigurationSection acceptSec = ConfigManager.config().getConfigurationSection("gui.request-gui.accept");
                        ConfigurationSection declineSec = ConfigManager.config().getConfigurationSection("gui.request-gui.decline");
                        int acceptSlot = (acceptSec != null ? acceptSec.getInt("slot", 2) : 2) - 1;
                        int declineSlot = (declineSec != null ? declineSec.getInt("slot", 4) : 4) - 1;
                        if (slot == acceptSlot) {
                            player.closeInventory();
                            DuelRequestManager.acceptRequest(player);
                        } else if (slot == declineSlot) {
                            player.closeInventory();
                            DuelRequestManager.denyRequest(player);
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {
        openInventories.remove(e.getInventory());
    }

    public static void closeFor(Player player) {
        openInventories.entrySet().removeIf(entry -> ((UUID)entry.getValue()).equals(player.getUniqueId()));
    }
}

