/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.datacomponent.DataComponentTypes
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.potion.PotionType
 */
package me.lifea.gui;

import io.papermc.paper.datacomponent.DataComponentTypes;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.kit.KitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.queue.QueueEntry;
import me.lifea.queue.QueueManager;
import me.lifea.queue.QuickQueuePreferenceManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.MaterialSpriteUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

public class CompGUI {
    private static final Map<UUID, OpenView> OPEN_VIEWS = new ConcurrentHashMap<UUID, OpenView>();
    private final boolean quickQueueSettings;

    public CompGUI() {
        this(false);
    }

    public CompGUI(boolean quickQueueSettings) {
        this.quickQueueSettings = quickQueueSettings;
    }

    public static Set<String> getCompGamemodes() {
        HashSet<String> gamemodes = new HashSet<String>();
        for (Map m : ConfigManager.queue().getMapList("comp-gui.modes")) {
            Object gm = m.get("gamemode");
            if (!(gm instanceof String)) continue;
            String s = (String)gm;
            gamemodes.add(s);
        }
        return gamemodes;
    }

    public void open(Player player) {
        this.openPage(player, 1);
    }

    public void openPage(Player player, int page) {
        if (page == 2) {
            this.openPvpTiers(player);
        } else {
            this.openMcTiers(player);
        }
    }

    private void openMcTiers(Player player) {
        int slot;
        ConfigurationSection nextSec;
        ConfigurationSection fillerSec;
        ConfigurationSection cfg = ConfigManager.queue().getConfigurationSection("comp-gui");
        String title = cfg != null ? cfg.getString("title", "Queues") : "Queues";
        int rows = cfg != null ? cfg.getInt("rows", 5) : 5;
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        if (cfg != null && (fillerSec = cfg.getConfigurationSection("filler")) != null) {
            Material fillerMat = Material.matchMaterial((String)fillerSec.getString("material", "GRAY_STAINED_GLASS_PANE"));
            if (fillerMat == null) {
                fillerMat = Material.GRAY_STAINED_GLASS_PANE;
            }
            GuiItem filler = ((ItemBuilder)HeadUtil.from(fillerMat, fillerSec).name((Component)Component.empty())).asGuiItem();
            Iterator iterator = fillerSec.getIntegerList("slots").iterator();
            while (iterator.hasNext()) {
                int slot2 = (Integer)iterator.next();
                gui.setItem(slot2, filler);
            }
        }
        LinkedHashMap<Integer, ModeRef> slots = new LinkedHashMap<Integer, ModeRef>();
        for (Map m : ConfigManager.queue().getMapList("comp-gui.modes")) {
            Material mat;
            int var10000;
            String gamemode = (String)m.get("gamemode");
            String tier = (String)m.get("tier");
            String name = (String)m.get("name");
            String matStr = (String)m.get("material");
            Object var15 = m.get("slot");
            if (var15 instanceof Number) {
                Number n = (Number)var15;
                var10000 = n.intValue();
            } else {
                var10000 = 0;
            }
            if (gamemode == null || tier == null || name == null || matStr == null || (mat = Material.matchMaterial((String)matStr)) == null || !KitManager.isKitEnabled(tier, gamemode)) continue;
            ModeRef ref = new ModeRef(gamemode, tier, name, mat, (String)m.get("texture"));
            gui.setItem(var10000, this.buildModeItem(player, ref, 1));
            slots.put(var10000, ref);
        }
        ConfigurationSection configurationSection = nextSec = cfg != null ? cfg.getConfigurationSection("next-page") : null;
        if (nextSec != null && (slot = nextSec.getInt("slot", -1)) >= 0) {
            gui.setItem(slot, new GuiItem(CompGUI.buildConfigStack(nextSec), e -> {
                SoundUtil.playClick(player);
                this.openPage(player, 2);
            }));
        }
        this.registerAndOpen(player, gui, slots);
    }

    private void openPvpTiers(Player player) {
        ConfigurationSection itemsSec;
        ConfigurationSection cfg = ConfigManager.queue().getConfigurationSection("pvptiers");
        String title = cfg != null ? cfg.getString("title", "Queue \u00bb PvPTiers") : "Queue \u00bb PvPTiers";
        int rows = CompGUI.parseRows(cfg != null ? cfg.getString("size", "chest-4") : "chest-4");
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        LinkedHashMap<Integer, ModeRef> slots = new LinkedHashMap<Integer, ModeRef>();
        ConfigurationSection configurationSection = itemsSec = cfg != null ? cfg.getConfigurationSection("items") : null;
        if (itemsSec != null) {
            for (String key : itemsSec.getKeys(false)) {
                int slot;
                ConfigurationSection itemSec = itemsSec.getConfigurationSection(key);
                if (itemSec == null) continue;
                try {
                    slot = Integer.parseInt(key);
                }
                catch (NumberFormatException var181) {
                    continue;
                }
                String kit = itemSec.getString("kit");
                Material mat = Material.matchMaterial((String)itemSec.getString("material", "AIR"));
                if (mat == null) {
                    mat = Material.AIR;
                }
                if (kit != null) {
                    String gamemode;
                    String tier;
                    String[] parsed = KitManager.parseKitKey(kit);
                    if (parsed == null || !KitManager.isKitEnabled(tier = parsed[0], gamemode = parsed[1])) continue;
                    ModeRef ref = new ModeRef(gamemode, tier, itemSec.getString("name", kit), mat, itemSec.getString("texture"));
                    gui.setItem(slot, this.buildModeItem(player, ref, 2));
                    slots.put(slot, ref);
                    continue;
                }
                if (mat == Material.ARROW) {
                    gui.setItem(slot, new GuiItem(CompGUI.buildConfigStack(itemSec), e -> {
                        SoundUtil.playClick(player);
                        this.openPage(player, 1);
                    }));
                    continue;
                }
                gui.setItem(slot, new GuiItem(CompGUI.buildConfigStack(itemSec)));
            }
        }
        this.registerAndOpen(player, gui, slots);
    }

    private void registerAndOpen(Player player, Gui gui, Map<Integer, ModeRef> slots) {
        UUID uuid = player.getUniqueId();
        gui.setCloseGuiAction(e -> OPEN_VIEWS.remove(uuid));
        OPEN_VIEWS.put(uuid, new OpenView(gui, uuid, slots));
        gui.open((HumanEntity)player);
    }

    private static int parseRows(String size) {
        if (size != null) {
            int dash = size.lastIndexOf(45);
            String num = dash >= 0 ? size.substring(dash + 1) : size;
            try {
                int r = Integer.parseInt(num.trim());
                if (r >= 1 && r <= 6) {
                    return r;
                }
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return 4;
    }

    private static ItemStack buildConfigStack(ConfigurationSection sec) {
        Material mat = Material.matchMaterial((String)sec.getString("material", "STONE"));
        if (mat == null) {
            mat = Material.STONE;
        }
        ItemStack stack = new ItemStack(mat, Math.max(1, sec.getInt("amount", 1)));
        String name = sec.getString("name");
        List loreLines = sec.getStringList("lore");
        stack.editMeta(meta -> {
            if (name != null) {
                meta.displayName(CompGUI.noItalic(name));
            }
            if (!loreLines.isEmpty()) {
                ArrayList<TextComponent> lore = new ArrayList<TextComponent>();
                for (String line : loreLines) {
                    lore.add((TextComponent)(line.isEmpty() ? Component.empty() : CompGUI.noItalic(line)));
                }
                meta.lore(lore);
            }
            meta.addItemFlags(ItemFlag.values());
        });
        return stack;
    }

    public static void refreshOpenViews() {
        if (!OPEN_VIEWS.isEmpty()) {
            Runnable task = () -> {
                for (OpenView view : OPEN_VIEWS.values()) {
                    Player viewer = Bukkit.getPlayer((UUID)view.viewerUuid());
                    if (viewer == null || !viewer.isOnline()) continue;
                    for (Map.Entry<Integer, ModeRef> entry : view.slots().entrySet()) {
                        ItemStack stack = CompGUI.buildDisplayStack(viewer, entry.getValue(), false);
                        view.gui().updateItem((int)entry.getKey(), stack);
                    }
                }
            };
            if (Bukkit.isPrimaryThread()) {
                task.run();
            } else {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), task);
            }
        }
    }

    private GuiItem buildModeItem(Player player, ModeRef ref, int page) {
        ItemStack stack = CompGUI.buildDisplayStack(player, ref, this.quickQueueSettings);
        return new GuiItem(stack, e -> {
            SoundUtil.playClick(player);
            if (this.quickQueueSettings) {
                QuickQueuePreferenceManager.toggle(player.getUniqueId(), ref.tier(), ref.gamemode());
                this.openPage(player, page);
                return;
            }
            QueueManager.toggleQueue(player, ref.tier(), ref.gamemode(), QueueEntry.MatchMode.COMPETITIVE);
            this.openPage(player, page);
        });
    }

    private static ItemStack buildDisplayStack(Player player, ModeRef ref, boolean quickQueueSettings) {
        int inDuel = QueueManager.getInDuelCount(ref.tier(), ref.gamemode());
        int queued = QueueManager.getQueuedCount(ref.tier(), ref.gamemode());
        boolean isQueued = quickQueueSettings ? QuickQueuePreferenceManager.isEnabled(player.getUniqueId(), ref.tier(), ref.gamemode()) : QueueManager.isQueuedFor(player, ref.tier(), ref.gamemode());
        List loreTemplate = quickQueueSettings ? ConfigManager.queue().getStringList("quickqueue-lore") : ConfigManager.queue().getStringList("comp-gui.lore");
        ArrayList<Component> lore = new ArrayList<Component>();
        String kitColor = ColorUtil.extractLastColorCode(ref.name());
        for (String line : loreTemplate) {
            String resolved = line.replace("%color_kit%", kitColor).replace("{in_duel}", String.valueOf(inDuel)).replace("{queued}", String.valueOf(queued)).replace("%selected%", isQueued ? "&aEnabled" : "&cDisabled");
            lore.add((Component)(resolved.isEmpty() ? Component.empty() : CompGUI.noItalic(resolved)));
        }
        int amount = Math.max(1, Math.min(999, inDuel));
        return CompGUI.buildStack(player, ref.material(), ref.texture(), ref.name(), lore, isQueued, amount);
    }

    private static ItemStack buildStack(Player player, Material mat, String texture, String displayName, List<Component> lore, boolean queued, int amount) {
        ItemStack stack = mat == Material.SPLASH_POTION ? CompGUI.buildPotionStack() : new ItemStack(mat);
        HeadUtil.applyTexture(stack, texture);
        stack.setData(DataComponentTypes.MAX_STACK_SIZE, (Object)99);
        stack.setAmount(amount);
        stack.editMeta(meta -> {
            Enchantment ench;
            meta.displayName(CompGUI.noItalic(MaterialSpriteUtil.prefix(player, mat, displayName)));
            meta.lore(lore);
            meta.addItemFlags(ItemFlag.values());
            if (queued && (ench = Enchantment.getByKey((NamespacedKey)NamespacedKey.minecraft((String)"unbreaking"))) != null) {
                meta.addEnchant(ench, 1, true);
            }
        });
        return stack;
    }

    private static ItemStack buildPotionStack() {
        ItemStack stack = new ItemStack(Material.SPLASH_POTION);
        stack.editMeta(PotionMeta.class, meta -> {
            meta.setBasePotionType(PotionType.STRONG_HEALING);
            meta.addCustomEffect(new PotionEffect(PotionEffectType.INSTANT_HEALTH, 1, 1), true);
        });
        return stack;
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }

    private record ModeRef(String gamemode, String tier, String name, Material material, String texture) {
    }

    private record OpenView(Gui gui, UUID viewerUuid, Map<Integer, ModeRef> slots) {
    }
}

