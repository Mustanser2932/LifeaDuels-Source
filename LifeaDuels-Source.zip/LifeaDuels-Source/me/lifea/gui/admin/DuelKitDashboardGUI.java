/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.admin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;
import java.util.function.Consumer;
import me.lifea.gui.admin.KitSettingsGUI;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.kit.KitRuleManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;

public final class DuelKitDashboardGUI {
    private static final int KITS_PER_PAGE = 36;

    private DuelKitDashboardGUI() {
    }

    public static void open(Player player) {
        DuelKitDashboardGUI.open(player, 1);
    }

    private static void open(Player player, int page) {
        ArrayList<GamemodeRegistry.GamemodeEntry> kits = new ArrayList<GamemodeRegistry.GamemodeEntry>(GamemodeRegistry.getAll());
        kits.sort(Comparator.comparing(GamemodeRegistry.GamemodeEntry::tier).thenComparing(GamemodeRegistry.GamemodeEntry::gamemode, String.CASE_INSENSITIVE_ORDER));
        int enabled = (int)kits.stream().filter(entryx -> KitManager.isKitEnabled(entryx.tier(), entryx.gamemode())).count();
        int totalPages = Math.max(1, (int)Math.ceil((double)kits.size() / 36.0));
        int currentPage = page = Math.max(1, Math.min(page, totalPages));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&#FB0000\u1d05\u1d1c\u1d07\u029f \u1d0b\u026a\u1d1b\u0455 &8\u2022 &f" + page + "/" + totalPages))).rows(6)).disableAllInteractions()).create();
        gui.setItem(0, DuelKitDashboardGUI.summary(Material.LIME_CONCRETE, "&a\u2714 &f\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05", enabled));
        gui.setItem(2, DuelKitDashboardGUI.summary(Material.RED_CONCRETE, "&c\u2718 &f\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05", kits.size() - enabled));
        gui.setItem(4, DuelKitDashboardGUI.summary(Material.BOOK, "&#FB0000\u1d1b\u1d0f\u1d1b\u1d00\u029f \u1d0b\u026a\u1d1b\u0455", kits.size()));
        gui.setItem(6, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.COMPASS).name(DuelKitDashboardGUI.noItalic("&#FB0000\u1d0b\u026a\u1d1b \u0262\u1d1c\u026a\u1d05\u1d07"))).lore(DuelKitDashboardGUI.noItalic("&7\u1d04\u029f\u026a\u1d04\u1d0b \u1d00 \u1d0b\u026a\u1d1b \u1d1b\u1d0f \u1d0d\u1d00\u0274\u1d00\u0262\u1d07 \u026a\u1d1b\u0455 \u0455\u1d1b\u1d00\u1d1b\u1d1c\u0455 \u1d00\u0274\u1d05 \u0280\u1d1c\u029f\u1d07\u0455"), DuelKitDashboardGUI.noItalic("&7\u1d04\u1d00\u0280\u1d05\u0455 \u0455\u029c\u1d0f\u1d21 \u0299\u1d1c\u026a\u029f\u1d05/\u0299\u0280\u1d07\u1d00\u1d0b \u1d18\u1d07\u0280\u1d0d\u026a\u0455\u0455\u026a\u1d0f\u0274\u0455"))).flags(ItemFlag.values())).asGuiItem(event -> {}));
        int start = (page - 1) * 36;
        int end = Math.min(start + 36, kits.size());
        for (int i = start; i < end; ++i) {
            GamemodeRegistry.GamemodeEntry entry = (GamemodeRegistry.GamemodeEntry)kits.get(i);
            String key = entry.kitKey();
            boolean available = KitManager.isKitEnabled(entry.tier(), entry.gamemode());
            boolean build = KitRuleManager.isBlockPlacingEnabled(key);
            boolean breakBlocks = KitRuleManager.isBlockBreakingEnabled(key);
            int var10001 = 9 + i - start;
            ItemBuilder var10002 = (ItemBuilder)ItemBuilder.from(available ? Material.LIME_CONCRETE : Material.RED_CONCRETE).name(DuelKitDashboardGUI.noItalic(entry.displayName()));
            Component[] var10003 = new Component[]{DuelKitDashboardGUI.noItalic(available ? "&a\u2714 \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07" : "&c\u2718 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05"), DuelKitDashboardGUI.noItalic("&7\u1d1b\u026a\u1d07\u0280: &f" + entry.tier()), DuelKitDashboardGUI.noItalic("&7\u1d0b\u1d07\u028f: &f" + key), null, null, null, null};
            String var10006 = DuelKitDashboardGUI.rule(build);
            var10003[3] = DuelKitDashboardGUI.noItalic("&7\u0299\u1d1c\u026a\u029f\u1d05: " + var10006 + " &8| &7\u0299\u0280\u1d07\u1d00\u1d0b: " + DuelKitDashboardGUI.rule(breakBlocks));
            var10003[4] = DuelKitDashboardGUI.noItalic("&7\u1d0f\u1d18\u1d07\u0274 \u1d0d\u1d00\u0274\u1d00\u0262\u1d07\u0280 \ua730\u1d0f\u0280 \u1d00\u029f\u029f \u1d0b\u026a\u1d1b \u0280\u1d1c\u029f\u1d07\u0455");
            var10003[5] = DuelKitDashboardGUI.noItalic("");
            var10003[6] = DuelKitDashboardGUI.noItalic("&#FB0000\u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d0d\u1d00\u0274\u1d00\u0262\u1d07");
            gui.setItem(var10001, ((ItemBuilder)((ItemBuilder)var10002.lore(var10003)).flags(ItemFlag.values())).asGuiItem(event -> KitSettingsGUI.open(player, key)));
        }
        gui.setItem(49, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.PAPER).name(DuelKitDashboardGUI.noItalic("&f\u1d18\u1d00\u0262\u1d07 &e" + page + "&f/&e" + totalPages))).flags(ItemFlag.values())).asGuiItem(event -> {}));
        if (page > 1) {
            gui.setItem(45, DuelKitDashboardGUI.nav("&#FB0000\u00ab &f\u1d18\u0280\u1d07\u1d20\u026a\u1d0f\u1d1c\u0455", event -> DuelKitDashboardGUI.open(player, currentPage - 1)));
        }
        if (page < totalPages) {
            gui.setItem(53, DuelKitDashboardGUI.nav("&#FB0000\u0274\u1d07x\u1d1b \u00bb", event -> DuelKitDashboardGUI.open(player, currentPage + 1)));
        }
        gui.open((HumanEntity)player);
    }

    private static GuiItem summary(Material material, String name, int count) {
        return ((ItemBuilder)((ItemBuilder)ItemBuilder.from(material).name(DuelKitDashboardGUI.noItalic(name + " &8(" + count + ")"))).flags(ItemFlag.values())).asGuiItem(event -> {});
    }

    private static GuiItem nav(String name, Consumer<InventoryClickEvent> click) {
        ItemBuilder var10000 = (ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(DuelKitDashboardGUI.noItalic(name))).flags(ItemFlag.values());
        Objects.requireNonNull(click);
        return var10000.asGuiItem(click::accept);
    }

    private static String rule(boolean enabled) {
        return enabled ? "&a\u2714 \u1d0f\u0274" : "&c\u2718 \u1d0f\ua730\ua730";
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

