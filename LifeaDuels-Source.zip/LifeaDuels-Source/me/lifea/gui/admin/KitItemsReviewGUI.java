/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.gui.admin;

import me.lifea.Lifea;
import me.lifea.gui.admin.KitSettingsGUI;
import me.lifea.kit.KitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class KitItemsReviewGUI {
    private KitItemsReviewGUI() {
    }

    public static void open(Player player, String kitKey) {
        String[] kit = KitManager.parseKitKey(kitKey);
        if (kit == null) {
            player.sendMessage(ColorUtil.parse("&cUnable to find the kit items for &f" + kitKey + "&c."));
        } else {
            ItemStack[] items = KitManager.getBaseKit(kit[0], kit[1]);
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&#FB0000\u0280\u1d07\u1d20\u026a\u1d07\u1d21 \u1d0b\u026a\u1d1b &8\u2022 &f" + kitKey))).rows(6)).disableAllInteractions()).create();
            for (int slot = 0; slot < 36; ++slot) {
                KitItemsReviewGUI.setItem(gui, slot, items, slot);
            }
            gui.setItem(45, KitItemsReviewGUI.label(Material.LEATHER_BOOTS, "&7\u0299\u1d0f\u1d0f\u1d1b\u0455"));
            gui.setItem(46, KitItemsReviewGUI.label(Material.LEATHER_LEGGINGS, "&7\u029f\u1d07\u0262\u0262\u026a\u0274\u0262\u0455"));
            gui.setItem(47, KitItemsReviewGUI.label(Material.LEATHER_CHESTPLATE, "&7\u1d04\u029c\u1d07\u0455\u1d1b\u1d18\u029f\u1d00\u1d1b\u1d07"));
            gui.setItem(48, KitItemsReviewGUI.label(Material.LEATHER_HELMET, "&7\u029c\u1d07\u029f\u1d0d\u1d07\u1d1b"));
            gui.setItem(50, KitItemsReviewGUI.label(Material.SHIELD, "&7\u1d0f\ua730\ua730\u029c\u1d00\u0274\u1d05"));
            KitItemsReviewGUI.setItem(gui, 36, items, 45);
            KitItemsReviewGUI.setItem(gui, 37, items, 46);
            KitItemsReviewGUI.setItem(gui, 38, items, 47);
            KitItemsReviewGUI.setItem(gui, 39, items, 48);
            KitItemsReviewGUI.setItem(gui, 40, items, 50);
            gui.setItem(52, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BOOK).name(KitItemsReviewGUI.noItalic("&f\u0280\u1d07\u1d00\u1d05-\u1d0f\u0274\u029f\u028f \u1d18\u0280\u1d07\u1d20\u026a\u1d07\u1d21"))).lore(KitItemsReviewGUI.noItalic("&7\u026a\u0274\u0455\u1d18\u1d07\u1d04\u1d1b \u1d1b\u029c\u1d07 \u0455\u1d00\u1d20\u1d07\u1d05 \u0299\u1d00\u0455\u1d07 \u1d0b\u026a\u1d1b \u026a\u1d1b\u1d07\u1d0d\u0455."), KitItemsReviewGUI.noItalic("&7\u1d1b\u1d0f \u1d04\u029c\u1d00\u0274\u0262\u1d07 \u1d1b\u029c\u1d07\u1d0d, \u1d1c\u0455\u1d07 \u1d1b\u029c\u1d07 \u1d0b\u026a\u1d1b \u1d07\u1d05\u026a\u1d1b\u1d0f\u0280."))).flags(ItemFlag.values())).asGuiItem(event -> {}));
            gui.setItem(49, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(KitItemsReviewGUI.noItalic("&#FB0000\u00ab &f\u0299\u1d00\u1d04\u1d0b \u1d1b\u1d0f \u0455\u1d07\u1d1b\u1d1b\u026a\u0274\u0262\u0455"))).flags(ItemFlag.values())).asGuiItem(event -> Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> KitSettingsGUI.open(player, kitKey))));
            gui.getFiller().fill(((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name((Component)Component.empty())).asGuiItem());
            gui.open((HumanEntity)player);
        }
    }

    private static void setItem(Gui gui, int itemIndex, ItemStack[] items, int guiSlot) {
        if (itemIndex < items.length && items[itemIndex] != null && items[itemIndex].getType() != Material.AIR) {
            gui.setItem(guiSlot, ItemBuilder.from(items[itemIndex].clone()).asGuiItem(event -> {}));
        }
    }

    private static GuiItem label(Material material, String name) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(material).name(KitItemsReviewGUI.noItalic(name))).lore(KitItemsReviewGUI.noItalic("&8\u1d0b\u026a\u1d1b \u0455\u029f\u1d0f\u1d1b"))).flags(ItemFlag.values())).asGuiItem(event -> {});
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

