/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.gui.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.gui.admin.KitItemsReviewGUI;
import me.lifea.gui.admin.KitRulesGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.plugin.Plugin;

public class KitSettingsGUI
implements Listener {
    private static final Map<UUID, String> awaitingRename = new HashMap<UUID, String>();

    public static void open(Player player, String kitKey) {
        Component[] componentArray;
        String kitStatus;
        boolean enabled = ConfigManager.config().getBoolean("kit-settings." + kitKey + ".enabled", true);
        int enabledRules = KitRulesGUI.getEnabledRuleCount(kitKey);
        ChestGuiBuilder var10000 = (ChestGuiBuilder)Gui.gui().rows(3);
        String var10001 = KitSettingsGUI.displayKitKey(kitKey);
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)var10000.title(ColorUtil.parse("Kit Settings &8| &f" + var10001))).disableAllInteractions()).create();
        gui.setItem(11, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.NAME_TAG).name(KitSettingsGUI.noItalic("&fKit Name"))).lore(KitSettingsGUI.noItalic("&fClick to rename kit."))).flags(ItemFlag.values())).asGuiItem(e -> {
            player.closeInventory();
            awaitingRename.put(player.getUniqueId(), kitKey);
            player.sendMessage(ColorUtil.parse("&aType the new kit name in chat. &f(Type 'cancel' to abort)"));
            player.sendMessage(ColorUtil.parse("&fNote: Kit names cannot contain spaces."));
        }));
        String string = kitStatus = enabled ? "&a\u25cf KIT ENABLED" : "&c\u25cf KIT DISABLED";
        if (enabled) {
            Component[] componentArray2 = new Component[3];
            componentArray2[0] = KitSettingsGUI.noItalic("&fPlayers can select and queue this kit.");
            componentArray2[1] = Component.empty();
            componentArray = componentArray2;
            componentArray2[2] = KitSettingsGUI.noItalic("&eClick to disable this kit.");
        } else {
            Component[] componentArray3 = new Component[3];
            componentArray3[0] = KitSettingsGUI.noItalic("&fPlayers cannot select or queue this kit.");
            componentArray3[1] = Component.empty();
            componentArray = componentArray3;
            componentArray3[2] = KitSettingsGUI.noItalic("&eClick to enable this kit.");
        }
        Component[] statusLore = componentArray;
        gui.setItem(13, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(enabled ? Material.LIME_CONCRETE : Material.RED_CONCRETE).name(KitSettingsGUI.noItalic(kitStatus))).lore(statusLore)).flags(ItemFlag.values())).asGuiItem(e -> {
            boolean current = ConfigManager.config().getBoolean("kit-settings." + kitKey + ".enabled", true);
            ConfigManager.config().set("kit-settings." + kitKey + ".enabled", (Object)(!current ? 1 : 0));
            Lifea.getInstance().saveConfig();
            player.closeInventory();
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> KitSettingsGUI.open(player, kitKey));
        }));
        gui.setItem(15, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BOOK).name(KitSettingsGUI.noItalic("&fKit Rules &8(" + enabledRules + "/" + KitRulesGUI.getRuleCount() + " enabled)"))).lore(new Component[]{KitSettingsGUI.noItalic("&a" + enabledRules + " rules are active"), KitSettingsGUI.noItalic("&c" + (KitRulesGUI.getRuleCount() - enabledRules) + " rules are inactive"), Component.empty(), KitSettingsGUI.noItalic("&eClick to review and edit rules.")})).flags(ItemFlag.values())).asGuiItem(e -> {
            player.closeInventory();
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> KitRulesGUI.open(player, kitKey));
        }));
        gui.setItem(16, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.CHEST).name(KitSettingsGUI.noItalic("&fReview Kit Items"))).lore(new Component[]{KitSettingsGUI.noItalic("&7Inspect the saved base loadout."), KitSettingsGUI.noItalic("&7Includes inventory, armor, and off-hand."), Component.empty(), KitSettingsGUI.noItalic("&eClick to review kit items.")})).flags(ItemFlag.values())).asGuiItem(e -> {
            player.closeInventory();
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> KitItemsReviewGUI.open(player, kitKey));
        }));
        gui.setItem(22, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(KitSettingsGUI.noItalic("&fGo Back"))).flags(ItemFlag.values())).asGuiItem(e -> player.closeInventory()));
        gui.getFiller().fill(((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name((Component)Component.empty())).asGuiItem());
        gui.open((HumanEntity)player);
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (awaitingRename.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
            String input = event.getMessage().trim();
            String kitKey = awaitingRename.remove(player.getUniqueId());
            if (input.equalsIgnoreCase("cancel")) {
                player.sendMessage(ColorUtil.parse("&fRename cancelled."));
            } else if (input.contains(" ")) {
                player.sendMessage(ColorUtil.parse("&fNote: Kit names cannot contain spaces."));
                awaitingRename.put(player.getUniqueId(), kitKey);
            } else {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                    boolean found = this.renameKitKey(kitKey, input);
                    if (found) {
                        player.sendMessage(ColorUtil.parse("&aKit &e" + kitKey + " &arenamed to &e" + input + "&a."));
                    } else {
                        player.sendMessage(ColorUtil.parse("&cKit &e" + kitKey + " &cnot found."));
                    }
                });
            }
        }
    }

    private boolean renameKitKey(String kitKey, String newName) {
        for (String tier : new String[]{"MCTiers", "PvPTiers", "SubTiers", "CactusTiers"}) {
            List gms = ConfigManager.kitEditor().getList("gamemodes." + tier);
            if (gms == null) continue;
            for (Object o : gms) {
                Map m;
                String name;
                if (!(o instanceof Map) || (name = (String)(m = (Map)o).get("name")) == null || !name.equalsIgnoreCase(kitKey)) continue;
                ConfigManager.config().set("kit-settings." + kitKey + ".display-name", (Object)newName);
                Lifea.getInstance().saveConfig();
                return true;
            }
        }
        return false;
    }

    public static boolean isKitEnabled(String kitKey) {
        return ConfigManager.config().getBoolean("kit-settings." + kitKey + ".enabled", true);
    }

    public static void clearPending(UUID uuid) {
        awaitingRename.remove(uuid);
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }

    private static String displayKitKey(String kitKey) {
        return kitKey != null && kitKey.regionMatches(true, 0, "BedPvP", 0, "BedPvP".length()) ? "&x&f&b&0&0&0&0&l\u0299\u1d07\u1d05 \u1d18\u1d20\u1d18&f" + kitKey.substring("BedPvP".length()) : kitKey;
    }
}

