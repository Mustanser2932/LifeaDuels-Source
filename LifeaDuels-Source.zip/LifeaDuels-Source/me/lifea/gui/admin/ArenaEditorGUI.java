/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.format.TextDecoration
 *  net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
 *  org.bukkit.Bukkit
 *  org.bukkit.Keyed
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.Tag
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.data.type.Bed
 *  org.bukkit.block.data.type.Bed$Part
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.gui.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.snapshot.ArenaSnapshotManager;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Bed;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.plugin.Plugin;

public class ArenaEditorGUI
implements Listener {
    private static final int KITS_PER_PAGE = 18;
    private static final Map<UUID, String> awaitingRename = new HashMap<UUID, String>();
    private static final Map<UUID, String> awaitingClone = new HashMap<UUID, String>();
    private static final Map<UUID, String> awaitingBuildLimit = new HashMap<UUID, String>();
    private static final Set<String> QUEUE_ONLY_KITS = Set.of("LT-Vanilla-Sub", "HT-Vanilla-Sub");

    public static void open(Player player, String arenaName) {
        Arena arena = ArenaManager.get(arenaName);
        if (arena == null) {
            player.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + " &cnot found."));
        } else {
            boolean regenEnabled = arena.isRegeneration();
            boolean enabled = arena.isEnabled();
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ArenaEditorGUI.legacy("\u1d07\u1d05\u026a\u1d1b\u026a\u0274\u0262: " + arenaName))).rows(3)).disableAllInteractions()).create();
            gui.setDefaultTopClickAction(e -> {
                HumanEntity patt0$temp = e.getWhoClicked();
                if (patt0$temp instanceof Player) {
                    Player p = (Player)patt0$temp;
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f);
                }
            });
            gui.setItem(10, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.NAME_TAG).name(ArenaEditorGUI.noItalic("&#FB0000\u270f &f\u1d00\u0280\u1d07\u0274\u1d00 \u0274\u1d00\u1d0d\u1d07: &#FB0000" + arenaName))).lore(ArenaEditorGUI.noItalic("&7\u270f \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u0280\u1d07\u0274\u1d00\u1d0d\u1d07 \u1d1b\u029c\u026as \u1d00\u0280\u1d07\u0274\u1d00"), ArenaEditorGUI.noItalic("&8\u26a0 \u0274\u1d00\u1d0d\u1d07s \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u1d04\u1d0f\u0274\u1d1b\u1d00\u026a\u0274 s\u1d18\u1d00\u1d04\u1d07s"))).flags(ItemFlag.values())).asGuiItem(e -> {
                player.closeInventory();
                awaitingRename.put(player.getUniqueId(), arenaName);
                player.sendMessage(ColorUtil.parse("&fType the new &#FB0000arena name&f in chat. &f(Type &#FB0000'cancel'&f to abort)"));
                player.sendMessage(ColorUtil.parse("&fNote: &#FB0000Arena names&f cannot contain spaces."));
            }));
            boolean hasSnapshot = ArenaSnapshotManager.hasSchematic(arenaName);
            gui.setItem(11, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.FILLED_MAP).name(ArenaEditorGUI.noItalic("&#FB0000\ud83d\uddfa &f\u1d04\u029f\u1d0f\u0274\u1d07 \u1d00\u0280\u1d07\u0274\u1d00"))).lore(ArenaEditorGUI.noItalic(hasSnapshot ? "&a\u2714 s\u1d04\u029c\u1d07\u1d0d\u1d00\u1d1b\u026a\u1d04 \ua730\u1d0f\u1d1c\u0274\u1d05!" : "&c\u2718 \u0274\u1d0f s\u1d04\u029c\u1d07\u1d0d\u1d00\u1d1b\u026a\u1d04 s\u1d00\u1d20\u1d07\u1d05 \u028f\u1d07\u1d1b!"), ArenaEditorGUI.noItalic("&7\ud83d\udccc \u1d18\u1d00s\u1d1b\u1d07s \u0299\u029f\u1d0f\u1d04\u1d0bs \u1d04\u1d07\u0274\u1d1b\u1d07\u0280\u1d07\u1d05 \u1d0f\u0274 \u028f\u1d0f\u1d1c\u0280 \u1d18\u1d0fs\u026a\u1d1b\u026a\u1d0f\u0274"), ArenaEditorGUI.noItalic("&7\ud83d\udcdd \u028f\u1d0f\u1d1c \u1d21\u026a\u029f\u029f \u0299\u1d07 \u1d00s\u1d0b\u1d07\u1d05 \ua730\u1d0f\u0280 \u1d00 \u0274\u1d07\u1d21 \u0274\u1d00\u1d0d\u1d07"))).flags(ItemFlag.values())).asGuiItem(e -> {
                if (!hasSnapshot) {
                    player.sendMessage(ColorUtil.parse("&f\u0455\u1d00\u1d20\u1d07 \u1d1b\u029c\u1d07 &#FB0000\u1d00\u0280\u1d07\u0274\u1d00&f \u1d1b\u1d0f \u1d1b\u029c\u1d07 \u1d05\u1d00\u1d1b\u1d00\u0299\u1d00\u0455\u1d07 \ua730\u026a\u0280\u0455\u1d1b."));
                } else {
                    player.closeInventory();
                    awaitingClone.put(player.getUniqueId(), arenaName);
                    player.sendMessage(ColorUtil.parse("&fType the new &#FB0000arena name&f in chat. &f(Type &#FB0000'cancel'&f to abort)"));
                    player.sendMessage(ColorUtil.parse("&fNote: &#FB0000Arena names&f cannot contain spaces."));
                }
            }));
            gui.setItem(12, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(enabled ? Material.LIME_CONCRETE : Material.RED_CONCRETE).name(ArenaEditorGUI.noItalic(enabled ? "&a\u2714 \u1d00\u0280\u1d07\u0274\u1d00 \u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05" : "&c\u2718 \u1d00\u0280\u1d07\u0274\u1d00 \u1d05\u026as\u1d00\u0299\u029f\u1d07\u1d05"))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udd04 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d1b\u1d0f\u0262\u0262\u029f\u1d07 \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u026a\u029f\u026a\u1d1b\u028f"), ArenaEditorGUI.noItalic("&8\u26a0 \u1d1b\u026a\u1d18: s\u1d07\u1d1b \u0299\u1d0f\u1d1b\u029c s\u1d18\u1d00\u1d21\u0274s \ua730\u026a\u0280s\u1d1b"))).flags(ItemFlag.values())).asGuiItem(e -> {
                arena.setEnabled(!enabled);
                ArenaManager.saveArena(arena);
                ArenaEditorGUI.open(player, arenaName);
            }));
            gui.setItem(13, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.RECOVERY_COMPASS).name(ArenaEditorGUI.noItalic("&#FB0000\ud83e\udded \u1d00\u0280\u1d07\u0274\u1d00 \u0280\u1d07\u0262\u026a\u1d0f\u0274"))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udcd0 \u1d07\u1d05\u026a\u1d1b s\u1d18\u1d00\u1d21\u0274s & \u0299\u1d0f\u1d1c\u0274\u1d05\u1d00\u0280\u026a\u1d07s"), ArenaEditorGUI.noItalic("&8\u26a0 \u0280\u1d07\u01eb\u1d1c\u026a\u0280\u1d07\u1d05 \ua730\u1d0f\u0280 \u1d00\u0280\u1d07\u0274\u1d00 \u1d1b\u1d0f \ua730\u1d1c\u0274\u1d04\u1d1b\u026a\u1d0f\u0274"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.openRegion(player, arenaName)));
            gui.setItem(14, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(regenEnabled ? Material.LIME_CONCRETE : Material.RED_CONCRETE).name(ArenaEditorGUI.noItalic("&#FB0000\ud83d\udd01 \u1d00\u0280\u1d07\u0274\u1d00 \u0280\u1d07\u0262\u1d07\u0274\u1d07\u0280\u1d00\u1d1b\u026a\u1d0f\u0274: " + (regenEnabled ? "&a\u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05" : "&c\u1d05\u026as\u1d00\u0299\u029f\u1d07\u1d05")))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udd04 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d1b\u1d0f\u0262\u0262\u029f\u1d07 \u0299\u029f\u1d0f\u1d04\u1d0b \u0280\u1d07\u0262\u1d07\u0274\u1d07\u0280\u1d00\u1d1b\u026a\u1d0f\u0274"), ArenaEditorGUI.noItalic("&8\u26a0 \u0280\u1d07\u01eb\u1d1c\u026a\u0280\u1d07s \u1d00 s\u1d00\u1d20\u1d07\u1d05 s\u1d04\u029c\u1d07\u1d0d\u1d00\u1d1b\u026a\u1d04"))).flags(ItemFlag.values())).asGuiItem(e -> {
                arena.setRegeneration(!regenEnabled);
                ArenaManager.saveArena(arena);
                ArenaEditorGUI.open(player, arenaName);
            }));
            gui.setItem(15, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.RESPAWN_ANCHOR).name(ArenaEditorGUI.noItalic("&#FB0000\ud83d\udcbe s\u1d00\u1d20\u1d07 s\u1d04\u029c\u1d07\u1d0d\u1d00\u1d1b\u026a\u1d04"))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udce6 s\u0274\u1d00\u1d18s\u029c\u1d0f\u1d1bs \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b \u1d00\u0280\u1d07\u0274\u1d00 \u0299\u029f\u1d0f\u1d04\u1d0bs"), ArenaEditorGUI.noItalic("&7\ud83d\udd01 \u1d1cs\u1d07\u1d05 \ua730\u1d0f\u0280 \u0280\u1d07\u0262\u1d07\u0274\u1d07\u0280\u1d00\u1d1b\u026a\u1d0f\u0274 \u1d00\ua730\u1d1b\u1d07\u0280 \u1d0d\u1d00\u1d1b\u1d04\u029c\u1d07s"), ArenaEditorGUI.noItalic("&8\u26a0 \u0280\u1d07\u01eb\u1d1c\u026a\u0280\u1d07s \u1d18\u1d0fs1 & \u1d18\u1d0fs2 \u1d1b\u1d0f \u0299\u1d07 s\u1d07\u1d1b"))).flags(ItemFlag.values())).asGuiItem(e -> {
                if (!arena.isRegionSet()) {
                    player.sendMessage(ColorUtil.parse("&fSet pos1 and pos2 first."));
                } else {
                    player.sendMessage(ColorUtil.parse("&fSaving arena schematic..."));
                    ((CompletableFuture)ArenaSnapshotManager.captureArena(arena).thenAccept(v -> Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> player.sendMessage(ColorUtil.parse("&aSaved arena schematic for &e" + arenaName + "&a."))))).exceptionally(ex -> {
                        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                            String var10001 = ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage();
                            player.sendMessage(ColorUtil.parse("&cFailed to save schematic: &f" + var10001));
                        });
                        return null;
                    });
                }
            }));
            gui.setItem(16, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BUNDLE).name(ArenaEditorGUI.noItalic("&#FB0000\u2694 \u1d0b\u026a\u1d1b \u1d00\u029f\u029f\u1d0f\u1d21\u1d00\u0274\u1d04\u1d07"))).lore(ArenaEditorGUI.noItalic("&7\u2694 \u1d04\u1d0f\u0274\u1d1b\u0280\u1d0f\u029f \u1d21\u029c\u026a\u1d04\u029c \u1d0b\u026a\u1d1bs \u1d04\u1d00\u0274 \u0299\u1d07 \u1d18\u029f\u1d00\u028f\u1d07\u1d05"), ArenaEditorGUI.noItalic("&7\ud83d\uddfa \u1d0f\u0274 \u1d1b\u029c\u026as \u1d00\u0280\u1d07\u0274\u1d00"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.openKitAllowance(player, arenaName, 1)));
            gui.open((HumanEntity)player);
        }
    }

    private static void openRegion(Player player, String arenaName) {
        try {
            Arena arena = ArenaManager.get(arenaName);
            if (arena == null) {
                player.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + " &cnot found."));
                return;
            }
            Location spawn1 = arena.getSpawn1();
            Location spawn2 = arena.getSpawn2();
            String blueSet = spawn1 != null ? ArenaEditorGUI.formatLoc(spawn1) : "&cNot set";
            String redSet = spawn2 != null ? ArenaEditorGUI.formatLoc(spawn2) : "&cNot set";
            String pos1Set = arena.isRegionSet() ? arena.getRegionMinX() + ", " + arena.getRegionMinY() + ", " + arena.getRegionMinZ() : "&cNot set";
            String pos2Set = arena.isRegionSet() ? arena.getRegionMaxX() + ", " + arena.getRegionMaxY() + ", " + arena.getRegionMaxZ() : "&cNot set";
            String blueBedSet = ArenaEditorGUI.formatBlock(arena.getBlueBed());
            String redBedSet = ArenaEditorGUI.formatBlock(arena.getRedBed());
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ArenaEditorGUI.legacy("&f\u1d00\u0280\u1d07\u0274\u1d00 \u0280\u1d07\u0262\u026a\u1d0f\u0274: &f" + arenaName))).rows(3)).disableAllInteractions()).create();
            gui.setDefaultTopClickAction(e -> {
                HumanEntity patt0$temp = e.getWhoClicked();
                if (patt0$temp instanceof Player) {
                    Player p = (Player)patt0$temp;
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f);
                }
            });
            gui.setItem(10, ArenaEditorGUI.spawnItem(Material.BLUE_CONCRETE, "&9\ud83d\udd35 \u0299\u029f\u1d1c\u1d07 \u1d18\u029f\u1d00\u028f\u1d07\u0280 s\u1d18\u1d00\u1d21\u0274", blueSet, player, arenaName, "spawn1"));
            gui.setItem(12, ArenaEditorGUI.spawnItem(Material.RED_CONCRETE, "&c\ud83d\udd34 \u0280\u1d07\u1d05 \u1d18\u029f\u1d00\u028f\u1d07\u0280 s\u1d18\u1d00\u1d21\u0274", redSet, player, arenaName, "spawn2"));
            gui.setItem(13, ArenaEditorGUI.buildLimitItem(player, arenaName));
            gui.setItem(14, ArenaEditorGUI.cornerItem(Material.YELLOW_CONCRETE, "&e\ud83d\udccd \u1d04\u1d0f\u0280\u0274\u1d07\u0280 1", pos1Set, player, arenaName, "pos1"));
            gui.setItem(16, ArenaEditorGUI.cornerItem(Material.ORANGE_CONCRETE, "&6\ud83d\udccd \u1d04\u1d0f\u0280\u0274\u1d07\u0280 2", pos2Set, player, arenaName, "pos2"));
            gui.setItem(19, ArenaEditorGUI.bedItem(Material.BLUE_BED, "&9\ud83d\udecf \u0299\u029f\u1d1c\u1d07 \u029c\u1d0f\u1d0d\u1d07 \u0299\u1d07\u1d05", blueBedSet, player, arenaName, true));
            gui.setItem(25, ArenaEditorGUI.bedItem(Material.RED_BED, "&c\ud83d\udecf \u0280\u1d07\u1d05 \u029c\u1d0f\u1d0d\u1d07 \u0299\u1d07\u1d05", redBedSet, player, arenaName, false));
            String centerSet = arena.hasCenter() ? ArenaEditorGUI.formatLoc(arena.getCenter()) : "&7\u1d00\u1d1c\u1d1b\u1d0f (\u0280\u1d07\u0262\u026a\u1d0f\u0274 \u1d04\u1d07\u0274\u1d1b\u1d07\u0280)";
            gui.setItem(21, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.TARGET).name(ArenaEditorGUI.noItalic("&#FB0000\ud83c\udfaf \u1d00\u0280\u1d07\u0274\u1d00 \u1d04\u1d07\u0274\u1d1b\u1d07\u0280"))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udccd " + centerSet), ArenaEditorGUI.noItalic("&7\ud83d\uddb1 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f s\u1d07\u1d1b \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280 \u1d18\u1d0fs\u026a\u1d1b\u026a\u1d0f\u0274"), ArenaEditorGUI.noItalic("&7\u21e7 s\u029c\u026a\ua730\u1d1b-\u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u0280\u1d07s\u1d07\u1d1b \u1d1b\u1d0f \u1d00\u1d1c\u1d1b\u1d0f (\u0280\u1d07\u0262\u026a\u1d0f\u0274 \u1d04\u1d07\u0274\u1d1b\u1d07\u0280)"), ArenaEditorGUI.noItalic("&8\u2139 \u1d1cs\u1d07\u1d05 \u1d00s \u1d1b\u029c\u1d07 \u1d21\u1d0f\u0280\u029f\u1d05 \u0299\u1d0f\u0280\u1d05\u1d07\u0280 \u1d04\u1d07\u0274\u1d1b\u1d07\u0280"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.runSafely(player, "set arena center", () -> {
                Arena a = ArenaManager.get(arenaName);
                if (a == null) {
                    player.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + " &cnot found."));
                } else {
                    if (player.isSneaking()) {
                        a.setCenter(null);
                        ArenaManager.saveArena(a);
                        player.sendMessage(ColorUtil.parse("&aReset the arena center to auto (region center)."));
                    } else {
                        a.setCenter(player.getLocation());
                        ArenaManager.saveArena(a);
                        player.sendMessage(ColorUtil.parse("&aSet the arena center &7(" + ArenaEditorGUI.formatLoc(player.getLocation()) + "&7)&a."));
                    }
                    ArenaEditorGUI.openRegion(player, arenaName);
                }
            })));
            gui.setItem(22, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ArenaEditorGUI.noItalic("&c\u00ab &f\u0262\u1d0f \u0299\u1d00\u1d04\u1d0b"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.open(player, arenaName)));
            gui.open((HumanEntity)player);
        }
        catch (Throwable t) {
            Lifea.getInstance().getLogger().log(Level.SEVERE, "Failed to open the arena region editor for '" + arenaName + "'", t);
            String var10001 = t.getMessage() == null ? t.toString() : t.getMessage();
            player.sendMessage(ColorUtil.parse("&cFailed to open the arena region editor: &f" + var10001));
        }
    }

    private static GuiItem spawnItem(Material mat, String name, String locStr, Player player, String arenaName, String key) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(mat).name(ArenaEditorGUI.noItalic(name))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udccd " + locStr), ArenaEditorGUI.noItalic("&7\ud83d\uddb1 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f s\u1d07\u1d1b \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280 \u1d18\u1d0fs\u026a\u1d1b\u026a\u1d0f\u0274"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.runSafely(player, "set spawn", () -> {
            Arena arena = ArenaManager.get(arenaName);
            if (arena == null) {
                player.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + " &cnot found."));
            } else {
                Location loc = player.getLocation();
                if (key.equals("spawn1")) {
                    arena.setSpawn1(loc);
                } else {
                    arena.setSpawn2(loc);
                }
                if (arena.getSpawn1() != null && arena.getSpawn2() != null && !arena.isEnabled()) {
                    arena.setEnabled(true);
                }
                ArenaManager.saveArena(arena);
                player.sendMessage(ColorUtil.parse("&aSet the " + (key.equals("spawn1") ? "blue" : "red") + " player spawn."));
                ArenaEditorGUI.openRegion(player, arenaName);
            }
        }));
    }

    private static GuiItem cornerItem(Material mat, String name, String locStr, Player player, String arenaName, String corner) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(mat).name(ArenaEditorGUI.noItalic(name))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udcd0 " + locStr), ArenaEditorGUI.noItalic("&7\ud83d\uddb1 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f s\u1d07\u1d1b \u1d1b\u1d0f \u028f\u1d0f\u1d1c\u0280 \u1d18\u1d0fs\u026a\u1d1b\u026a\u1d0f\u0274"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.runSafely(player, "set corner", () -> {
            Arena arena = ArenaManager.get(arenaName);
            if (arena == null) {
                player.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + " &cnot found."));
            } else {
                Location loc = player.getLocation();
                int x = (int)loc.getX();
                int y = (int)loc.getY();
                int z = (int)loc.getZ();
                if (!arena.isRegionSet()) {
                    arena.setRegion(x, y, z, x, y, z);
                } else if (corner.equals("pos1")) {
                    arena.setRegion(x, y, z, arena.getRegionMaxX(), arena.getRegionMaxY(), arena.getRegionMaxZ());
                } else {
                    arena.setRegion(arena.getRegionMinX(), arena.getRegionMinY(), arena.getRegionMinZ(), x, y, z);
                }
                ArenaManager.saveArena(arena);
                player.sendMessage(ColorUtil.parse("&aSet " + (corner.equals("pos1") ? "corner 1" : "corner 2") + " (" + x + ", " + y + ", " + z + ")."));
                ArenaEditorGUI.openRegion(player, arenaName);
            }
        }));
    }

    private static GuiItem bedItem(Material mat, String name, String locStr, Player player, String arenaName, boolean blue) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(mat).name(ArenaEditorGUI.noItalic(name))).lore(ArenaEditorGUI.noItalic("&7\ud83d\udccd " + locStr), ArenaEditorGUI.noItalic("&7\ud83d\uddb1 Look at the placed bed, then click"), ArenaEditorGUI.noItalic("&8BedWars objective \u2014 players cannot place beds"))).flags(ItemFlag.values())).asGuiItem(e -> {
            Arena arena = ArenaManager.get(arenaName);
            Block bed = player.getTargetBlockExact(8);
            if (arena != null) {
                if (bed != null && Tag.BEDS.isTagged((Keyed)bed.getType())) {
                    Block foot = ArenaEditorGUI.getBedFoot(bed);
                    if (!arena.isInside(foot.getLocation())) {
                        player.sendMessage(ColorUtil.parse("&cThe selected bed must be inside this arena region."));
                    } else {
                        if (blue) {
                            arena.setBlueBed(foot);
                        } else {
                            arena.setRedBed(foot);
                        }
                        ArenaManager.saveArena(arena);
                        player.sendMessage(ColorUtil.parse("&aSet the " + (blue ? "blue" : "red") + " home bed."));
                        ArenaEditorGUI.openRegion(player, arenaName);
                    }
                } else {
                    player.sendMessage(ColorUtil.parse("&cLook directly at a placed bed within 8 blocks, then click again."));
                }
            }
        });
    }

    private static GuiItem buildLimitItem(Player player, String arenaName) {
        Arena arena = ArenaManager.get(arenaName);
        if (arena == null) {
            return null;
        }
        Integer limit = arena.getBuildLimitY();
        Object state = limit != null ? "&7Current: &e" + limit : "&7No limit (uses arena region max height)";
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.IRON_PICKAXE).name(ArenaEditorGUI.noItalic("&#FB0000\u26cf \u0299\u1d1c\u026a\u029f\u1d05 \u029f\u026a\u1d0d\u026a\u1d1b"))).lore(ArenaEditorGUI.noItalic("&7" + (String)state), ArenaEditorGUI.noItalic("&7\ud83d\uddb1 \u1d04\u029f\u026a\u1d04\u1d0b, then type the max build Y level in chat"), ArenaEditorGUI.noItalic("&8\u2139 \u0299\u029f\u1d0f\u1d04\u1d0bs \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u0299\u1d07 \u1d18\u029f\u1d00\u1d04\u1d07\u1d05 \u1d00\u0299\u1d0f\u1d20\u1d07 \u1d1b\u029c\u026as \u028f"))).flags(ItemFlag.values())).asGuiItem(e -> {
            if (player.isSneaking()) {
                ArenaEditorGUI.runSafely(player, "reset build limit", () -> {
                    Arena a = ArenaManager.get(arenaName);
                    if (a != null) {
                        a.setBuildLimitY(null);
                        ArenaManager.saveArena(a);
                        player.sendMessage(ColorUtil.parse("&aReset the build limit (no ceiling)."));
                        ArenaEditorGUI.openRegion(player, arenaName);
                    }
                });
            } else {
                player.closeInventory();
                awaitingBuildLimit.put(player.getUniqueId(), arenaName);
                player.sendMessage(ColorUtil.parse("&fType the build limit &#FB0000(Y level)&f in chat. Type &#FB0000'cancel'&f to abort."));
            }
        });
    }

    private static Block getBedFoot(Block bed) {
        Bed data = (Bed)bed.getBlockData();
        return data.getPart() == Bed.Part.FOOT ? bed : bed.getRelative(data.getFacing().getOppositeFace());
    }

    private static void runSafely(Player player, String action, Runnable runnable) {
        try {
            runnable.run();
        }
        catch (Throwable t) {
            Lifea.getInstance().getLogger().log(Level.SEVERE, "Arena editor action failed (" + action + ")", t);
            player.sendMessage(ColorUtil.parse("&cThat action failed (" + action + "): &f" + (t.getMessage() == null ? t.toString() : t.getMessage())));
        }
    }

    private static void openKitAllowance(Player player, String arenaName, int page) {
        List<String> allKits = ArenaEditorGUI.getAllPlayableKits();
        int totalPages = Math.max(1, (int)Math.ceil((double)allKits.size() / 18.0));
        int finalPage = page = Math.max(1, Math.min(page, totalPages));
        Arena arena = ArenaManager.get(arenaName);
        ArrayList allowed = arena != null ? arena.getAllowedKits() : new ArrayList();
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ArenaEditorGUI.legacy("\u1d0b\u026a\u1d1b \u1d00\u029f\u029f\u1d0f\u1d21\u1d00\u0274\u1d04\u1d07: " + arenaName + "&#FB0000 " + page + "/" + totalPages))).rows(3)).disableAllInteractions()).create();
        gui.setDefaultTopClickAction(e -> {
            HumanEntity patt0$temp = e.getWhoClicked();
            if (patt0$temp instanceof Player) {
                Player p = (Player)patt0$temp;
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f);
            }
        });
        int start = (page - 1) * 18;
        int end = Math.min(start + 18, allKits.size());
        for (int i = start; i < end; ++i) {
            String kit = allKits.get(i);
            boolean bound = allowed.stream().anyMatch(k -> k.equalsIgnoreCase(kit));
            Object displayName = QUEUE_ONLY_KITS.contains(kit) ? kit + " &e[QUEUE ONLY]" : kit;
            gui.setItem(i - start, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(bound ? Material.LIME_WOOL : Material.RED_WOOL).name(ArenaEditorGUI.noItalic((bound ? "&8[&a\u2714&8] &f" : "&8[&c\u2718&8] &f") + (String)displayName))).lore(ArenaEditorGUI.noItalic(bound ? "&a\u2139 \u1d1b\u029c\u026a\u0455 \u1d0b\u026a\u1d1b \u026a\u0455 \u1d00\u029f\u029f\u1d0f\u1d21\u1d07\u1d05" : "&c\u2139 \u1d1b\u029c\u026a\u0455 \u1d0b\u026a\u1d1b \u026a\u0455 \u0274\u1d0f\u1d1b \u1d00\u029f\u029f\u1d0f\u1d21\u1d07\u1d05"), ArenaEditorGUI.noItalic(bound ? "&f\u2139 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d05\u026a\u0455\u1d00\u029f\u029f\u1d0f\u1d21." : "&f\u2139 \u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d00\u029f\u029f\u1d0f\u1d21."))).flags(ItemFlag.values())).asGuiItem(e -> {
                Arena a = ArenaManager.get(arenaName);
                if (a != null) {
                    ArrayList<String> current = new ArrayList<String>(a.getAllowedKits());
                    if (current.stream().anyMatch(k -> k.equalsIgnoreCase(kit))) {
                        current.removeIf(k -> k.equalsIgnoreCase(kit));
                    } else {
                        current.add(kit);
                    }
                    a.setAllowedKits(current);
                    ArenaManager.saveArena(a);
                    ArenaEditorGUI.openKitAllowance(player, arenaName, finalPage);
                }
            }));
        }
        gui.setItem(22, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ArenaEditorGUI.noItalic("&c\u00ab &f\u0262\u1d0f \u0299\u1d00\u1d04\u1d0b"))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.open(player, arenaName)));
        if (page > 1) {
            gui.setItem(18, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ArenaEditorGUI.noItalic("&#FB0000\u00ab \u1d18\u0280\u1d07\u1d20\u026a\u1d0f\u1d1cs \u1d18\u1d00\u0262\u1d07"))).lore(ArenaEditorGUI.noItalic("&7\u25c0 \u0262\u1d0f \u1d1b\u1d0f \u1d18\u1d00\u0262\u1d07 " + (finalPage - 1)))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.openKitAllowance(player, arenaName, finalPage - 1)));
        }
        if (page < totalPages) {
            gui.setItem(26, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ArenaEditorGUI.noItalic("&#FB0000\u0274\u1d07x\u1d1b \u1d18\u1d00\u0262\u1d07 \u00bb"))).lore(ArenaEditorGUI.noItalic("&7\u25b6 \u0262\u1d0f \u1d1b\u1d0f \u1d18\u1d00\u0262\u1d07 " + (finalPage + 1)))).flags(ItemFlag.values())).asGuiItem(e -> ArenaEditorGUI.openKitAllowance(player, arenaName, finalPage + 1)));
        }
        gui.open((HumanEntity)player);
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        boolean rename = awaitingRename.containsKey(player.getUniqueId());
        boolean clone = awaitingClone.containsKey(player.getUniqueId());
        if (rename || clone) {
            String arenaName;
            event.setCancelled(true);
            String input = event.getMessage().trim();
            String string = arenaName = rename ? awaitingRename.remove(player.getUniqueId()) : awaitingClone.remove(player.getUniqueId());
            if (input.equalsIgnoreCase("cancel")) {
                player.sendMessage(ColorUtil.parse("&fCancelled."));
            } else if (input.contains(" ")) {
                player.sendMessage(ColorUtil.parse("&fArena names cannot contain spaces."));
                if (rename) {
                    awaitingRename.put(player.getUniqueId(), arenaName);
                } else {
                    awaitingClone.put(player.getUniqueId(), arenaName);
                }
            } else {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                    if (ArenaManager.exists(input)) {
                        player.sendMessage(ColorUtil.parse("&fAn arena named &6" + input + "&f already exists."));
                        if (rename) {
                            awaitingRename.put(player.getUniqueId(), arenaName);
                        } else {
                            awaitingClone.put(player.getUniqueId(), arenaName);
                        }
                    } else {
                        Arena arena = ArenaManager.get(arenaName);
                        if (arena != null) {
                            if (rename) {
                                if (!ArenaManager.rename(arenaName, input)) {
                                    player.sendMessage(ColorUtil.parse("&cFailed to rename arena. Try again."));
                                    awaitingRename.put(player.getUniqueId(), arenaName);
                                } else {
                                    player.sendMessage(ColorUtil.parse("&f\u2139 Arena &6" + arenaName + "&f renamed to &6" + input + "&f."));
                                    ArenaEditorGUI.open(player, input);
                                }
                            } else {
                                Location playerLoc = player.getLocation().clone();
                                player.sendMessage(ColorUtil.parse("&fCloning arena schematic..."));
                                ((CompletableFuture)((CompletableFuture)ArenaSnapshotManager.loadSchematicInfo(arenaName).thenCompose(snapOpt -> snapOpt.isEmpty() ? CompletableFuture.failedFuture(new IllegalStateException("No schematic for " + arenaName)) : ArenaSnapshotManager.pasteCenteredAtPlayer(arenaName, playerLoc).thenApply(pasteMin -> new ClonePasteResult((Location)pasteMin, (ArenaSnapshotManager.SnapshotInfo)snapOpt.get())))).thenAccept(result -> Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                                    int dz;
                                    int dy;
                                    Location pasteMin = result.pasteMin();
                                    ArenaSnapshotManager.SnapshotInfo snap = result.info();
                                    Arena newArena = ArenaManager.create(input);
                                    newArena.setEnabled(true);
                                    newArena.setRegeneration(arena.isRegeneration());
                                    newArena.setAllowedKits(new ArrayList<String>(arena.getAllowedKits()));
                                    newArena.setBuildLimitY(arena.getBuildLimitY());
                                    int newMinX = pasteMin.getBlockX();
                                    int newMinY = pasteMin.getBlockY();
                                    int newMinZ = pasteMin.getBlockZ();
                                    newArena.setRegion(newMinX, newMinY, newMinZ, newMinX + snap.sizeX() - 1, newMinY + snap.sizeY() - 1, newMinZ + snap.sizeZ() - 1);
                                    if (arena.getSpawn1() != null) {
                                        Location s1 = arena.getSpawn1();
                                        newArena.setSpawn1(new Location(pasteMin.getWorld(), (double)newMinX + (s1.getX() - (double)snap.originMinX()), (double)newMinY + (s1.getY() - (double)snap.originMinY()), (double)newMinZ + (s1.getZ() - (double)snap.originMinZ()), s1.getYaw(), s1.getPitch()));
                                    }
                                    if (arena.getSpawn2() != null) {
                                        Location s2 = arena.getSpawn2();
                                        newArena.setSpawn2(new Location(pasteMin.getWorld(), (double)newMinX + (s2.getX() - (double)snap.originMinX()), (double)newMinY + (s2.getY() - (double)snap.originMinY()), (double)newMinZ + (s2.getZ() - (double)snap.originMinZ()), s2.getYaw(), s2.getPitch()));
                                    }
                                    if (arena.hasBedObjectives()) {
                                        int dx = newMinX - snap.originMinX();
                                        dy = newMinY - snap.originMinY();
                                        dz = newMinZ - snap.originMinZ();
                                        newArena.setBedObjectives(arena.getBlueBedX() + dx, arena.getBlueBedY() + dy, arena.getBlueBedZ() + dz, arena.getRedBedX() + dx, arena.getRedBedY() + dy, arena.getRedBedZ() + dz);
                                        newArena.setBlueBedFacing(arena.getBlueBedFacing());
                                        newArena.setRedBedFacing(arena.getRedBedFacing());
                                    }
                                    if (arena.hasCenter()) {
                                        int dx = newMinX - snap.originMinX();
                                        dy = newMinY - snap.originMinY();
                                        dz = newMinZ - snap.originMinZ();
                                        newArena.setCenter(arena.getCenterX() + (double)dx, arena.getCenterY() + (double)dy, arena.getCenterZ() + (double)dz);
                                    }
                                    ((CompletableFuture)ArenaSnapshotManager.cloneSchematic(arenaName, input).thenAccept(v -> Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                                        ArenaManager.saveArena(newArena);
                                        player.sendMessage(ColorUtil.parse("&aCloned arena &e" + arenaName + " &ato &e" + input + "&a."));
                                        ArenaEditorGUI.open(player, input);
                                    }))).exceptionally(ex -> {
                                        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                                            String var10001 = ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage();
                                            player.sendMessage(ColorUtil.parse("&cFailed to clone schematic file: &f" + var10001));
                                        });
                                        return null;
                                    });
                                }))).exceptionally(ex -> {
                                    Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                                        String var10001 = ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage();
                                        player.sendMessage(ColorUtil.parse("&cFailed to clone arena: &f" + var10001));
                                    });
                                    return null;
                                });
                            }
                        }
                    }
                });
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerChatBuildLimit(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String arenaName = awaitingBuildLimit.remove(player.getUniqueId());
        if (arenaName != null) {
            event.setCancelled(true);
            String input = event.getMessage().trim();
            if (input.equalsIgnoreCase("cancel")) {
                player.sendMessage(ColorUtil.parse("&fCancelled."));
            } else {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                    try {
                        int maxWorldY;
                        int y = Integer.parseInt(input);
                        Arena arena = ArenaManager.get(arenaName);
                        if (arena == null) {
                            player.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + " &cnot found."));
                            return;
                        }
                        World w = Bukkit.getWorld((String)arena.getWorld());
                        int n = maxWorldY = w != null ? w.getMaxHeight() : 320;
                        if (y >= arena.getRegionMinY() && y <= maxWorldY) {
                            arena.setBuildLimitY(y);
                            ArenaManager.saveArena(arena);
                            player.sendMessage(ColorUtil.parse("&aBuild limit set to &e" + y + "&a."));
                            ArenaEditorGUI.openRegion(player, arenaName);
                        } else {
                            int var10001 = arena.getRegionMinY();
                            player.sendMessage(ColorUtil.parse("&cBuild limit must be between &e" + var10001 + " &cand &e" + maxWorldY + "&c."));
                        }
                    }
                    catch (NumberFormatException var7) {
                        player.sendMessage(ColorUtil.parse("&cInvalid build limit. Use a whole number."));
                    }
                });
            }
        }
    }

    private static List<String> getAllPlayableKits() {
        ArrayList<String> kits = new ArrayList<String>(GamemodeRegistry.getEnabledKitKeys());
        kits.add("CUSTOM_KITS");
        return kits;
    }

    private static String formatLoc(Location loc) {
        return String.format("%.1f, %.1f, %.1f", loc.getX(), loc.getY(), loc.getZ());
    }

    private static String formatBlock(Block block) {
        return block != null ? block.getX() + ", " + block.getY() + ", " + block.getZ() : "&cNot set";
    }

    private static Component legacy(String text) {
        return ((TextComponent)Component.empty().decoration(TextDecoration.ITALIC, false)).append((Component)LegacyComponentSerializer.legacySection().deserialize(text.replace("&", "\u00a7")));
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }

    public static void clearPending(UUID uuid) {
        awaitingRename.remove(uuid);
        awaitingClone.remove(uuid);
        awaitingBuildLimit.remove(uuid);
    }

    private record ClonePasteResult(Location pasteMin, ArenaSnapshotManager.SnapshotInfo info) {
    }
}

