/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.admin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.snapshot.ArenaSnapshotManager;
import me.lifea.gui.admin.ArenaEditorGUI;
import me.lifea.kit.KitRuleManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public final class ArenaListGUI {
    private static final int ARENAS_PER_PAGE = 36;

    private ArenaListGUI() {
    }

    public static void open(Player player) {
        ArenaListGUI.open(player, 1);
    }

    private static void open(Player player, int page) {
        ArrayList<Arena> arenas = new ArrayList<Arena>(ArenaManager.getAll());
        arenas.sort(Comparator.comparing(Arena::getName, String.CASE_INSENSITIVE_ORDER));
        int ready = (int)arenas.stream().filter(ArenaListGUI::isReady).count();
        int inUse = (int)arenas.stream().filter(Arena::isInUse).count();
        int disabled = (int)arenas.stream().filter(arenax -> !arenax.isEnabled()).count();
        int totalPages = Math.max(1, (int)Math.ceil((double)arenas.size() / 36.0));
        int currentPage = page = Math.max(1, Math.min(page, totalPages));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&#FB0000\u1d00\u0280\u1d07\u0274\u1d00 \u1d05\u1d00\u0455\u029c\u0299\u1d0f\u1d00\u0280\u1d05 &8\u2022 &f" + page + "/" + totalPages))).rows(6)).disableAllInteractions()).create();
        gui.setItem(0, ArenaListGUI.summaryItem(Material.LIME_CONCRETE, "&a\u2714 &f\u0280\u1d07\u1d00\u1d05\u028f", ready, "&7\ua730\u1d1c\u029f\u029f\u028f \u1d04\u1d0f\u0274\ua730\u026a\u0262\u1d1c\u0280\u1d07\u1d05 \u1d00\u0274\u1d05 \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07"));
        gui.setItem(2, ArenaListGUI.summaryItem(Material.ORANGE_CONCRETE, "&6\u25cf &f\u026a\u0274 \u1d1c\u0455\u1d07", inUse, "&7\u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b\u029f\u028f \u029c\u1d0f\u0455\u1d1b\u026a\u0274\u0262 \u1d00 \u1d0d\u1d00\u1d1b\u1d04\u029c"));
        gui.setItem(4, ArenaListGUI.summaryItem(Material.RED_CONCRETE, "&c\u2718 &f\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05", disabled, "&7\u0274\u1d0f\u1d1b \u1d00\u1d20\u1d00\u026a\u029f\u1d00\u0299\u029f\u1d07 \ua730\u1d0f\u0280 \u1d0d\u1d00\u1d1b\u1d04\u029c\u1d07\u0455"));
        gui.setItem(6, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.COMPASS).name(ArenaListGUI.noItalic("&#FB0000\u1d00\u0280\u1d07\u0274\u1d00 \u0262\u1d1c\u026a\u1d05\u1d07"))).lore(ArenaListGUI.noItalic("&a\u0262\u0280\u1d07\u1d07\u0274 &8\u2022 &f\u0280\u1d07\u1d00\u1d05\u028f"), ArenaListGUI.noItalic("&6\u1d0f\u0280\u1d00\u0274\u0262\u1d07 &8\u2022 &f\u026a\u0274 \u1d1c\u0455\u1d07"), ArenaListGUI.noItalic("&e\u028f\u1d07\u029f\u029f\u1d0f\u1d21 &8\u2022 &f\u0274\u1d07\u1d07\u1d05\u0455 \u0455\u1d07\u1d1b\u1d1c\u1d18"), ArenaListGUI.noItalic("&c\u0280\u1d07\u1d05 &8\u2022 &f\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05"))).flags(ItemFlag.values())).asGuiItem(event -> {}));
        gui.setItem(8, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BOOK).name(ArenaListGUI.noItalic("&#FB0000\u029c\u1d0f\u1d21 \u1d1b\u1d0f \u1d1c\u0455\u1d07"))).lore(ArenaListGUI.noItalic("&7\u1d04\u029f\u026a\u1d04\u1d0b \u1d00\u0274 \u1d00\u0280\u1d07\u0274\u1d00 \u1d1b\u1d0f \u1d0f\u1d18\u1d07\u0274 \u026a\u1d1b\u0455 \u1d07\u1d05\u026a\u1d1b\u1d0f\u0280"), ArenaListGUI.noItalic("&7\u1d0b\u026a\u1d1b \u0299\u026a\u0274\u1d05\u026a\u0274\u0262\u0455 \u0455\u029c\u1d0f\u1d21 \u0299\u1d1c\u026a\u029f\u1d05/\u0299\u0280\u1d07\u1d00\u1d0b \u0280\u1d1c\u029f\u1d07\u0455"))).flags(ItemFlag.values())).asGuiItem(event -> {}));
        int start = (page - 1) * 36;
        int end = Math.min(start + 36, arenas.size());
        for (int index = start; index < end; ++index) {
            Arena arena = (Arena)arenas.get(index);
            gui.setItem(9 + index - start, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(ArenaListGUI.statusMaterial(arena)).name(ArenaListGUI.noItalic("&f" + arena.getName()))).lore(ArenaListGUI.buildLore(arena))).flags(ItemFlag.values())).asGuiItem(event -> ArenaEditorGUI.open(player, arena.getName())));
        }
        gui.setItem(49, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.PAPER).name(ArenaListGUI.noItalic("&#FB0000\u1d1b\u1d0f\u1d1b\u1d00\u029f \u1d00\u0280\u1d07\u0274\u1d00\u0455: &f" + arenas.size()))).lore(ArenaListGUI.noItalic("&7\u0455\u1d0f\u0280\u1d1b\u1d07\u1d05 \u1d00\u029f\u1d18\u029c\u1d00\u0299\u1d07\u1d1b\u026a\u1d04\u1d00\u029f\u029f\u028f"), ArenaListGUI.noItalic("&7\u1d18\u1d00\u0262\u1d07 &f" + page + "&7 \u1d0f\ua730 &f" + totalPages))).flags(ItemFlag.values())).asGuiItem(event -> {}));
        if (page > 1) {
            gui.setItem(45, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ArenaListGUI.noItalic("&#FB0000\u00ab &f\u1d18\u0280\u1d07\u1d20\u026a\u1d0f\u1d1c\u0455 \u1d18\u1d00\u0262\u1d07"))).flags(ItemFlag.values())).asGuiItem(event -> ArenaListGUI.open(player, currentPage - 1)));
        }
        if (page < totalPages) {
            gui.setItem(53, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ArenaListGUI.noItalic("&#FB0000\u0274\u1d07x\u1d1b \u1d18\u1d00\u0262\u1d07 \u00bb"))).flags(ItemFlag.values())).asGuiItem(event -> ArenaListGUI.open(player, currentPage + 1)));
        }
        gui.open((HumanEntity)player);
    }

    private static Component[] buildLore(Arena arena) {
        ArrayList<Component> lore = new ArrayList<Component>();
        lore.add(ArenaListGUI.noItalic(ArenaListGUI.statusText(arena)));
        lore.add(ArenaListGUI.noItalic("&8\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501"));
        lore.add(ArenaListGUI.noItalic("&7\u1d21\u1d0f\u0280\u029f\u1d05: &f" + ArenaListGUI.valueOrUnset(arena.getWorld())));
        lore.add(ArenaListGUI.noItalic("&7\u0280\u1d07\u0262\u026a\u1d0f\u0274: " + ArenaListGUI.state(arena.isRegionSet())));
        String var10001 = ArenaListGUI.state(arena.getSpawn1() != null && arena.getSpawn2() != null);
        lore.add(ArenaListGUI.noItalic("&7\u0455\u1d18\u1d00\u1d21\u0274\u0455: " + var10001));
        String string = var10001 = arena.isRegeneration() ? "&a\u2714 \u1d0f\u0274" : "&c\u2718 \u1d0f\ua730\ua730";
        lore.add(ArenaListGUI.noItalic("&7\u0280\u1d07\u0262\u1d07\u0274: " + var10001 + (String)(arena.isRegeneration() ? " &8\u2022 " + (ArenaSnapshotManager.hasSchematic(arena.getName()) ? "&a\u0455\u1d04\u029c\u1d07\u1d0d\u1d00\u1d1b\u026a\u1d04 \u0455\u1d00\u1d20\u1d07\u1d05" : "&c\u0455\u1d04\u029c\u1d07\u1d0d\u1d00\u1d1b\u026a\u1d04 \u1d0d\u026a\u0455\u0455\u026a\u0274\u0262") : "")));
        lore.add(ArenaListGUI.noItalic(""));
        lore.add(ArenaListGUI.noItalic("&#FB0000\u1d0b\u026a\u1d1b \u0299\u026a\u0274\u1d05\u026a\u0274\u0262\u0455"));
        List<String> kits = arena.getAllowedKits();
        if (kits != null && !kits.isEmpty()) {
            int shown = 0;
            for (String kit : kits) {
                if (kit == null || kit.isBlank()) continue;
                if (shown++ == 8) {
                    int var10 = kits.size();
                    lore.add(ArenaListGUI.noItalic("&8 \u2022 +" + (var10 - 8) + " \u1d0d\u1d0f\u0280\u1d07"));
                    break;
                }
                boolean build = KitRuleManager.isBlockPlacingEnabled(kit);
                boolean breakBlocks = KitRuleManager.isBlockBreakingEnabled(kit);
                var10001 = ArenaListGUI.displayKit(kit);
                lore.add(ArenaListGUI.noItalic("&f \u2022 " + var10001 + " &8| " + ArenaListGUI.rule("\u0299\u1d1c\u026a\u029f\u1d05", build) + " &8| " + ArenaListGUI.rule("\u0299\u0280\u1d07\u1d00\u1d0b", breakBlocks)));
            }
        } else {
            lore.add(ArenaListGUI.noItalic("&f \u2022 &a\u1d00\u0274\u028f \u1d0b\u026a\u1d1b &8(\u0274\u1d0f \u0280\u1d07\u0455\u1d1b\u0280\u026a\u1d04\u1d1b\u026a\u1d0f\u0274)"));
        }
        lore.add(ArenaListGUI.noItalic(""));
        lore.add(ArenaListGUI.noItalic("&#FB0000\u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d07\u1d05\u026a\u1d1b \u1d00\u0280\u1d07\u0274\u1d00"));
        return lore.toArray(new Component[0]);
    }

    private static String state(boolean enabled) {
        return enabled ? "&a\u2714 \u1d07\u0274\u1d00\u0299\u029f\u1d07\u1d05" : "&c\u2718 \u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05";
    }

    private static boolean isReady(Arena arena) {
        return arena.isEnabled() && !arena.isInUse() && arena.isRegionSet() && arena.getSpawn1() != null && arena.getSpawn2() != null && (!arena.isRegeneration() || ArenaSnapshotManager.hasSchematic(arena.getName()));
    }

    private static Material statusMaterial(Arena arena) {
        if (arena.isInUse()) {
            return Material.ORANGE_CONCRETE;
        }
        if (ArenaListGUI.isReady(arena)) {
            return Material.LIME_CONCRETE;
        }
        return arena.isEnabled() ? Material.YELLOW_CONCRETE : Material.RED_CONCRETE;
    }

    private static String statusText(Arena arena) {
        if (arena.isInUse()) {
            return "&6\u25cf &f\u026a\u0274 \u1d1c\u0455\u1d07";
        }
        if (ArenaListGUI.isReady(arena)) {
            return "&a\u2714 &f\u0280\u1d07\u1d00\u1d05\u028f \ua730\u1d0f\u0280 \u1d0d\u1d00\u1d1b\u1d04\u029c\u1d07\u0455";
        }
        return arena.isEnabled() ? "&e\u26a0 &f\u0274\u1d07\u1d07\u1d05\u0455 \u0455\u1d07\u1d1b\u1d1c\u1d18" : "&c\u2718 &f\u1d05\u026a\u0455\u1d00\u0299\u029f\u1d07\u1d05";
    }

    private static GuiItem summaryItem(Material material, String name, int amount, String detail) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(material).name(ArenaListGUI.noItalic(name + " &8(" + amount + ")"))).lore(ArenaListGUI.noItalic(detail))).flags(ItemFlag.values())).asGuiItem(event -> {});
    }

    private static String displayKit(String kit) {
        if (kit.regionMatches(true, 0, "BedPvP", 0, "BedPvP".length())) {
            String suffix = kit.substring("BedPvP".length());
            Object var10000 = suffix.isBlank() ? "" : " &8" + suffix;
            return "&x&f&b&0&0&0&0&l\u0299\u1d07\u1d05 \u1d18\u1d20\u1d18" + (String)var10000;
        }
        return kit;
    }

    private static String rule(String name, boolean enabled) {
        return (enabled ? "&a\u2714 " : "&c\u2718 ") + name;
    }

    private static String valueOrUnset(String value) {
        return value != null && !value.isBlank() ? value : "&c\u0274\u1d0f\u1d1b \u0455\u1d07\u1d1b";
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

