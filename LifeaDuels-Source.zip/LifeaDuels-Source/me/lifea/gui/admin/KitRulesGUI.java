/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.gui.admin;

import java.util.ArrayList;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.gui.admin.KitSettingsGUI;
import me.lifea.kit.KitRuleManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.storage.DatabaseManager;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.plugin.Plugin;

public class KitRulesGUI {
    private static final Object[][] RULES = new Object[][]{{10, Material.OAK_PLANKS, "Block Placing", "block-placing", "Allow players to place blocks."}, {11, Material.IRON_PICKAXE, "Block Breaking", "block-breaking", "Allow players to break blocks."}, {12, Material.RED_DYE, "Health Indicator", "health-indicator", "Show the opponent's health below their name."}, {13, Material.BREAD, "Disable Hunger", "disable-hunger", "Keep hunger locked at full."}, {14, Material.GOLDEN_APPLE, "Disable Health Regen", "disable-health-regen", "Stop natural health regeneration."}, {15, Material.CRAFTING_TABLE, "Enable Crafting", "enable-crafting", "Allow using crafting tables."}, {16, Material.FEATHER, "Disable Fall Damage", "disable-fall-damage", "Players take no fall damage."}, {19, Material.ANVIL, "33% Damage Boost", "damage-boost-33", "Deal 33% more damage."}, {20, Material.STONE_PICKAXE, "Personal Blocks", "player-mined-blocks", "Players may only break blocks they placed", "themselves - never the arena's own blocks."}, {21, Material.EXPERIENCE_BOTTLE, "No XP Randomness", "no-xp-randomness", "XP is split evenly into Mending items."}, {22, Material.WATER_BUCKET, "Sumo (Water = Lose)", "sumo", "Touching water eliminates a player."}, {23, Material.RED_WOOL, "Boxing (100 Hits to Win)", "boxing", "First to land 100 hits wins."}, {24, Material.RED_BED, "Bed Fight", "bed-fight", "Placed beds explode on contact."}, {25, Material.FIRE_CHARGE, "Fireball Fight", "fireball-fight", "Right-click fire charges to launch fireballs."}, {28, Material.STONE, "Bridges", "bridges", "Bridge-style objective mode."}, {29, Material.OAK_FENCE, "Cages (Animated Fences)", "cages", "Spawn animated fence cages."}, {30, Material.LEAD, "Auto Tame", "auto-tame", "Automatically tame spawned animals."}, {32, Material.COMPASS, "Adventure Mode", "adventure-mode", "Force players into adventure mode."}, {33, Material.BARRIER, "No Damage (Immortal)", "no-damage", "Players cannot take any damage."}, {34, Material.CREEPER_SPAWN_EGG, "Creeper PvP", "creeper-pvp", "Creepers ignite near players."}, {37, Material.TNT, "TNT PvP", "tnt-pvp", "Placed TNT primes instantly."}, {38, Material.GUNPOWDER, "TNT Tag", "tnt-tag", "TNT tag objective mode."}, {39, Material.ITEM_FRAME, "Custom Scoreboard", "custom-scoreboard", "Use this kit's custom scoreboard."}, {40, Material.TOTEM_OF_UNDYING, "Immortality", "immortality", "Players are healed to full health on every hit."}, {26, Material.RED_BED, "BedWars (1v1)", "bedwars", "Classic BedWars: dying while your bed is intact", "respawns you instead of ending the duel. Breaking", "the enemy bed and then killing the owner wins."}, {41, Material.PISTON, "Round Drag Animation", "round-drag-animation", "Animate players back to their spawn", "between rounds."}};

    public static void open(Player player, String kitKey) {
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().rows(6)).title(ColorUtil.parse("Kit Rules: " + kitKey))).disableAllInteractions()).create();
        gui.getFiller().fill(((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name((Component)Component.empty())).asGuiItem());
        int enabledRules = KitRulesGUI.getEnabledRuleCount(kitKey);
        boolean kitEnabled = ConfigManager.config().getBoolean("kit-settings." + kitKey + ".enabled", true);
        gui.setItem(4, KitRulesGUI.buildKitStatusItem(kitEnabled));
        gui.setItem(47, KitRulesGUI.buildRuleCountItem(Material.LIME_DYE, "&aEnabled Rules", enabledRules, "&aThese rules are currently active."));
        gui.setItem(51, KitRulesGUI.buildRuleCountItem(Material.RED_DYE, "&cDisabled Rules", RULES.length - enabledRules, "&cThese rules are currently inactive."));
        for (Object[] rule : RULES) {
            int slot = (Integer)rule[0];
            Material mat = (Material)rule[1];
            String name = (String)rule[2];
            String ruleKey = (String)rule[3];
            String[] desc = new String[rule.length - 4];
            for (int i = 4; i < rule.length; ++i) {
                desc[i - 4] = (String)rule[i];
            }
            boolean enabled = DatabaseManager.getKitRule(kitKey, ruleKey);
            gui.setItem(slot, KitRulesGUI.buildRuleItem(gui, mat, name, ruleKey, kitKey, slot, enabled, desc));
        }
        gui.setItem(49, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(KitRulesGUI.noItalic("&6Go Back"))).lore(KitRulesGUI.noItalic("&fClick to return to Kit Settings."))).flags(ItemFlag.values())).asGuiItem(e -> {
            player.closeInventory();
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> KitSettingsGUI.open(player, kitKey));
        }));
        gui.open((HumanEntity)player);
    }

    private static GuiItem buildRuleItem(Gui gui, Material mat, String name, String ruleKey, String kitKey, int slot, boolean enabled, String[] desc) {
        ArrayList<Component> lore = new ArrayList<Component>();
        for (String line : desc) {
            lore.add(KitRulesGUI.noItalic("&f" + line));
        }
        if (desc.length > 0) {
            lore.add((Component)Component.empty());
        }
        lore.add(KitRulesGUI.noItalic("&8\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501"));
        lore.add(KitRulesGUI.noItalic(enabled ? "&a\u25cf STATUS: ENABLED" : "&c\u25cf STATUS: DISABLED"));
        lore.add(KitRulesGUI.noItalic(enabled ? "&eClick to disable this rule" : "&eClick to enable this rule"));
        ItemBuilder builder = (ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(mat).name(KitRulesGUI.noItalic((enabled ? "&a\u25cf ENABLED &8| &f" : "&c\u25cf DISABLED &8| &f") + name))).lore(lore)).flags(ItemFlag.values());
        if (enabled) {
            builder.glow();
        }
        return builder.asGuiItem(e -> {
            Player p = (Player)e.getWhoClicked();
            boolean newVal = !DatabaseManager.getKitRule(kitKey, ruleKey);
            DatabaseManager.setKitRule(kitKey, ruleKey, newVal);
            KitRuleManager.invalidate(kitKey);
            gui.updateItem(slot, KitRulesGUI.buildRuleItem(gui, mat, name, ruleKey, kitKey, slot, newVal, desc));
            int activeRules = KitRulesGUI.getEnabledRuleCount(kitKey);
            gui.updateItem(47, KitRulesGUI.buildRuleCountItem(Material.LIME_DYE, "&aEnabled Rules", activeRules, "&aThese rules are currently active."));
            gui.updateItem(51, KitRulesGUI.buildRuleCountItem(Material.RED_DYE, "&cDisabled Rules", RULES.length - activeRules, "&cThese rules are currently inactive."));
            p.playSound(p.getLocation(), newVal ? Sound.BLOCK_NOTE_BLOCK_PLING : Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.2f);
        });
    }

    public static int getEnabledRuleCount(String kitKey) {
        int enabled = 0;
        for (Object[] rule : RULES) {
            if (!DatabaseManager.getKitRule(kitKey, (String)rule[3])) continue;
            ++enabled;
        }
        return enabled;
    }

    public static int getRuleCount() {
        return RULES.length;
    }

    private static GuiItem buildKitStatusItem(boolean enabled) {
        String status = enabled ? "&a\u25cf KIT ENABLED" : "&c\u25cf KIT DISABLED";
        String detail = enabled ? "&fThis kit is available to players." : "&fThis kit is unavailable to players.";
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(enabled ? Material.LIME_CONCRETE : Material.RED_CONCRETE).name(KitRulesGUI.noItalic(status))).lore(new Component[]{KitRulesGUI.noItalic(detail), Component.empty(), KitRulesGUI.noItalic("&7Change kit availability in Kit Settings.")})).flags(ItemFlag.values())).asGuiItem();
    }

    private static GuiItem buildRuleCountItem(Material material, String name, int count, String detail) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(material).name(KitRulesGUI.noItalic(name + " &8(" + count + ")"))).lore(KitRulesGUI.noItalic("&f" + count + " of " + RULES.length + " rules"), KitRulesGUI.noItalic(detail))).flags(ItemFlag.values())).asGuiItem();
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

