/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui;

import java.util.List;
import java.util.Map;
import me.lifea.config.ConfigManager;
import me.lifea.gui.RoundSelectionGUI;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.gui.kit.KitRoomGUI;
import me.lifea.gui.kit.custom.CustomKitEditorMenuGUI;
import me.lifea.gui.kit.custom.CustomKitsMenuGUI;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.MaterialSpriteUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class DuelMenuGUI {
    public static final String ROOT_SECTION = "Duel-menu";
    private static final String EDIT_LORE = "&7\u2139 Click to Edit Kit.";
    private static final String[] KNOWN_FORMATS = new String[]{"COM", "IO", "Sub", "Extra", "Custom"};
    private static final Map<String, String> FORMAT_TO_TIER = Map.of("COM", "MCTiers", "IO", "PvPTiers", "Sub", "SubTiers", "Extra", "Extra");
    private static final Map<String, String> SECTION_BY_TIER = Map.of("MCTiers", "duel-mctiers", "PvPTiers", "duel-pvptiers", "SubTiers", "duel-subtiers", "Extra", "extra-gamemodes");
    private static final Map<String, String> TIER_BY_SECTION = Map.of("duel-mctiers", "MCTiers", "duel-pvptiers", "PvPTiers", "duel-subtiers", "SubTiers", "extra-gamemodes", "Extra", "custom", "CustomKits");
    public static final List<String> PLAYABLE_TIERS = List.of("MCTiers", "PvPTiers", "SubTiers", "Extra");
    private final String section;
    private final Player opponent;
    private final Mode mode;

    public static String tierForSection(String section) {
        return TIER_BY_SECTION.getOrDefault(section.toLowerCase(), section);
    }

    public static ConfigurationSection tierSection(String tier) {
        return ConfigManager.duelGui().getConfigurationSection(DuelMenuGUI.sectionForTier(tier));
    }

    public DuelMenuGUI(String section, Player opponent, Mode mode) {
        this.section = section;
        this.opponent = opponent;
        this.mode = mode;
    }

    public static String sectionForTier(String tier) {
        return SECTION_BY_TIER.getOrDefault(tier, ROOT_SECTION);
    }

    public static String[] resolveKit(String kitValue, String sectionFormat) {
        String format = sectionFormat;
        String base = kitValue;
        int idx = kitValue.lastIndexOf(45);
        if (idx > 0 && idx < kitValue.length() - 1) {
            String suffix = kitValue.substring(idx + 1);
            for (String known : KNOWN_FORMATS) {
                if (!known.equalsIgnoreCase(suffix)) continue;
                format = known;
                base = kitValue.substring(0, idx);
                break;
            }
        }
        String gamemode = base.trim();
        String tier = FORMAT_TO_TIER.getOrDefault(format, format);
        return new String[]{tier, gamemode};
    }

    private static int parseRows(String size) {
        if (size != null && size.startsWith("chest-")) {
            try {
                return Integer.parseInt(size.substring("chest-".length()).trim());
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return 3;
    }

    public void open(Player player) {
        ConfigurationSection sec = ConfigManager.duelGui().getConfigurationSection(this.section);
        if (sec == null) {
            player.sendMessage(ColorUtil.parse("&cMenu '" + this.section + "' is not defined in duel.yml."));
        } else {
            int rows = DuelMenuGUI.parseRows(sec.getString("size", "chest-3"));
            String title = sec.getString("title", this.section);
            String kitFormat = sec.getString("kit-format", "");
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
            ConfigurationSection items = sec.getConfigurationSection("items");
            if (items != null) {
                for (String key : items.getKeys(false)) {
                    List<Component> lore;
                    int slot;
                    ConfigurationSection it = items.getConfigurationSection(key);
                    if (it == null) continue;
                    try {
                        slot = Integer.parseInt(key.trim());
                    }
                    catch (NumberFormatException numberFormatException) {
                        continue;
                    }
                    Material mat = Material.matchMaterial((String)it.getString("material", "STONE"));
                    if (mat == null) {
                        mat = Material.STONE;
                    }
                    String name = it.getString("name", "");
                    String kit = it.getString("kit");
                    String opens = it.getString("opens");
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, it).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                    if (kit != null && !kit.isBlank()) {
                        List<Component> lore2;
                        builder.name(ColorUtil.parse(MaterialSpriteUtil.prefix(player, mat, name)));
                        String[] tg = DuelMenuGUI.resolveKit(kit, kitFormat);
                        String tier = tg[0];
                        String gamemode = tg[1];
                        List<Component> list = lore2 = this.mode == Mode.KIT_EDITOR ? List.of(ColorUtil.parse(EDIT_LORE)) : LoreUtil.read(it, "lore");
                        if (!lore2.isEmpty()) {
                            builder.lore(lore2);
                        }
                        gui.setItem(slot, builder.asGuiItem(ex -> {
                            SoundUtil.playClick(player);
                            if (this.mode == Mode.DUEL) {
                                new RoundSelectionGUI(tier, gamemode, this.opponent).open(player);
                            } else {
                                this.openEditor(player, tier, gamemode);
                            }
                        }));
                        continue;
                    }
                    if (opens != null && !opens.isBlank()) {
                        lore = LoreUtil.read(it, "lore");
                        if (!lore.isEmpty()) {
                            builder.lore(lore);
                        }
                        gui.setItem(slot, builder.asGuiItem(ex -> this.handleOpens(player, opens)));
                        continue;
                    }
                    lore = LoreUtil.read(it, "lore");
                    if (!lore.isEmpty()) {
                        builder.lore(lore);
                    }
                    gui.setItem(slot, builder.asGuiItem());
                }
            }
            gui.open((HumanEntity)player);
        }
    }

    private void handleOpens(Player player, String target) {
        SoundUtil.playClick(player);
        switch (target.toLowerCase()) {
            case "close": {
                player.closeInventory();
                break;
            }
            case "back": {
                new DuelMenuGUI(ROOT_SECTION, this.opponent, this.mode).open(player);
                break;
            }
            case "custom": {
                if (!CustomKitManager.isEnabled()) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
                    break;
                }
                if (this.mode == Mode.DUEL) {
                    new CustomKitsMenuGUI(this.opponent).open(player);
                    break;
                }
                new CustomKitEditorMenuGUI().open(player);
                break;
            }
            default: {
                new DuelMenuGUI(target, this.opponent, this.mode).open(player);
            }
        }
    }

    private void openEditor(Player player, String tier, String gamemode) {
        ConfigurationSection multiKit = ConfigManager.kitEditor().getConfigurationSection("multi-kit.gamemodes." + gamemode);
        if (multiKit != null) {
            new KitRoomGUI(tier, gamemode).open(player);
        } else {
            new KitEditorGUI(tier, gamemode).open(player);
        }
    }

    public static final class Mode
    extends Enum<Mode> {
        public static final /* enum */ Mode DUEL = new Mode();
        public static final /* enum */ Mode KIT_EDITOR = new Mode();
        private static final /* synthetic */ Mode[] $VALUES;

        public static Mode[] values() {
            return (Mode[])$VALUES.clone();
        }

        public static Mode valueOf(String name) {
            return Enum.valueOf(Mode.class, name);
        }

        private static Mode[] $values() {
            return new Mode[]{DUEL, KIT_EDITOR};
        }

        private static Mode[] $values$() {
            return new Mode[]{DUEL, KIT_EDITOR};
        }

        private static /* synthetic */ Mode[] $values$$() {
            return new Mode[]{DUEL, KIT_EDITOR};
        }

        static {
            $VALUES = Mode.$values$$();
        }
    }
}

