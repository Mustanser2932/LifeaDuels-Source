/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.retrooper.packetevents.PacketEvents
 *  com.github.retrooper.packetevents.wrapper.PacketWrapper
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerClearDialog
 *  org.bukkit.entity.Player
 */
package me.lifea.gui;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerClearDialog;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.gui.CompGUI;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.RoundSelectionGUI;
import me.lifea.queue.QuickQueuePreferenceManager;
import org.bukkit.entity.Player;

public class GUIManager {
    private static final Map<UUID, String> selectedArenas = new ConcurrentHashMap<UUID, String>();
    private static final Map<UUID, String> selectedArenaKit = new ConcurrentHashMap<UUID, String>();

    public static void openMainMenu(Player player, Player opponent) {
        new DuelMenuGUI("Duel-menu", opponent, DuelMenuGUI.Mode.DUEL).open(player);
    }

    public static void openGamemodeMenu(Player player, Player opponent, String tier) {
        new DuelMenuGUI(DuelMenuGUI.sectionForTier(tier), opponent, DuelMenuGUI.Mode.DUEL).open(player);
    }

    public static void openRoundSelection(Player player, Player opponent, String tier, String gamemode) {
        new RoundSelectionGUI(tier, gamemode, opponent).open(player);
    }

    public static void openQueueMainMenu(Player player) {
        new CompGUI().open(player);
    }

    public static void openQuickQueueSettings(Player player) {
        QuickQueuePreferenceManager.loadAsync(player.getUniqueId(), () -> new CompGUI(true).open(player));
    }

    public static void openCompMenu(Player player) {
        new CompGUI().open(player);
    }

    public static void closeMenus(Player ... players) {
        for (Player player : players) {
            if (player == null || !player.isOnline()) continue;
            player.closeInventory();
            PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerClearDialog());
        }
    }

    public static void setSelectedArena(UUID uuid, String arenaBaseName) {
        if (arenaBaseName == null) {
            selectedArenas.remove(uuid);
            selectedArenaKit.remove(uuid);
        } else {
            selectedArenas.put(uuid, arenaBaseName);
        }
    }

    public static void setSelectedArena(UUID uuid, String arenaBaseName, String kitKey) {
        if (arenaBaseName == null) {
            selectedArenas.remove(uuid);
            selectedArenaKit.remove(uuid);
        } else {
            selectedArenas.put(uuid, arenaBaseName);
            selectedArenaKit.put(uuid, kitKey);
        }
    }

    public static String getSelectedArena(UUID uuid) {
        return selectedArenas.get(uuid);
    }

    public static String getSelectedArena(UUID uuid, String kitKey) {
        return kitKey != null && !kitKey.equalsIgnoreCase(selectedArenaKit.get(uuid)) ? null : selectedArenas.get(uuid);
    }

    public static void clearSelectedArena(UUID uuid) {
        selectedArenas.remove(uuid);
        selectedArenaKit.remove(uuid);
    }

    public static void remove(UUID uuid) {
        selectedArenas.remove(uuid);
        selectedArenaKit.remove(uuid);
    }
}

