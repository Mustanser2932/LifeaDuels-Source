/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.config.ConfigManager;
import me.lifea.gui.GUIManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class ArenaSelectGUI {
    private static final Pattern ARENA_PATTERN = Pattern.compile("^(.+)-(\\d+)$");

    public static void open(Player player, String kitKey, Runnable onClose) {
        ArenaSelectGUI.open(player, kitKey, 0, onClose);
    }

    public static void open(Player player, String kitKey, int page, Runnable onClose) {
        ConfigurationSection cfg = ConfigManager.config().getConfigurationSection("gui.arena-select");
        int size = cfg != null ? cfg.getInt("size", 27) : 27;
        int rows = size / 9;
        String title = cfg != null ? cfg.getString("name", "Select Arena") : "Select Arena";
        int startSlot = cfg != null ? cfg.getInt("item-start-slot", 9) : 9;
        int arenaSlotCount = (rows - 1) * 9 - startSlot;
        if (arenaSlotCount <= 0) {
            arenaSlotCount = size - startSlot;
        }
        LinkedHashSet<String> baseNames = new LinkedHashSet<String>();
        String keyLower = kitKey != null && !kitKey.isBlank() ? kitKey.toLowerCase() : null;
        for (Arena arena : ArenaManager.getAll()) {
            boolean matches;
            if (!arena.isEnabled() || arena.getSpawn1() == null || arena.getSpawn2() == null) continue;
            List<String> allowed = arena.getAllowedKits();
            boolean bl = matches = allowed == null || allowed.isEmpty();
            if (!matches && keyLower != null) {
                for (String k : allowed) {
                    if (k == null || !k.trim().equalsIgnoreCase(keyLower)) continue;
                    matches = true;
                    break;
                }
            }
            if (!matches) continue;
            Matcher m = ARENA_PATTERN.matcher(arena.getName());
            String baseName = m.matches() ? m.group(1) : arena.getName();
            baseNames.add(baseName);
        }
        if (baseNames.isEmpty()) {
            player.sendMessage(ColorUtil.parse("&#FB0000No arenas available!"));
            player.closeInventory();
            onClose.run();
        } else {
            ArrayList nameList = new ArrayList(baseNames);
            int totalPages = (int)Math.ceil((double)nameList.size() / (double)arenaSlotCount);
            int currentPage = Math.max(0, Math.min(page, totalPages - 1));
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
            if (cfg != null) {
                ConfigurationSection closeSec;
                ConfigurationSection fillerSec = cfg.getConfigurationSection("fillers");
                if (fillerSec != null) {
                    Material fillerMat = Material.matchMaterial((String)fillerSec.getString("material", "GRAY_STAINED_GLASS_PANE"));
                    if (fillerMat == null) {
                        fillerMat = Material.GRAY_STAINED_GLASS_PANE;
                    }
                    String fillerName = fillerSec.getString("name", " ");
                    String slotsStr = fillerSec.getString("slots", "");
                    GuiItem fillerItem = ((ItemBuilder)((ItemBuilder)HeadUtil.from(fillerMat, fillerSec).name(ColorUtil.parse(fillerName))).flags(ItemFlag.values())).asGuiItem();
                    for (String s : slotsStr.split(",")) {
                        try {
                            gui.setItem(Integer.parseInt(s.trim()), fillerItem);
                        }
                        catch (NumberFormatException numberFormatException) {
                            // empty catch block
                        }
                    }
                }
                if ((closeSec = cfg.getConfigurationSection("close-item")) != null) {
                    Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                    if (closeMat == null) {
                        closeMat = Material.BARRIER;
                    }
                    int closeSlot = closeSec.getInt("slot", 22);
                    gui.setItem(closeSlot, ((ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cBack")))).flags(ItemFlag.values())).asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        GUIManager.clearSelectedArena(player.getUniqueId());
                        onClose.run();
                    }));
                }
            }
            if (totalPages > 1) {
                int bottomRowStart = (rows - 1) * 9;
                if (currentPage > 0) {
                    gui.setItem(bottomRowStart, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ColorUtil.parse("&ePrevious Page"))).flags(ItemFlag.values())).asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        ArenaSelectGUI.open(player, kitKey, currentPage - 1, onClose);
                    }));
                }
                if (currentPage < totalPages - 1) {
                    gui.setItem(bottomRowStart + 8, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ColorUtil.parse("&eNext Page"))).flags(ItemFlag.values())).asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        ArenaSelectGUI.open(player, kitKey, currentPage + 1, onClose);
                    }));
                }
            }
            ConfigurationSection itemSec = cfg != null ? cfg.getConfigurationSection("arena-item") : null;
            Material itemMat = Material.MAP;
            String itemName = "&f%arena%";
            List selectedLore = List.of();
            List unselectedLore = List.of();
            if (itemSec != null) {
                Material m = Material.matchMaterial((String)itemSec.getString("material", "MAP"));
                if (m != null) {
                    itemMat = m;
                }
                itemName = itemSec.getString("name", "&f%arena%");
                selectedLore = itemSec.getStringList("selected-lore");
                unselectedLore = itemSec.getStringList("lore");
            }
            int pageOffset = currentPage * arenaSlotCount;
            for (int i = 0; i < arenaSlotCount && pageOffset + i < nameList.size(); ++i) {
                String baseName = (String)nameList.get(pageOffset + i);
                int currentSlot = startSlot + i;
                String displayName = itemName.replace("%arena%", baseName);
                String currentSelection = GUIManager.getSelectedArena(player.getUniqueId());
                boolean isSelected = baseName.equals(currentSelection);
                List<Component> lore = isSelected ? ArenaSelectGUI.buildLore(selectedLore, baseName) : ArenaSelectGUI.buildLore(unselectedLore, baseName);
                ItemBuilder builder = (ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(itemMat, itemSec).name(ColorUtil.parse(displayName))).lore(lore)).flags(ItemFlag.values());
                if (isSelected) {
                    builder.glow();
                }
                gui.setItem(currentSlot, builder.asGuiItem(e -> {
                    SoundUtil.playClick(player);
                    GUIManager.setSelectedArena(player.getUniqueId(), baseName, kitKey);
                    player.closeInventory();
                    onClose.run();
                }));
            }
            gui.open((HumanEntity)player);
        }
    }

    private static List<Component> buildLore(List<String> lines, String baseName) {
        Stream<Component> var10000 = lines.stream().map(line -> ColorUtil.parse(line.replace("%arena%", baseName)));
        Objects.requireNonNull(Component.class);
        Objects.requireNonNull(Component.class);
        return var10000.map(Component.class::cast).toList();
    }
}

