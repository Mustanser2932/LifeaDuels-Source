/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.retrooper.packetevents.PacketEvents
 *  com.github.retrooper.packetevents.protocol.chat.clickevent.ClickEvent
 *  com.github.retrooper.packetevents.protocol.dialog.CommonDialogData
 *  com.github.retrooper.packetevents.protocol.dialog.Dialog
 *  com.github.retrooper.packetevents.protocol.dialog.DialogAction
 *  com.github.retrooper.packetevents.protocol.dialog.MultiActionDialog
 *  com.github.retrooper.packetevents.protocol.dialog.action.Action
 *  com.github.retrooper.packetevents.protocol.dialog.action.DialogTemplate
 *  com.github.retrooper.packetevents.protocol.dialog.action.DynamicRunCommandAction
 *  com.github.retrooper.packetevents.protocol.dialog.action.StaticAction
 *  com.github.retrooper.packetevents.protocol.dialog.body.PlainMessage
 *  com.github.retrooper.packetevents.protocol.dialog.body.PlainMessageDialogBody
 *  com.github.retrooper.packetevents.protocol.dialog.button.ActionButton
 *  com.github.retrooper.packetevents.protocol.dialog.button.CommonButtonData
 *  com.github.retrooper.packetevents.protocol.dialog.input.Input
 *  com.github.retrooper.packetevents.protocol.dialog.input.InputControl
 *  com.github.retrooper.packetevents.protocol.dialog.input.NumberRangeInputControl
 *  com.github.retrooper.packetevents.protocol.dialog.input.NumberRangeInputControl$RangeInfo
 *  com.github.retrooper.packetevents.wrapper.PacketWrapper
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerClearDialog
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerShowDialog
 *  com.viaversion.viaversion.api.Via
 *  com.viaversion.viaversion.api.protocol.version.ProtocolVersion
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.entity.Player
 */
package me.lifea.gui;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.chat.clickevent.ClickEvent;
import com.github.retrooper.packetevents.protocol.dialog.CommonDialogData;
import com.github.retrooper.packetevents.protocol.dialog.Dialog;
import com.github.retrooper.packetevents.protocol.dialog.DialogAction;
import com.github.retrooper.packetevents.protocol.dialog.MultiActionDialog;
import com.github.retrooper.packetevents.protocol.dialog.action.Action;
import com.github.retrooper.packetevents.protocol.dialog.action.DialogTemplate;
import com.github.retrooper.packetevents.protocol.dialog.action.DynamicRunCommandAction;
import com.github.retrooper.packetevents.protocol.dialog.action.StaticAction;
import com.github.retrooper.packetevents.protocol.dialog.body.PlainMessage;
import com.github.retrooper.packetevents.protocol.dialog.body.PlainMessageDialogBody;
import com.github.retrooper.packetevents.protocol.dialog.button.ActionButton;
import com.github.retrooper.packetevents.protocol.dialog.button.CommonButtonData;
import com.github.retrooper.packetevents.protocol.dialog.input.Input;
import com.github.retrooper.packetevents.protocol.dialog.input.InputControl;
import com.github.retrooper.packetevents.protocol.dialog.input.NumberRangeInputControl;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerClearDialog;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerShowDialog;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;

public final class RoundSelectionDialog {
    private static final Map<UUID, State> STATES = new ConcurrentHashMap<UUID, State>();
    private static final int MIN_ROUNDS = 1;
    private static final int MAX_ROUNDS = 10;

    private RoundSelectionDialog() {
    }

    public static boolean supports(Player player) {
        if (!player.getServer().getPluginManager().isPluginEnabled("ViaVersion")) {
            return true;
        }
        try {
            return Via.getAPI().getPlayerProtocolVersion(player.getUniqueId()).newerThanOrEqualTo(ProtocolVersion.v1_21_5);
        }
        catch (Exception ignored) {
            return false;
        }
    }

    public static void open(Player player, String kitName, String opponentName, String mapName, int rounds, Consumer<Integer> advanced, Consumer<Integer> map, Consumer<Integer> confirm, Runnable close) {
        if (player == null || !player.isOnline()) {
            return;
        }
        int initialRounds = Math.max(1, Math.min(10, rounds));
        STATES.put(player.getUniqueId(), new State(initialRounds, advanced, map, confirm, close));
        Component title = ColorUtil.parse("&6Confirm Duel").decoration(TextDecoration.ITALIC, false);
        Component body = ((TextComponent)((TextComponent)ColorUtil.parse("&e" + player.getName() + " &fvs &e" + opponentName).decoration(TextDecoration.ITALIC, false)).append((Component)Component.newline())).append(ColorUtil.parse("&7Kit: &f" + kitName).decoration(TextDecoration.ITALIC, false));
        NumberRangeInputControl slider = new NumberRangeInputControl(400, ColorUtil.parse("&fRounds").decoration(TextDecoration.ITALIC, false), "options.generic_value", new NumberRangeInputControl.RangeInfo(1.0f, 10.0f, Float.valueOf(initialRounds), Float.valueOf(1.0f)));
        CommonDialogData common = new CommonDialogData(title, title, true, false, DialogAction.NONE, List.of(new PlainMessageDialogBody(new PlainMessage(body, 220))), List.of(new Input("rounds", (InputControl)slider)));
        List<ActionButton> buttons = List.of(RoundSelectionDialog.button("&f<sprite:\"minecraft:items\":item/book> &fView Advanced Options", "advanced"), RoundSelectionDialog.button("&f<sprite:\"minecraft:items\":item/paper> &fMap Selector &e(" + mapName + ")", "map"), RoundSelectionDialog.button("&f<sprite:\"minecraft:items\":item/lime_dye> &fSend Duel", "confirm"));
        ActionButton closeButton = new ActionButton(new CommonButtonData(ColorUtil.parse("&c\u2718 Close").decoration(TextDecoration.ITALIC, false), null, 400), (Action)RoundSelectionDialog.action("close"));
        MultiActionDialog dialog = new MultiActionDialog(common, buttons, closeButton, 1);
        PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerShowDialog((Dialog)dialog));
    }

    private static ActionButton button(String label, String action) {
        Component component = ColorUtil.parse(label).decoration(TextDecoration.ITALIC, false);
        return new ActionButton(new CommonButtonData(component, null, 400), (Action)RoundSelectionDialog.dynamicAction(action));
    }

    private static StaticAction action(String action) {
        return new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)("/duelround " + action))));
    }

    private static DynamicRunCommandAction dynamicAction(String action) {
        return new DynamicRunCommandAction(new DialogTemplate("/duelround " + action + " $(rounds)"));
    }

    public static void handle(Player player, String action, String roundsArg) {
        State state;
        State state2 = state = player == null ? null : STATES.get(player.getUniqueId());
        if (state == null || action == null) {
            return;
        }
        int rounds = state.rounds;
        if (roundsArg != null) {
            try {
                rounds = Math.max(1, Math.min(10, Integer.parseInt(roundsArg)));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        state.rounds = rounds;
        switch (action.toLowerCase()) {
            case "advanced": {
                state.advanced.accept(rounds);
                break;
            }
            case "map": {
                state.map.accept(rounds);
                break;
            }
            case "confirm": {
                STATES.remove(player.getUniqueId());
                RoundSelectionDialog.close(player);
                player.closeInventory();
                state.confirm.accept(rounds);
                break;
            }
            case "close": {
                STATES.remove(player.getUniqueId());
                RoundSelectionDialog.close(player);
                state.close.run();
                break;
            }
        }
    }

    public static void close(Player player) {
        if (player != null) {
            STATES.remove(player.getUniqueId());
            PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerClearDialog());
        }
    }

    private static final class State {
        private final Consumer<Integer> advanced;
        private final Consumer<Integer> map;
        private final Consumer<Integer> confirm;
        private final Runnable close;
        private int rounds;

        private State(int rounds, Consumer<Integer> advanced, Consumer<Integer> map, Consumer<Integer> confirm, Runnable close) {
            this.rounds = rounds;
            this.advanced = advanced;
            this.map = map;
            this.confirm = confirm;
            this.close = close;
        }
    }
}

