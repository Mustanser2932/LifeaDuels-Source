/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 */
package me.lifea.gui.kit.ffa;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class FfaKitEditorHolder
implements InventoryHolder {
    private final String kitName;
    private Inventory inventory;

    public FfaKitEditorHolder(String kitName) {
        this.kitName = kitName;
    }

    public String getKitName() {
        return this.kitName;
    }

    void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Inventory getInventory() {
        return this.inventory;
    }
}

