/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package me.lifea.gui.kit.ffa;

import me.lifea.gui.kit.ffa.FfaKitEditorHolder;
import me.lifea.kit.ffa.FfaKitManager;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class FfaKitEditorGUI {
    public static final int HELMET_SLOT = 45;
    public static final int CHEST_SLOT = 46;
    public static final int LEGS_SLOT = 47;
    public static final int BOOTS_SLOT = 48;
    public static final int OFFHAND_SLOT = 50;
    private static final int PLACEHOLDER_CMD = 424242;

    private FfaKitEditorGUI() {
    }

    public static void open(Player player, String kitName) {
        FfaKitEditorHolder holder = new FfaKitEditorHolder(kitName);
        Inventory inv = Bukkit.createInventory((InventoryHolder)holder, (int)54, (Component)ColorUtil.parse("&#FF5555\u2694 &fFFA Kit: &e" + kitName));
        holder.setInventory(inv);
        ItemStack[] kit = FfaKitManager.getItems(kitName);
        if (kit == null) {
            kit = new ItemStack[41];
        }
        for (int i = 0; i <= 35; ++i) {
            inv.setItem(i, kit[i]);
        }
        inv.setItem(45, kit[39] != null ? kit[39] : FfaKitEditorGUI.ghost(Material.LEATHER_HELMET, "&#FFD1D1\ud83e\ude96 Helmet"));
        inv.setItem(46, kit[38] != null ? kit[38] : FfaKitEditorGUI.ghost(Material.LEATHER_CHESTPLATE, "&#FFD1D1\ud83d\udee1 Chestplate"));
        inv.setItem(47, kit[37] != null ? kit[37] : FfaKitEditorGUI.ghost(Material.LEATHER_LEGGINGS, "&#FFD1D1\ud83d\udc56 Leggings"));
        inv.setItem(48, kit[36] != null ? kit[36] : FfaKitEditorGUI.ghost(Material.LEATHER_BOOTS, "&#FFD1D1\ud83e\udd7e Boots"));
        inv.setItem(50, kit[40] != null ? kit[40] : FfaKitEditorGUI.ghost(Material.SHIELD, "&#FFD1D1\ud83e\udd1a Offhand"));
        ItemStack filler = FfaKitEditorGUI.filler();
        for (int i = 36; i <= 44; ++i) {
            inv.setItem(i, filler);
        }
        inv.setItem(49, filler);
        inv.setItem(51, filler);
        inv.setItem(52, filler);
        inv.setItem(53, filler);
        player.openInventory(inv);
    }

    public static boolean isPlaceholder(ItemStack item) {
        if (item == null) {
            return false;
        }
        Material t = item.getType();
        boolean armorGhost = t == Material.LEATHER_HELMET || t == Material.LEATHER_CHESTPLATE || t == Material.LEATHER_LEGGINGS || t == Material.LEATHER_BOOTS || t == Material.SHIELD;
        return armorGhost && item.hasItemMeta() && item.getItemMeta().hasCustomModelData() && item.getItemMeta().getCustomModelData() == 424242;
    }

    public static boolean isFiller(ItemStack item) {
        return item != null && item.getType() == Material.GRAY_STAINED_GLASS_PANE;
    }

    private static ItemStack ghost(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(FfaKitEditorGUI.noItalic(name));
        meta.setCustomModelData(Integer.valueOf(424242));
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack filler() {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName((Component)Component.empty());
        item.setItemMeta(meta);
        return item;
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

