/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryAction
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.gui.kit.ffa;

import java.util.Iterator;
import java.util.Set;
import me.lifea.gui.kit.ffa.FfaKitEditorGUI;
import me.lifea.gui.kit.ffa.FfaKitEditorHolder;
import me.lifea.kit.ffa.FfaKitManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class FfaKitEditorListener
implements Listener {
    private static final Set<Integer> EDITABLE_ARMOR = Set.of(Integer.valueOf(45), Integer.valueOf(46), Integer.valueOf(47), Integer.valueOf(48), Integer.valueOf(50));

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof FfaKitEditorHolder) {
            boolean inTop;
            Inventory top = event.getView().getTopInventory();
            int raw = event.getRawSlot();
            boolean bl = inTop = raw < top.getSize();
            if (event.isShiftClick()) {
                event.setCancelled(true);
            } else if (event.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
                event.setCancelled(true);
            } else if (inTop) {
                boolean editable;
                boolean bl2 = editable = raw >= 0 && raw <= 35 || EDITABLE_ARMOR.contains(raw);
                if (!editable) {
                    event.setCancelled(true);
                } else if (EDITABLE_ARMOR.contains(raw) && FfaKitEditorGUI.isPlaceholder(event.getCurrentItem()) && event.getCursor() != null && !event.getCursor().getType().isAir()) {
                    event.setCurrentItem((ItemStack)null);
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof FfaKitEditorHolder) {
            int topSize = event.getView().getTopInventory().getSize();
            Iterator iterator = event.getRawSlots().iterator();
            while (iterator.hasNext()) {
                boolean editable;
                int raw = (Integer)iterator.next();
                if (raw >= topSize || (editable = raw >= 0 && raw <= 35 || EDITABLE_ARMOR.contains(raw))) continue;
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        InventoryHolder var3 = event.getInventory().getHolder();
        if (var3 instanceof FfaKitEditorHolder) {
            FfaKitEditorHolder holder = (FfaKitEditorHolder)var3;
            Inventory var6 = event.getInventory();
            ItemStack[] kit = new ItemStack[41];
            for (int i = 0; i <= 35; ++i) {
                kit[i] = FfaKitEditorListener.clean(var6.getItem(i));
            }
            kit[39] = FfaKitEditorListener.clean(var6.getItem(45));
            kit[38] = FfaKitEditorListener.clean(var6.getItem(46));
            kit[37] = FfaKitEditorListener.clean(var6.getItem(47));
            kit[36] = FfaKitEditorListener.clean(var6.getItem(48));
            kit[40] = FfaKitEditorListener.clean(var6.getItem(50));
            FfaKitManager.setItems(holder.getKitName(), kit);
        }
    }

    private static ItemStack clean(ItemStack item) {
        if (item == null) {
            return null;
        }
        return !FfaKitEditorGUI.isFiller(item) && !FfaKitEditorGUI.isPlaceholder(item) ? item : null;
    }
}

