/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.gui.kit.ffa;

import java.util.ArrayList;
import java.util.Objects;
import java.util.function.Consumer;
import me.lifea.gui.kit.ffa.FfaKitEditorGUI;
import me.lifea.kit.ffa.FfaKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public final class FfaKitManagerGUI {
    private static final int KITS_PER_PAGE = 45;

    private FfaKitManagerGUI() {
    }

    public static void open(Player player) {
        FfaKitManagerGUI.open(player, 1);
    }

    private static void open(Player player, int page) {
        ArrayList<String> names = new ArrayList<String>(FfaKitManager.names());
        names.sort(String.CASE_INSENSITIVE_ORDER);
        int totalPages = Math.max(1, (int)Math.ceil((double)names.size() / 45.0));
        int finalPage = page = Math.max(1, Math.min(page, totalPages));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&#FB0000\ua730\ua730\u1d00 \u1d0b\u026a\u1d1b\u0455 &8\u2022 &f" + page + "/" + totalPages))).rows(6)).disableAllInteractions()).create();
        int start = (page - 1) * 45;
        int end = Math.min(start + 45, names.size());
        for (int i = start; i < end; ++i) {
            String name = (String)names.get(i);
            ItemStack[] contents = FfaKitManager.getItems(name);
            int itemCount = FfaKitManagerGUI.countItems(contents);
            gui.setItem(i - start, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.CHEST).name(FfaKitManagerGUI.noItalic("&f" + name))).lore(FfaKitManagerGUI.noItalic("&7\u0455\u1d00\u1d20\u1d07\u1d05 \u026a\u1d1b\u1d07\u1d0d\u0455: &f" + itemCount), FfaKitManagerGUI.noItalic("&7\u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d0d\u1d00\u0274\u1d00\u0262\u1d07 \u1d1b\u029c\u026a\u0455 \u1d0b\u026a\u1d1b"))).flags(ItemFlag.values())).asGuiItem(event -> FfaKitManagerGUI.openKit(player, name, finalPage)));
        }
        gui.setItem(49, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BOOK).name(FfaKitManagerGUI.noItalic("&#FB0000\u1d0b\u026a\u1d1b\u0455: &f" + names.size()))).lore(FfaKitManagerGUI.noItalic("&7\u1d04\u0280\u1d07\u1d00\u1d1b\u1d07: &f/ffa-kit create <name>"), FfaKitManagerGUI.noItalic("&7\u1d04\u029f\u026a\u1d04\u1d0b \u1d00 \u1d0b\u026a\u1d1b \ua730\u1d0f\u0280 \u1d07\u1d05\u026a\u1d1b, \u0262\u026a\u1d20\u1d07, \u0455\u1d00\u1d20\u1d07, \u1d0f\u0280 \u1d05\u1d07\u029f\u1d07\u1d1b\u1d07"))).flags(ItemFlag.values())).asGuiItem(event -> {}));
        if (page > 1) {
            gui.setItem(45, FfaKitManagerGUI.navItem("&#FB0000\u00ab &f\u1d18\u0280\u1d07\u1d20\u026a\u1d0f\u1d1c\u0455", event -> FfaKitManagerGUI.open(player, finalPage - 1)));
        }
        if (page < totalPages) {
            gui.setItem(53, FfaKitManagerGUI.navItem("&#FB0000\u0274\u1d07x\u1d1b \u00bb", event -> FfaKitManagerGUI.open(player, finalPage + 1)));
        }
        gui.open((HumanEntity)player);
    }

    private static void openKit(Player player, String name, int page) {
        ItemStack[] contents = FfaKitManager.getItems(name);
        int itemCount = FfaKitManagerGUI.countItems(contents);
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&#FB0000\u1d0d\u1d00\u0274\u1d00\u0262\u1d07: &f" + name))).rows(3)).disableAllInteractions()).create();
        gui.setItem(11, FfaKitManagerGUI.action(Material.CRAFTING_TABLE, "&a\u270e &f\u1d07\u1d05\u026a\u1d1b \u1d0b\u026a\u1d1b", "&7\u1d0f\u1d18\u1d07\u0274 \u1d1b\u029c\u1d07 \ua730\u1d1c\u029f\u029f \u026a\u0274\u1d20\u1d07\u0274\u1d1b\u1d0f\u0280\u028f \u1d07\u1d05\u026a\u1d1b\u1d0f\u0280", event -> FfaKitEditorGUI.open(player, name)));
        gui.setItem(12, FfaKitManagerGUI.action(Material.CHEST, "&#FB0000\u2193 &f\u0455\u1d00\u1d20\u1d07 \u1d0d\u028f \u026a\u0274\u1d20\u1d07\u0274\u1d1b\u1d0f\u0280\u028f", "&7\u1d0f\u1d20\u1d07\u0280\u1d21\u0280\u026a\u1d1b\u1d07 \u1d21\u026a\u1d1b\u029c \u028f\u1d0f\u1d1c\u0280 \u1d04\u1d1c\u0280\u0280\u1d07\u0274\u1d1b \u026a\u0274\u1d20\u1d07\u0274\u1d1b\u1d0f\u0280\u028f", event -> {
            FfaKitManager.setItems(name, FfaKitManagerGUI.inventoryOf(player));
            player.sendMessage(ColorUtil.parse("&aSaved your inventory into FFA kit &e" + name + "&a."));
            FfaKitManagerGUI.openKit(player, name, page);
        }));
        gui.setItem(14, FfaKitManagerGUI.action(Material.SHULKER_BOX, "&b\u2197 &f\u0262\u026a\u1d20\u1d07 \u1d1b\u1d0f \u1d0d\u1d07", "&7\u0280\u1d07\u1d18\u029f\u1d00\u1d04\u1d07 \u028f\u1d0f\u1d1c\u0280 \u026a\u0274\u1d20\u1d07\u0274\u1d1b\u1d0f\u0280\u028f \u1d21\u026a\u1d1b\u029c \u1d1b\u029c\u026a\u0455 \u1d0b\u026a\u1d1b", event -> {
            FfaKitManagerGUI.apply(player, contents);
            player.sendMessage(ColorUtil.parse("&aGave you FFA kit &e" + name + "&a."));
        }));
        gui.setItem(15, FfaKitManagerGUI.action(Material.PAPER, "&f\u026a\u1d1b\u1d07\u1d0d\u0455: &e" + itemCount, "&7\u026a\u0274\u1d04\u029f\u1d1c\u1d05\u1d07\u0455 \u1d00\u0280\u1d0d\u1d0f\u0280 \u1d00\u0274\u1d05 \u1d0f\ua730\ua730\u029c\u1d00\u0274\u1d05", event -> {}));
        gui.setItem(22, FfaKitManagerGUI.action(Material.TNT, "&c\u2718 &f\u1d05\u1d07\u029f\u1d07\u1d1b\u1d07 \u1d0b\u026a\u1d1b", "&c\u1d04\u029f\u026a\u1d04\u1d0b \u1d1b\u1d0f \u1d04\u1d0f\u0274\ua730\u026a\u0280\u1d0d", event -> FfaKitManagerGUI.confirmDelete(player, name, page)));
        gui.setItem(18, FfaKitManagerGUI.navItem("&c\u00ab &f\u0299\u1d00\u1d04\u1d0b", event -> FfaKitManagerGUI.open(player, page)));
        gui.open((HumanEntity)player);
    }

    private static void confirmDelete(Player player, String name, int page) {
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&c\u1d05\u1d07\u029f\u1d07\u1d1b\u1d07: &f" + name))).rows(3)).disableAllInteractions()).create();
        gui.setItem(11, FfaKitManagerGUI.action(Material.LIME_CONCRETE, "&a\u2714 &f\u1d0b\u1d07\u1d07\u1d18 \u1d0b\u026a\u1d1b", "&7\u0280\u1d07\u1d1b\u1d1c\u0280\u0274 \u1d21\u026a\u1d1b\u029c\u1d0f\u1d1c\u1d1b \u1d05\u1d07\u029f\u1d07\u1d1b\u026a\u0274\u0262", event -> FfaKitManagerGUI.openKit(player, name, page)));
        gui.setItem(15, FfaKitManagerGUI.action(Material.RED_CONCRETE, "&c\u2718 &f\u1d18\u1d07\u0280\u1d0d\u1d00\u0274\u1d07\u0274\u1d1b\u029f\u028f \u1d05\u1d07\u029f\u1d07\u1d1b\u1d07", "&c\u1d1b\u029c\u026a\u0455 \u1d04\u1d00\u0274\u0274\u1d0f\u1d1b \u0299\u1d07 \u1d1c\u0274\u1d05\u1d0f\u0274\u1d07", event -> {
            if (FfaKitManager.delete(name)) {
                player.sendMessage(ColorUtil.parse("&aDeleted FFA kit &e" + name + "&a."));
            }
            FfaKitManagerGUI.open(player, page);
        }));
        gui.open((HumanEntity)player);
    }

    private static GuiItem action(Material material, String name, String lore, Consumer<InventoryClickEvent> click) {
        ItemBuilder var10000 = (ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(material).name(FfaKitManagerGUI.noItalic(name))).lore(FfaKitManagerGUI.noItalic(lore))).flags(ItemFlag.values());
        Objects.requireNonNull(click);
        return var10000.asGuiItem(click::accept);
    }

    private static GuiItem navItem(String name, Consumer<InventoryClickEvent> click) {
        return FfaKitManagerGUI.action(Material.ARROW, name, "&7\u0274\u1d00\u1d20\u026a\u0262\u1d00\u1d1b\u1d07", click);
    }

    private static int countItems(ItemStack[] contents) {
        int count = 0;
        if (contents != null) {
            for (ItemStack item : contents) {
                if (item == null || item.getType().isAir()) continue;
                ++count;
            }
        }
        return count;
    }

    private static ItemStack[] inventoryOf(Player player) {
        ItemStack[] kit = new ItemStack[41];
        ItemStack[] storage = player.getInventory().getStorageContents();
        System.arraycopy(storage, 0, kit, 0, Math.min(36, storage.length));
        ItemStack[] armor = player.getInventory().getArmorContents();
        kit[36] = armor[0];
        kit[37] = armor[1];
        kit[38] = armor[2];
        kit[39] = armor[3];
        kit[40] = player.getInventory().getItemInOffHand();
        return kit;
    }

    private static void apply(Player player, ItemStack[] kit) {
        if (kit != null) {
            ItemStack[] main = new ItemStack[36];
            System.arraycopy(kit, 0, main, 0, Math.min(36, kit.length));
            player.getInventory().setStorageContents(main);
            player.getInventory().setArmorContents(new ItemStack[]{kit[36], kit[37], kit[38], kit[39]});
            player.getInventory().setItemInOffHand(kit[40]);
            player.updateInventory();
        }
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

