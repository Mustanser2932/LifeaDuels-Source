/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.gui.kit.custom;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class CustomKitSettingsGUI {
    private final int kitSlot;
    private final Player opponent;
    private Map<String, String> settings;
    private Player player;
    private boolean closing;

    public CustomKitSettingsGUI(int kitSlot, Player opponent) {
        this.kitSlot = kitSlot;
        this.opponent = opponent;
    }

    public void open(Player player) {
        ConfigurationSection section = ConfigManager.customKits().getConfigurationSection("custom-kit-settings");
        if (section == null) {
            player.sendMessage(ColorUtil.parse("&#FB0000Custom kit settings config not found!"));
        } else {
            CustomKit kit = CustomKitManager.getKit(player.getUniqueId(), this.kitSlot);
            if (kit == null) {
                player.sendMessage(ColorUtil.parse("&#FB0000Kit not found!"));
            } else {
                ConfigurationSection togglesSec;
                this.settings = new HashMap<String, String>(kit.getSettings());
                this.player = player;
                int size = section.getInt("size", 27);
                int rows = size / 9;
                String title = section.getString("title", "&8Kit Settings");
                Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
                FillerUtil.fill(gui, section.getConfigurationSection("fillers"));
                ConfigurationSection closeSec = section.getConfigurationSection("close-item");
                if (closeSec != null) {
                    Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                    if (closeMat == null) {
                        closeMat = Material.BARRIER;
                    }
                    int closeSlot = closeSec.getInt("slot", 22);
                    List<Component> closeLore = LoreUtil.read(closeSec, "lore");
                    ItemBuilder closeBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cClose")))).flags(ItemFlag.values());
                    if (!closeLore.isEmpty()) {
                        closeBuilder.lore(closeLore);
                    }
                    gui.setItem(closeSlot, closeBuilder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        player.closeInventory();
                    }));
                }
                if ((togglesSec = section.getConfigurationSection("toggles")) != null) {
                    for (String ruleKey : togglesSec.getKeys(false)) {
                        ConfigurationSection itemSec = togglesSec.getConfigurationSection(ruleKey);
                        if (itemSec == null) continue;
                        int slot = itemSec.getInt("slot", 0);
                        Material mat = Material.matchMaterial((String)itemSec.getString("material", "STONE"));
                        if (mat == null) {
                            mat = Material.STONE;
                        }
                        String name = itemSec.getString("name", ruleKey);
                        boolean enabled = Boolean.parseBoolean(this.settings.getOrDefault(ruleKey, "false"));
                        gui.setItem(slot, this.buildToggleItem(gui, mat, itemSec.getString("texture"), name, ruleKey, slot, enabled));
                    }
                }
                gui.setCloseGuiAction(event -> {
                    if (!this.closing) {
                        this.closing = true;
                        CustomKit k = CustomKitManager.getKit(player.getUniqueId(), this.kitSlot);
                        ItemStack[] currentContent = k != null ? k.getContent() : new ItemStack[41];
                        HashMap<String, String> potions = k != null ? k.getPotions() : new HashMap<String, String>();
                        CustomKitManager.saveKit(player.getUniqueId(), this.kitSlot, currentContent, this.settings, potions);
                        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> new CustomKitEditorGUI(this.kitSlot, this.opponent).open(player));
                    }
                });
                gui.open((HumanEntity)player);
            }
        }
    }

    private GuiItem buildToggleItem(Gui gui, Material mat, String texture, String name, String ruleKey, int slot, boolean enabled) {
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, texture).name(ColorUtil.parse(name))).lore(ColorUtil.parse(enabled ? "&fStatus: &a&lON &f- Click to disable" : "&fStatus: &c&lOFF &f- Click to enable"))).flags(ItemFlag.values())).asGuiItem(e -> {
            boolean newVal = !Boolean.parseBoolean(this.settings.getOrDefault(ruleKey, "false"));
            this.settings.put(ruleKey, String.valueOf(newVal));
            gui.updateItem(slot, this.buildToggleItem(gui, mat, texture, name, ruleKey, slot, newVal));
            this.player.playSound(this.player.getLocation(), newVal ? Sound.BLOCK_NOTE_BLOCK_PLING : Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.2f);
        });
    }
}

