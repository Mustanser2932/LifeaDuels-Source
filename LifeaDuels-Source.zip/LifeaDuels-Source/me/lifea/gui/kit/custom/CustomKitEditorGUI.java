/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.potion.PotionType
 */
package me.lifea.gui.kit.custom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.gui.kit.custom.CustomKitAutoPotionGUI;
import me.lifea.gui.kit.custom.CustomKitItemEditGUI;
import me.lifea.gui.kit.custom.CustomKitPotionEditGUI;
import me.lifea.gui.kit.custom.CustomKitPresetsGUI;
import me.lifea.gui.kit.custom.CustomKitSettingsGUI;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.kit.custom.CustomKitShareManager;
import me.lifea.libs.anvilgui.AnvilGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

public class CustomKitEditorGUI {
    private static final int GUI_SIZE = 54;
    private static final ItemFlag[] ALL_FLAGS = ItemFlag.values();
    private static final Map<UUID, UUID> editingPlayers = new HashMap<UUID, UUID>();
    private static final Map<UUID, ItemStack[]> savedInventories = new HashMap<UUID, ItemStack[]>();
    private final int kitSlot;
    private final Player opponent;
    private Gui gui;
    private Player player;
    private int currentCategoryIndex;
    private ItemStack[] content;
    private Map<String, String> settings;
    private Map<String, String> potions;
    private List<String> categoryOrder;
    private ConfigurationSection categoriesSec;
    private final Map<String, List<GuiItem>> cachedCategoryItems = new HashMap<String, List<GuiItem>>();
    private final Map<String, List<Map<String, Object>>> cachedCategoryData = new HashMap<String, List<Map<String, Object>>>();
    private Map<Material, Map<String, Object>> materialEntryCache;
    private boolean materialCacheBuilt;
    private ConfigurationSection cfg;
    private String guiTitle;
    private Material fillerMat;
    private String fillerName;
    private int renameSlot;
    private Material renameMat;
    private String renameName;
    private List<Component> renameLore;
    private String renameAnvilTitle;
    private boolean openingAnvil;
    private int presetsSlot;
    private Material presetsMat;
    private String presetsName;
    private List<Component> presetsLore;
    private int shareSlot;
    private Material shareMat;
    private String shareName;
    private List<Component> shareLore;
    private int settingsSlot;
    private Material settingsMat;
    private String settingsName;
    private List<Component> settingsLore;
    private int helmetSlot;
    private Material helmetPlaceholderMat;
    private String helmetPlaceholderName;
    private List<Component> helmetPlaceholderLore;
    private int chestplateSlot;
    private Material chestplatePlaceholderMat;
    private String chestplatePlaceholderName;
    private List<Component> chestplatePlaceholderLore;
    private int leggingsSlot;
    private Material leggingsPlaceholderMat;
    private String leggingsPlaceholderName;
    private List<Component> leggingsPlaceholderLore;
    private int bootsSlot;
    private Material bootsPlaceholderMat;
    private String bootsPlaceholderName;
    private List<Component> bootsPlaceholderLore;
    private int offhandSlot;
    private Material offhandPlaceholderMat;
    private String offhandPlaceholderName;
    private List<Component> offhandPlaceholderLore;
    private int autoPotionSlot;
    private Material autoPotionMat;
    private String autoPotionName;
    private List<Component> autoPotionLore;
    private int categoryDisplaySlot;
    private int prevCategorySlot;
    private Material prevCategoryMat;
    private String prevCategoryName;
    private List<Component> prevCategoryLore;
    private int nextCategorySlot;
    private Material nextCategoryMat;
    private String nextCategoryName;
    private List<Component> nextCategoryLore;
    private int[] itemSlots;
    private int[] fillerSlots;

    public CustomKitEditorGUI(int kitSlot, Player opponent) {
        this.kitSlot = kitSlot;
        this.opponent = opponent;
    }

    private void loadConfig() {
        this.cfg = ConfigManager.customKits().getConfigurationSection("editor-gui");
        if (this.cfg == null) {
            this.cfg = ConfigManager.customKits().createSection("editor-gui");
        }
        this.guiTitle = this.cfg.getString("title", "&8Editing Kit #{slot}");
        this.fillerMat = this.readMat("fillers.material", Material.GRAY_STAINED_GLASS_PANE);
        this.fillerName = this.cfg.getString("fillers.name", "&f");
        this.renameSlot = this.cfg.getInt("rename.slot", 0);
        this.renameMat = this.readMat("rename.material", Material.NAME_TAG);
        this.renameName = this.cfg.getString("rename.name", "&fKit Rename");
        this.renameLore = this.readLore("rename.lore", "&fClick to rename this kit");
        this.renameAnvilTitle = this.cfg.getString("rename.anvil-title", "Rename Kit");
        this.presetsSlot = this.cfg.getInt("presets.slot", 1);
        this.presetsMat = this.readMat("presets.material", Material.BUNDLE);
        this.presetsName = this.cfg.getString("presets.name", "&fKit Presets");
        this.presetsLore = this.readLore("presets.lore", "&fClick to manage presets");
        this.shareSlot = this.cfg.getInt("share.slot", 7);
        this.shareMat = this.readMat("share.material", Material.STONE_AXE);
        this.shareName = this.cfg.getString("share.name", "&fShare Kit");
        this.shareLore = this.readLore("share.lore", "&fClick to share this kit");
        this.settingsSlot = this.cfg.getInt("settings.slot", 8);
        this.settingsMat = this.readMat("settings.material", Material.COMPARATOR);
        this.settingsName = this.cfg.getString("settings.name", "&6Custom Kit Settings");
        this.settingsLore = this.readLore("settings.lore", "&fClick to open settings");
        this.helmetSlot = this.cfg.getInt("helmet.slot", 10);
        this.helmetPlaceholderMat = this.readMat("helmet.placeholder-material", Material.ARMOR_STAND);
        this.helmetPlaceholderName = this.cfg.getString("helmet.placeholder-name", "&8Helmet Slot");
        this.helmetPlaceholderLore = this.readLore("helmet.placeholder-lore", "&fPlace armor here from your cursor");
        this.chestplateSlot = this.cfg.getInt("chestplate.slot", 11);
        this.chestplatePlaceholderMat = this.readMat("chestplate.placeholder-material", Material.ARMOR_STAND);
        this.chestplatePlaceholderName = this.cfg.getString("chestplate.placeholder-name", "&8Chestplate Slot");
        this.chestplatePlaceholderLore = this.readLore("chestplate.placeholder-lore", "&fPlace armor here from your cursor");
        this.leggingsSlot = this.cfg.getInt("leggings.slot", 12);
        this.leggingsPlaceholderMat = this.readMat("leggings.placeholder-material", Material.ARMOR_STAND);
        this.leggingsPlaceholderName = this.cfg.getString("leggings.placeholder-name", "&8Leggings Slot");
        this.leggingsPlaceholderLore = this.readLore("leggings.placeholder-lore", "&fPlace armor here from your cursor");
        this.bootsSlot = this.cfg.getInt("boots.slot", 13);
        this.bootsPlaceholderMat = this.readMat("boots.placeholder-material", Material.ARMOR_STAND);
        this.bootsPlaceholderName = this.cfg.getString("boots.placeholder-name", "&8Boots Slot");
        this.bootsPlaceholderLore = this.readLore("boots.placeholder-lore", "&fPlace armor here from your cursor");
        this.offhandSlot = this.cfg.getInt("offhand.slot", 14);
        this.offhandPlaceholderMat = this.readMat("offhand.placeholder-material", Material.PAINTING);
        this.offhandPlaceholderName = this.cfg.getString("offhand.placeholder-name", "&8Offhand Slot");
        this.offhandPlaceholderLore = this.readLore("offhand.placeholder-lore", "&fPlace item here from your cursor");
        this.autoPotionSlot = this.cfg.getInt("auto-potion.slot", 16);
        this.autoPotionMat = this.readMat("auto-potion.material", Material.POTION);
        this.autoPotionName = this.cfg.getString("auto-potion.name", "&#FFAA00AutoPotion");
        this.autoPotionLore = this.readLore("auto-potion.lore", "&fClick to edit auto potions");
        this.categoryDisplaySlot = this.cfg.getInt("category-display.slot", 43);
        this.prevCategorySlot = this.cfg.getInt("previous-category.slot", 34);
        this.prevCategoryMat = this.readMat("previous-category.material", Material.BLACK_BANNER);
        this.prevCategoryName = this.cfg.getString("previous-category.name", "&fPrevious Category");
        this.prevCategoryLore = this.readLore("previous-category.lore", "&fClick to go to previous category");
        this.nextCategorySlot = this.cfg.getInt("next-category.slot", 52);
        this.nextCategoryMat = this.readMat("next-category.material", Material.BLACK_BANNER);
        this.nextCategoryName = this.cfg.getString("next-category.name", "&fNext Category");
        this.nextCategoryLore = this.readLore("next-category.lore", "&fClick to go to next category");
        this.itemSlots = this.readIntArray("item-slots", new int[]{28, 29, 30, 31, 32, 37, 38, 39, 40, 41, 46, 47, 48, 49, 50});
        this.fillerSlots = this.readIntArray("filler-slots", new int[]{15, 19, 20, 21, 22, 23, 24, 25, 33, 42, 51});
    }

    private Material readMat(String path, Material def) {
        String name = this.cfg.getString(path);
        if (name == null) {
            return def;
        }
        Material m = Material.matchMaterial((String)name);
        return m != null ? m : def;
    }

    private List<Component> readLore(String path, String defaultLine) {
        ConfigurationSection sec = this.cfg;
        String[] parts = path.split("\\.");
        for (int i = 0; i < parts.length - 1; ++i) {
            if ((sec = sec.getConfigurationSection(parts[i])) != null) continue;
            ArrayList<Component> list = new ArrayList<Component>();
            list.add(ColorUtil.parse(defaultLine));
            return list;
        }
        List<Component> result = LoreUtil.read(sec, parts[parts.length - 1]);
        if (result.isEmpty() && defaultLine != null) {
            result.add(ColorUtil.parse(defaultLine));
        }
        return result;
    }

    private int[] readIntArray(String path, int[] def) {
        List list = this.cfg.getIntegerList(path);
        if (list.isEmpty()) {
            return def;
        }
        int[] arr = new int[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            arr[i] = (Integer)list.get(i);
        }
        return arr;
    }

    public static boolean isEditing(Player player) {
        return editingPlayers.containsKey(player.getUniqueId());
    }

    public static UUID getEditingKitOwner(Player player) {
        return editingPlayers.get(player.getUniqueId());
    }

    public static void removeIfEditing(Player player) {
        editingPlayers.remove(player.getUniqueId());
    }

    public static void cleanupOnQuit(Player player) {
        if (editingPlayers.remove(player.getUniqueId()) != null) {
            CustomKitEditorGUI.restoreInventory(player);
        }
    }

    private static void restoreInventory(Player player) {
        ItemStack[] saved = savedInventories.remove(player.getUniqueId());
        if (saved != null) {
            player.getInventory().setContents(saved);
        } else {
            player.getInventory().clear();
            player.getInventory().setArmorContents((ItemStack[])null);
            player.getInventory().setItemInOffHand((ItemStack)null);
        }
    }

    public void open(Player player) {
        if (!CustomKitManager.isEnabled()) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
        } else {
            this.loadConfig();
            ConfigurationSection kitEditorSec = ConfigManager.customKits().getConfigurationSection("kit-editor");
            if (kitEditorSec == null) {
                player.sendMessage(ColorUtil.parse("&#FB0000Kit editor config not found!"));
            } else {
                this.categoriesSec = kitEditorSec.getConfigurationSection("categories");
                if (this.categoriesSec == null) {
                    player.sendMessage(ColorUtil.parse("&#FB0000No categories defined!"));
                } else {
                    this.categoryOrder = new ArrayList<String>(this.categoriesSec.getKeys(false));
                    if (this.categoryOrder.isEmpty()) {
                        player.sendMessage(ColorUtil.parse("&#FB0000No categories defined!"));
                    } else {
                        int[] armorSlots;
                        this.currentCategoryIndex = Math.max(0, Math.min(this.currentCategoryIndex, this.categoryOrder.size() - 1));
                        CustomKit existing = CustomKitManager.getKit(player.getUniqueId(), this.kitSlot);
                        this.content = existing != null ? existing.getContent() : new ItemStack[41];
                        this.settings = existing != null ? new HashMap<String, String>(existing.getSettings()) : new HashMap();
                        this.potions = existing != null ? new HashMap<String, String>(existing.getPotions()) : new HashMap();
                        savedInventories.putIfAbsent(player.getUniqueId(), player.getInventory().getContents());
                        player.getInventory().clear();
                        player.getInventory().setArmorContents((ItemStack[])null);
                        player.getInventory().setItemInOffHand((ItemStack)null);
                        for (int i = 0; i < 36; ++i) {
                            if (this.content[i] == null || this.content[i].getType() == Material.AIR) continue;
                            player.getInventory().setItem(i, this.content[i].clone());
                        }
                        if (this.content[39] != null) {
                            player.getInventory().setHelmet(this.content[39].clone());
                        }
                        if (this.content[38] != null) {
                            player.getInventory().setChestplate(this.content[38].clone());
                        }
                        if (this.content[37] != null) {
                            player.getInventory().setLeggings(this.content[37].clone());
                        }
                        if (this.content[36] != null) {
                            player.getInventory().setBoots(this.content[36].clone());
                        }
                        if (this.content[40] != null && this.content[40].getType() != Material.AIR) {
                            player.getInventory().setItemInOffHand(this.content[40].clone());
                        }
                        String kitName = this.settings.getOrDefault("kit-name", "Kit " + this.kitSlot);
                        this.gui = ((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(this.guiTitle.replace("{slot}", String.valueOf(this.kitSlot)).replace("{name}", kitName)))).rows(6)).create();
                        this.player = player;
                        for (int slot : this.fillerSlots) {
                            this.gui.setItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
                        }
                        this.gui.setItem(this.renameSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.renameMat).name(ColorUtil.parse(this.renameName))).lore(this.renameLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            e.setCancelled(true);
                            SoundUtil.playClick(player);
                            this.openingAnvil = true;
                            this.openRenameAnvil();
                        }));
                        this.gui.setItem(this.presetsSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.presetsMat).name(ColorUtil.parse(this.presetsName))).lore(this.presetsLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            e.setCancelled(true);
                            SoundUtil.playClick(player);
                            this.captureAll();
                            this.saveKit();
                            new CustomKitPresetsGUI(this.kitSlot, this.opponent).open(player);
                        }));
                        this.gui.setItem(this.shareSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.shareMat).name(ColorUtil.parse(this.shareName))).lore(this.shareLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            e.setCancelled(true);
                            SoundUtil.playClick(player);
                            this.captureAll();
                            this.saveKit();
                            String code = CustomKitShareManager.encode(this.content, this.settings, this.potions);
                            player.sendMessage(ColorUtil.parse("&aKit exported! Click to copy the share code:"));
                            player.sendMessage(ColorUtil.parse("&f" + code).clickEvent(ClickEvent.copyToClipboard((String)code)).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse("&eClick to copy share code"))));
                            player.sendMessage(ColorUtil.parse("&fShare this code with friends so they can use &f/importkit &fto import your kit!"));
                        }));
                        this.gui.setItem(this.settingsSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.settingsMat).name(ColorUtil.parse(this.settingsName))).lore(this.settingsLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            SoundUtil.playClick(player);
                            this.captureAll();
                            this.saveKit();
                            new CustomKitSettingsGUI(this.kitSlot, this.opponent).open(player);
                        }));
                        for (int slot : armorSlots = new int[]{this.helmetSlot, this.chestplateSlot, this.leggingsSlot, this.bootsSlot}) {
                            this.setArmorSlot(slot, this.contentIndexForSlot(slot));
                        }
                        this.setOffhandSlot();
                        this.gui.setItem(this.autoPotionSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.autoPotionMat).name(ColorUtil.parse(this.autoPotionName))).lore(this.autoPotionLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            e.setCancelled(true);
                            SoundUtil.playClick(player);
                            this.captureAll();
                            this.saveKit();
                            new CustomKitAutoPotionGUI(this.kitSlot, this.opponent).open(player);
                        }));
                        this.gui.setItem(this.prevCategorySlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.prevCategoryMat).name(ColorUtil.parse(this.prevCategoryName))).lore(this.prevCategoryLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            e.setCancelled(true);
                            SoundUtil.playClick(player);
                            this.captureAll();
                            --this.currentCategoryIndex;
                            if (this.currentCategoryIndex < 0) {
                                this.currentCategoryIndex = this.categoryOrder.size() - 1;
                            }
                            this.renderCategory();
                        }));
                        this.gui.setItem(this.nextCategorySlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.nextCategoryMat).name(ColorUtil.parse(this.nextCategoryName))).lore(this.nextCategoryLore)).flags(ALL_FLAGS)).asGuiItem(e -> {
                            e.setCancelled(true);
                            SoundUtil.playClick(player);
                            this.captureAll();
                            ++this.currentCategoryIndex;
                            if (this.currentCategoryIndex >= this.categoryOrder.size()) {
                                this.currentCategoryIndex = 0;
                            }
                            this.renderCategory();
                        }));
                        this.renderCategory();
                        this.gui.setDefaultClickAction(event -> {
                            ItemStack item;
                            if (event.getRawSlot() < 54) {
                                event.setCancelled(true);
                            } else if (event.isRightClick() && event.getSlot() >= 0 && event.getSlot() < 36 && (item = event.getCurrentItem()) != null && item.getType() != Material.AIR) {
                                event.setCancelled(true);
                                this.captureAll();
                                if (item.getItemMeta() instanceof PotionMeta) {
                                    new CustomKitPotionEditGUI(this.kitSlot, this.opponent, event.getSlot(), this.content, this.settings, this.potions, player).open(player);
                                } else {
                                    Map<String, Object> entry = this.findCategoryEntry(item);
                                    new CustomKitItemEditGUI(this.kitSlot, this.opponent, event.getSlot(), this.content, entry, this.settings, this.potions, player).open(player);
                                }
                            }
                        });
                        this.gui.setCloseGuiAction(event -> {
                            if (!this.openingAnvil) {
                                this.captureAll();
                                try {
                                    this.saveKit();
                                }
                                catch (Exception exception) {
                                    // empty catch block
                                }
                                editingPlayers.remove(player.getUniqueId());
                                CustomKitEditorGUI.restoreInventory(player);
                                player.setItemOnCursor((ItemStack)null);
                            }
                        });
                        this.gui.open((HumanEntity)player);
                        editingPlayers.put(player.getUniqueId(), this.opponent.getUniqueId());
                    }
                }
            }
        }
    }

    private void syncPlayerEquipment() {
        this.player.getInventory().setHelmet(this.content[39] != null ? this.content[39].clone() : null);
        this.player.getInventory().setChestplate(this.content[38] != null ? this.content[38].clone() : null);
        this.player.getInventory().setLeggings(this.content[37] != null ? this.content[37].clone() : null);
        this.player.getInventory().setBoots(this.content[36] != null ? this.content[36].clone() : null);
        this.player.getInventory().setItemInOffHand(this.content[40] != null ? this.content[40].clone() : null);
    }

    private Material placeholderMatForSlot(int guiSlot) {
        if (guiSlot == this.helmetSlot) {
            return this.helmetPlaceholderMat;
        }
        if (guiSlot == this.chestplateSlot) {
            return this.chestplatePlaceholderMat;
        }
        if (guiSlot == this.leggingsSlot) {
            return this.leggingsPlaceholderMat;
        }
        return guiSlot == this.bootsSlot ? this.bootsPlaceholderMat : Material.ARMOR_STAND;
    }

    private void setArmorSlot(int guiSlot, int contentIdx) {
        ItemStack display = this.buildSlotDisplay(guiSlot, contentIdx);
        Material placeholder = this.placeholderMatForSlot(guiSlot);
        this.gui.updateItem(guiSlot, ItemBuilder.from(display).asGuiItem(e -> {
            ItemStack slotItem;
            e.setCancelled(true);
            if (e.isRightClick() && (slotItem = this.gui.getInventory().getItem(guiSlot)) != null && slotItem.getType() != Material.AIR && slotItem.getType() != placeholder) {
                this.captureAll();
                if (slotItem.getItemMeta() instanceof PotionMeta) {
                    new CustomKitPotionEditGUI(this.kitSlot, this.opponent, contentIdx, this.content, this.settings, this.potions, this.player).open(this.player);
                } else {
                    Map<String, Object> entry = this.findCategoryEntry(slotItem);
                    new CustomKitItemEditGUI(this.kitSlot, this.opponent, contentIdx, this.content, entry, this.settings, this.potions, this.player).open(this.player);
                }
                return;
            }
            this.handleArmorClick(guiSlot, contentIdx);
        }));
    }

    private void setOffhandSlot() {
        ItemStack display = this.buildOffhandDisplay();
        this.gui.updateItem(this.offhandSlot, ItemBuilder.from(display).asGuiItem(e -> {
            ItemStack slotItem;
            e.setCancelled(true);
            if (e.isRightClick() && (slotItem = this.gui.getInventory().getItem(this.offhandSlot)) != null && slotItem.getType() != Material.AIR && slotItem.getType() != this.offhandPlaceholderMat) {
                this.captureAll();
                if (slotItem.getItemMeta() instanceof PotionMeta) {
                    new CustomKitPotionEditGUI(this.kitSlot, this.opponent, 40, this.content, this.settings, this.potions, this.player).open(this.player);
                } else {
                    Map<String, Object> entry = this.findCategoryEntry(slotItem);
                    new CustomKitItemEditGUI(this.kitSlot, this.opponent, 40, this.content, entry, this.settings, this.potions, this.player).open(this.player);
                }
                return;
            }
            this.handleOffhandClick();
        }));
    }

    private void handleArmorClick(int guiSlot, int contentIdx) {
        boolean isPlaceholder;
        ItemStack cursor = this.player.getItemOnCursor();
        ItemStack slotItem = this.gui.getInventory().getItem(guiSlot);
        Material placeholder = this.placeholderMatForSlot(guiSlot);
        boolean bl = isPlaceholder = slotItem != null && slotItem.getType() == placeholder;
        if (!isPlaceholder || cursor != null && cursor.getType() != Material.AIR) {
            Object expected;
            if (cursor != null && cursor.getType() != Material.AIR && (expected = guiSlot == this.helmetSlot ? EquipmentSlot.HEAD : (guiSlot == this.chestplateSlot ? EquipmentSlot.CHEST : (guiSlot == this.leggingsSlot ? EquipmentSlot.LEGS : (guiSlot == this.bootsSlot ? EquipmentSlot.FEET : null)))) != null && cursor.getType().getEquipmentSlot() != expected && (expected != EquipmentSlot.CHEST || cursor.getType() != Material.ELYTRA)) {
                this.player.sendMessage(ColorUtil.parse("&cWrong armor type for this slot!"));
                return;
            }
            if (isPlaceholder) {
                this.gui.getInventory().setItem(guiSlot, cursor.clone());
                this.player.setItemOnCursor((ItemStack)null);
            } else {
                this.player.setItemOnCursor(slotItem);
                if (cursor != null && cursor.getType() != Material.AIR) {
                    this.gui.getInventory().setItem(guiSlot, cursor.clone());
                } else {
                    this.gui.getInventory().setItem(guiSlot, (ItemStack)null);
                }
            }
            this.updateContentFromSlot(guiSlot, contentIdx, placeholder);
            this.syncPlayerEquipment();
            this.setArmorSlot(guiSlot, contentIdx);
        }
    }

    private void handleOffhandClick() {
        boolean isPlaceholder;
        ItemStack cursor = this.player.getItemOnCursor();
        ItemStack slotItem = this.gui.getInventory().getItem(this.offhandSlot);
        boolean bl = isPlaceholder = slotItem != null && slotItem.getType() == this.offhandPlaceholderMat;
        if (!isPlaceholder || cursor != null && cursor.getType() != Material.AIR) {
            if (isPlaceholder) {
                this.gui.getInventory().setItem(this.offhandSlot, cursor.clone());
                this.player.setItemOnCursor((ItemStack)null);
            } else {
                this.player.setItemOnCursor(slotItem);
                if (cursor != null && cursor.getType() != Material.AIR) {
                    this.gui.getInventory().setItem(this.offhandSlot, cursor.clone());
                } else {
                    this.gui.getInventory().setItem(this.offhandSlot, (ItemStack)null);
                }
            }
            this.updateContentFromSlot(this.offhandSlot, 40, this.offhandPlaceholderMat);
            this.syncPlayerEquipment();
            this.setOffhandSlot();
        }
    }

    private void updateContentFromSlot(int guiSlot, int contentIdx, Material placeholderType) {
        ItemStack newSlot = this.gui.getInventory().getItem(guiSlot);
        this.content[contentIdx] = newSlot != null && newSlot.getType() != Material.AIR && newSlot.getType() != placeholderType ? newSlot.clone() : null;
    }

    private ItemStack buildSlotDisplay(int guiSlot, int contentIdx) {
        List<Component> pLore;
        Material pMat;
        String pName;
        if (this.content[contentIdx] != null && this.content[contentIdx].getType() != Material.AIR) {
            return this.content[contentIdx].clone();
        }
        if (guiSlot == this.helmetSlot) {
            pName = this.helmetPlaceholderName;
            pMat = this.helmetPlaceholderMat;
            pLore = this.helmetPlaceholderLore;
        } else if (guiSlot == this.chestplateSlot) {
            pName = this.chestplatePlaceholderName;
            pMat = this.chestplatePlaceholderMat;
            pLore = this.chestplatePlaceholderLore;
        } else if (guiSlot == this.leggingsSlot) {
            pName = this.leggingsPlaceholderName;
            pMat = this.leggingsPlaceholderMat;
            pLore = this.leggingsPlaceholderLore;
        } else if (guiSlot == this.bootsSlot) {
            pName = this.bootsPlaceholderName;
            pMat = this.bootsPlaceholderMat;
            pLore = this.bootsPlaceholderLore;
        } else {
            pName = "&8Armor Slot";
            pMat = Material.ARMOR_STAND;
            pLore = List.of(ColorUtil.parse("&fPlace armor here from your cursor"));
        }
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(pMat).name(ColorUtil.parse(pName))).lore(pLore)).flags(ALL_FLAGS)).build();
    }

    private ItemStack buildOffhandDisplay() {
        return this.content[40] != null && this.content[40].getType() != Material.AIR ? this.content[40].clone() : ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.offhandPlaceholderMat).name(ColorUtil.parse(this.offhandPlaceholderName))).lore(this.offhandPlaceholderLore)).flags(ALL_FLAGS)).build();
    }

    private void renderCategory() {
        String catName = this.categoryOrder.get(this.currentCategoryIndex);
        ConfigurationSection catSec = this.categoriesSec.getConfigurationSection(catName);
        if (catSec != null) {
            ParsedMaterial iconPm = CustomKitEditorGUI.parseMaterialString(catSec.getString("icon", "STONE"));
            ItemStack iconStack = iconPm.isPotion() ? CustomKitEditorGUI.toItemStack(iconPm, 1) : new ItemStack(iconPm.material(), 1);
            this.gui.updateItem(this.categoryDisplaySlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(iconStack).name(ColorUtil.parse("&e" + catName))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            List<GuiItem> catItems = this.cachedCategoryItems.get(catName);
            if (catItems == null) {
                List<Map<String, Object>> itemData = this.loadCategoryItems(catName);
                catItems = new ArrayList<GuiItem>(itemData.size());
                for (Map<String, Object> itemMap : itemData) {
                    catItems.add(this.buildCategoryItem(itemMap));
                }
                this.cachedCategoryItems.put(catName, catItems);
            }
            for (int i = 0; i < this.itemSlots.length; ++i) {
                int slot = this.itemSlots[i];
                if (i < catItems.size()) {
                    this.gui.updateItem(slot, catItems.get(i));
                    continue;
                }
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
        }
    }

    private List<Map<String, Object>> loadCategoryItems(String catName) {
        List<Map<String, Object>> cached = this.cachedCategoryData.get(catName);
        if (cached != null) {
            return cached;
        }
        ConfigurationSection catSec = this.categoriesSec.getConfigurationSection(catName);
        if (catSec == null) {
            return Collections.emptyList();
        }
        ArrayList<Map<String, Object>> items = new ArrayList<Map<String, Object>>();
        List raw = catSec.getList("items");
        if (raw != null) {
            for (Object obj : raw) {
                if (!(obj instanceof Map)) continue;
                items.add((Map)obj);
            }
        }
        this.cachedCategoryData.put(catName, items);
        return items;
    }

    private GuiItem buildCategoryItem(Map<String, Object> itemMap) {
        String matName = (String)itemMap.getOrDefault("material", "STONE");
        ParsedMaterial pm = CustomKitEditorGUI.parseMaterialString(matName);
        Material mat = pm.material();
        boolean allowStack = (Boolean)itemMap.getOrDefault("allow-stack", false);
        int maxStack = ((Number)itemMap.getOrDefault("max-stack", mat.getMaxStackSize())).intValue();
        List enchantments = itemMap.getOrDefault("allowed-enchantments", Collections.emptyList());
        List variants = itemMap.getOrDefault("variant-materials", Collections.emptyList());
        ItemStack display = pm.isPotion() ? CustomKitEditorGUI.toItemStack(pm, 1) : new ItemStack(mat, 1);
        ItemBuilder builder = (ItemBuilder)ItemBuilder.from(display).name(ColorUtil.parse("&f" + CustomKitEditorGUI.formatName(matName)));
        return builder.asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            int amount = allowStack ? Math.min(maxStack, mat.getMaxStackSize()) : 1;
            this.player.setItemOnCursor(pm.isPotion() ? CustomKitEditorGUI.toItemStack(pm, amount) : new ItemStack(mat, amount));
        });
    }

    private Map<String, Object> findCategoryEntry(ItemStack item) {
        if (item != null && this.categoriesSec != null) {
            Material mat = item.getType();
            if (!this.materialCacheBuilt) {
                this.materialEntryCache = new HashMap<Material, Map<String, Object>>();
                for (String catName : this.categoryOrder) {
                    for (Map<String, Object> entry : this.loadCategoryItems(catName)) {
                        List variants;
                        Material primaryMat;
                        String primary = (String)entry.get("material");
                        if (primary != null && (primaryMat = Material.matchMaterial((String)CustomKitEditorGUI.bareMaterial(primary))) != null) {
                            this.materialEntryCache.put(primaryMat, entry);
                        }
                        if ((variants = (List)entry.get("variant-materials")) == null) continue;
                        for (String v : variants) {
                            Material vMat = Material.matchMaterial((String)CustomKitEditorGUI.bareMaterial(v));
                            if (vMat == null) continue;
                            this.materialEntryCache.put(vMat, entry);
                        }
                    }
                }
                this.materialCacheBuilt = true;
            }
            return this.materialEntryCache.get(mat);
        }
        return null;
    }

    private void captureAll() {
        for (int i = 0; i < 36; ++i) {
            ItemStack item = this.player.getInventory().getItem(i);
            this.content[i] = item != null && item.getType() != Material.AIR ? item.clone() : null;
        }
        ItemStack boots = this.player.getInventory().getBoots();
        this.content[36] = boots != null && boots.getType() != Material.AIR ? boots.clone() : null;
        ItemStack leggings = this.player.getInventory().getLeggings();
        this.content[37] = leggings != null && leggings.getType() != Material.AIR ? leggings.clone() : null;
        ItemStack chestplate = this.player.getInventory().getChestplate();
        this.content[38] = chestplate != null && chestplate.getType() != Material.AIR ? chestplate.clone() : null;
        ItemStack helmet = this.player.getInventory().getHelmet();
        this.content[39] = helmet != null && helmet.getType() != Material.AIR ? helmet.clone() : null;
        ItemStack offhand = this.player.getInventory().getItemInOffHand();
        this.content[40] = offhand != null && offhand.getType() != Material.AIR ? offhand.clone() : null;
    }

    private void saveKit() {
        CustomKitManager.saveKit(this.player.getUniqueId(), this.kitSlot, this.content, this.settings, this.potions);
    }

    private void reopenEditGui() {
        new CustomKitEditorGUI(this.kitSlot, this.opponent).open(this.player);
    }

    private void openRenameAnvil() {
        String currentName = this.settings.getOrDefault("kit-name", "Kit " + this.kitSlot);
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title(this.renameAnvilTitle).text(currentName).itemLeft(new ItemStack(this.renameMat)).onClick((slot, state) -> {
            if (slot != 2) {
                return List.of();
            }
            String text = state.getText();
            if (text != null && !text.trim().isEmpty()) {
                this.settings.put("kit-name", text.trim());
                this.captureAll();
                this.saveKit();
                return List.of(AnvilGUI.ResponseAction.close());
            }
            return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a name"));
        }).onClose(state -> {
            String text = state.getText();
            if (text != null && !text.trim().isEmpty()) {
                this.settings.put("kit-name", text.trim());
                this.captureAll();
                this.saveKit();
            }
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
        }).open(this.player);
    }

    private int contentIndexForSlot(int guiSlot) {
        if (guiSlot == this.helmetSlot) {
            return 39;
        }
        if (guiSlot == this.chestplateSlot) {
            return 38;
        }
        if (guiSlot == this.leggingsSlot) {
            return 37;
        }
        if (guiSlot == this.bootsSlot) {
            return 36;
        }
        return guiSlot == this.offhandSlot ? 40 : -1;
    }

    private static String formatName(String matName) {
        String base = matName.contains(":") ? matName.substring(0, matName.indexOf(58)) : matName;
        String[] parts = base.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.length() <= 0) continue;
            sb.append(Character.toUpperCase(part.charAt(0)));
            sb.append(part.substring(1));
            sb.append(' ');
        }
        return sb.toString().trim();
    }

    private static String bareMaterial(String input) {
        int idx = input.indexOf(58);
        return idx >= 0 ? input.substring(0, idx) : input;
    }

    private static ParsedMaterial parseMaterialString(String input) {
        String[] parts = input.split(":");
        Material mat = Material.matchMaterial((String)parts[0]);
        if (mat == null) {
            mat = Material.STONE;
        }
        if (parts.length == 1) {
            return new ParsedMaterial(mat, null, 0, -1);
        }
        String type = parts[1].replace(' ', '_').toUpperCase();
        int strength = parts.length >= 3 ? Math.max(0, Integer.parseInt(parts[2]) - 1) : 0;
        int durationSec = parts.length >= 4 ? Integer.parseInt(parts[3]) : -1;
        int ticks = durationSec > 0 ? durationSec * 20 : -1;
        return new ParsedMaterial(mat, type, strength, ticks);
    }

    private static ItemStack toItemStack(ParsedMaterial pm, int amount) {
        ItemStack stack = new ItemStack(pm.material(), amount);
        if (pm.isPotion()) {
            try {
                PotionType type = PotionType.valueOf((String)pm.potionType());
                stack.editMeta(PotionMeta.class, meta -> {
                    PotionEffectType effectType;
                    meta.setBasePotionType(type);
                    if (pm.durationTicks() > 0 && (effectType = type.getEffectType()) != null) {
                        meta.addCustomEffect(new PotionEffect(effectType, pm.durationTicks(), pm.amplifier()), true);
                    }
                });
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
        return stack;
    }

    private record ParsedMaterial(Material material, String potionType, int amplifier, int durationTicks) {
        boolean isPotion() {
            return this.potionType != null;
        }
    }
}

