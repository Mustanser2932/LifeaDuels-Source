/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.kit.custom;

import java.util.ArrayList;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.duel.custom.CustomKitRequestManager;
import me.lifea.gui.ArenaSelectGUI;
import me.lifea.gui.GUIManager;
import me.lifea.gui.RoundSelectionDialog;
import me.lifea.gui.kit.custom.CustomKitsMenuGUI;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class CustomKitRoundSelectionGUI {
    private static final int MIN_ROUNDS = 1;
    private static final int MAX_ROUNDS = 10;
    private final Player requester;
    private final Player target;
    private final int kitSlot;
    private final int rounds;

    public CustomKitRoundSelectionGUI(Player requester, Player target, int kitSlot) {
        this(requester, target, kitSlot, 1);
    }

    public CustomKitRoundSelectionGUI(Player requester, Player target, int kitSlot, int rounds) {
        this.requester = requester;
        this.target = target;
        this.kitSlot = kitSlot;
        this.rounds = rounds;
    }

    public void open(Player player) {
        if (!CustomKitManager.isEnabled()) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
        } else if (!RoundSelectionDialog.supports(player)) {
            this.openLegacy(player);
        } else {
            String selectedArena = GUIManager.getSelectedArena(player.getUniqueId());
            RoundSelectionDialog.open(player, "Custom Kit", this.target.getName(), selectedArena != null ? selectedArena : "Random", this.rounds, selectedRounds -> player.sendMessage(ColorUtil.parse("&7Advanced options are not available for custom-kit duels yet.")), selectedRounds -> {
                RoundSelectionDialog.close(player);
                ArenaSelectGUI.open(player, "CUSTOM_KITS", () -> new CustomKitRoundSelectionGUI(this.requester, this.target, this.kitSlot, (int)selectedRounds).open(player));
            }, selectedRounds -> {
                RoundSelectionDialog.close(player);
                String arenaBaseName = GUIManager.getSelectedArena(player.getUniqueId());
                CustomKitRequestManager.sendRequest(this.requester, this.target, this.kitSlot, (int)selectedRounds, arenaBaseName);
            }, () -> {});
        }
    }

    private void openLegacy(Player player) {
        ConfigurationSection cfg = ConfigManager.config().getConfigurationSection("round-gui");
        if (cfg == null) {
            cfg = ConfigManager.config().getConfigurationSection("gui.round-gui");
        }
        String title = cfg != null ? cfg.getString("name", "Round Selection") : "Round Selection";
        int size = cfg != null ? cfg.getInt("size", 27) : 27;
        int rows = size / 9;
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
        if (cfg == null) {
            gui.open((HumanEntity)player);
        } else {
            ConfigurationSection items;
            ConfigurationSection closeSec;
            ConfigurationSection fillerSec = cfg.getConfigurationSection("fillers");
            if (fillerSec != null) {
                Material fillerMat = Material.matchMaterial((String)fillerSec.getString("material", "GRAY_STAINED_GLASS_PANE"));
                if (fillerMat == null) {
                    fillerMat = Material.GRAY_STAINED_GLASS_PANE;
                }
                String fillerName = fillerSec.getString("name", " ");
                String slotsStr = fillerSec.getString("slots", "");
                GuiItem fillerItem = ((ItemBuilder)((ItemBuilder)HeadUtil.from(fillerMat, fillerSec).name(ColorUtil.parse(fillerName))).flags(ItemFlag.values())).asGuiItem();
                for (String s : slotsStr.split(",")) {
                    try {
                        gui.setItem(Integer.parseInt(s.trim()) - 1, fillerItem);
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            if ((closeSec = cfg.getConfigurationSection("close-item")) != null) {
                int closeSlot = closeSec.getInt("slot", 23) - 1;
                Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                if (closeMat == null) {
                    closeMat = Material.BARRIER;
                }
                List<Component> closeLore = this.buildLore(closeSec.getStringList("lore"), this.rounds, new String[0]);
                gui.setItem(closeSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cClose")))).lore(closeLore)).flags(ItemFlag.values())).asGuiItem(e -> {
                    SoundUtil.playClick(player);
                    new CustomKitsMenuGUI(this.target).open(player);
                }));
            }
            if ((items = cfg.getConfigurationSection("items")) == null) {
                gui.open((HumanEntity)player);
            } else {
                ConfigurationSection sendSec;
                ConfigurationSection mapSec;
                ConfigurationSection roundsSec;
                ConfigurationSection infoSec = items.getConfigurationSection("Information");
                if (infoSec != null) {
                    int slot = infoSec.getInt("slot", 11) - 1;
                    Material mat = Material.matchMaterial((String)infoSec.getString("material", "PAINTING"));
                    if (mat == null) {
                        mat = Material.PAINTING;
                    }
                    List<Component> lore = this.buildLore(infoSec.getStringList("lore"), this.rounds, "%kit%", "Custom Kit", "%opponent%", this.target.getName(), "%sender%", this.requester.getName());
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, infoSec).name(ColorUtil.parse(infoSec.getString("name", "&fInfo")))).lore(lore)).flags(ItemFlag.values())).asGuiItem());
                }
                if ((roundsSec = items.getConfigurationSection("Rounds")) != null) {
                    int slot = roundsSec.getInt("slot", 12) - 1;
                    Material mat = Material.matchMaterial((String)roundsSec.getString("material", "CLOCK"));
                    if (mat == null) {
                        mat = Material.CLOCK;
                    }
                    List<Component> lore = this.buildLore(roundsSec.getStringList("lore"), this.rounds, new String[0]);
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, roundsSec).name(ColorUtil.parse(roundsSec.getString("name", "&eRounds")))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                        int newRounds = this.rounds;
                        if (e.isLeftClick()) {
                            newRounds = Math.min(this.rounds + 1, 10);
                        } else if (e.isRightClick()) {
                            newRounds = Math.max(this.rounds - 1, 1);
                        }
                        if (newRounds != this.rounds) {
                            SoundUtil.playClick(player);
                            new CustomKitRoundSelectionGUI(this.requester, this.target, this.kitSlot, newRounds).open(player);
                        }
                    }));
                }
                if ((mapSec = items.getConfigurationSection("Map-Selection")) != null) {
                    String arenaSelect;
                    int slot = mapSec.getInt("slot", 13) - 1;
                    Material mat = Material.matchMaterial((String)mapSec.getString("material", "MAP"));
                    if (mat == null) {
                        mat = Material.MAP;
                    }
                    List loreTemplate = (arenaSelect = GUIManager.getSelectedArena(player.getUniqueId())) != null ? mapSec.getStringList("selected-lore") : mapSec.getStringList("lore");
                    List<Component> lore = this.buildLore(loreTemplate, this.rounds, "%arena%", arenaSelect != null ? arenaSelect : "Random");
                    ItemBuilder mapBuilder = (ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, mapSec).name(ColorUtil.parse(mapSec.getString("name", "&fMap").replace("%arena%", arenaSelect != null ? arenaSelect : "Random")))).lore(lore)).flags(ItemFlag.values());
                    if (arenaSelect != null) {
                        mapBuilder.glow();
                    }
                    gui.setItem(slot, mapBuilder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        ArenaSelectGUI.open(player, "CUSTOM_KITS", () -> new CustomKitRoundSelectionGUI(this.requester, this.target, this.kitSlot, this.rounds).open(player));
                    }));
                }
                if ((sendSec = items.getConfigurationSection("Send-Request")) != null) {
                    int slot = sendSec.getInt("slot", 16) - 1;
                    Material mat = Material.matchMaterial((String)sendSec.getString("material", "LIME_STAINED_GLASS_PANE"));
                    if (mat == null) {
                        mat = Material.LIME_STAINED_GLASS_PANE;
                    }
                    List<Component> lore = this.buildLore(sendSec.getStringList("lore"), this.rounds, new String[0]);
                    int fKitSlot = this.kitSlot;
                    gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sendSec).name(ColorUtil.parse(sendSec.getString("name", "&aSend")))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                        player.closeInventory();
                        String arenaBaseName = GUIManager.getSelectedArena(player.getUniqueId());
                        CustomKitRequestManager.sendRequest(this.requester, this.target, fKitSlot, this.rounds, arenaBaseName);
                    }));
                }
                gui.open((HumanEntity)player);
            }
        }
    }

    private List<Component> buildLore(List<String> lines, int rounds, String ... extraReplacements) {
        ArrayList<Component> result = new ArrayList<Component>();
        for (String line : lines) {
            String replaced = line.replace("%rounds%", String.valueOf(rounds));
            int i = 0;
            while (i + 1 < extraReplacements.length) {
                replaced = replaced.replace(extraReplacements[i], extraReplacements[i + 1]);
                i += 2;
            }
            result.add(ColorUtil.parse(replaced));
        }
        return result;
    }
}

