/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.kit.custom;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.config.ConfigManager;
import me.lifea.duel.custom.CustomKitRequestManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class CustomKitArenaSelectGUI {
    private static final Pattern ARENA_PATTERN = Pattern.compile("^(.+)-(\\d+)$");
    private final Player requester;
    private final Player target;
    private final int kitSlotRequester;
    private final int kitSlotTarget;

    public CustomKitArenaSelectGUI(Player requester, Player target, int kitSlotRequester, int kitSlotTarget) {
        this.requester = requester;
        this.target = target;
        this.kitSlotRequester = kitSlotRequester;
        this.kitSlotTarget = kitSlotTarget;
    }

    public void open(Player player) {
        ConfigurationSection section = ConfigManager.customKits().getConfigurationSection("arena-select");
        if (section == null) {
            player.sendMessage(ColorUtil.parse("&#FB0000Arena selection config not found!"));
        } else {
            ConfigurationSection closeSec;
            int size = section.getInt("size", 27);
            int rows = size / 9;
            String title = section.getString("name", "Select Arena");
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
            ConfigurationSection fillerSec = section.getConfigurationSection("fillers");
            if (fillerSec != null) {
                Material mat = Material.matchMaterial((String)fillerSec.getString("material", "GRAY_STAINED_GLASS_PANE"));
                if (mat == null) {
                    mat = Material.GRAY_STAINED_GLASS_PANE;
                }
                String name = fillerSec.getString("name", " ");
                String slotsStr = fillerSec.getString("slots", "");
                ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, fillerSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                for (String s : slotsStr.split(",")) {
                    try {
                        gui.setItem(Integer.parseInt(s.trim()), builder.asGuiItem());
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            if ((closeSec = section.getConfigurationSection("close-item")) != null) {
                Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                if (closeMat == null) {
                    closeMat = Material.BARRIER;
                }
                int closeSlot = closeSec.getInt("slot", 22);
                ItemBuilder closeBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cClose")))).flags(ItemFlag.values());
                gui.setItem(closeSlot, closeBuilder.asGuiItem(e -> {
                    SoundUtil.playClick(player);
                    player.closeInventory();
                }));
            }
            LinkedHashSet<String> baseNames = new LinkedHashSet<String>();
            for (Arena arena : ArenaManager.getAll()) {
                List<String> allowed;
                String baseName;
                Matcher m = ARENA_PATTERN.matcher(arena.getName());
                if (!m.matches() || baseNames.contains(baseName = m.group(1)) || (allowed = arena.getAllowedKits()) != null && !allowed.isEmpty() && !allowed.stream().anyMatch(k -> k.equalsIgnoreCase("CUSTOM_KITS"))) continue;
                baseNames.add(baseName);
            }
            if (baseNames.isEmpty()) {
                player.sendMessage(ColorUtil.parse("&#FB0000No arenas available for custom kits!"));
                player.closeInventory();
            } else {
                int slot = 0;
                int startSlot = section.getInt("item-start-slot", 0);
                ConfigurationSection itemSec = section.getConfigurationSection("arena-item");
                Material itemMat = Material.MAP;
                String itemName = "&f%arena%";
                if (itemSec != null) {
                    Material m = Material.matchMaterial((String)itemSec.getString("material", "MAP"));
                    if (m != null) {
                        itemMat = m;
                    }
                    itemName = itemSec.getString("name", "&f%arena%");
                }
                for (String baseName : baseNames) {
                    int currentSlot = startSlot + slot;
                    if (currentSlot >= size) break;
                    String displayName = itemName.replace("%arena%", baseName);
                    boolean isRequester = player.getUniqueId().equals(this.requester.getUniqueId());
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(itemMat, itemSec).name(ColorUtil.parse(displayName))).flags(ItemFlag.values());
                    gui.setItem(currentSlot, builder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        player.closeInventory();
                        CustomKitRequestManager.sendRequest(this.requester, this.target, this.kitSlotRequester, this.kitSlotTarget, 3);
                    }));
                    ++slot;
                }
                gui.open((HumanEntity)player);
            }
        }
    }
}

