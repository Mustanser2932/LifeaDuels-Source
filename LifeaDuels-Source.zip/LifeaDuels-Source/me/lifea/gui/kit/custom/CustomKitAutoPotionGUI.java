/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Registry
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.potion.PotionType
 */
package me.lifea.gui.kit.custom;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.lifea.Lifea;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.anvilgui.AnvilGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

public class CustomKitAutoPotionGUI {
    private static final int[] EFFECT_SLOTS = new int[]{19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private static final int ADD_SLOT = 15;
    private static final int BACK_SLOT = 0;
    private static final int SAVE_SLOT = 5;
    private static final int DEFAULT_MAX_AMPLIFIER = 10;
    private final int kitSlot;
    private final Player opponent;
    private Map<String, String> potions;
    private Player player;
    private boolean closing;

    private static int parseOrDefault(String s, int def) {
        try {
            return Integer.parseInt(s);
        }
        catch (NumberFormatException var3) {
            return def;
        }
    }

    public CustomKitAutoPotionGUI(int kitSlot, Player opponent) {
        this.kitSlot = kitSlot;
        this.opponent = opponent;
    }

    public void open(Player player) {
        CustomKit kit = CustomKitManager.getKit(player.getUniqueId(), this.kitSlot);
        if (kit == null) {
            player.sendMessage(ColorUtil.parse("&#FB0000Kit not found!"));
        } else {
            this.potions = new HashMap<String, String>(kit.getPotions());
            this.player = player;
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&8Potion Settings"))).rows(6)).disableAllInteractions()).create();
            for (int slot : new int[]{1, 2, 3, 4, 6, 7, 8, 9, 10, 14, 18, 19, 23, 24, 25, 26, 27, 28, 32, 36, 37, 41, 45, 46, 47, 48, 49, 51, 52, 53, 54}) {
                int s = slot - 1;
                if (s < 0 || s >= 54) continue;
                gui.setItem(s, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name(ColorUtil.parse("&f"))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
            }
            gui.setItem(0, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.FEATHER).name(ColorUtil.parse("&fBack to Kit Editor"))).lore(ColorUtil.parse("&fClick to return"))).flags(ItemFlag.values())).asGuiItem(e -> {
                SoundUtil.playClick(player);
                this.saveAndClose();
            }));
            gui.setItem(5, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.GLOWSTONE_DUST).name(ColorUtil.parse("&#FB0000Save Potion Layout"))).lore(ColorUtil.parse("&fClick to save the potion layout"))).flags(ItemFlag.values())).asGuiItem(e -> {
                SoundUtil.playClick(player);
                this.saveAndClose();
            }));
            gui.setItem(15, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.POTION).name(ColorUtil.parse("&#00FB4EAdd Potion Effect"))).lore(ColorUtil.parse("&fClick to add a new potion effect"))).flags(ItemFlag.values())).asGuiItem(e -> {
                e.setCancelled(true);
                SoundUtil.playClick(player);
                this.captureCurrent();
                this.closing = true;
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.openPotionSelectionGUI());
            }));
            this.renderEffects(gui);
            gui.setCloseGuiAction(event -> {
                if (!this.closing) {
                    this.closing = true;
                    this.captureCurrent();
                    this.savePotions();
                    Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> new CustomKitEditorGUI(this.kitSlot, this.opponent).open(player));
                }
            });
            gui.open((HumanEntity)player);
        }
    }

    private void renderEffects(Gui gui) {
        for (int slot : EFFECT_SLOTS) {
            gui.updateItem(slot, ItemBuilder.from(Material.AIR).asGuiItem(e -> e.setCancelled(true)));
        }
        ArrayList<String> keys = new ArrayList<String>(this.potions.keySet());
        int idx = 0;
        for (String effectName : keys) {
            if (idx >= EFFECT_SLOTS.length) break;
            int slot = EFFECT_SLOTS[idx];
            String val = this.potions.get(effectName);
            String[] parts = val.split(":");
            int amp = 0;
            int dur = -1;
            try {
                amp = Integer.parseInt(parts[0]);
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            if (parts.length > 1) {
                try {
                    dur = Integer.parseInt(parts[1]);
                }
                catch (NumberFormatException numberFormatException) {
                    // empty catch block
                }
            }
            PotionEffectType type = PotionEffectType.getByName((String)effectName);
            ItemStack display = this.buildPotionStack(type, effectName);
            Object durDisplay = dur <= 0 ? "Infinite" : dur + "s";
            int ampDisplay = amp + 1;
            ArrayList<Component> lore = new ArrayList<Component>();
            lore.add(ColorUtil.parse("&fAmplifier: &f" + ampDisplay));
            lore.add(ColorUtil.parse("&fDuration: &f" + (String)durDisplay));
            lore.add(ColorUtil.parse(""));
            lore.add(ColorUtil.parse("&eLeft-click &fcycle amplifier"));
            lore.add(ColorUtil.parse("&eRight-click &fset duration"));
            lore.add(ColorUtil.parse("&cShift+Right-click &fto remove"));
            String effectKey = effectName;
            int currentAmplifier = amp;
            int currentDuration = dur;
            ItemBuilder var10002 = ItemBuilder.from(display);
            String var10003 = this.formatEffectName(effectName);
            gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse("&f" + var10003))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                e.setCancelled(true);
                if (e.isRightClick() && e.isShiftClick()) {
                    this.potions.remove(effectKey);
                    this.renderEffects(gui);
                } else if (e.isRightClick()) {
                    this.captureCurrent();
                    this.closing = true;
                    this.promptEffectDuration(effectKey, currentAmplifier, currentDuration, gui);
                } else {
                    int maxAmp = this.getMaxAmplifier(effectKey);
                    int nextAmp = (currentAmplifier + 1) % (maxAmp + 1);
                    this.potions.put(effectKey, nextAmp + ":" + currentDuration);
                    this.renderEffects(gui);
                }
            }));
            ++idx;
        }
        if (keys.isEmpty()) {
            gui.updateItem(22, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BARRIER).name(ColorUtil.parse("&cNo Potion Effects"))).lore(ColorUtil.parse("&fClick the &eAdd Potion Effect &fbutton to add one"))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
    }

    private ItemStack buildPotionStack(PotionEffectType type, String effectName) {
        ItemStack stack = new ItemStack(Material.POTION, 1);
        if (type != null) {
            try {
                PotionType pt = PotionType.valueOf((String)effectName);
                stack.editMeta(PotionMeta.class, meta -> meta.setBasePotionType(pt));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
        return stack;
    }

    private int getMaxAmplifier(String effectName) {
        PotionEffectType effectType = PotionEffectType.getByName((String)effectName);
        if (effectType == null) {
            return 10;
        }
        boolean hasStrong = false;
        boolean hasAny = false;
        for (PotionType type : Registry.POTION) {
            PotionEffectType pet = type.getEffectType();
            if (pet == null || !pet.equals(effectType) && !pet.getName().equals(effectName)) continue;
            hasAny = true;
            if (!type.getKey().getKey().startsWith("strong_")) continue;
            hasStrong = true;
        }
        if (!hasAny) {
            return 10;
        }
        return hasStrong ? 1 : 0;
    }

    private String formatEffectName(String raw) {
        String[] parts = raw.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    private void openPotionSelectionGUI() {
        ArrayList<PotionEffectType> allEffects = new ArrayList<PotionEffectType>();
        for (PotionEffectType type : Registry.POTION_EFFECT_TYPE) {
            if (type == null) continue;
            allEffects.add(type);
        }
        allEffects.sort(Comparator.comparing(PotionEffectType::getName));
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&8Select Potion Effect"))).rows(6)).disableAllInteractions()).create();
        for (int i = 0; i < 54; ++i) {
            if (i >= 9 && i < 45 && i % 9 != 0 && i % 9 != 8) continue;
            gui.setItem(i, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name(ColorUtil.parse("&f"))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
        gui.setItem(0, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.FEATHER).name(ColorUtil.parse("&fBack"))).lore(ColorUtil.parse("&fClick to return"))).flags(ItemFlag.values())).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopen());
        }));
        gui.setItem(4, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.POTION).name(ColorUtil.parse("&#FFAA00Select a Potion Effect"))).lore(ColorUtil.parse("&fClick a potion below to add it"))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        int slot = 10;
        for (PotionEffectType type : allEffects) {
            if (slot >= 44) break;
            if (slot % 9 == 0) {
                ++slot;
                continue;
            }
            if (slot % 9 == 8) {
                if ((slot += 2) < 44) continue;
                break;
            }
            String name = type.getName();
            ItemStack stack = this.buildPotionStack(type, name);
            ItemBuilder var10002 = ItemBuilder.from(stack);
            String var10003 = this.formatEffectName(name);
            gui.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse("&f" + var10003))).lore(ColorUtil.parse("&eClick &fto select this effect"))).flags(ItemFlag.values())).asGuiItem(e -> {
                e.setCancelled(true);
                SoundUtil.playClick(this.player);
                this.promptDuration(name);
            }));
            ++slot;
        }
        gui.setCloseGuiAction(event -> Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopen()));
        gui.open((HumanEntity)this.player);
    }

    private void promptDuration(String effectName) {
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title("Duration in seconds").text("60").itemLeft(new ItemStack(Material.CLOCK)).onClick((s, state) -> {
            if (s != 2) {
                return List.of();
            }
            String text = state.getText().trim();
            try {
                int dur = Integer.parseInt(text);
                if (dur < 0) {
                    dur = 0;
                }
                if (dur > 86400) {
                    dur = 86400;
                }
                return List.of(AnvilGUI.ResponseAction.close());
            }
            catch (NumberFormatException var4) {
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Invalid number!"));
            }
        }).onClose(state -> {
            String text = state.getText().trim();
            int temp = -1;
            try {
                temp = Integer.parseInt(text);
                if (temp < 0) {
                    temp = 0;
                }
                if (temp > 86400) {
                    temp = 86400;
                }
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            int duration = temp;
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.promptAmplifierNew(effectName, duration));
        }).open(this.player);
    }

    private void promptAmplifierNew(String effectName, int duration) {
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title("Amplifier (level)").text("1").itemLeft(new ItemStack(Material.REPEATER)).onClick((s, state) -> {
            if (s != 2) {
                return List.of();
            }
            String text = state.getText().trim();
            try {
                int amp = Integer.parseInt(text);
                if (amp < 1) {
                    amp = 1;
                }
                if (amp > 255) {
                    amp = 255;
                }
                this.potions.put(effectName, amp - 1 + ":" + duration);
                return List.of(AnvilGUI.ResponseAction.close());
            }
            catch (NumberFormatException var7) {
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Invalid number!"));
            }
        }).onClose(state -> {
            String text = state.getText().trim();
            int amp = 1;
            try {
                amp = Integer.parseInt(text);
                if (amp < 1) {
                    amp = 1;
                }
                if (amp > 255) {
                    amp = 255;
                }
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            this.potions.put(effectName, amp - 1 + ":" + duration);
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                this.savePotions();
                this.reopen();
            });
        }).open(this.player);
    }

    private void promptEffectDuration(String effectName, int amplifier, int duration, Gui gui) {
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title("Duration in seconds (-1 = infinite)").text(String.valueOf(duration <= 0 ? -1 : duration)).itemLeft(new ItemStack(Material.CLOCK)).onClick((s, state) -> {
            if (s != 2) {
                return List.of();
            }
            String text = state.getText().trim();
            try {
                Integer.parseInt(text);
                return List.of(AnvilGUI.ResponseAction.close());
            }
            catch (NumberFormatException var4) {
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Invalid number!"));
            }
        }).onClose(state -> {
            String text = state.getText().trim();
            int dur = -1;
            try {
                dur = Integer.parseInt(text);
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            this.potions.put(effectName, amplifier + ":" + dur);
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                this.savePotions();
                this.reopen();
            });
        }).open(this.player);
    }

    private void saveAndClose() {
        this.closing = true;
        this.captureCurrent();
        this.savePotions();
        this.player.closeInventory();
        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> new CustomKitEditorGUI(this.kitSlot, this.opponent).open(this.player));
    }

    private void captureCurrent() {
    }

    private void savePotions() {
        CustomKit k = CustomKitManager.getKit(this.player.getUniqueId(), this.kitSlot);
        ItemStack[] content = k != null ? k.getContent() : new ItemStack[41];
        HashMap<String, String> settings = k != null ? k.getSettings() : new HashMap<String, String>();
        CustomKitManager.saveKit(this.player.getUniqueId(), this.kitSlot, content, settings, this.potions);
    }

    private void reopen() {
        new CustomKitAutoPotionGUI(this.kitSlot, this.opponent).open(this.player);
    }
}

