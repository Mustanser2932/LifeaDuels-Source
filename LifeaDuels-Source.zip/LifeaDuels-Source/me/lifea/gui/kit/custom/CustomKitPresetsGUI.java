/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.gui.kit.custom;

import java.util.HashMap;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.kit.KitManager;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class CustomKitPresetsGUI {
    private final int kitSlot;
    private final Player opponent;

    public CustomKitPresetsGUI(int kitSlot, Player opponent) {
        this.kitSlot = kitSlot;
        this.opponent = opponent;
    }

    public void open(Player player) {
        ConfigurationSection items;
        ConfigurationSection root = ConfigManager.duelGui().getConfigurationSection("Duel-menu");
        int rows = CustomKitPresetsGUI.parseRows(root != null ? root.getString("size", "chest-3") : "chest-3");
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&8Select a Preset Kit"))).rows(rows)).disableAllInteractions()).create();
        ConfigurationSection configurationSection = items = root != null ? root.getConfigurationSection("items") : null;
        if (items != null) {
            for (String key : items.getKeys(false)) {
                int slot;
                try {
                    slot = Integer.parseInt(key.trim());
                }
                catch (NumberFormatException numberFormatException) {
                    continue;
                }
                ConfigurationSection sec = items.getConfigurationSection(key);
                if (sec == null) continue;
                Material mat = Material.matchMaterial((String)sec.getString("material", "STONE"));
                if (mat == null) {
                    mat = Material.STONE;
                }
                String name = sec.getString("name", "");
                String opens = sec.getString("opens");
                ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                List<Component> lore = LoreUtil.read(sec, "lore");
                if (!lore.isEmpty()) {
                    builder.lore(lore);
                }
                if (opens != null && !opens.isBlank() && !"custom".equalsIgnoreCase(opens)) {
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(player);
                        if (!"close".equalsIgnoreCase(opens) && !"back".equalsIgnoreCase(opens)) {
                            this.openGamemodes(player, DuelMenuGUI.tierForSection(opens));
                        } else {
                            this.reopenEditor(player);
                        }
                    }));
                    continue;
                }
                gui.setItem(slot, builder.asGuiItem());
            }
        }
        gui.open((HumanEntity)player);
    }

    private void openGamemodes(Player player, String tier) {
        ConfigurationSection items;
        ConfigurationSection sec = DuelMenuGUI.tierSection(tier);
        int rows = CustomKitPresetsGUI.parseRows(sec != null ? sec.getString("size", "chest-4") : "chest-4");
        String kitFormat = sec != null ? sec.getString("kit-format", "") : "";
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&8Presets - " + tier))).rows(rows)).disableAllInteractions()).create();
        ConfigurationSection configurationSection = items = sec != null ? sec.getConfigurationSection("items") : null;
        if (items != null) {
            for (String key : items.getKeys(false)) {
                int slot;
                try {
                    slot = Integer.parseInt(key.trim());
                }
                catch (NumberFormatException numberFormatException) {
                    continue;
                }
                ConfigurationSection it = items.getConfigurationSection(key);
                if (it == null) continue;
                Material mat = Material.matchMaterial((String)it.getString("material", "STONE"));
                if (mat == null) {
                    mat = Material.STONE;
                }
                String name = it.getString("name", "");
                String kit = it.getString("kit");
                String opens = it.getString("opens");
                ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, it).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                List<Component> lore = LoreUtil.read(it, "lore");
                if (!lore.isEmpty()) {
                    builder.lore(lore);
                }
                if (kit != null && !kit.isBlank()) {
                    String modeName = DuelMenuGUI.resolveKit(kit, kitFormat)[1];
                    if (!KitManager.isKitEnabled(tier, modeName) || !KitManager.hasBaseKit(tier, modeName)) continue;
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(player);
                        this.applyPreset(player, tier, modeName);
                    }));
                    continue;
                }
                if ("back".equalsIgnoreCase(opens)) {
                    gui.setItem(slot, builder.asGuiItem(ex -> {
                        SoundUtil.playClick(player);
                        this.open(player);
                    }));
                    continue;
                }
                gui.setItem(slot, builder.asGuiItem());
            }
        }
        gui.open((HumanEntity)player);
    }

    private void applyPreset(Player player, String tier, String gamemode) {
        ItemStack[] baseKit = KitManager.getBaseKit(tier, gamemode);
        if (baseKit == null) {
            player.sendMessage(ColorUtil.parse("&cNo preset data found for " + gamemode));
            this.reopenEditor(player);
        } else {
            ItemStack[] newContent = new ItemStack[41];
            int len = Math.min(baseKit.length, 41);
            for (int i = 0; i < len; ++i) {
                newContent[i] = baseKit[i] != null ? baseKit[i].clone() : null;
            }
            HashMap<String, String> emptySettings = new HashMap<String, String>();
            HashMap<String, String> emptyPotions = new HashMap<String, String>();
            CustomKitManager.saveKit(player.getUniqueId(), this.kitSlot, newContent, emptySettings, emptyPotions);
            this.reopenEditor(player);
        }
    }

    private void reopenEditor(Player player) {
        new CustomKitEditorGUI(this.kitSlot, this.opponent).open(player);
    }

    private static int parseRows(String size) {
        if (size != null && size.startsWith("chest-")) {
            try {
                return Integer.parseInt(size.substring("chest-".length()).trim());
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return 4;
    }
}

