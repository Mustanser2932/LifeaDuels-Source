/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.Damageable
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.gui.kit.custom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.anvilgui.AnvilGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

public class CustomKitItemEditGUI {
    private static final int GUI_SIZE = 54;
    private static final ItemFlag[] ALL_FLAGS = ItemFlag.values();
    private final int kitSlot;
    private final Player opponent;
    private final int contentIdx;
    private final ItemStack[] content;
    private final Map<String, Object> configEntry;
    private final Map<String, String> settings;
    private final Map<String, String> potions;
    private final Player player;
    private Gui gui;
    private boolean variantMode;
    private boolean enchantMode;
    private boolean amountMode;
    private boolean openingAnvil;
    private ConfigurationSection cfg;
    private Material fillerMat;
    private String fillerName;
    private int backSlot;
    private Material backMat;
    private int previewSlot;
    private Material noItemMat;
    private int renameSlot;
    private Material renameMat;
    private List<Component> renameLore;
    private int durabilitySlot;
    private Material durabilityMat;
    private List<Component> durabilityLore;
    private Material durabilityDisabledMat;
    private int variantSlot;
    private Material variantToggleMat;
    private List<Component> variantLore;
    private List<Component> variantActiveLore;
    private Material variantDisabledMat;
    private int enchantSlot;
    private Material enchantToggleMat;
    private List<Component> enchantLore;
    private List<Component> enchantActiveLore;
    private Material enchantDisabledMat;
    private int amountSlot;
    private Material amountToggleMat;
    private List<Component> amountLore;
    private List<Component> amountActiveLore;
    private Material amountDisabledMat;
    private int[] dynamicSlots;
    private int amountCustomSlot;
    private Material amountCustomMat;
    private List<Component> amountCustomLore;
    private int[] amountPresetSlots;
    private int[] amountPresetValues;
    private Material amountPresetMat;

    public CustomKitItemEditGUI(int kitSlot, Player opponent, int contentIdx, ItemStack[] content, Map<String, Object> configEntry, Map<String, String> settings, Map<String, String> potions, Player player) {
        this.kitSlot = kitSlot;
        this.opponent = opponent;
        this.contentIdx = contentIdx;
        this.content = content;
        this.configEntry = configEntry;
        this.settings = settings;
        this.potions = potions;
        this.player = player;
    }

    private void loadConfig() {
        this.cfg = ConfigManager.customKits().getConfigurationSection("item-edit");
        if (this.cfg == null) {
            this.cfg = ConfigManager.customKits().createSection("item-edit");
        }
        this.fillerMat = this.readMat("fillers.material", Material.GRAY_STAINED_GLASS_PANE);
        this.fillerName = this.cfg.getString("fillers.name", "&f");
        this.backSlot = this.cfg.getInt("back.slot", 0);
        this.backMat = this.readMat("back.material", Material.FEATHER);
        this.previewSlot = this.cfg.getInt("preview.slot", 10);
        this.noItemMat = this.readMat("preview.no-item-material", Material.BARRIER);
        this.renameSlot = this.cfg.getInt("rename.slot", 16);
        this.renameMat = this.readMat("rename.material", Material.NAME_TAG);
        this.renameLore = this.readLore("rename.lore", "&fClick to rename this item");
        this.durabilitySlot = this.cfg.getInt("durability.slot", 13);
        this.durabilityMat = this.readMat("durability.material", Material.ANVIL);
        this.durabilityLore = this.readLore("durability.lore", "&fClick to set remaining durability");
        this.durabilityDisabledMat = this.readMat("durability.disabled-material", Material.BARRIER);
        this.variantSlot = this.cfg.getInt("variant.slot", 28);
        this.variantToggleMat = this.readMat("variant.toggle-material", Material.HEAVY_CORE);
        this.variantLore = this.readLore("variant.toggle-lore", "&fClick to show variants");
        this.variantActiveLore = this.readLore("variant.toggle-active-lore", "&fClick to hide variants");
        this.dynamicSlots = this.readIntArray("variant.dynamic-slots", new int[]{30, 31, 32, 33, 34, 39, 40, 41, 42, 43, 48, 49, 50, 51, 52});
        this.variantDisabledMat = this.readMat("variant.disabled-material", Material.BARRIER);
        this.enchantSlot = this.cfg.getInt("enchant.slot", 37);
        this.enchantToggleMat = this.readMat("enchant.toggle-material", Material.ENCHANTED_BOOK);
        this.enchantLore = this.readLore("enchant.toggle-lore", "&fClick to show enchants");
        this.enchantActiveLore = this.readLore("enchant.toggle-active-lore", "&fClick to hide enchants");
        this.enchantDisabledMat = this.readMat("enchant.disabled-material", Material.BARRIER);
        this.amountSlot = this.cfg.getInt("amount.slot", 46);
        this.amountToggleMat = this.readMat("amount.toggle-material", Material.AMETHYST_CLUSTER);
        this.amountLore = this.readLore("amount.toggle-lore", "&fClick to show amounts");
        this.amountActiveLore = this.readLore("amount.toggle-active-lore", "&fClick to hide amounts");
        this.amountDisabledMat = this.readMat("amount.disabled-material", Material.BARRIER);
        this.amountCustomSlot = this.cfg.getInt("amount.custom-slot", 48);
        this.amountCustomMat = this.readMat("amount.custom-material", Material.ANVIL);
        this.amountCustomLore = this.readLore("amount.custom-lore", "&fClick to set custom amount");
        this.amountPresetSlots = this.readIntArray("amount.preset-slots", new int[]{49, 50, 51, 52});
        this.amountPresetValues = this.readIntArray("amount.preset-values", new int[]{1, 16, 32, 48});
        this.amountPresetMat = this.readMat("amount.preset-material", Material.PAPER);
    }

    private Material readMat(String path, Material def) {
        String name = this.cfg.getString(path);
        if (name == null) {
            return def;
        }
        Material m = Material.matchMaterial((String)name);
        return m != null ? m : def;
    }

    private List<Component> readLore(String path, String defaultLine) {
        ConfigurationSection sec = this.cfg;
        String[] parts = path.split("\\.");
        for (int i = 0; i < parts.length - 1; ++i) {
            if ((sec = sec.getConfigurationSection(parts[i])) != null) continue;
            ArrayList<Component> list = new ArrayList<Component>();
            list.add(ColorUtil.parse(defaultLine));
            return list;
        }
        List<Component> result = LoreUtil.read(sec, parts[parts.length - 1]);
        if (result.isEmpty() && defaultLine != null) {
            result.add(ColorUtil.parse(defaultLine));
        }
        return result;
    }

    private int[] readIntArray(String path, int[] def) {
        List list = this.cfg.getIntegerList(path);
        if (list.isEmpty()) {
            return def;
        }
        int[] arr = new int[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            arr[i] = (Integer)list.get(i);
        }
        return arr;
    }

    private boolean isFixedSlot(int slot) {
        if (slot != this.backSlot && slot != this.previewSlot && slot != this.durabilitySlot && slot != this.renameSlot && slot != this.variantSlot && slot != this.enchantSlot && slot != this.amountSlot && slot != this.amountCustomSlot) {
            for (int s : this.dynamicSlots) {
                if (s != slot) continue;
                return true;
            }
            for (int s : this.amountPresetSlots) {
                if (s != slot) continue;
                return true;
            }
            return false;
        }
        return true;
    }

    public void open(Player player) {
        boolean allowStack;
        List allowedEnchants;
        List variants;
        boolean allowDurability;
        this.loadConfig();
        String title = this.cfg.getString("title", "&8Edit Item");
        this.gui = ((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(6)).create();
        for (int slot = 0; slot < 54; ++slot) {
            if (this.isFixedSlot(slot)) continue;
            this.gui.setItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.setCloseGuiAction(event -> {
            if (!this.openingAnvil) {
                this.saveAndGoBack();
            }
        });
        this.gui.setItem(this.backSlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.backMat).name(ColorUtil.parse(this.cfg.getString("back.name", "&fBack to Kit Editor")))).flags(ItemFlag.values())).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(player);
            player.closeInventory();
        }));
        this.gui.setItem(this.renameSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.renameMat).name(ColorUtil.parse(this.cfg.getString("rename.name", "&fRename Item")))).lore(this.renameLore)).flags(ItemFlag.values())).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(player);
            this.openingAnvil = true;
            this.openRenameAnvil();
        }));
        boolean bl = allowDurability = this.configEntry != null && (Boolean)this.configEntry.getOrDefault("allow-durability-change", false) != false;
        if (allowDurability) {
            this.gui.setItem(this.durabilitySlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.durabilityMat).name(ColorUtil.parse(this.cfg.getString("durability.name", "&fChange Durability")))).lore(this.durabilityLore)).flags(ItemFlag.values())).asGuiItem(e -> {
                e.setCancelled(true);
                SoundUtil.playClick(player);
                this.openingAnvil = true;
                this.openDurabilityAnvil();
            }));
        } else {
            this.gui.setItem(this.durabilitySlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.durabilityDisabledMat).name(ColorUtil.parse(this.cfg.getString("durability.disabled-name", "&8Durability Change Disabled")))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
        List list = variants = this.configEntry != null ? this.configEntry.getOrDefault("variant-materials", Collections.emptyList()) : Collections.emptyList();
        if (!variants.isEmpty()) {
            this.updateVariantToggle();
        } else {
            this.gui.setItem(this.variantSlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.variantDisabledMat).name(ColorUtil.parse(this.cfg.getString("variant.disabled-name", "&8No Variants Available")))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
        List list2 = allowedEnchants = this.configEntry != null ? this.configEntry.getOrDefault("allowed-enchantments", Collections.emptyList()) : Collections.emptyList();
        if (!allowedEnchants.isEmpty()) {
            this.updateEnchantToggle();
        } else {
            this.gui.setItem(this.enchantSlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.enchantDisabledMat).name(ColorUtil.parse(this.cfg.getString("enchant.disabled-name", "&8No Enchants Available")))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
        ItemStack currentItem = this.getCurrentItem();
        boolean bl2 = allowStack = currentItem != null && currentItem.getMaxStackSize() > 1;
        if (this.configEntry != null) {
            allowStack = (Boolean)this.configEntry.getOrDefault("allow-stack", allowStack);
        }
        if (allowStack) {
            this.updateAmountToggle();
        } else {
            this.gui.setItem(this.amountSlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.amountDisabledMat).name(ColorUtil.parse(this.cfg.getString("amount.disabled-name", "&8Stacking Disabled")))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.setDefaultClickAction(event -> {
            if (event.getRawSlot() < 54) {
                event.setCancelled(true);
            }
        });
        this.gui.setDragAction(event -> {
            Iterator i$ = event.getRawSlots().iterator();
            while (i$.hasNext()) {
                int slot = (Integer)i$.next();
                if (slot >= 54) continue;
                event.setCancelled(true);
                return;
            }
        });
        this.gui.open((HumanEntity)player);
        this.updatePreview();
        this.clearDynamicSlots();
    }

    private void updatePreview() {
        ItemStack item = this.getCurrentItem();
        if (item != null) {
            this.gui.updateItem(this.previewSlot, ItemBuilder.from(item.clone()).asGuiItem(e -> e.setCancelled(true)));
        } else {
            this.gui.updateItem(this.previewSlot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.noItemMat).name(ColorUtil.parse(this.cfg.getString("preview.no-item-name", "&cNo Item")))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
        }
    }

    private ItemStack getCurrentItem() {
        ItemStack item;
        if (this.contentIdx >= 0 && this.contentIdx < this.content.length && (item = this.content[this.contentIdx]) != null && item.getType() != Material.AIR) {
            return item;
        }
        return null;
    }

    private void clearDynamicSlots() {
        ItemStack filler = ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).build();
        for (int slot : this.dynamicSlots) {
            this.gui.updateItem(slot, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.updateItem(this.amountCustomSlot, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        for (int slot : this.amountPresetSlots) {
            this.gui.updateItem(slot, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        }
    }

    private void updateVariantToggle() {
        List variants = this.configEntry != null ? this.configEntry.getOrDefault("variant-materials", Collections.emptyList()) : Collections.emptyList();
        Gui var10000 = this.gui;
        int var10001 = this.variantSlot;
        ItemBuilder var10002 = ItemBuilder.from(this.variantToggleMat);
        String var10003 = this.variantMode ? "&a" : "&f";
        var10000.updateItem(var10001, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse(var10003 + this.cfg.getString("variant.toggle-name", "Variant Mode")))).lore(this.variantMode ? this.variantActiveLore : this.variantLore)).flags(ItemFlag.values())).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            this.variantMode = !this.variantMode;
            this.updateVariantToggle();
            if (this.variantMode) {
                this.enchantMode = false;
                this.amountMode = false;
                this.updateEnchantToggle();
                this.updateAmountToggle();
            }
            this.clearDynamicSlots();
            this.updateVariantSlots(variants);
        }));
    }

    private void updateVariantSlots(List<String> variants) {
        if (!this.variantMode) {
            for (int slot : this.dynamicSlots) {
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
            }
        } else {
            String selectedPrefix = this.cfg.getString("variant.selected-prefix", "&a\u2713 ");
            String unselectedPrefix = this.cfg.getString("variant.unselected-prefix", "&f");
            String selectedLore = this.cfg.getString("variant.selected-lore", "&fCurrently selected");
            String unselectedLore = this.cfg.getString("variant.unselected-lore", "&fClick to select");
            for (int i = 0; i < this.dynamicSlots.length; ++i) {
                int slot = this.dynamicSlots[i];
                if (i < variants.size()) {
                    String varName = variants.get(i);
                    Material varMat = Material.matchMaterial((String)varName);
                    Material finalMat = varMat != null ? varMat : Material.STONE;
                    boolean isCurrent = this.getCurrentItem() != null && this.getCurrentItem().getType() == varMat;
                    String displayName = CustomKitItemEditGUI.formatName(varName);
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(varMat).name(ColorUtil.parse((isCurrent ? selectedPrefix : unselectedPrefix) + displayName))).lore(ColorUtil.parse(isCurrent ? selectedLore : unselectedLore))).flags(ItemFlag.values())).asGuiItem(e -> {
                        e.setCancelled(true);
                        SoundUtil.playClick(this.player);
                        ItemStack current = this.getCurrentItem();
                        if (current != null) {
                            int oldAmount = current.getAmount();
                            HashMap enchants = new HashMap(current.getEnchantments());
                            ItemStack replacement = new ItemStack(finalMat, oldAmount);
                            for (Map.Entry entry : enchants.entrySet()) {
                                replacement.addUnsafeEnchantment((Enchantment)entry.getKey(), ((Integer)entry.getValue()).intValue());
                            }
                            ItemMeta oldMeta = current.getItemMeta();
                            if (oldMeta != null && oldMeta.hasDisplayName()) {
                                ItemMeta newMeta = replacement.getItemMeta();
                                newMeta.displayName(oldMeta.displayName());
                                replacement.setItemMeta(newMeta);
                            }
                            this.content[this.contentIdx] = replacement;
                            this.syncArmorIfNeeded();
                            this.updatePreview();
                            this.updateVariantSlots(variants);
                            this.updateEnchantSlots();
                        }
                    }));
                    continue;
                }
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
            }
        }
    }

    private void updateEnchantToggle() {
        Gui var10000 = this.gui;
        int var10001 = this.enchantSlot;
        ItemBuilder var10002 = ItemBuilder.from(this.enchantToggleMat);
        String var10003 = this.enchantMode ? "&a" : "&f";
        var10000.updateItem(var10001, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse(var10003 + this.cfg.getString("enchant.toggle-name", "Enchant Mode")))).lore(this.enchantMode ? this.enchantActiveLore : this.enchantLore)).flags(ItemFlag.values())).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            this.enchantMode = !this.enchantMode;
            this.updateEnchantToggle();
            if (this.enchantMode) {
                this.variantMode = false;
                this.amountMode = false;
                this.updateVariantToggle();
                this.updateAmountToggle();
            }
            this.clearDynamicSlots();
            this.updateEnchantSlots();
        }));
    }

    private void updateEnchantSlots() {
        List<String> allowedEnchants;
        List<String> list = allowedEnchants = this.configEntry != null ? this.configEntry.getOrDefault("allowed-enchantments", Collections.emptyList()) : Collections.emptyList();
        if (!this.enchantMode) {
            for (int slot : this.dynamicSlots) {
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
            }
        } else {
            ItemStack item = this.getCurrentItem();
            if (item == null) {
                for (int slot : this.dynamicSlots) {
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.enchantDisabledMat).name(ColorUtil.parse("&cNo item"))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
                }
            } else {
                Material activeBookMat = this.readMat("enchant.active-book-material", Material.ENCHANTED_BOOK);
                Material addBookMat = this.readMat("enchant.add-book-material", Material.BOOK);
                String addLoreStr = this.cfg.getString("enchant.add-lore", "&fClick to add this enchant");
                String levelUpLore = this.cfg.getString("enchant.level-up-lore", "&fLeft-click: +1 level");
                String levelDownLore = this.cfg.getString("enchant.level-down-lore", "&fRight-click: -1 level");
                HashMap currentEnchants = new HashMap(item.getEnchantments());
                Set currentNames = currentEnchants.keySet().stream().map(e -> e.getKey().getKey().toLowerCase()).collect(Collectors.toSet());
                int slotIdx = 0;
                for (Map.Entry entry : currentEnchants.entrySet()) {
                    if (slotIdx >= this.dynamicSlots.length) break;
                    int slot = this.dynamicSlots[slotIdx++];
                    Enchantment ench = (Enchantment)entry.getKey();
                    int level = (Integer)entry.getValue();
                    String enchantKey = ench.getKey().getKey();
                    String displayName = CustomKitItemEditGUI.formatName(enchantKey);
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(activeBookMat).name(ColorUtil.parse("&d" + displayName + " " + CustomKitItemEditGUI.toRoman(level)))).lore(ColorUtil.parse(levelUpLore), ColorUtil.parse(levelDownLore))).flags(ItemFlag.values())).asGuiItem(e -> {
                        e.setCancelled(true);
                        SoundUtil.playClick(this.player);
                        ItemStack current = this.getCurrentItem();
                        if (current != null) {
                            if (e.isLeftClick()) {
                                current.addUnsafeEnchantment(ench, level + 1);
                            } else if (e.isRightClick()) {
                                if (level <= 1) {
                                    current.removeEnchantment(ench);
                                } else {
                                    current.addUnsafeEnchantment(ench, level - 1);
                                }
                            }
                            this.content[this.contentIdx] = current;
                            this.syncArmorIfNeeded();
                            this.updatePreview();
                            this.updateEnchantSlots();
                        }
                    }));
                }
                ArrayList<String> availableToAdd = new ArrayList<String>();
                for (String allowed : allowedEnchants) {
                    if (currentNames.contains(allowed.toLowerCase())) continue;
                    availableToAdd.add(allowed);
                }
                for (String enchantName : availableToAdd) {
                    if (slotIdx >= this.dynamicSlots.length) break;
                    int slot = this.dynamicSlots[slotIdx++];
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(addBookMat).name(ColorUtil.parse("&f+ " + CustomKitItemEditGUI.formatName(enchantName)))).lore(ColorUtil.parse(addLoreStr))).flags(ItemFlag.values())).asGuiItem(e -> {
                        Enchantment ench;
                        e.setCancelled(true);
                        SoundUtil.playClick(this.player);
                        ItemStack current = this.getCurrentItem();
                        if (current != null && (ench = Enchantment.getByKey((NamespacedKey)NamespacedKey.minecraft((String)enchantName.toLowerCase()))) != null) {
                            current.addUnsafeEnchantment(ench, 1);
                            this.content[this.contentIdx] = current;
                            this.syncArmorIfNeeded();
                            this.updatePreview();
                            this.updateEnchantSlots();
                        }
                    }));
                }
                while (slotIdx < this.dynamicSlots.length) {
                    int n = this.dynamicSlots[slotIdx++];
                    this.gui.updateItem(n, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
                }
            }
        }
    }

    private void updateAmountToggle() {
        Gui var10000 = this.gui;
        int var10001 = this.amountSlot;
        ItemBuilder var10002 = ItemBuilder.from(this.amountToggleMat);
        String var10003 = this.amountMode ? "&a" : "&f";
        var10000.updateItem(var10001, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse(var10003 + this.cfg.getString("amount.toggle-name", "Amount Mode")))).lore(this.amountMode ? this.amountActiveLore : this.amountLore)).flags(ItemFlag.values())).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            this.amountMode = !this.amountMode;
            this.updateAmountToggle();
            if (this.amountMode) {
                this.variantMode = false;
                this.enchantMode = false;
                this.updateVariantToggle();
                this.updateEnchantToggle();
            }
            this.clearDynamicSlots();
            this.updateAmountSlots();
        }));
    }

    private void updateAmountSlots() {
        block4: {
            block3: {
                if (this.amountMode) break block3;
                for (int slot : this.dynamicSlots) {
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
                }
                break block4;
            }
            ItemStack item = this.getCurrentItem();
            if (item == null) break block4;
            int maxStack = item.getMaxStackSize();
            String selectedPrefix = this.cfg.getString("amount.selected-prefix", "&a\u2713 ");
            String unselectedPrefix = this.cfg.getString("amount.unselected-prefix", "&f");
            String selectedLoreBase = this.cfg.getString("amount.selected-lore", "&fCurrently selected");
            String unselectedLoreBase = this.cfg.getString("amount.unselected-lore", "&fClick to set amount to %amount%");
            this.gui.updateItem(this.amountCustomSlot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.amountCustomMat).name(ColorUtil.parse(this.cfg.getString("amount.custom-name", "&fCustom Amount")))).lore(this.amountCustomLore)).flags(ItemFlag.values())).asGuiItem(e -> {
                e.setCancelled(true);
                SoundUtil.playClick(this.player);
                this.openingAnvil = true;
                this.openCustomAmountAnvil(maxStack);
            }));
            for (int i = 0; i < this.amountPresetSlots.length && i < this.amountPresetValues.length; ++i) {
                int slot = this.amountPresetSlots[i];
                int amt = this.amountPresetValues[i];
                if (amt >= 1 && amt <= maxStack) {
                    boolean isCurrent = item.getAmount() == amt;
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.amountPresetMat).name(ColorUtil.parse((isCurrent ? selectedPrefix : unselectedPrefix) + "x" + amt))).lore(ColorUtil.parse(isCurrent ? selectedLoreBase : unselectedLoreBase.replace("%amount%", String.valueOf(amt))))).flags(ItemFlag.values())).asGuiItem(e -> {
                        e.setCancelled(true);
                        SoundUtil.playClick(this.player);
                        ItemStack current = this.getCurrentItem();
                        if (current != null) {
                            current.setAmount(amt);
                            this.content[this.contentIdx] = current;
                            this.syncArmorIfNeeded();
                            this.updatePreview();
                            this.updateAmountSlots();
                        }
                    }));
                    continue;
                }
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(this.fillerMat).name(ColorUtil.parse(this.fillerName))).flags(ItemFlag.values())).asGuiItem(e -> e.setCancelled(true)));
            }
        }
    }

    private void reopenEditGui() {
        new CustomKitItemEditGUI(this.kitSlot, this.opponent, this.contentIdx, this.content, this.configEntry, this.settings, this.potions, this.player).open(this.player);
    }

    private void openRenameAnvil() {
        ItemStack current = this.getCurrentItem();
        if (current != null) {
            String currentName = "";
            if (current.getItemMeta() != null && current.getItemMeta().hasDisplayName()) {
                currentName = current.getItemMeta().getDisplayName().replaceAll("\u00a7[0-9a-fk-or]", "");
            }
            new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title(this.cfg.getString("rename.anvil-title", "Rename Item")).text(currentName).itemLeft(new ItemStack(this.renameMat)).onClick((slot, state) -> {
                if (slot != 2) {
                    return List.of();
                }
                String text = state.getText();
                if (text != null && !text.trim().isEmpty()) {
                    ItemStack item = this.getCurrentItem();
                    if (item != null) {
                        ItemMeta meta = item.getItemMeta();
                        try {
                            meta.displayName(ColorUtil.parse(text));
                        }
                        catch (Exception var7) {
                            return List.of(AnvilGUI.ResponseAction.replaceInputText("Invalid name"));
                        }
                        item.setItemMeta(meta);
                        this.content[this.contentIdx] = item;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                    }
                    return List.of(AnvilGUI.ResponseAction.close());
                }
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a name"));
            }).onClose(state -> {
                ItemStack item;
                String text = state.getText();
                if (text != null && !text.trim().isEmpty() && (item = this.getCurrentItem()) != null) {
                    ItemMeta meta = item.getItemMeta();
                    try {
                        meta.displayName(ColorUtil.parse(text));
                        item.setItemMeta(meta);
                        this.content[this.contentIdx] = item;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
            }).open(this.player);
        }
    }

    private void openDurabilityAnvil() {
        short maxDurability;
        ItemStack current = this.getCurrentItem();
        if (current != null && (maxDurability = current.getType().getMaxDurability()) > 0) {
            int currentDamage = 0;
            ItemMeta var5 = current.getItemMeta();
            if (var5 instanceof Damageable) {
                Damageable damageable = (Damageable)var5;
                currentDamage = damageable.getDamage();
            }
            int currentRemaining = maxDurability - currentDamage;
            new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title(this.cfg.getString("durability.anvil-title", "Set Durability (0-" + maxDurability + ")")).text(String.valueOf(currentRemaining)).itemLeft(new ItemStack(this.durabilityMat)).onClick((slot, state) -> {
                if (slot != 2) {
                    return List.of();
                }
                String text = state.getText();
                if (text != null && !text.trim().isEmpty()) {
                    try {
                        ItemMeta meta;
                        ItemStack item;
                        int remaining = Integer.parseInt(text.trim());
                        if (remaining < 0) {
                            remaining = 0;
                        }
                        if (remaining > maxDurability) {
                            remaining = maxDurability;
                        }
                        if ((item = this.getCurrentItem()) != null && (meta = item.getItemMeta()) instanceof Damageable) {
                            Damageable damageable = (Damageable)meta;
                            damageable.setDamage(maxDurability - remaining);
                            item.setItemMeta((ItemMeta)damageable);
                            this.content[this.contentIdx] = item;
                            this.syncArmorIfNeeded();
                            this.updatePreview();
                        }
                        return List.of(AnvilGUI.ResponseAction.close());
                    }
                    catch (NumberFormatException var9) {
                        return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a valid number"));
                    }
                }
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a number"));
            }).onClose(state -> {
                String text = state.getText();
                if (text != null && !text.trim().isEmpty()) {
                    try {
                        ItemMeta meta;
                        ItemStack item;
                        int remaining = Integer.parseInt(text.trim());
                        if (remaining < 0) {
                            remaining = 0;
                        }
                        if (remaining > maxDurability) {
                            remaining = maxDurability;
                        }
                        if ((item = this.getCurrentItem()) != null && (meta = item.getItemMeta()) instanceof Damageable) {
                            Damageable damageable = (Damageable)meta;
                            damageable.setDamage(maxDurability - remaining);
                            item.setItemMeta((ItemMeta)damageable);
                            this.content[this.contentIdx] = item;
                            this.syncArmorIfNeeded();
                            this.updatePreview();
                        }
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
            }).open(this.player);
        }
    }

    private void openCustomAmountAnvil(int maxStack) {
        int currentAmount = 1;
        ItemStack currentItem = this.getCurrentItem();
        if (currentItem != null) {
            currentAmount = currentItem.getAmount();
        }
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title(this.cfg.getString("amount.anvil-title", "Set Amount (1-" + maxStack + ")")).text(String.valueOf(currentAmount)).itemLeft(new ItemStack(this.amountCustomMat)).onClick((slot, state) -> {
            if (slot != 2) {
                return List.of();
            }
            String text = state.getText();
            if (text != null && !text.trim().isEmpty()) {
                try {
                    ItemStack item;
                    int amount = Integer.parseInt(text.trim());
                    if (amount < 1) {
                        amount = 1;
                    }
                    if (amount > maxStack) {
                        amount = maxStack;
                    }
                    if ((item = this.getCurrentItem()) != null) {
                        item.setAmount(amount);
                        this.content[this.contentIdx] = item;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                        this.updateAmountSlots();
                    }
                    return List.of(AnvilGUI.ResponseAction.close());
                }
                catch (NumberFormatException var7) {
                    return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a valid number"));
                }
            }
            return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a number"));
        }).onClose(state -> {
            String text = state.getText();
            if (text != null && !text.trim().isEmpty()) {
                try {
                    ItemStack item;
                    int amount = Integer.parseInt(text.trim());
                    if (amount < 1) {
                        amount = 1;
                    }
                    if (amount > maxStack) {
                        amount = maxStack;
                    }
                    if ((item = this.getCurrentItem()) != null) {
                        item.setAmount(amount);
                        this.content[this.contentIdx] = item;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                        this.updateAmountSlots();
                    }
                }
                catch (NumberFormatException numberFormatException) {
                    // empty catch block
                }
            }
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
        }).open(this.player);
    }

    private void saveAndGoBack() {
        this.player.setItemOnCursor((ItemStack)null);
        try {
            CustomKitManager.saveKit(this.player.getUniqueId(), this.kitSlot, this.content, this.settings, this.potions);
        }
        catch (Exception exception) {
            // empty catch block
        }
        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> new CustomKitEditorGUI(this.kitSlot, this.opponent).open(this.player));
    }

    private void syncArmorIfNeeded() {
        if (this.contentIdx == 39) {
            this.player.getInventory().setHelmet(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 38) {
            this.player.getInventory().setChestplate(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 37) {
            this.player.getInventory().setLeggings(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 36) {
            this.player.getInventory().setBoots(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 40) {
            this.player.getInventory().setItemInOffHand(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        }
    }

    private static String formatName(String name) {
        String[] parts = name.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0)));
            sb.append(part.substring(1));
            sb.append(' ');
        }
        return sb.toString().trim();
    }

    private static String toRoman(int n) {
        return switch (n) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            case 7 -> "VII";
            case 8 -> "VIII";
            case 9 -> "IX";
            case 10 -> "X";
            default -> String.valueOf(n);
        };
    }
}

