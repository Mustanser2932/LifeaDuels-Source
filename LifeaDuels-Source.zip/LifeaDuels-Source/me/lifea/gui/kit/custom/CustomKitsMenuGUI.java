/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.kit.custom;

import java.util.ArrayList;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.kit.custom.CustomKitRoundSelectionGUI;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class CustomKitsMenuGUI {
    private final Player target;

    public CustomKitsMenuGUI(Player target) {
        this.target = target;
    }

    public void open(Player player) {
        if (!CustomKitManager.isEnabled()) {
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
        } else {
            ConfigurationSection section = ConfigManager.customKits().getConfigurationSection("Custom-Kits");
            if (section == null) {
                player.sendMessage(ColorUtil.parse("&#FB0000Custom kits config not found!"));
            } else {
                ConfigurationSection statsSec;
                int size = section.getInt("size", 45);
                int rows = size / 9;
                String title = section.getString("name", "Custom Kits");
                Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
                FillerUtil.fill(gui, section.getConfigurationSection("Fillers"));
                ConfigurationSection closeSec = section.getConfigurationSection("close-item");
                if (closeSec != null) {
                    Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                    if (closeMat == null) {
                        closeMat = Material.BARRIER;
                    }
                    int closeSlot = closeSec.getInt("slot", 41);
                    List<Component> closeLore = LoreUtil.read(closeSec, "lore");
                    ItemBuilder closeBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cClose")))).flags(ItemFlag.values());
                    if (!closeLore.isEmpty()) {
                        closeBuilder.lore(closeLore);
                    }
                    gui.setItem(closeSlot, closeBuilder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        player.closeInventory();
                    }));
                }
                if ((statsSec = section.getConfigurationSection("Items.Stats")) != null) {
                    this.addConfigItem(gui, statsSec, null);
                }
                List<Integer> occupiedSlots = CustomKitManager.getOccupiedSlots(player.getUniqueId());
                int startSlot = section.getInt("kit-start-slot", 20);
                int slotIndex = 0;
                for (int kitSlot : occupiedSlots) {
                    int guiSlot = startSlot + slotIndex;
                    if (guiSlot >= size) break;
                    Object kitName = "Kit " + kitSlot;
                    CustomKit kit = CustomKitManager.getKit(player.getUniqueId(), kitSlot);
                    if (kit == null) continue;
                    String n = kit.getSettings().get("kit-name");
                    if (n != null && !n.isBlank()) {
                        kitName = n;
                    }
                    ArrayList<Component> lore = new ArrayList<Component>();
                    lore.add(ColorUtil.parse("&f[Kit " + kitSlot + "]"));
                    lore.add(ColorUtil.parse("&fName: &f" + (String)kitName));
                    lore.add(ColorUtil.parse("&fClick to duel with this kit"));
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BOOK).name(ColorUtil.parse("&#FBDA00" + (String)kitName))).flags(ItemFlag.values())).lore(lore);
                    gui.setItem(guiSlot, builder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        new CustomKitRoundSelectionGUI(player, this.target, kitSlot).open(player);
                    }));
                    ++slotIndex;
                }
                gui.open((HumanEntity)player);
            }
        }
    }

    private void addConfigItem(Gui gui, ConfigurationSection sec, Runnable click) {
        Material mat = Material.matchMaterial((String)sec.getString("material", "STONE"));
        if (mat == null) {
            mat = Material.STONE;
        }
        String name = sec.getString("name", "");
        int slot = sec.getInt("slot", 0);
        List<Component> lore = LoreUtil.read(sec, "lore");
        ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
        if (!lore.isEmpty()) {
            builder.lore(lore);
        }
        gui.setItem(slot, click != null ? builder.asGuiItem(e -> click.run()) : builder.asGuiItem());
    }
}

