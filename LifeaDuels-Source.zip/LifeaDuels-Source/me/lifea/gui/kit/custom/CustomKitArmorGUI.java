/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.gui.kit.custom;

import java.util.HashMap;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class CustomKitArmorGUI {
    private final int kitSlot;
    private final String armorType;
    private final Player opponent;

    public CustomKitArmorGUI(int kitSlot, String armorType, Player opponent) {
        this.kitSlot = kitSlot;
        this.armorType = armorType;
        this.opponent = opponent;
    }

    public void open(Player player) {
        String var10000 = this.armorType.substring(0, 1).toUpperCase();
        String configKey = var10000 + this.armorType.substring(1);
        ConfigurationSection section = ConfigManager.customKits().getConfigurationSection(configKey);
        if (section == null) {
            player.sendMessage(ColorUtil.parse("&#FB0000Armor config not found: " + configKey));
        } else {
            String armorPlural;
            ConfigurationSection armorSec;
            ConfigurationSection itemsSec;
            ConfigurationSection horseSec;
            ConfigurationSection closeSec;
            int size = section.getInt("size", 27);
            int rows = size / 9;
            String title = section.getString("name", "Select " + configKey);
            Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(title))).rows(rows)).disableAllInteractions()).create();
            FillerUtil.fill(gui, section.getConfigurationSection("fillers"));
            ConfigurationSection secFiller = section.getConfigurationSection("fillers-secondary");
            if (secFiller != null) {
                Material mat = Material.matchMaterial((String)secFiller.getString("material", "GRAY_STAINED_GLASS_PANE"));
                if (mat == null) {
                    mat = Material.GRAY_STAINED_GLASS_PANE;
                }
                String name = secFiller.getString("name", " ");
                String slotsStr = secFiller.getString("slots", "");
                ItemBuilder fillerBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, secFiller).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                for (String s : slotsStr.split(",")) {
                    try {
                        gui.setItem(Integer.parseInt(s.trim()) - 1, fillerBuilder.asGuiItem());
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
            }
            if ((closeSec = section.getConfigurationSection("close-item")) != null) {
                Material closeMat = Material.matchMaterial((String)closeSec.getString("material", "BARRIER"));
                if (closeMat == null) {
                    closeMat = Material.BARRIER;
                }
                int closeSlot = closeSec.getInt("slot", 23);
                List<Component> closeLore = LoreUtil.read(closeSec, "lore");
                ItemBuilder closeBuilder = (ItemBuilder)((ItemBuilder)HeadUtil.from(closeMat, closeSec).name(ColorUtil.parse(closeSec.getString("name", "&cClose")))).flags(ItemFlag.values());
                if (!closeLore.isEmpty()) {
                    closeBuilder.lore(closeLore);
                }
                gui.setItem(closeSlot, closeBuilder.asGuiItem(e -> {
                    SoundUtil.playClick(player);
                    new CustomKitEditorGUI(this.kitSlot, this.opponent).open(player);
                }));
            }
            if ((horseSec = section.getConfigurationSection("horse-armors")) != null && (itemsSec = horseSec.getConfigurationSection("items")) != null) {
                for (String key : itemsSec.getKeys(false)) {
                    ConfigurationSection itemSec = itemsSec.getConfigurationSection(key);
                    if (itemSec == null) continue;
                    Material mat = Material.matchMaterial((String)itemSec.getString("material", "STONE"));
                    if (mat == null) {
                        mat = Material.STONE;
                    }
                    int slot = itemSec.getInt("slot", 0);
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, itemSec).name(ColorUtil.parse("&f"))).flags(ItemFlag.values());
                    gui.setItem(slot - 1, builder.asGuiItem());
                }
            }
            if ((armorSec = section.getConfigurationSection(armorPlural = this.armorType.equalsIgnoreCase("boots") ? "boots" : (this.armorType.equalsIgnoreCase("leggings") ? "leggings" : (this.armorType.equalsIgnoreCase("chestplate") ? "chestplates" : "helmets")))) != null) {
                for (String key : armorSec.getKeys(false)) {
                    ConfigurationSection itemSec = armorSec.getConfigurationSection(key);
                    if (itemSec == null) continue;
                    Material mat = Material.matchMaterial((String)itemSec.getString("material", "STONE"));
                    if (mat == null) {
                        mat = Material.STONE;
                    }
                    String name = itemSec.getString("name", key);
                    int slot = itemSec.getInt("slot", 0);
                    List<Component> lore = LoreUtil.read(itemSec, "lore");
                    ItemBuilder builder = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat, itemSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
                    if (!lore.isEmpty()) {
                        builder.lore(lore);
                    }
                    gui.setItem(slot - 1, builder.asGuiItem(e -> {
                        SoundUtil.playClick(player);
                        CustomKit existing = CustomKitManager.getKit(player.getUniqueId(), this.kitSlot);
                        HashMap<String, String> settingsMap = existing != null ? new HashMap<String, String>(existing.getSettings()) : new HashMap();
                        HashMap<String, String> potionsMap = existing != null ? new HashMap<String, String>(existing.getPotions()) : new HashMap();
                        ItemStack[] content = existing != null ? existing.getContent() : new ItemStack[41];
                        String armorMatName = key.contains("_") ? key.split("_")[0].toUpperCase() : key.toUpperCase();
                        String fullMatName = armorMatName + "_" + this.armorType.toUpperCase();
                        Material armorMat = Material.matchMaterial((String)fullMatName);
                        if (armorMat != null && armorMat.isItem()) {
                            ItemStack armorItem = new ItemStack(armorMat);
                            int armorIndex = switch (this.armorType) {
                                case "boots" -> 36;
                                case "leggings" -> 37;
                                case "chestplate" -> 38;
                                case "helmet" -> 39;
                                default -> -1;
                            };
                            if (armorIndex >= 0 && armorIndex < content.length) {
                                content[armorIndex] = armorItem;
                            }
                        }
                        CustomKitManager.saveKit(player.getUniqueId(), this.kitSlot, content, settingsMap, potionsMap);
                        new CustomKitEditorGUI(this.kitSlot, this.opponent).open(player);
                    }));
                }
            }
            gui.open((HumanEntity)player);
        }
    }
}

