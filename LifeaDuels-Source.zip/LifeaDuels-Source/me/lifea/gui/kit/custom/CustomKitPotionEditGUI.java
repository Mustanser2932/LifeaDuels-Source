/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.potion.PotionType
 */
package me.lifea.gui.kit.custom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import me.lifea.Lifea;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.libs.anvilgui.AnvilGUI;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

public class CustomKitPotionEditGUI {
    private static final int GUI_SIZE = 54;
    private static final Material FILLER_MAT = Material.GRAY_STAINED_GLASS_PANE;
    private static final ItemFlag[] ALL_FLAGS = ItemFlag.values();
    private static final int BACK_SLOT = 0;
    private static final int PREVIEW_SLOT = 10;
    private static final int RENAME_SLOT = 16;
    private static final int VARIANT_TOGGLE_SLOT = 28;
    private static final int[] VARIANT_SLOTS = new int[]{30, 31, 32, 33, 34, 35};
    private static final int AMOUNT_TOGGLE_SLOT = 37;
    private static final int AMOUNT_CUSTOM_SLOT = 39;
    private static final int[] AMOUNT_PRESET_SLOTS = new int[]{40, 41, 42, 43};
    private static final int[] AMOUNT_PRESET_VALUES = new int[]{1, 16, 32, 64};
    private static final int TIMING_TOGGLE_SLOT = 46;
    private static final int TIMING_PREV_SLOT = 47;
    private static final int TIMING_CUSTOM_SLOT = 48;
    private static final int[] TIMING_PRESET_SLOTS = new int[]{49, 50, 51, 52};
    private static final int TIMING_NEXT_SLOT = 53;
    private static final String[] ALL_TIMING_LABELS = new String[]{"-1 (Inf)", "5s", "10s", "11s", "22s", "45s", "1m", "1m 30s", "2m", "2m 30s"};
    private static final int[] ALL_TIMING_VALUES = new int[]{-1, 5, 10, 11, 22, 45, 60, 90, 120, 150};
    private static final int PRESETS_PER_PAGE = TIMING_PRESET_SLOTS.length;
    private final int kitSlot;
    private final Player opponent;
    private final int contentIdx;
    private final ItemStack[] content;
    private final Map<String, String> settings;
    private final Map<String, String> potions;
    private final Player player;
    private Gui gui;
    private boolean variantMode;
    private boolean timingMode;
    private boolean amountMode;
    private boolean openingAnvil;
    private int timingPage;
    private PotionType activePotionType;
    private int activeTiming = -2;
    private int activeAmount = 1;
    private boolean hasCustomName;
    private String customName;

    public CustomKitPotionEditGUI(int kitSlot, Player opponent, int contentIdx, ItemStack[] content, Map<String, String> settings, Map<String, String> potions, Player player) {
        this.kitSlot = kitSlot;
        this.opponent = opponent;
        this.contentIdx = contentIdx;
        this.content = content;
        this.settings = settings;
        this.potions = potions;
        this.player = player;
    }

    public void open(Player player) {
        boolean isInstant;
        this.parseCurrentPotion();
        this.gui = ((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("&8Edit Potion"))).rows(6)).create();
        for (int slot = 0; slot < 54; ++slot) {
            if (this.isFixedSlot(slot)) continue;
            this.gui.setItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.setDefaultClickAction(event -> {
            if (event.getRawSlot() < 54) {
                event.setCancelled(true);
            }
        });
        this.gui.setDragAction(event -> {
            Iterator i$ = event.getRawSlots().iterator();
            while (i$.hasNext()) {
                int slot = (Integer)i$.next();
                if (slot >= 54) continue;
                event.setCancelled(true);
                return;
            }
        });
        this.gui.setCloseGuiAction(event -> {
            if (!this.openingAnvil) {
                this.saveAndGoBack();
            }
        });
        this.gui.setItem(0, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.FEATHER).name(ColorUtil.parse("&fBack to Kit Editor"))).flags(ALL_FLAGS)).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(player);
            player.closeInventory();
        }));
        this.gui.setItem(16, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.NAME_TAG).name(ColorUtil.parse("&fRename Item"))).lore(ColorUtil.parse("&fClick to rename this item"))).flags(ALL_FLAGS)).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(player);
            this.openingAnvil = true;
            this.openRenameAnvil();
        }));
        this.updateVariantToggle();
        boolean bl = isInstant = this.activePotionType != null && this.isInstantPotion(this.activePotionType);
        if (isInstant) {
            this.gui.setItem(46, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BARRIER).name(ColorUtil.parse("&8Timing N/A"))).lore(ColorUtil.parse("&fThis potion has no duration"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
        } else {
            this.updateTimingToggle();
        }
        if (this.isTippedArrow()) {
            this.updateAmountToggle();
        } else {
            this.gui.setItem(37, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BARRIER).name(ColorUtil.parse("&8Stacking Disabled"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.open((HumanEntity)player);
        this.updatePreview();
        this.clearDynamicSlots();
    }

    private boolean isFixedSlot(int slot) {
        if (slot != 0 && slot != 10 && slot != 16 && slot != 28 && slot != 46 && slot != 47 && slot != 48 && slot != 53 && slot != 37 && slot != 39) {
            for (int s : VARIANT_SLOTS) {
                if (s != slot) continue;
                return true;
            }
            for (int s : TIMING_PRESET_SLOTS) {
                if (s != slot) continue;
                return true;
            }
            for (int s : AMOUNT_PRESET_SLOTS) {
                if (s != slot) continue;
                return true;
            }
            return false;
        }
        return true;
    }

    private void parseCurrentPotion() {
        ItemMeta var3;
        this.activePotionType = null;
        this.activeTiming = -2;
        this.activeAmount = 1;
        this.hasCustomName = false;
        this.customName = null;
        ItemStack item = this.getCurrentItem();
        if (item != null && (var3 = item.getItemMeta()) instanceof PotionMeta) {
            PotionType base;
            PotionMeta meta = (PotionMeta)var3;
            this.activeAmount = item.getAmount();
            if (meta.hasDisplayName()) {
                this.hasCustomName = true;
                this.customName = meta.getDisplayName();
            }
            this.activePotionType = (base = meta.getBasePotionType()) != null && base.getEffectType() != null ? base : this.deducePotionType(meta);
            PotionEffectType matchType = this.activePotionType != null ? this.activePotionType.getEffectType() : null;
            for (PotionEffect effect : meta.getCustomEffects()) {
                if (matchType == null || !effect.getType().equals(matchType)) continue;
                int ticks = effect.getDuration();
                this.activeTiming = ticks >= Integer.MAX_VALUE ? -1 : ticks / 20;
                break;
            }
            return;
        }
    }

    private PotionType deducePotionType(PotionMeta meta) {
        int expectedAmp;
        PotionEffectType ptEffect;
        List effects = meta.getCustomEffects();
        if (effects.isEmpty()) {
            return null;
        }
        PotionEffect first = (PotionEffect)effects.get(0);
        PotionEffectType needle = first.getType();
        int amp = first.getAmplifier();
        PotionType best = null;
        for (PotionType pt : PotionType.values()) {
            ptEffect = pt.getEffectType();
            if (ptEffect == null || !ptEffect.equals(needle)) continue;
            int n = expectedAmp = pt.name().startsWith("STRONG_") ? 1 : 0;
            if (expectedAmp != amp || pt.name().startsWith("LONG_")) continue;
            best = pt;
        }
        if (best == null) {
            for (PotionType pt : PotionType.values()) {
                ptEffect = pt.getEffectType();
                if (ptEffect == null || !ptEffect.equals(needle)) continue;
                int n = expectedAmp = pt.name().startsWith("STRONG_") ? 1 : 0;
                if (expectedAmp != amp) continue;
                best = pt;
                break;
            }
        }
        return best;
    }

    private boolean isInstantPotion(PotionType type) {
        PotionEffectType effectType = type.getEffectType();
        if (effectType == null) {
            return true;
        }
        String key = effectType.getKey().getKey();
        return key.contains("instant");
    }

    private ItemStack getCurrentItem() {
        ItemStack item;
        if (this.contentIdx >= 0 && this.contentIdx < this.content.length && (item = this.content[this.contentIdx]) != null && item.getType() != Material.AIR) {
            return item;
        }
        return null;
    }

    private void updatePreview() {
        ItemStack item = this.buildPotionItem();
        if (item != null) {
            this.gui.updateItem(10, ItemBuilder.from(item.clone()).asGuiItem(e -> e.setCancelled(true)));
        } else {
            this.gui.updateItem(10, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.BARRIER).name(ColorUtil.parse("&cNo Item"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
        }
    }

    private ItemStack buildPotionItem() {
        if (this.activePotionType == null) {
            return this.getCurrentItem();
        }
        ItemStack curItem = this.getCurrentItem();
        Material rawMat = curItem != null ? curItem.getType() : Material.POTION;
        Material mat = this.isPotionMaterial(rawMat) ? rawMat : Material.POTION;
        ItemStack stack = new ItemStack(mat, this.activeAmount);
        stack.editMeta(PotionMeta.class, meta -> {
            if (this.activeTiming >= -1) {
                PotionEffectType effectType = this.activePotionType.getEffectType();
                meta.setBasePotionType(PotionType.AWKWARD);
                if (effectType != null) {
                    int ticks = this.activeTiming == -1 ? Integer.MAX_VALUE : this.activeTiming * 20;
                    int amplifier = this.getPotionAmplifier(this.activePotionType);
                    meta.addCustomEffect(new PotionEffect(effectType, ticks, amplifier), true);
                    try {
                        meta.setColor(effectType.getColor());
                    }
                    catch (Exception exception) {}
                }
            } else {
                meta.setBasePotionType(this.activePotionType);
            }
            if (this.hasCustomName && this.customName != null) {
                meta.displayName(ColorUtil.parse(this.customName));
            } else {
                meta.displayName(ColorUtil.parse(this.generateDefaultPotionName(this.activePotionType, mat)));
            }
        });
        return stack;
    }

    private String generateDefaultPotionName(PotionType type, Material material) {
        String var10000 = switch (material) {
            case Material.SPLASH_POTION -> "Splash Potion";
            case Material.LINGERING_POTION -> "Lingering Potion";
            case Material.TIPPED_ARROW -> "Tipped Arrow";
            default -> "Potion";
        };
        String typeName = type.name();
        if (typeName.startsWith("LONG_")) {
            String effectName = CustomKitPotionEditGUI.formatEffectName(typeName.replace("LONG_", ""));
            return var10000 + " of " + effectName + " (Extended)";
        }
        if (typeName.startsWith("STRONG_")) {
            String effectName = CustomKitPotionEditGUI.formatEffectName(typeName.replace("STRONG_", ""));
            return var10000 + " of " + effectName + " II";
        }
        String effectName = CustomKitPotionEditGUI.formatEffectName(typeName);
        return var10000 + " of " + effectName;
    }

    private int getPotionAmplifier(PotionType type) {
        String name = type.name();
        return name.startsWith("STRONG_") ? 1 : 0;
    }

    private boolean isPotionMaterial(Material mat) {
        return mat == Material.POTION || mat == Material.SPLASH_POTION || mat == Material.LINGERING_POTION || mat == Material.TIPPED_ARROW;
    }

    private boolean isTippedArrow() {
        return this.getCurrentItem() != null && this.getCurrentItem().getType() == Material.TIPPED_ARROW;
    }

    private void clearDynamicSlots() {
        ItemStack filler = ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).build();
        for (int slot : VARIANT_SLOTS) {
            this.gui.updateItem(slot, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        }
        for (int slot : TIMING_PRESET_SLOTS) {
            this.gui.updateItem(slot, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.updateItem(48, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        this.gui.updateItem(47, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        this.gui.updateItem(53, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        for (int slot : AMOUNT_PRESET_SLOTS) {
            this.gui.updateItem(slot, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
        }
        this.gui.updateItem(39, ItemBuilder.from(filler).asGuiItem(e -> e.setCancelled(true)));
    }

    private void updateVariantToggle() {
        Gui var10000 = this.gui;
        ItemBuilder var10002 = ItemBuilder.from(Material.HEAVY_CORE);
        String var10003 = this.variantMode ? "&a" : "&f";
        var10000.updateItem(28, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse(var10003 + "Variant Mode"))).lore(ColorUtil.parse(this.variantMode ? "&fClick to hide variants" : "&fClick to show variants"))).flags(ALL_FLAGS)).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            this.variantMode = !this.variantMode;
            this.updateVariantToggle();
            if (this.variantMode) {
                this.timingMode = false;
                this.amountMode = false;
                this.updateTimingToggle();
                this.updateAmountToggle();
            }
            this.updateVariantSlots();
            this.updateTimingSlots();
            this.updateAmountSlots();
        }));
    }

    private void updateVariantSlots() {
        if (this.variantMode && this.activePotionType != null) {
            List<PotionVariantOption> variants = this.generateVariants();
            ItemStack current = this.getCurrentItem();
            Material currentMat = current != null ? current.getType() : Material.POTION;
            PotionType currentType = this.activePotionType;
            for (int i = 0; i < VARIANT_SLOTS.length; ++i) {
                int slot = VARIANT_SLOTS[i];
                if (i < variants.size()) {
                    PotionVariantOption var = variants.get(i);
                    boolean isSelected = var.material == currentMat && var.type == currentType;
                    String prefix = isSelected ? "&a\u2713 " : "&f";
                    ItemStack display = this.buildVariantDisplay(var);
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(display).name(ColorUtil.parse(prefix + this.formatPotionName(var)))).lore(ColorUtil.parse(isSelected ? "&fCurrently selected" : "&eClick &fto select"))).flags(ALL_FLAGS)).asGuiItem(e -> {
                        e.setCancelled(true);
                        SoundUtil.playClick(this.player);
                        Material newMat = var.material;
                        PotionType newType = var.type;
                        ItemStack stack = new ItemStack(newMat, this.activeAmount);
                        stack.editMeta(PotionMeta.class, meta -> {
                            if (this.activeTiming >= -1) {
                                PotionEffectType effType = newType.getEffectType();
                                meta.setBasePotionType(PotionType.AWKWARD);
                                if (effType != null) {
                                    int amp = this.getPotionAmplifier(newType);
                                    int ticks = this.activeTiming == -1 ? Integer.MAX_VALUE : this.activeTiming * 20;
                                    meta.addCustomEffect(new PotionEffect(effType, ticks, amp), true);
                                    try {
                                        meta.setColor(effType.getColor());
                                    }
                                    catch (Exception exception) {}
                                }
                            } else {
                                meta.setBasePotionType(newType);
                            }
                            if (this.hasCustomName && this.customName != null) {
                                meta.displayName(ColorUtil.parse(this.customName));
                            } else {
                                meta.displayName(ColorUtil.parse(this.generateDefaultPotionName(newType, newMat)));
                            }
                        });
                        this.content[this.contentIdx] = stack;
                        this.activePotionType = newType;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                        this.updateVariantSlots();
                    }));
                    continue;
                }
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
        } else {
            for (int slot : VARIANT_SLOTS) {
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
        }
    }

    private List<PotionVariantOption> generateVariants() {
        PotionType[] strengths;
        PotionType[] potionTypeArray;
        PotionType basePotionType;
        Material[] materialArray;
        boolean isArrow;
        ArrayList<PotionVariantOption> variants = new ArrayList<PotionVariantOption>();
        if (this.activePotionType == null) {
            return variants;
        }
        boolean bl = isArrow = this.getCurrentItem() != null && this.getCurrentItem().getType() == Material.TIPPED_ARROW;
        if (isArrow) {
            Material[] materialArray2 = new Material[1];
            materialArray = materialArray2;
            materialArray2[0] = Material.TIPPED_ARROW;
        } else {
            Material[] materialArray3 = new Material[3];
            materialArray3[0] = Material.POTION;
            materialArray3[1] = Material.SPLASH_POTION;
            materialArray = materialArray3;
            materialArray3[2] = Material.LINGERING_POTION;
        }
        Material[] materials = materialArray;
        PotionType baseType = this.activePotionType;
        String rawName = baseType.name();
        String baseName = rawName.startsWith("STRONG_") ? rawName.substring(7) : (rawName.startsWith("LONG_") ? rawName.substring(5) : rawName);
        PotionType strongType = null;
        try {
            strongType = PotionType.valueOf((String)("STRONG_" + baseName));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // empty catch block
        }
        try {
            basePotionType = PotionType.valueOf((String)baseName);
        }
        catch (IllegalArgumentException var181) {
            return variants;
        }
        if (strongType != null) {
            PotionType[] potionTypeArray2 = new PotionType[2];
            potionTypeArray2[0] = basePotionType;
            potionTypeArray = potionTypeArray2;
            potionTypeArray2[1] = strongType;
        } else {
            PotionType[] potionTypeArray3 = new PotionType[1];
            potionTypeArray = potionTypeArray3;
            potionTypeArray3[0] = basePotionType;
        }
        for (PotionType pt : strengths = potionTypeArray) {
            for (Material mat : materials) {
                variants.add(new PotionVariantOption(mat, pt));
            }
        }
        return variants;
    }

    private ItemStack buildVariantDisplay(PotionVariantOption var) {
        ItemStack stack = new ItemStack(var.material, 1);
        stack.editMeta(PotionMeta.class, meta -> meta.setBasePotionType(var.type));
        return stack;
    }

    private String formatPotionName(PotionVariantOption var) {
        String typeName = var.type.name();
        String var10000 = switch (var.material) {
            case Material.SPLASH_POTION -> "Splash";
            case Material.LINGERING_POTION -> "Lingering";
            case Material.TIPPED_ARROW -> "Arrow";
            default -> "Drinkable";
        };
        String effectName = CustomKitPotionEditGUI.formatEffectName(typeName.replace("STRONG_", ""));
        return typeName.startsWith("STRONG_") ? effectName + " II (" + var10000 + ")" : effectName + " I (" + var10000 + ")";
    }

    private void updateTimingToggle() {
        Gui var10000 = this.gui;
        ItemBuilder var10002 = ItemBuilder.from(Material.CLOCK);
        String var10003 = this.timingMode ? "&a" : "&f";
        var10000.updateItem(46, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse(var10003 + "Potion Timing"))).lore(ColorUtil.parse(this.timingMode ? "&fClick to hide timing" : "&fClick to set potion duration"))).flags(ALL_FLAGS)).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            this.timingMode = !this.timingMode;
            this.updateTimingToggle();
            if (this.timingMode) {
                this.variantMode = false;
                this.amountMode = false;
                this.updateVariantToggle();
                this.updateAmountToggle();
            }
            this.updateTimingSlots();
            this.updateVariantSlots();
            this.updateAmountSlots();
        }));
    }

    private void updateTimingSlots() {
        if (this.timingMode) {
            boolean hasNext;
            this.gui.updateItem(48, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ANVIL).name(ColorUtil.parse("&fCustom Timing"))).lore(ColorUtil.parse("&fClick to set custom duration"))).flags(ALL_FLAGS)).asGuiItem(e -> {
                e.setCancelled(true);
                SoundUtil.playClick(this.player);
                this.openingAnvil = true;
                this.openTimingAnvil();
            }));
            int totalPresets = ALL_TIMING_VALUES.length;
            int maxPage = (totalPresets - 1) / PRESETS_PER_PAGE;
            if (this.timingPage > maxPage) {
                this.timingPage = maxPage;
            }
            int start = this.timingPage * PRESETS_PER_PAGE;
            for (int i = 0; i < PRESETS_PER_PAGE; ++i) {
                int slot = TIMING_PRESET_SLOTS[i];
                int idx = start + i;
                if (idx < totalPresets) {
                    int val = ALL_TIMING_VALUES[idx];
                    String label = ALL_TIMING_LABELS[idx];
                    boolean isCurrent = this.activeTiming == val;
                    String prefix = isCurrent ? "&a\u2713 " : "&f";
                    this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.PAPER).name(ColorUtil.parse(prefix + label))).lore(ColorUtil.parse(isCurrent ? "&fCurrently selected" : "&eClick &fto select"))).flags(ALL_FLAGS)).asGuiItem(e -> {
                        e.setCancelled(true);
                        SoundUtil.playClick(this.player);
                        this.activeTiming = val;
                        this.applyTimingToItem();
                        this.updatePreview();
                        this.updateTimingSlots();
                    }));
                    continue;
                }
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
            boolean hasPrev = this.timingPage > 0;
            boolean bl = hasNext = this.timingPage < maxPage;
            if (hasPrev) {
                this.gui.updateItem(47, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ColorUtil.parse("&fPrevious Page"))).flags(ALL_FLAGS)).asGuiItem(e -> {
                    e.setCancelled(true);
                    SoundUtil.playClick(this.player);
                    --this.timingPage;
                    this.updateTimingSlots();
                }));
            } else {
                this.gui.updateItem(47, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
            if (hasNext) {
                this.gui.updateItem(53, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(ColorUtil.parse("&fNext Page"))).flags(ALL_FLAGS)).asGuiItem(e -> {
                    e.setCancelled(true);
                    SoundUtil.playClick(this.player);
                    ++this.timingPage;
                    this.updateTimingSlots();
                }));
            } else {
                this.gui.updateItem(53, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
        } else {
            for (int slot : TIMING_PRESET_SLOTS) {
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
            this.gui.updateItem(48, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            this.gui.updateItem(47, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            this.gui.updateItem(53, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
        }
    }

    private void applyTimingToItem() {
        ItemStack updated;
        ItemStack current = this.getCurrentItem();
        if (current != null && (updated = this.buildPotionItem()) != null) {
            this.content[this.contentIdx] = updated;
            this.syncArmorIfNeeded();
        }
    }

    private void updateAmountToggle() {
        Gui var10000 = this.gui;
        ItemBuilder var10002 = ItemBuilder.from(Material.AMETHYST_CLUSTER);
        String var10003 = this.amountMode ? "&a" : "&f";
        var10000.updateItem(37, ((ItemBuilder)((ItemBuilder)((ItemBuilder)var10002.name(ColorUtil.parse(var10003 + "Item Amount"))).lore(ColorUtil.parse(this.amountMode ? "&fClick to hide amounts" : "&fClick to set item count"))).flags(ALL_FLAGS)).asGuiItem(e -> {
            e.setCancelled(true);
            SoundUtil.playClick(this.player);
            this.amountMode = !this.amountMode;
            this.updateAmountToggle();
            if (this.amountMode) {
                this.variantMode = false;
                this.timingMode = false;
                this.updateVariantToggle();
                this.updateTimingToggle();
            }
            this.updateAmountSlots();
            this.updateVariantSlots();
            this.updateTimingSlots();
        }));
    }

    private void updateAmountSlots() {
        if (this.amountMode) {
            this.gui.updateItem(39, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ANVIL).name(ColorUtil.parse("&fCustom Amount"))).lore(ColorUtil.parse("&fClick to set custom amount"))).flags(ALL_FLAGS)).asGuiItem(e -> {
                e.setCancelled(true);
                SoundUtil.playClick(this.player);
                this.openingAnvil = true;
                this.openAmountAnvil();
            }));
            for (int i = 0; i < AMOUNT_PRESET_SLOTS.length; ++i) {
                int slot = AMOUNT_PRESET_SLOTS[i];
                int amt = AMOUNT_PRESET_VALUES[i];
                boolean isCurrent = this.activeAmount == amt;
                String prefix = isCurrent ? "&a\u2713 " : "&f";
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.PAPER).name(ColorUtil.parse(prefix + "x" + amt))).lore(ColorUtil.parse((String)(isCurrent ? "&fCurrently selected" : "&eClick &fto set to x" + amt)))).flags(ALL_FLAGS)).asGuiItem(e -> {
                    e.setCancelled(true);
                    SoundUtil.playClick(this.player);
                    this.activeAmount = amt;
                    ItemStack current = this.getCurrentItem();
                    if (current != null) {
                        current.setAmount(amt);
                        this.content[this.contentIdx] = current;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                        this.updateAmountSlots();
                    }
                }));
            }
        } else {
            for (int slot : AMOUNT_PRESET_SLOTS) {
                this.gui.updateItem(slot, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
            }
            this.gui.updateItem(39, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(FILLER_MAT).name(ColorUtil.parse("&f"))).flags(ALL_FLAGS)).asGuiItem(e -> e.setCancelled(true)));
        }
    }

    private void openAmountAnvil() {
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title("Set Amount (1-64)").text(String.valueOf(this.activeAmount)).itemLeft(new ItemStack(Material.ANVIL)).onClick((slot, state) -> {
            if (slot != 2) {
                return List.of();
            }
            String text = state.getText().trim();
            try {
                int amt = Integer.parseInt(text);
                return amt >= 1 && amt <= 64 ? List.of(AnvilGUI.ResponseAction.close()) : List.of(AnvilGUI.ResponseAction.replaceInputText("1-64 only"));
            }
            catch (NumberFormatException var4) {
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Invalid number!"));
            }
        }).onClose(state -> {
            String text = state.getText().trim();
            try {
                int amt = Integer.parseInt(text);
                if (amt >= 1 && amt <= 64) {
                    this.activeAmount = amt;
                    ItemStack current = this.getCurrentItem();
                    if (current != null) {
                        current.setAmount(amt);
                        this.content[this.contentIdx] = current;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                        this.updateAmountSlots();
                    }
                }
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
        }).open(this.player);
    }

    private void openRenameAnvil() {
        ItemStack current = this.getCurrentItem();
        if (current != null) {
            String currentName = "";
            if (current.getItemMeta() != null && current.getItemMeta().hasDisplayName()) {
                currentName = current.getItemMeta().getDisplayName().replaceAll("\u00a7[0-9a-fk-or]", "");
            }
            new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title("Rename Potion").text(currentName).itemLeft(new ItemStack(Material.NAME_TAG)).onClick((slot, state) -> {
                if (slot != 2) {
                    return List.of();
                }
                String text = state.getText();
                if (text != null && !text.trim().isEmpty()) {
                    this.hasCustomName = true;
                    this.customName = text.trim();
                    ItemStack updated = this.buildPotionItem();
                    if (updated != null) {
                        this.content[this.contentIdx] = updated;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                    }
                    return List.of(AnvilGUI.ResponseAction.close());
                }
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Enter a name"));
            }).onClose(state -> {
                String text = state.getText();
                if (text != null && !text.trim().isEmpty()) {
                    this.hasCustomName = true;
                    this.customName = text.trim();
                    ItemStack updated = this.buildPotionItem();
                    if (updated != null) {
                        this.content[this.contentIdx] = updated;
                        this.syncArmorIfNeeded();
                        this.updatePreview();
                    }
                }
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
            }).open(this.player);
        }
    }

    private void openTimingAnvil() {
        new AnvilGUI.Builder().plugin((Plugin)Lifea.getInstance()).title("Duration in seconds (-1 = inf)").text(String.valueOf(this.activeTiming < 0 ? -1 : this.activeTiming)).itemLeft(new ItemStack(Material.CLOCK)).onClick((slot, state) -> {
            if (slot != 2) {
                return List.of();
            }
            String text = state.getText().trim();
            try {
                Integer.parseInt(text);
                return List.of(AnvilGUI.ResponseAction.close());
            }
            catch (NumberFormatException var4) {
                return List.of(AnvilGUI.ResponseAction.replaceInputText("Invalid number!"));
            }
        }).onClose(state -> {
            String text = state.getText().trim();
            try {
                int val = Integer.parseInt(text);
                this.activeTiming = Math.max(val, -1);
                this.applyTimingToItem();
                this.updatePreview();
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> this.reopenEditGui());
        }).open(this.player);
    }

    private void saveAndGoBack() {
        this.player.setItemOnCursor((ItemStack)null);
        try {
            CustomKitManager.saveKit(this.player.getUniqueId(), this.kitSlot, this.content, this.settings, this.potions);
        }
        catch (Exception exception) {
            // empty catch block
        }
        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> new CustomKitEditorGUI(this.kitSlot, this.opponent).open(this.player));
    }

    private void reopenEditGui() {
        new CustomKitPotionEditGUI(this.kitSlot, this.opponent, this.contentIdx, this.content, this.settings, this.potions, this.player).open(this.player);
    }

    private void syncArmorIfNeeded() {
        if (this.contentIdx == 39) {
            this.player.getInventory().setHelmet(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 38) {
            this.player.getInventory().setChestplate(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 37) {
            this.player.getInventory().setLeggings(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 36) {
            this.player.getInventory().setBoots(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        } else if (this.contentIdx == 40) {
            this.player.getInventory().setItemInOffHand(this.content[this.contentIdx] != null ? this.content[this.contentIdx].clone() : null);
        }
    }

    private static String formatEffectName(String raw) {
        String[] parts = raw.toLowerCase().replace("_", " ").split(" ");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    private record PotionVariantOption(Material material, PotionType type) {
    }
}

