/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.gui.kit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.kit.KitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class KitRoomGUI {
    private final String tier;
    private final String gamemode;

    public KitRoomGUI(String tier, String gamemode) {
        this.tier = tier;
        this.gamemode = gamemode;
    }

    public void open(Player player) {
        FileConfiguration ke = ConfigManager.kitEditor();
        ConfigurationSection guiSec = ke.getConfigurationSection("multi-kit.gui");
        int kitCount = ke.getInt("multi-kit.kit-count", 3);
        int primarySlot = KitManager.getPrimaryKitSlot(player.getUniqueId(), this.tier, this.gamemode);
        Gui g = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(this.gamemode + " Kits"))).rows(3)).disableAllInteractions()).create();
        if (guiSec != null) {
            List fillerSlots = guiSec.getIntegerList("filler-slots");
            GuiItem filler = ((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name((Component)Component.empty())).asGuiItem();
            Iterator iterator = fillerSlots.iterator();
            while (iterator.hasNext()) {
                int slot = (Integer)iterator.next();
                g.setItem(slot, filler);
            }
        }
        int i = 1;
        while (i <= kitCount) {
            boolean isPrimary;
            boolean hasKit = KitManager.hasPlayerKit(player.getUniqueId(), this.tier, this.gamemode, i);
            boolean bl = isPrimary = primarySlot == i;
            ConfigurationSection sec = guiSec != null ? guiSec.getConfigurationSection(hasKit ? "kit-edited" : "kit-unedited") : null;
            Material mat = Material.BOOK;
            Object name = "&#FB0000&lKit " + i;
            int slot = 10 + i * 2 - 1;
            List loreStrings = new ArrayList();
            if (sec != null) {
                Material m = Material.matchMaterial((String)sec.getString("material", "BOOK"));
                if (m != null) {
                    mat = m;
                }
                name = sec.getString("name", (String)name).replace("%slot%", String.valueOf(i));
                slot = sec.getInt("slot-" + i, slot);
                loreStrings = sec.getStringList("lore");
            }
            if (isPrimary) {
                String suffix = ke.getString("multi-kit.gui.primary-suffix", " &8[&#FB0000Primary&8]");
                name = (String)name + suffix;
            }
            ArrayList<Component> lore = new ArrayList<Component>();
            for (String line : loreStrings) {
                lore.add(KitRoomGUI.noItalic(line));
            }
            int kitSlot = i++;
            g.setItem(slot, ((ItemBuilder)((ItemBuilder)((ItemBuilder)HeadUtil.from(mat, sec).name(KitRoomGUI.noItalic((String)name))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
                if (e.isShiftClick() && e.isLeftClick()) {
                    KitManager.setPrimaryKitSlot(player.getUniqueId(), this.tier, this.gamemode, kitSlot);
                    player.sendMessage(ColorUtil.parse("&#FB0000Kit " + kitSlot + " &fset as primary for &f" + this.gamemode + "&f."));
                    SoundUtil.playClick(player);
                    this.open(player);
                } else {
                    SoundUtil.playClick(player);
                    new KitEditorGUI(this.tier, this.gamemode, kitSlot, this).open(player);
                }
            }));
        }
        g.setItem(0, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(KitRoomGUI.noItalic("&#FB0000Go Back"))).flags(ItemFlag.values())).asGuiItem(e -> {
            SoundUtil.playClick(player);
            new DuelMenuGUI(DuelMenuGUI.sectionForTier(this.tier), null, DuelMenuGUI.Mode.KIT_EDITOR).open(player);
        }));
        g.open((HumanEntity)player);
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }
}

