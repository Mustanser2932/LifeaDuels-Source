/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 */
package me.lifea.gui.kit;

import java.util.Iterator;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

public final class KitEditorProtectionListener
implements Listener {
    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity who = event.getWhoClicked();
        if (!(who instanceof Player)) {
            return;
        }
        Player player = (Player)who;
        if (KitEditorGUI.isEditing(player)) {
            boolean editableTopSlot;
            int rawSlot = event.getRawSlot();
            int topSize = event.getView().getTopInventory().getSize();
            boolean bl = editableTopSlot = event.getClickedInventory() == event.getView().getTopInventory() && rawSlot >= 9 && rawSlot <= 45 && rawSlot < topSize;
            if (!editableTopSlot || event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT) {
                event.setCancelled(true);
            }
            return;
        }
        if (CustomKitEditorGUI.isEditing(player)) {
            int rawSlot = event.getRawSlot();
            int topSize = event.getView().getTopInventory().getSize();
            if (rawSlot >= 0 && rawSlot < topSize) {
                event.setCancelled(true);
            } else if (rawSlot < 0 || event.getClick() == ClickType.DROP || event.getClick() == ClickType.CONTROL_DROP) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        block4: {
            Player player;
            block3: {
                HumanEntity who = event.getWhoClicked();
                if (!(who instanceof Player)) {
                    return;
                }
                player = (Player)who;
                if (!KitEditorGUI.isEditing(player)) break block3;
                int topSize = event.getView().getTopInventory().getSize();
                Iterator iterator = event.getRawSlots().iterator();
                while (iterator.hasNext()) {
                    int rawSlot = (Integer)iterator.next();
                    if (rawSlot >= 9 && rawSlot <= 45 && rawSlot < topSize) continue;
                    event.setCancelled(true);
                    return;
                }
                break block4;
            }
            if (!CustomKitEditorGUI.isEditing(player)) break block4;
            Iterator iterator = event.getRawSlots().iterator();
            while (iterator.hasNext()) {
                int slot = (Integer)iterator.next();
                if (event.getView().getInventory(slot) != event.getView().getTopInventory()) continue;
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
        if (KitEditorGUI.isEditing(event.getPlayer()) || CustomKitEditorGUI.isEditing(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (KitEditorGUI.isEditing(player) || CustomKitEditorGUI.isEditing(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onInventoryClose(InventoryCloseEvent event) {
        Player player;
        HumanEntity who = event.getPlayer();
        if (who instanceof Player && KitEditorGUI.isEditing(player = (Player)who)) {
            KitEditorGUI.onEditorClose(player);
        }
    }
}

