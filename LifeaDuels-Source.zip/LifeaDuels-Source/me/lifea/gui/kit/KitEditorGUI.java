/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package me.lifea.gui.kit;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.kit.KitRoomGUI;
import me.lifea.hotbar.HotbarManager;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.components.util.ItemNbt;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.player.PlayerStateManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.FillerUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class KitEditorGUI {
    private static final Map<UUID, KitEditSession> editingPlayers = new HashMap<UUID, KitEditSession>();
    private final String tier;
    private final String gamemode;
    private final int kitSlot;
    private final KitRoomGUI backRoom;

    public KitEditorGUI(String tier, String gamemode) {
        this(tier, gamemode, 1, null);
    }

    public KitEditorGUI(String tier, String gamemode, int kitSlot, KitRoomGUI backRoom) {
        this.tier = tier;
        this.gamemode = gamemode;
        this.kitSlot = kitSlot;
        this.backRoom = backRoom;
    }

    public static boolean isEditing(Player player) {
        return editingPlayers.containsKey(player.getUniqueId());
    }

    public static KitEditSession getSession(Player player) {
        return editingPlayers.get(player.getUniqueId());
    }

    public static void removeIfEditing(Player player) {
        KitEditorGUI.onEditorClose(player);
    }

    public static void remove(UUID uuid) {
        editingPlayers.remove(uuid);
    }

    public static void cleanupOnQuit(Player player) {
        KitEditSession session = editingPlayers.remove(player.getUniqueId());
        if (session != null) {
            KitEditorGUI.returnCursorToLayout(player, session.inventory);
            KitManager.savePlayerKit(player.getUniqueId(), session.getTier(), session.getGamemode(), KitEditorGUI.captureLayout(session.inventory, session.getTier(), session.getGamemode()));
        }
    }

    public static void onEditorClose(Player player) {
        KitEditSession session = editingPlayers.remove(player.getUniqueId());
        if (session != null) {
            KitEditorGUI.returnCursorToLayout(player, session.inventory);
            KitManager.savePlayerKit(player.getUniqueId(), session.getTier(), session.getGamemode(), KitEditorGUI.captureLayout(session.inventory, session.getTier(), session.getGamemode()));
            player.setItemOnCursor((ItemStack)null);
            PlayerStateManager.refreshInventory(player);
            PlayerStateManager.refreshLobbyCosmetics(player);
        }
    }

    private static void returnCursorToLayout(Player player, Inventory inventory) {
        ItemStack cursor = player.getItemOnCursor();
        if (cursor == null || cursor.getType() == Material.AIR || inventory == null) {
            return;
        }
        for (int slot = 9; slot <= 44; ++slot) {
            ItemStack current = inventory.getItem(slot);
            if (current != null && current.getType() != Material.AIR) continue;
            inventory.setItem(slot, cursor.clone());
            player.setItemOnCursor((ItemStack)null);
            return;
        }
    }

    private static ItemStack[] captureLayout(Inventory inventory, String tier, String gamemode) {
        ItemStack[] layout = new ItemStack[41];
        if (inventory != null) {
            for (int i = 0; i < 36; ++i) {
                ItemStack item = inventory.getItem(i + 9);
                layout[i] = item == null || item.getType() == Material.AIR ? null : ItemNbt.removeTag(item.clone(), "mf-gui");
            }
            ItemStack offhand = inventory.getItem(45);
            layout[40] = offhand == null || offhand.getType() == Material.AIR ? null : ItemNbt.removeTag(offhand.clone(), "mf-gui");
        }
        ItemStack[] base = KitManager.getBaseKit(tier, gamemode);
        for (int i = 36; i <= 39; ++i) {
            layout[i] = i < base.length && base[i] != null ? base[i].clone() : null;
        }
        return layout;
    }

    private static boolean isEmptyLayout(ItemStack[] items) {
        if (items == null) {
            return true;
        }
        for (int i = 0; i < Math.min(items.length, 36); ++i) {
            if (items[i] == null || items[i].getType() == Material.AIR) continue;
            return false;
        }
        return items.length <= 40 || items[40] == null || items[40].getType() == Material.AIR;
    }

    public void open(Player player) {
        ItemStack offhand;
        ConfigurationSection backSec;
        ConfigurationSection resetSec;
        ConfigurationSection saveSec;
        FileConfiguration ke = ConfigManager.kitEditor();
        int rows = Math.max(6, ke.getInt("editor.rows", 6));
        HotbarManager.clearCache(player);
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse(ConfigManager.guiTitle("kit-editor-gamemode", "{gamemode}", this.gamemode)))).rows(rows)).create();
        FillerUtil.fill(gui, ke.getConfigurationSection("fillers.editor"));
        ConfigurationSection infoSec = ke.getConfigurationSection("editor.info");
        if (infoSec != null) {
            Material mat = Material.matchMaterial((String)infoSec.getString("material", "BOOK"));
            String name = infoSec.getString("name", "&e{tier} &f- &e{gamemode}").replace("{tier}", this.tier).replace("{gamemode}", this.gamemode);
            int slot = infoSec.getInt("slot", 4);
            List<Component> lore = LoreUtil.read(infoSec, "lore");
            ItemBuilder b = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat != null ? mat : Material.BOOK, infoSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
            if (!lore.isEmpty()) {
                b.lore(lore);
            }
            gui.setItem(slot, b.asGuiItem());
        }
        if ((saveSec = ke.getConfigurationSection("editor.save")) != null) {
            Material mat = Material.matchMaterial((String)saveSec.getString("material", "LIME_CONCRETE"));
            String name = saveSec.getString("name", "&aSave Kit");
            int slot = saveSec.getInt("slot", 7);
            List<Component> lore = LoreUtil.read(saveSec, "lore");
            ItemBuilder b = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat != null ? mat : Material.LIME_CONCRETE, saveSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
            if (!lore.isEmpty()) {
                b.lore(lore);
            }
            gui.setItem(slot, b.asGuiItem(e -> {
                SoundUtil.playClick(player);
                this.saveKit(player);
            }));
        }
        if ((resetSec = ke.getConfigurationSection("editor.reset")) != null) {
            Material mat = Material.matchMaterial((String)resetSec.getString("material", "RED_CONCRETE"));
            String name = resetSec.getString("name", "&cReset to Base");
            int slot = resetSec.getInt("slot", 8);
            List<Component> lore = LoreUtil.read(resetSec, "lore");
            ItemBuilder b = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat != null ? mat : Material.RED_CONCRETE, resetSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
            if (!lore.isEmpty()) {
                b.lore(lore);
            }
            gui.setItem(slot, b.asGuiItem(e -> {
                boolean hasCursorItem;
                SoundUtil.playClick(player);
                ItemStack cursor = player.getItemOnCursor();
                boolean bl = hasCursorItem = cursor != null && cursor.getType() != Material.AIR;
                if (hasCursorItem) {
                    player.setItemOnCursor((ItemStack)null);
                }
                KitManager.resetPlayerKit(player.getUniqueId(), this.tier, this.gamemode);
                KitEditSession session = KitEditorGUI.getSession(player);
                if (session != null) {
                    ItemStack[] base = KitManager.getBaseKit(this.tier, this.gamemode);
                    for (int i = 0; i < 36; ++i) {
                        ItemStack item = i < base.length ? base[i] : null;
                        session.inventory.setItem(i + 9, item == null ? null : item.clone());
                    }
                    session.inventory.setItem(45, base.length > 40 && base[40] != null ? base[40].clone() : null);
                }
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("kit.reset").replace("%tier%", this.tier).replace("%gamemode%", GamemodeRegistry.getDisplayName(this.tier, this.gamemode))));
            }));
        }
        if ((backSec = ke.getConfigurationSection("editor.back")) != null) {
            Material mat = Material.matchMaterial((String)backSec.getString("material", "ORANGE_CANDLE"));
            String name = backSec.getString("name", "&#FB6000Go Back");
            int slot = backSec.getInt("slot", 0);
            List<Component> lore = LoreUtil.read(backSec, "lore");
            ItemBuilder b = (ItemBuilder)((ItemBuilder)HeadUtil.from(mat != null ? mat : Material.ORANGE_CANDLE, backSec).name(ColorUtil.parse(name))).flags(ItemFlag.values());
            if (!lore.isEmpty()) {
                b.lore(lore);
            }
            gui.setItem(slot, b.asGuiItem(e -> {
                SoundUtil.playClick(player);
                KitEditorGUI.onEditorClose(player);
                if (this.backRoom != null) {
                    this.backRoom.open(player);
                } else {
                    new DuelMenuGUI(DuelMenuGUI.sectionForTier(this.tier), null, DuelMenuGUI.Mode.KIT_EDITOR).open(player);
                }
            }));
        }
        ItemStack[] kit = KitManager.getPlayerKit(player.getUniqueId(), this.tier, this.gamemode);
        ItemStack[] baseKit = KitManager.getBaseKit(this.tier, this.gamemode);
        if (KitEditorGUI.isEmptyLayout(kit) && !KitEditorGUI.isEmptyLayout(baseKit)) {
            kit = baseKit;
        }
        Inventory inventory = gui.getInventory();
        for (int i = 0; i < 36; ++i) {
            ItemStack item;
            ItemStack itemStack = item = i < kit.length ? kit[i] : null;
            if (item == null || item.getType() == Material.AIR) continue;
            gui.setItem(i + 9, new GuiItem(item.clone()));
        }
        int[] armorSlots = new int[]{ke.getInt("editor.armor.boots-slot", 46), ke.getInt("editor.armor.leggings-slot", 47), ke.getInt("editor.armor.chestplate-slot", 48), ke.getInt("editor.armor.helmet-slot", 49)};
        for (int i = 0; i < armorSlots.length; ++i) {
            int kitIndex = 36 + i;
            ItemStack armor = kitIndex < baseKit.length ? baseKit[kitIndex] : null;
            ItemMeta meta = (armor = armor == null || armor.getType() == Material.AIR ? new ItemStack(Material.BARRIER) : armor.clone()).getItemMeta();
            if (meta != null) {
                meta.lore(List.of(ColorUtil.parse("&cEquipped armor cannot be changed here.")));
                armor.setItemMeta(meta);
            }
            gui.setItem(armorSlots[i], new GuiItem(armor));
        }
        int offhandSlot = ke.getInt("editor.armor.offhand-slot", 45);
        ItemStack itemStack = offhand = kit.length > 40 ? kit[40] : null;
        if (offhand != null && offhand.getType() != Material.AIR) {
            gui.setItem(offhandSlot, new GuiItem(offhand.clone()));
        }
        gui.open((HumanEntity)player);
        editingPlayers.put(player.getUniqueId(), new KitEditSession(this.tier, this.gamemode, this.kitSlot, this.backRoom, inventory));
    }

    private void saveKit(Player player) {
        if (player.getItemOnCursor() != null && player.getItemOnCursor().getType() != Material.AIR) {
            player.sendMessage(ColorUtil.parse("&cEmpty your cursor before saving."));
        } else {
            KitEditSession session = KitEditorGUI.getSession(player);
            if (session != null) {
                KitManager.savePlayerKit(player.getUniqueId(), this.tier, this.gamemode, KitEditorGUI.captureLayout(session.inventory, this.tier, this.gamemode));
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("kit.saved").replace("%tier%", this.tier).replace("%gamemode%", GamemodeRegistry.getDisplayName(this.tier, this.gamemode))));
        }
    }

    public static class KitEditSession {
        private final String tier;
        private final String gamemode;
        private final int kitSlot;
        private final KitRoomGUI backRoom;
        private final Inventory inventory;

        public KitEditSession(String tier, String gamemode, int kitSlot, KitRoomGUI backRoom, Inventory inventory) {
            this.tier = tier;
            this.gamemode = gamemode;
            this.kitSlot = kitSlot;
            this.backRoom = backRoom;
            this.inventory = inventory;
        }

        public String getTier() {
            return this.tier;
        }

        public String getGamemode() {
            return this.gamemode;
        }

        public int getKitSlot() {
            return this.kitSlot;
        }

        public KitRoomGUI getBackRoom() {
            return this.backRoom;
        }
    }
}

