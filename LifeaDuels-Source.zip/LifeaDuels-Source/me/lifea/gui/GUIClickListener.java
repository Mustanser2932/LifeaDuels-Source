/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryType
 */
package me.lifea.gui;

import me.lifea.match.MatchManager;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;

public class GUIClickListener
implements Listener {
    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryType type;
        Player player;
        HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof Player && MatchManager.inMatch((player = (Player)var3).getUniqueId()) && (type = event.getView().getTopInventory().getType()) != InventoryType.CRAFTING && type != InventoryType.SHULKER_BOX && type != InventoryType.HOPPER) {
            event.setCancelled(true);
        }
    }
}

