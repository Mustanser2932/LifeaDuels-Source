/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryOpenEvent
 */
package me.lifea.gui;

import me.lifea.libs.triumphgui.guis.BaseGui;
import me.lifea.util.SoundUtil;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;

public class GuiOpenSoundListener
implements Listener {
    @EventHandler
    public void onOpen(InventoryOpenEvent event) {
        HumanEntity var3;
        if (event.getInventory().getHolder() instanceof BaseGui && (var3 = event.getPlayer()) instanceof Player) {
            Player player = (Player)var3;
            SoundUtil.playOpen(player);
        }
    }
}

