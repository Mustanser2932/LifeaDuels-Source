/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package me.lifea.spectate;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.config.ConfigManager;
import me.lifea.config.PerformanceConfig;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.queue.QueueManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spectate.SpectateSession;
import me.lifea.util.ColorUtil;
import me.lifea.util.TabRole;
import me.lifea.visibility.MatchVisibilityManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class SpectateManager {
    private static final Map<UUID, SpectateSession> spectators = new ConcurrentHashMap<UUID, SpectateSession>();
    private static final Map<String, Set<UUID>> byArena = new ConcurrentHashMap<String, Set<UUID>>();
    private static final Map<UUID, Set<UUID>> byTarget = new ConcurrentHashMap<UUID, Set<UUID>>();
    private static BukkitTask failsafeMonitor = null;

    private SpectateManager() {
    }

    public static boolean isSpectating(UUID uuid) {
        return spectators.containsKey(uuid);
    }

    public static SpectateSession getSession(UUID uuid) {
        return spectators.get(uuid);
    }

    public static Set<UUID> getSpectatorsForArena(String arenaName) {
        return byArena.getOrDefault(arenaName, Collections.emptySet());
    }

    public static Set<UUID> getSpectatorsForTarget(UUID targetId) {
        return byTarget.getOrDefault(targetId, Collections.emptySet());
    }

    public static void startSpectating(Player spectator, Player target) {
        if (spectator.getUniqueId().equals(target.getUniqueId())) {
            spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.cannot-spectate-self")));
        } else if (MatchManager.inMatch(spectator.getUniqueId())) {
            spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.already-in-match")));
        } else {
            Match match = MatchManager.getMatch(target.getUniqueId());
            if (match != null && match.isActive()) {
                Arena arena = ArenaManager.get(match.getArenaName());
                if (arena == null) {
                    spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.arena-not-found")));
                } else {
                    SpectateSession existing = spectators.get(spectator.getUniqueId());
                    if (existing != null && existing.getTargetId().equals(target.getUniqueId())) {
                        spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.already-spectating")));
                    } else {
                        if (existing != null) {
                            SpectateManager.stopSpectating(spectator);
                        }
                        QueueManager.removePlayerFromQueues(spectator);
                        spectator.closeInventory();
                        spectator.setItemOnCursor((ItemStack)null);
                        Location prevLocation = spectator.getLocation().clone();
                        GameMode prevGameMode = spectator.getGameMode();
                        SpectateSession session = new SpectateSession(spectator.getUniqueId(), target.getUniqueId(), match.getArenaName(), prevLocation, prevGameMode);
                        spectators.put(spectator.getUniqueId(), session);
                        SpectateManager.indexSession(session);
                        try {
                            match.addSpectator(spectator.getUniqueId());
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                        MatchVisibilityManager.applyRole(spectator, match, TabRole.SPECTATOR);
                        spectator.getInventory().clear();
                        Location spectatorSpawn = SpectateManager.resolveSpectatorSpawn(arena);
                        if (spectatorSpawn == null) {
                            spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.unsafe-location")));
                            SpectateManager.deindexSession(spectator.getUniqueId());
                            spectators.remove(spectator.getUniqueId());
                        } else {
                            spectator.teleport(spectatorSpawn);
                            spectator.setGameMode(GameMode.SPECTATOR);
                            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                                if (SpectateManager.isSpectating(spectator.getUniqueId()) && !spectator.getGameMode().equals((Object)GameMode.SPECTATOR)) {
                                    spectator.setGameMode(GameMode.SPECTATOR);
                                }
                            }, 2L);
                            ScoreboardManager.updatePlayer(spectator);
                            spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.now-spectating").replace("%target%", target.getName())));
                            String spectateNotify = "&f\u2139 &#FB0000" + spectator.getName() + "&f is now spectating your match.";
                            Player p1 = Bukkit.getPlayer((UUID)match.getPlayer1());
                            Player p2 = Bukkit.getPlayer((UUID)match.getPlayer2());
                            if (p1 != null) {
                                p1.sendMessage(ColorUtil.parse(spectateNotify));
                            }
                            if (p2 != null) {
                                p2.sendMessage(ColorUtil.parse(spectateNotify));
                            }
                        }
                    }
                }
            } else {
                spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.target-not-in-match")));
            }
        }
    }

    public static void stopSpectating(Player spectator) {
        SpectateManager.stopSpectating(spectator, true);
    }

    public static void stopSpectating(Player spectator, boolean teleportToSpawn) {
        if (SpectateManager.isSpectating(spectator.getUniqueId())) {
            SpectateSession session = spectators.remove(spectator.getUniqueId());
            if (session != null) {
                SpectateManager.removeFromIndexes(session);
            }
            String targetName = "";
            try {
                if (session != null) {
                    Match m;
                    Player target = Bukkit.getPlayer((UUID)session.getTargetId());
                    if (target != null) {
                        targetName = target.getName();
                    }
                    if ((m = MatchManager.getMatch(session.getTargetId())) != null) {
                        m.removeSpectator(spectator.getUniqueId());
                    }
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            MatchVisibilityManager.reset(spectator);
            PlayerStateManager.resetToLobby(spectator, teleportToSpawn);
            spectator.sendMessage(ColorUtil.parse(ConfigManager.msg("spectate.stopped").replace("%target%", targetName)));
        }
    }

    public static void removeSpectatorsForArena(String arenaName) {
        Set toRemove = byArena.getOrDefault(arenaName, Collections.emptySet());
        for (UUID specId : Set.copyOf(toRemove)) {
            Player spec = Bukkit.getPlayer((UUID)specId);
            if (spec != null && spec.isOnline()) {
                SpectateManager.stopSpectating(spec);
                continue;
            }
            SpectateSession session = spectators.remove(specId);
            if (session == null) continue;
            SpectateManager.removeFromIndexes(session);
        }
    }

    public static void removeAllByTarget(UUID targetId) {
        Set toRemove = byTarget.getOrDefault(targetId, Collections.emptySet());
        for (UUID specId : Set.copyOf(toRemove)) {
            Player spec = Bukkit.getPlayer((UUID)specId);
            if (spec != null && spec.isOnline()) {
                SpectateManager.stopSpectating(spec);
                continue;
            }
            SpectateSession session = spectators.remove(specId);
            if (session == null) continue;
            SpectateManager.removeFromIndexes(session);
        }
    }

    public static Set<UUID> getActiveSpectators() {
        return Collections.unmodifiableSet(spectators.keySet());
    }

    public static void removeDisconnected(UUID uuid) {
        SpectateSession session = spectators.remove(uuid);
        if (session != null) {
            SpectateManager.removeFromIndexes(session);
        }
    }

    private static void removeFromIndexes(SpectateSession session) {
        Set<UUID> targetSet;
        Set<UUID> arenaSet = byArena.get(session.getArenaName());
        if (arenaSet != null) {
            arenaSet.remove(session.getSpectatorId());
            if (arenaSet.isEmpty()) {
                byArena.remove(session.getArenaName());
            }
        }
        if ((targetSet = byTarget.get(session.getTargetId())) != null) {
            targetSet.remove(session.getSpectatorId());
            if (targetSet.isEmpty()) {
                byTarget.remove(session.getTargetId());
            }
        }
    }

    public static void startFailsafeMonitor() {
        if (failsafeMonitor == null) {
            failsafeMonitor = Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), () -> {
                for (UUID specId : spectators.keySet()) {
                    Player spec = Bukkit.getPlayer((UUID)specId);
                    if (spec == null || !spec.isOnline() || spec.getGameMode().equals((Object)GameMode.SPECTATOR)) continue;
                    Logger var10000 = Lifea.getInstance().getLogger();
                    String var10001 = spec.getName();
                    var10000.warning("[SPECTATE MONITOR] Spectator " + var10001 + " reverted to " + String.valueOf(spec.getGameMode()) + " - restoring SPECTATOR");
                    spec.setGameMode(GameMode.SPECTATOR);
                }
            }, PerformanceConfig.getSpectateFailsafeInterval(), PerformanceConfig.getSpectateFailsafeInterval());
        }
    }

    public static void stopFailsafeMonitor() {
        if (failsafeMonitor != null) {
            failsafeMonitor.cancel();
            failsafeMonitor = null;
        }
    }

    private static void indexSession(SpectateSession session) {
        byArena.computeIfAbsent(session.getArenaName(), k -> ConcurrentHashMap.newKeySet()).add(session.getSpectatorId());
        byTarget.computeIfAbsent(session.getTargetId(), k -> ConcurrentHashMap.newKeySet()).add(session.getSpectatorId());
    }

    private static void deindexSession(UUID specId) {
        SpectateSession session = spectators.get(specId);
        if (session != null) {
            Set<UUID> targetSet;
            Set<UUID> arenaSet = byArena.get(session.getArenaName());
            if (arenaSet != null) {
                arenaSet.remove(specId);
                if (arenaSet.isEmpty()) {
                    byArena.remove(session.getArenaName());
                }
            }
            if ((targetSet = byTarget.get(session.getTargetId())) != null) {
                targetSet.remove(specId);
                if (targetSet.isEmpty()) {
                    byTarget.remove(session.getTargetId());
                }
            }
        }
    }

    private static Location resolveSpectatorSpawn(Arena arena) {
        World world;
        Location spawn;
        Location location = spawn = arena.getSpawn1() != null ? arena.getSpawn1() : arena.getSpawn2();
        if (spawn != null && arena.isInside(spawn)) {
            return spawn;
        }
        if (!arena.isRegionSet()) {
            return spawn;
        }
        World world2 = world = spawn != null ? spawn.getWorld() : null;
        if (world == null && arena.getWorld() != null) {
            world = Bukkit.getWorld((String)arena.getWorld());
        }
        if (world == null) {
            return spawn;
        }
        int minX = arena.getRegionMinX();
        int maxX = arena.getRegionMaxX();
        int minY = arena.getRegionMinY();
        int maxY = arena.getRegionMaxY();
        int minZ = arena.getRegionMinZ();
        int maxZ = arena.getRegionMaxZ();
        double x = (double)(minX + maxX) / 2.0 + 0.5;
        double y = minY < maxY ? (double)minY + 1.0 : (double)minY;
        double z = (double)(minZ + maxZ) / 2.0 + 0.5;
        return new Location(world, x, y, z, 0.0f, 0.0f);
    }
}

