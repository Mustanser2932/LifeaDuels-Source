/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package me.lifea.spectate;

import java.util.UUID;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.config.ConfigManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.spectate.SpectateSession;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class SpectateListener
implements Listener {
    private boolean tasksStarted = false;
    private BukkitTask actionBarTask;
    private BukkitTask teleportTask;

    public void startTasks() {
        if (!this.tasksStarted) {
            this.tasksStarted = true;
            this.actionBarTask = new BukkitRunnable(this){

                public void run() {
                    for (UUID specId : SpectateManager.getActiveSpectators()) {
                        Player spec = Bukkit.getPlayer((UUID)specId);
                        if (spec == null || !spec.isOnline()) continue;
                        spec.sendActionBar(ColorUtil.parse(ConfigManager.msg("spectate.leave-hint")));
                    }
                }
            }.runTaskTimer((Plugin)Lifea.getInstance(), 0L, 80L);
            this.teleportTask = new BukkitRunnable(){

                public void run() {
                    for (UUID specId : SpectateManager.getActiveSpectators()) {
                        Location spawn;
                        Arena arena;
                        SpectateSession session;
                        Player spec = Bukkit.getPlayer((UUID)specId);
                        if (spec == null || !spec.isOnline() || (session = SpectateManager.getSession(specId)) == null || (arena = ArenaManager.get(session.getArenaName())) == null || arena.isInside(spec.getLocation()) || (spawn = SpectateListener.this.resolveSpectatorSpawn(arena)) == null) continue;
                        spec.teleport(spawn);
                    }
                }
            }.runTaskTimer((Plugin)Lifea.getInstance(), 20L, 40L);
        }
    }

    public void stopTasks() {
        if (this.actionBarTask != null) {
            this.actionBarTask.cancel();
            this.actionBarTask = null;
        }
        if (this.teleportTask != null) {
            this.teleportTask.cancel();
            this.teleportTask = null;
        }
        this.tasksStarted = false;
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (SpectateManager.isSpectating(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        if (SpectateManager.isSpectating(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player && SpectateManager.isSpectating(event.getDamager().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onEntityPickupItem(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player && SpectateManager.isSpectating(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        if (SpectateManager.isSpectating(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player && SpectateManager.isSpectating(event.getWhoClicked().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player && SpectateManager.isSpectating(event.getWhoClicked().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
        if (SpectateManager.isSpectating(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onBlockBreak(BlockBreakEvent event) {
        if (SpectateManager.isSpectating(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (SpectateManager.isSpectating(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player && SpectateManager.isSpectating(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerMove(PlayerMoveEvent event) {
        Location spawn;
        Arena arena;
        SpectateSession session;
        Player player;
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to != null && (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()) && SpectateManager.isSpectating((player = event.getPlayer()).getUniqueId()) && (session = SpectateManager.getSession(player.getUniqueId())) != null && (arena = ArenaManager.get(session.getArenaName())) != null && !arena.isInside(to) && (spawn = this.resolveSpectatorSpawn(arena)) != null) {
            event.setTo(spawn);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Location spawn;
        Location to;
        Arena arena;
        SpectateSession session;
        Player player = event.getPlayer();
        if (SpectateManager.isSpectating(player.getUniqueId()) && (session = SpectateManager.getSession(player.getUniqueId())) != null && (arena = ArenaManager.get(session.getArenaName())) != null && ((to = event.getTo()) == null || !arena.isInside(to)) && (spawn = this.resolveSpectatorSpawn(arena)) != null) {
            event.setTo(spawn);
        }
    }

    private Location resolveSpectatorSpawn(Arena arena) {
        World world;
        Location spawn;
        Location location = spawn = arena.getSpawn1() != null ? arena.getSpawn1() : arena.getSpawn2();
        if (spawn != null && arena.isInside(spawn)) {
            return spawn;
        }
        if (!arena.isRegionSet()) {
            return spawn;
        }
        World world2 = world = spawn != null ? spawn.getWorld() : null;
        if (world == null && arena.getWorld() != null) {
            world = Bukkit.getWorld((String)arena.getWorld());
        }
        if (world == null) {
            return spawn;
        }
        int minX = arena.getRegionMinX();
        int maxX = arena.getRegionMaxX();
        int minY = arena.getRegionMinY();
        int maxY = arena.getRegionMaxY();
        int minZ = arena.getRegionMinZ();
        int maxZ = arena.getRegionMaxZ();
        double x = (double)(minX + maxX) / 2.0 + 0.5;
        double y = minY < maxY ? (double)minY + 1.0 : (double)minY;
        double z = (double)(minZ + maxZ) / 2.0 + 0.5;
        return new Location(world, x, y, z, 0.0f, 0.0f);
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (SpectateManager.isSpectating(player.getUniqueId())) {
            SpectateManager.removeDisconnected(player.getUniqueId());
        }
        SpectateManager.removeAllByTarget(player.getUniqueId());
    }
}

