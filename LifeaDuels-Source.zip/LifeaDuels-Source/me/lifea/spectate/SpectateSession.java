/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 */
package me.lifea.spectate;

import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;

public class SpectateSession {
    private final UUID spectatorId;
    private final UUID targetId;
    private final String arenaName;
    private final Location previousLocation;
    private final GameMode previousGameMode;

    public SpectateSession(UUID spectatorId, UUID targetId, String arenaName, Location previousLocation, GameMode previousGameMode) {
        this.spectatorId = spectatorId;
        this.targetId = targetId;
        this.arenaName = arenaName;
        this.previousLocation = previousLocation;
        this.previousGameMode = previousGameMode;
    }

    public UUID getSpectatorId() {
        return this.spectatorId;
    }

    public UUID getTargetId() {
        return this.targetId;
    }

    public String getArenaName() {
        return this.arenaName;
    }

    public Location getPreviousLocation() {
        return this.previousLocation;
    }

    public GameMode getPreviousGameMode() {
        return this.previousGameMode;
    }
}

