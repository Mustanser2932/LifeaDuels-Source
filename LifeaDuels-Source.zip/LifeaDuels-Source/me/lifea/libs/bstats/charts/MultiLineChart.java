/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.bstats.charts;

import java.util.Map;
import java.util.concurrent.Callable;
import me.lifea.libs.bstats.charts.CustomChart;
import me.lifea.libs.bstats.json.JsonObjectBuilder;

public class MultiLineChart
extends CustomChart {
    private final Callable<Map<String, Integer>> callable;

    public MultiLineChart(String chartId, Callable<Map<String, Integer>> callable) {
        super(chartId);
        this.callable = callable;
    }

    @Override
    protected JsonObjectBuilder.JsonObject getChartData() throws Exception {
        JsonObjectBuilder valuesBuilder = new JsonObjectBuilder();
        Map<String, Integer> map = this.callable.call();
        if (map != null && !map.isEmpty()) {
            boolean allSkipped = true;
            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                if (entry.getValue() == 0) continue;
                allSkipped = false;
                valuesBuilder.appendField(entry.getKey(), entry.getValue());
            }
            if (allSkipped) {
                return null;
            }
            return new JsonObjectBuilder().appendField("values", valuesBuilder.build()).build();
        }
        return null;
    }
}

