/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.bstats.charts;

import java.util.concurrent.Callable;
import me.lifea.libs.bstats.charts.CustomChart;
import me.lifea.libs.bstats.json.JsonObjectBuilder;

public class SingleLineChart
extends CustomChart {
    private final Callable<Integer> callable;

    public SingleLineChart(String chartId, Callable<Integer> callable) {
        super(chartId);
        this.callable = callable;
    }

    @Override
    protected JsonObjectBuilder.JsonObject getChartData() throws Exception {
        int value = this.callable.call();
        return value == 0 ? null : new JsonObjectBuilder().appendField("value", value).build();
    }
}

