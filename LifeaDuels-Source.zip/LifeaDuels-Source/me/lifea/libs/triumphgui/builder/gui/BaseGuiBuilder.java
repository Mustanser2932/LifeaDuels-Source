/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package me.lifea.libs.triumphgui.builder.gui;

import java.util.EnumSet;
import java.util.Set;
import java.util.function.Consumer;
import me.lifea.libs.triumphgui.components.InteractionModifier;
import me.lifea.libs.triumphgui.guis.BaseGui;
import net.kyori.adventure.text.Component;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class BaseGuiBuilder<G extends BaseGui, B extends BaseGuiBuilder<G, B>> {
    private Component title = null;
    private final EnumSet<InteractionModifier> interactionModifiers = EnumSet.noneOf(InteractionModifier.class);
    private Consumer<G> consumer;

    @Contract(value="_ -> this")
    @NotNull
    public B title(@NotNull Component title) {
        this.title = title;
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B disableItemPlace() {
        this.interactionModifiers.add(InteractionModifier.PREVENT_ITEM_PLACE);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B disableItemTake() {
        this.interactionModifiers.add(InteractionModifier.PREVENT_ITEM_TAKE);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B disableItemSwap() {
        this.interactionModifiers.add(InteractionModifier.PREVENT_ITEM_SWAP);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B disableItemDrop() {
        this.interactionModifiers.add(InteractionModifier.PREVENT_ITEM_DROP);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B disableOtherActions() {
        this.interactionModifiers.add(InteractionModifier.PREVENT_OTHER_ACTIONS);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B disableAllInteractions() {
        this.interactionModifiers.addAll(InteractionModifier.VALUES);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B enableItemPlace() {
        this.interactionModifiers.remove((Object)InteractionModifier.PREVENT_ITEM_PLACE);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B enableItemTake() {
        this.interactionModifiers.remove((Object)InteractionModifier.PREVENT_ITEM_TAKE);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B enableItemSwap() {
        this.interactionModifiers.remove((Object)InteractionModifier.PREVENT_ITEM_SWAP);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B enableItemDrop() {
        this.interactionModifiers.remove((Object)InteractionModifier.PREVENT_ITEM_DROP);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B enableOtherActions() {
        this.interactionModifiers.remove((Object)InteractionModifier.PREVENT_OTHER_ACTIONS);
        return (B)this;
    }

    @Contract(value=" -> this")
    @NotNull
    public B enableAllInteractions() {
        this.interactionModifiers.clear();
        return (B)this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public B apply(@NotNull Consumer<G> consumer) {
        this.consumer = consumer;
        return (B)this;
    }

    @Contract(value=" -> new")
    @NotNull
    public abstract G create();

    @NotNull
    protected Component getTitle() {
        return this.title;
    }

    @Nullable
    protected Consumer<G> getConsumer() {
        return this.consumer;
    }

    @NotNull
    protected Set<InteractionModifier> getModifiers() {
        return this.interactionModifiers;
    }

    protected void consumeBuilder(@NotNull BaseGuiBuilder<?, ?> builder) {
        this.title = builder.title;
        this.interactionModifiers.addAll(builder.interactionModifiers);
    }
}

