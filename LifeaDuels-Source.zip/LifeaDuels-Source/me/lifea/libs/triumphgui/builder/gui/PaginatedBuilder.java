/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.gui;

import java.util.function.Consumer;
import me.lifea.libs.triumphgui.builder.gui.BaseChestGuiBuilder;
import me.lifea.libs.triumphgui.guis.PaginatedGui;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class PaginatedBuilder
extends BaseChestGuiBuilder<PaginatedGui, PaginatedBuilder> {
    private int pageSize = 0;

    @Contract(value="_ -> this")
    @NotNull
    public PaginatedBuilder pageSize(int pageSize) {
        this.pageSize = pageSize;
        return this;
    }

    @Override
    @Contract(value=" -> new")
    @NotNull
    public PaginatedGui create() {
        PaginatedGui gui = new PaginatedGui(this.createContainer(), this.pageSize, this.getModifiers());
        Consumer consumer = this.getConsumer();
        if (consumer != null) {
            consumer.accept(gui);
        }
        return gui;
    }
}

