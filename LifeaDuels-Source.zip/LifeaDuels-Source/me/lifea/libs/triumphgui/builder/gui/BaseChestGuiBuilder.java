/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.inventory.InventoryHolder
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.gui;

import me.lifea.libs.triumphgui.builder.gui.BaseGuiBuilder;
import me.lifea.libs.triumphgui.components.GuiContainer;
import me.lifea.libs.triumphgui.components.InventoryProvider;
import me.lifea.libs.triumphgui.components.util.Legacy;
import me.lifea.libs.triumphgui.guis.BaseGui;
import org.bukkit.Bukkit;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public abstract class BaseChestGuiBuilder<G extends BaseGui, B extends BaseChestGuiBuilder<G, B>>
extends BaseGuiBuilder<G, B> {
    private int rows = 1;
    private InventoryProvider.Chest inventoryProvider = (title, owner, rows) -> Bukkit.createInventory((InventoryHolder)owner, (int)rows, (String)Legacy.SERIALIZER.serialize(title));

    @Contract(value="_ -> this")
    @NotNull
    public B rows(int rows) {
        this.rows = rows;
        return (B)this;
    }

    public B inventory(@NotNull InventoryProvider.Chest inventoryProvider) {
        this.inventoryProvider = inventoryProvider;
        return (B)this;
    }

    protected int getRows() {
        return this.rows;
    }

    protected @NotNull InventoryProvider.Chest getInventoryProvider() {
        return this.inventoryProvider;
    }

    protected @NotNull GuiContainer.Chest createContainer() {
        return new GuiContainer.Chest(this.getTitle(), this.inventoryProvider, this.getRows());
    }
}

