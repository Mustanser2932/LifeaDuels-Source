/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.inventory.InventoryHolder
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.gui;

import java.util.function.Consumer;
import me.lifea.libs.triumphgui.builder.gui.BaseGuiBuilder;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.components.GuiContainer;
import me.lifea.libs.triumphgui.components.GuiType;
import me.lifea.libs.triumphgui.components.InventoryProvider;
import me.lifea.libs.triumphgui.components.util.Legacy;
import me.lifea.libs.triumphgui.guis.Gui;
import org.bukkit.Bukkit;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class TypedGuiBuilder
extends BaseGuiBuilder<Gui, TypedGuiBuilder> {
    private GuiType guiType;
    private InventoryProvider.Typed inventoryProvider = (title, owner, type) -> Bukkit.createInventory((InventoryHolder)owner, (InventoryType)type, (String)Legacy.SERIALIZER.serialize(title));

    public TypedGuiBuilder(@NotNull GuiType guiType) {
        this.guiType = guiType;
    }

    public TypedGuiBuilder(@NotNull GuiType guiType, @NotNull ChestGuiBuilder builder) {
        this.guiType = guiType;
        this.consumeBuilder(builder);
    }

    @Contract(value="_ -> this")
    @NotNull
    public TypedGuiBuilder type(@NotNull GuiType guiType) {
        this.guiType = guiType;
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public TypedGuiBuilder inventory(@NotNull InventoryProvider.Typed inventoryProvider) {
        this.inventoryProvider = inventoryProvider;
        return this;
    }

    @Override
    @Contract(value=" -> new")
    @NotNull
    public Gui create() {
        Gui gui = new Gui(new GuiContainer.Typed(this.getTitle(), this.inventoryProvider, this.guiType), this.getModifiers());
        Consumer consumer = this.getConsumer();
        if (consumer != null) {
            consumer.accept(gui);
        }
        return gui;
    }
}

