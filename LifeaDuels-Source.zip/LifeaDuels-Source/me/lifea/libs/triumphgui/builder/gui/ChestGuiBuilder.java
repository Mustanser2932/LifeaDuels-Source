/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.gui;

import java.util.function.Consumer;
import me.lifea.libs.triumphgui.builder.gui.BaseChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.gui.TypedGuiBuilder;
import me.lifea.libs.triumphgui.components.GuiType;
import me.lifea.libs.triumphgui.guis.Gui;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class ChestGuiBuilder
extends BaseChestGuiBuilder<Gui, ChestGuiBuilder> {
    @Contract(value="_ -> new")
    @NotNull
    public TypedGuiBuilder type(@NotNull GuiType guiType) {
        return new TypedGuiBuilder(guiType, this);
    }

    @Override
    @Contract(value=" -> new")
    @NotNull
    public Gui create() {
        Gui gui = new Gui(this.createContainer(), this.getModifiers());
        Consumer consumer = this.getConsumer();
        if (consumer != null) {
            consumer.accept(gui);
        }
        return gui;
    }
}

