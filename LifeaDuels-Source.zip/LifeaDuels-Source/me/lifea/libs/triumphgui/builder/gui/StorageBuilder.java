/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.gui;

import java.util.function.Consumer;
import me.lifea.libs.triumphgui.builder.gui.BaseChestGuiBuilder;
import me.lifea.libs.triumphgui.guis.StorageGui;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class StorageBuilder
extends BaseChestGuiBuilder<StorageGui, StorageBuilder> {
    @Override
    @Contract(value=" -> new")
    @NotNull
    public StorageGui create() {
        StorageGui gui = new StorageGui(this.createContainer(), this.getModifiers());
        Consumer consumer = this.getConsumer();
        if (consumer != null) {
            consumer.accept(gui);
        }
        return gui;
    }
}

