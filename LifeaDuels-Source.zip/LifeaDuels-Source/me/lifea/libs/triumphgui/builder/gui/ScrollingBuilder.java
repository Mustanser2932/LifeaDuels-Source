/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.gui;

import java.util.function.Consumer;
import me.lifea.libs.triumphgui.builder.gui.BaseChestGuiBuilder;
import me.lifea.libs.triumphgui.components.ScrollType;
import me.lifea.libs.triumphgui.guis.ScrollingGui;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class ScrollingBuilder
extends BaseChestGuiBuilder<ScrollingGui, ScrollingBuilder> {
    private ScrollType scrollType;
    private int pageSize = 0;

    public ScrollingBuilder(@NotNull ScrollType scrollType) {
        this.scrollType = scrollType;
    }

    @Contract(value="_ -> this")
    @NotNull
    public ScrollingBuilder scrollType(@NotNull ScrollType scrollType) {
        this.scrollType = scrollType;
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public ScrollingBuilder pageSize(int pageSize) {
        this.pageSize = pageSize;
        return this;
    }

    @Override
    @Contract(value=" -> new")
    @NotNull
    public ScrollingGui create() {
        ScrollingGui gui = new ScrollingGui(this.createContainer(), this.pageSize, this.scrollType, this.getModifiers());
        Consumer consumer = this.getConsumer();
        if (consumer != null) {
            consumer.accept(gui);
        }
        return gui;
    }
}

