/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package me.lifea.libs.triumphgui.builder.item;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import me.lifea.libs.triumphgui.builder.item.NameLoreHandler;
import net.kyori.adventure.text.Component;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class BukkitNameLoreHandler
implements NameLoreHandler {
    private static final BukkitNameLoreHandler INSTANCE = new BukkitNameLoreHandler();

    @NotNull
    public static BukkitNameLoreHandler getInstance() {
        return INSTANCE;
    }

    @Override
    public void name(@NotNull ItemMeta itemMeta, @NotNull Component name) {
        itemMeta.displayName(name);
    }

    @Override
    public void lore(@NotNull ItemMeta itemMeta, @NotNull List<Component> lore) {
        itemMeta.lore(lore.stream().filter(Objects::nonNull).toList());
    }

    @Override
    public void lore(@NotNull ItemMeta itemMeta, @NotNull Consumer<List<@Nullable Component>> lore) {
        ArrayList components = new ArrayList(itemMeta.lore() != null ? itemMeta.lore() : List.of());
        lore.accept(components);
        itemMeta.lore(components);
    }
}

