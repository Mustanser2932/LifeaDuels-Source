/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.profile.PlayerProfile
 *  org.bukkit.profile.PlayerTextures
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.item;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;
import me.lifea.libs.triumphgui.builder.item.BaseItemBuilder;
import me.lifea.libs.triumphgui.builder.item.NameLoreHandler;
import me.lifea.libs.triumphgui.components.exception.GuiException;
import me.lifea.libs.triumphgui.components.util.SkullUtil;
import me.lifea.libs.triumphgui.components.util.VersionHelper;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class SkullBuilder
extends BaseItemBuilder<SkullBuilder> {
    private static final Field PROFILE_FIELD;

    SkullBuilder(@NotNull NameLoreHandler nameLoreHandler) {
        super(SkullUtil.skull(), nameLoreHandler);
    }

    SkullBuilder(@NotNull ItemStack itemStack, @NotNull NameLoreHandler nameLoreHandler) {
        super(itemStack, nameLoreHandler);
        if (!SkullUtil.isPlayerSkull(itemStack)) {
            throw new GuiException("SkullBuilder requires the material to be a PLAYER_HEAD/SKULL_ITEM!");
        }
    }

    @Contract(value="_, _ -> this")
    @NotNull
    public SkullBuilder texture(@NotNull String texture, @NotNull UUID profileId) {
        if (!SkullUtil.isPlayerSkull(this.getItemStack())) {
            return this;
        }
        if (VersionHelper.IS_PLAYER_PROFILE_API) {
            String textureUrl = SkullUtil.getSkinUrl(texture);
            if (textureUrl == null) {
                return this;
            }
            SkullMeta skullMeta = (SkullMeta)this.getMeta();
            PlayerProfile profile = Bukkit.createPlayerProfile((UUID)profileId, (String)"");
            PlayerTextures textures = profile.getTextures();
            try {
                textures.setSkin(new URL(textureUrl));
            }
            catch (MalformedURLException exception) {
                throw new GuiException("Failed to set texture url!", exception);
            }
            profile.setTextures(textures);
            skullMeta.setOwnerProfile(profile);
            this.setMeta((ItemMeta)skullMeta);
            return this;
        }
        if (PROFILE_FIELD == null) {
            return this;
        }
        SkullMeta skullMeta = (SkullMeta)this.getMeta();
        GameProfile profile = new GameProfile(profileId, "");
        profile.getProperties().put((Object)"textures", (Object)new Property("textures", texture));
        try {
            PROFILE_FIELD.set(skullMeta, profile);
        }
        catch (IllegalAccessException | IllegalArgumentException exception) {
            throw new GuiException("Failed to set profile field!", exception);
        }
        this.setMeta((ItemMeta)skullMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public SkullBuilder texture(@NotNull String texture) {
        return this.texture(texture, UUID.randomUUID());
    }

    @Contract(value="_ -> this")
    @NotNull
    public SkullBuilder owner(@NotNull OfflinePlayer player) {
        if (!SkullUtil.isPlayerSkull(this.getItemStack())) {
            return this;
        }
        SkullMeta skullMeta = (SkullMeta)this.getMeta();
        if (VersionHelper.IS_SKULL_OWNER_LEGACY) {
            skullMeta.setOwner(player.getName());
        } else {
            skullMeta.setOwningPlayer(player);
        }
        this.setMeta((ItemMeta)skullMeta);
        return this;
    }

    static {
        Field field;
        try {
            SkullMeta skullMeta = (SkullMeta)SkullUtil.skull().getItemMeta();
            field = skullMeta.getClass().getDeclaredField("profile");
            field.setAccessible(true);
        }
        catch (NoSuchFieldException exception) {
            throw new GuiException("Failed to find profile field in SkullMeta!", exception);
        }
        PROFILE_FIELD = field;
    }
}

