/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.item;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.lang.reflect.Field;
import java.util.UUID;
import me.lifea.libs.triumphgui.builder.item.BannerBuilder;
import me.lifea.libs.triumphgui.builder.item.BaseItemBuilder;
import me.lifea.libs.triumphgui.builder.item.BookBuilder;
import me.lifea.libs.triumphgui.builder.item.BukkitNameLoreHandler;
import me.lifea.libs.triumphgui.builder.item.FireworkBuilder;
import me.lifea.libs.triumphgui.builder.item.MapBuilder;
import me.lifea.libs.triumphgui.builder.item.SkullBuilder;
import me.lifea.libs.triumphgui.components.exception.GuiException;
import me.lifea.libs.triumphgui.components.util.SkullUtil;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class ItemBuilder
extends BaseItemBuilder<ItemBuilder> {
    ItemBuilder(@NotNull ItemStack itemStack) {
        super(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static ItemBuilder from(@NotNull ItemStack itemStack) {
        return new ItemBuilder(itemStack);
    }

    @Contract(value="_ -> new")
    @NotNull
    public static ItemBuilder from(@NotNull Material material) {
        return new ItemBuilder(new ItemStack(material));
    }

    @Contract(value=" -> new")
    @NotNull
    public static BannerBuilder banner() {
        return new BannerBuilder(BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static BannerBuilder banner(@NotNull ItemStack itemStack) {
        return new BannerBuilder(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static BookBuilder book(@NotNull ItemStack itemStack) {
        return new BookBuilder(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Contract(value=" -> new")
    @NotNull
    public static FireworkBuilder firework() {
        return new FireworkBuilder(new ItemStack(Material.FIREWORK_ROCKET), BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static FireworkBuilder firework(@NotNull ItemStack itemStack) {
        return new FireworkBuilder(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Contract(value=" -> new")
    @NotNull
    public static MapBuilder map() {
        return new MapBuilder(BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static MapBuilder map(@NotNull ItemStack itemStack) {
        return new MapBuilder(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Contract(value=" -> new")
    @NotNull
    public static SkullBuilder skull() {
        return new SkullBuilder(BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static SkullBuilder skull(@NotNull ItemStack itemStack) {
        return new SkullBuilder(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Contract(value=" -> new")
    @NotNull
    public static FireworkBuilder star() {
        return new FireworkBuilder(new ItemStack(Material.FIREWORK_STAR), BukkitNameLoreHandler.getInstance());
    }

    @Contract(value="_ -> new")
    @NotNull
    public static FireworkBuilder star(@NotNull ItemStack itemStack) {
        return new FireworkBuilder(itemStack, BukkitNameLoreHandler.getInstance());
    }

    @Deprecated
    public ItemBuilder setSkullTexture(@NotNull String texture) {
        if (!SkullUtil.isPlayerSkull(this.getItemStack())) {
            return this;
        }
        SkullMeta skullMeta = (SkullMeta)this.getMeta();
        GameProfile profile = new GameProfile(UUID.randomUUID(), (String)null);
        profile.getProperties().put((Object)"textures", (Object)new Property("textures", texture));
        try {
            Field profileField = skullMeta.getClass().getDeclaredField("profile");
            profileField.setAccessible(true);
            profileField.set(skullMeta, profile);
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException exception) {
            throw new GuiException("Failed to set profile field!", exception);
        }
        this.setMeta((ItemMeta)skullMeta);
        return this;
    }

    @Deprecated
    public ItemBuilder setSkullOwner(@NotNull OfflinePlayer player) {
        if (!SkullUtil.isPlayerSkull(this.getItemStack())) {
            return this;
        }
        SkullMeta skullMeta = (SkullMeta)this.getMeta();
        skullMeta.setOwningPlayer(player);
        this.setMeta((ItemMeta)skullMeta);
        return this;
    }
}

