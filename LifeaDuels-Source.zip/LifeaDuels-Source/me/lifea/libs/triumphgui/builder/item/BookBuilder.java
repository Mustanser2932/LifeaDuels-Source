/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.BookMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package me.lifea.libs.triumphgui.builder.item;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import me.lifea.libs.triumphgui.builder.item.BaseItemBuilder;
import me.lifea.libs.triumphgui.builder.item.NameLoreHandler;
import me.lifea.libs.triumphgui.components.exception.GuiException;
import me.lifea.libs.triumphgui.components.util.Legacy;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BookBuilder
extends BaseItemBuilder<BookBuilder> {
    private static final EnumSet<Material> BOOKS = EnumSet.of(Material.WRITABLE_BOOK, Material.WRITTEN_BOOK);

    BookBuilder(@NotNull ItemStack itemStack, @NotNull NameLoreHandler nameLoreHandler) {
        super(itemStack, nameLoreHandler);
        if (!BOOKS.contains(itemStack.getType())) {
            throw new GuiException("BookBuilder requires the material to be a WRITABLE_BOOK/WRITTEN_BOOK!");
        }
    }

    @Contract(value="_ -> this")
    @NotNull
    public BookBuilder author(@Nullable Component author) {
        BookMeta bookMeta = (BookMeta)this.getMeta();
        if (author == null) {
            bookMeta.setAuthor((String)null);
            this.setMeta((ItemMeta)bookMeta);
            return this;
        }
        bookMeta.setAuthor(Legacy.SERIALIZER.serialize(author));
        this.setMeta((ItemMeta)bookMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public BookBuilder generation(// Could not load outer class - annotation placement on inner may be incorrect
    @Nullable BookMeta.Generation generation) {
        BookMeta bookMeta = (BookMeta)this.getMeta();
        bookMeta.setGeneration(generation);
        this.setMeta((ItemMeta)bookMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public BookBuilder page(Component ... pages) {
        return this.page(Arrays.asList(pages));
    }

    @Contract(value="_ -> this")
    @NotNull
    public BookBuilder page(@NotNull List<Component> pages) {
        BookMeta bookMeta = (BookMeta)this.getMeta();
        for (Component page : pages) {
            bookMeta.addPage(new String[]{Legacy.SERIALIZER.serialize(page)});
        }
        this.setMeta((ItemMeta)bookMeta);
        return this;
    }

    @Contract(value="_, _ -> this")
    @NotNull
    public BookBuilder page(int page, @NotNull Component data) {
        BookMeta bookMeta = (BookMeta)this.getMeta();
        bookMeta.setPage(page, Legacy.SERIALIZER.serialize(data));
        this.setMeta((ItemMeta)bookMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public BookBuilder title(@Nullable Component title) {
        BookMeta bookMeta = (BookMeta)this.getMeta();
        if (title == null) {
            bookMeta.setTitle((String)null);
            this.setMeta((ItemMeta)bookMeta);
            return this;
        }
        bookMeta.setTitle(Legacy.SERIALIZER.serialize(title));
        this.setMeta((ItemMeta)bookMeta);
        return this;
    }
}

