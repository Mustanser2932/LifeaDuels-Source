/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.DyeColor
 *  org.bukkit.Material
 *  org.bukkit.Tag
 *  org.bukkit.block.banner.Pattern
 *  org.bukkit.block.banner.PatternType
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.BannerMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.item;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import me.lifea.libs.triumphgui.builder.item.BaseItemBuilder;
import me.lifea.libs.triumphgui.builder.item.NameLoreHandler;
import me.lifea.libs.triumphgui.components.exception.GuiException;
import me.lifea.libs.triumphgui.components.util.VersionHelper;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public final class BannerBuilder
extends BaseItemBuilder<BannerBuilder> {
    private static final Material DEFAULT_BANNER;
    private static final EnumSet<Material> BANNERS;
    private static final Map<DyeColor, Material> BASE_COLORS;

    BannerBuilder(@NotNull NameLoreHandler nameLoreHandler) {
        super(new ItemStack(DEFAULT_BANNER), nameLoreHandler);
    }

    BannerBuilder(@NotNull ItemStack itemStack, @NotNull NameLoreHandler nameLoreHandler) {
        super(itemStack, nameLoreHandler);
        if (!BANNERS.contains(itemStack.getType())) {
            throw new GuiException("BannerBuilder requires the material to be a banner!");
        }
    }

    @Contract(value="_ -> this")
    @NotNull
    public BannerBuilder baseColor(@NotNull DyeColor color) {
        Material banner = BASE_COLORS.get(color);
        if (banner != null) {
            this.getItemStack().setType(banner);
        }
        return this;
    }

    @Contract(value="_, _ -> this")
    @NotNull
    public BannerBuilder pattern(@NotNull DyeColor color, @NotNull PatternType pattern) {
        BannerMeta bannerMeta = (BannerMeta)this.getMeta();
        bannerMeta.addPattern(new Pattern(color, pattern));
        this.setMeta((ItemMeta)bannerMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public BannerBuilder pattern(Pattern ... pattern) {
        return this.pattern(Arrays.asList(pattern));
    }

    @Contract(value="_ -> this")
    @NotNull
    public BannerBuilder pattern(@NotNull List<Pattern> patterns) {
        BannerMeta bannerMeta = (BannerMeta)this.getMeta();
        for (Pattern it : patterns) {
            bannerMeta.addPattern(it);
        }
        this.setMeta((ItemMeta)bannerMeta);
        return this;
    }

    @Contract(value="_, _, _ -> this")
    @NotNull
    public BannerBuilder pattern(int index, @NotNull DyeColor color, @NotNull PatternType pattern) {
        return this.pattern(index, new Pattern(color, pattern));
    }

    @Contract(value="_, _ -> this")
    @NotNull
    public BannerBuilder pattern(int index, @NotNull Pattern pattern) {
        BannerMeta bannerMeta = (BannerMeta)this.getMeta();
        bannerMeta.setPattern(index, pattern);
        this.setMeta((ItemMeta)bannerMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public BannerBuilder setPatterns(@NotNull @NotNull List<@NotNull Pattern> patterns) {
        BannerMeta bannerMeta = (BannerMeta)this.getMeta();
        bannerMeta.setPatterns(patterns);
        this.setMeta((ItemMeta)bannerMeta);
        return this;
    }

    static {
        BASE_COLORS = new EnumMap<DyeColor, Material>(DyeColor.class);
        BASE_COLORS.put(DyeColor.WHITE, Material.WHITE_BANNER);
        BASE_COLORS.put(DyeColor.ORANGE, Material.ORANGE_BANNER);
        BASE_COLORS.put(DyeColor.MAGENTA, Material.MAGENTA_BANNER);
        BASE_COLORS.put(DyeColor.LIGHT_BLUE, Material.LIGHT_BLUE_BANNER);
        BASE_COLORS.put(DyeColor.YELLOW, Material.YELLOW_BANNER);
        BASE_COLORS.put(DyeColor.LIME, Material.LIME_BANNER);
        BASE_COLORS.put(DyeColor.PINK, Material.PINK_BANNER);
        BASE_COLORS.put(DyeColor.GRAY, Material.GRAY_BANNER);
        BASE_COLORS.put(DyeColor.LIGHT_GRAY, Material.LIGHT_GRAY_BANNER);
        BASE_COLORS.put(DyeColor.CYAN, Material.CYAN_BANNER);
        BASE_COLORS.put(DyeColor.PURPLE, Material.PURPLE_BANNER);
        BASE_COLORS.put(DyeColor.BLUE, Material.BLUE_BANNER);
        BASE_COLORS.put(DyeColor.BROWN, Material.BROWN_BANNER);
        BASE_COLORS.put(DyeColor.GREEN, Material.GREEN_BANNER);
        BASE_COLORS.put(DyeColor.RED, Material.RED_BANNER);
        BASE_COLORS.put(DyeColor.BLACK, Material.BLACK_BANNER);
        if (VersionHelper.IS_ITEM_LEGACY) {
            DEFAULT_BANNER = Material.valueOf((String)"BANNER");
            BANNERS = EnumSet.of(Material.valueOf((String)"BANNER"));
        } else {
            DEFAULT_BANNER = Material.WHITE_BANNER;
            BANNERS = EnumSet.copyOf(Tag.BANNERS.getValues());
        }
    }
}

