/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package me.lifea.libs.triumphgui.builder.item;

import java.util.List;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface NameLoreHandler {
    public void name(@NotNull ItemMeta var1, @NotNull Component var2);

    public void lore(@NotNull ItemMeta var1, @NotNull List<Component> var2);

    public void lore(@NotNull ItemMeta var1, @NotNull Consumer<List<@Nullable Component>> var2);
}

