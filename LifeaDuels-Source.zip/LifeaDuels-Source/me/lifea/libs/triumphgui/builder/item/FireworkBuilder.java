/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.FireworkEffect
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.FireworkEffectMeta
 *  org.bukkit.inventory.meta.FireworkMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.builder.item;

import java.util.Arrays;
import java.util.List;
import me.lifea.libs.triumphgui.builder.item.BaseItemBuilder;
import me.lifea.libs.triumphgui.builder.item.NameLoreHandler;
import me.lifea.libs.triumphgui.components.exception.GuiException;
import org.bukkit.FireworkEffect;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkEffectMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class FireworkBuilder
extends BaseItemBuilder<FireworkBuilder> {
    private static final Material STAR = Material.FIREWORK_STAR;
    private static final Material ROCKET = Material.FIREWORK_ROCKET;

    FireworkBuilder(@NotNull ItemStack itemStack, @NotNull NameLoreHandler nameLoreHandler) {
        super(itemStack, nameLoreHandler);
        if (itemStack.getType() != STAR && itemStack.getType() != ROCKET) {
            throw new GuiException("FireworkBuilder requires the material to be a FIREWORK_STAR/FIREWORK_ROCKET!");
        }
    }

    @Contract(value="_ -> this")
    @NotNull
    public FireworkBuilder effect(FireworkEffect ... effects) {
        return this.effect(Arrays.asList(effects));
    }

    @Contract(value="_ -> this")
    @NotNull
    public FireworkBuilder effect(@NotNull List<FireworkEffect> effects) {
        if (effects.isEmpty()) {
            return this;
        }
        if (this.getItemStack().getType() == STAR) {
            FireworkEffectMeta effectMeta = (FireworkEffectMeta)this.getMeta();
            effectMeta.setEffect(effects.get(0));
            this.setMeta((ItemMeta)effectMeta);
            return this;
        }
        FireworkMeta fireworkMeta = (FireworkMeta)this.getMeta();
        fireworkMeta.addEffects(effects);
        this.setMeta((ItemMeta)fireworkMeta);
        return this;
    }

    @Contract(value="_ -> this")
    @NotNull
    public FireworkBuilder power(int power) {
        if (this.getItemStack().getType() == ROCKET) {
            FireworkMeta fireworkMeta = (FireworkMeta)this.getMeta();
            fireworkMeta.setPower(power);
            this.setMeta((ItemMeta)fireworkMeta);
        }
        return this;
    }
}

