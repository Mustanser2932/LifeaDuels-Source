/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Preconditions
 *  org.bukkit.Material
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemStack
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package me.lifea.libs.triumphgui.guis;

import com.google.common.base.Preconditions;
import java.util.UUID;
import me.lifea.libs.triumphgui.components.GuiAction;
import me.lifea.libs.triumphgui.components.util.ItemNbt;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class GuiItem {
    private final UUID uuid = UUID.randomUUID();
    private GuiAction<InventoryClickEvent> action;
    private ItemStack itemStack;

    public GuiItem(@NotNull ItemStack itemStack, @Nullable GuiAction<@NotNull InventoryClickEvent> action) {
        Preconditions.checkNotNull((Object)itemStack, (Object)"The ItemStack for the GUI Item cannot be null!");
        this.action = action;
        this.setItemStack(itemStack);
    }

    public GuiItem(@NotNull ItemStack itemStack) {
        this(itemStack, (GuiAction<InventoryClickEvent>)null);
    }

    public GuiItem(@NotNull Material material) {
        this(new ItemStack(material), (GuiAction<InventoryClickEvent>)null);
    }

    public GuiItem(@NotNull Material material, @Nullable GuiAction<@NotNull InventoryClickEvent> action) {
        this(new ItemStack(material), action);
    }

    @NotNull
    public ItemStack getItemStack() {
        return this.itemStack;
    }

    public void setItemStack(@NotNull ItemStack itemStack) {
        Preconditions.checkNotNull((Object)itemStack, (Object)"The ItemStack for the GUI Item cannot be null!");
        this.itemStack = itemStack.getType() != Material.AIR ? ItemNbt.setString(itemStack.clone(), "mf-gui", this.uuid.toString()) : itemStack.clone();
    }

    @Nullable
    public GuiAction<InventoryClickEvent> getAction() {
        return this.action;
    }

    public void setAction(@Nullable GuiAction<@NotNull InventoryClickEvent> action) {
        this.action = action;
    }

    @NotNull
    UUID getUuid() {
        return this.uuid;
    }
}

