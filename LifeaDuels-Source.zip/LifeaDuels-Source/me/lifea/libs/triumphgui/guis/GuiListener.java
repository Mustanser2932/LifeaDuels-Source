/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.libs.triumphgui.guis;

import java.util.logging.Level;
import me.lifea.Lifea;
import me.lifea.libs.triumphgui.components.GuiAction;
import me.lifea.libs.triumphgui.components.util.ItemNbt;
import me.lifea.libs.triumphgui.guis.BaseGui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.libs.triumphgui.guis.PaginatedGui;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class GuiListener
implements Listener {
    @EventHandler
    public void onGuiClick(InventoryClickEvent event) {
        Inventory inventory = event.getInventory();
        InventoryHolder var4 = inventory.getHolder();
        if (var4 instanceof BaseGui) {
            BaseGui gui = (BaseGui)var4;
            GuiAction<InventoryClickEvent> outsideAction = gui.getOutsideClickAction();
            if (outsideAction != null && event.getClickedInventory() == null) {
                GuiListener.defer(event, outsideAction);
            } else if (event.getClickedInventory() != null) {
                GuiAction<InventoryClickEvent> itemAction;
                GuiItem guiItem;
                GuiAction<InventoryClickEvent> slotAction;
                GuiAction<InventoryClickEvent> defaultAction;
                GuiAction<InventoryClickEvent> playerInvAction;
                GuiAction<InventoryClickEvent> defaultTopAction = gui.getDefaultTopClickAction();
                if (defaultTopAction != null && event.getClickedInventory().getType() != InventoryType.PLAYER) {
                    GuiListener.defer(event, defaultTopAction);
                }
                if ((playerInvAction = gui.getPlayerInventoryAction()) != null && event.getClickedInventory().getType() == InventoryType.PLAYER) {
                    GuiListener.defer(event, playerInvAction);
                }
                if ((defaultAction = gui.getDefaultClickAction()) != null) {
                    GuiListener.defer(event, defaultAction);
                }
                if ((slotAction = gui.getSlotAction(event.getSlot())) != null && event.getClickedInventory().getType() != InventoryType.PLAYER) {
                    GuiListener.defer(event, slotAction);
                }
                if (gui instanceof PaginatedGui) {
                    PaginatedGui paginatedGui = (PaginatedGui)gui;
                    guiItem = paginatedGui.getGuiItem(event.getSlot());
                    if (guiItem == null) {
                        guiItem = paginatedGui.getPageItem(event.getSlot());
                    }
                } else {
                    guiItem = gui.getGuiItem(event.getSlot());
                }
                if (GuiListener.isGuiItem(event.getCurrentItem(), guiItem) && (itemAction = guiItem.getAction()) != null) {
                    GuiListener.defer(event, itemAction);
                }
            }
        }
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent event) {
        GuiAction<InventoryDragEvent> dragAction;
        if (event.getInventory().getHolder() instanceof BaseGui && (dragAction = ((BaseGui)event.getInventory().getHolder()).getDragAction()) != null) {
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                try {
                    dragAction.execute(event);
                }
                catch (Exception e) {
                    Lifea.getInstance().getLogger().log(Level.SEVERE, "Deferred GUI drag action failed", e);
                }
            });
        }
    }

    @EventHandler
    public void onGuiClose(InventoryCloseEvent event) {
        BaseGui gui;
        GuiAction<InventoryCloseEvent> closeAction;
        InventoryHolder var3 = event.getInventory().getHolder();
        if (var3 instanceof BaseGui && (closeAction = (gui = (BaseGui)var3).getCloseGuiAction()) != null && !gui.isUpdating() && gui.shouldRunCloseAction()) {
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                try {
                    closeAction.execute(event);
                }
                catch (Exception e) {
                    Lifea.getInstance().getLogger().log(Level.SEVERE, "Deferred GUI close action failed", e);
                }
            });
        }
    }

    @EventHandler
    public void onGuiOpen(InventoryOpenEvent event) {
        BaseGui gui;
        GuiAction<InventoryOpenEvent> openAction;
        InventoryHolder var3 = event.getInventory().getHolder();
        if (var3 instanceof BaseGui && (openAction = (gui = (BaseGui)var3).getOpenGuiAction()) != null && !gui.isUpdating()) {
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                try {
                    openAction.execute(event);
                }
                catch (Exception e) {
                    Lifea.getInstance().getLogger().log(Level.SEVERE, "Deferred GUI open action failed", e);
                }
            });
        }
    }

    private static void defer(InventoryClickEvent event, GuiAction<InventoryClickEvent> action) {
        Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
            try {
                action.execute(event);
            }
            catch (Exception e) {
                Lifea.getInstance().getLogger().log(Level.SEVERE, "Deferred GUI click action failed", e);
            }
        });
    }

    private static boolean isGuiItem(ItemStack itemStack, GuiItem guiItem) {
        if (itemStack != null && guiItem != null) {
            String nbtValue = ItemNbt.getString(itemStack, "mf-gui");
            return nbtValue == null ? false : nbtValue.equals(guiItem.getUuid().toString());
        }
        return false;
    }
}

