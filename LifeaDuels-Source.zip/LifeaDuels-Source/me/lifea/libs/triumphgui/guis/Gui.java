/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.guis;

import java.util.Set;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.gui.PaginatedBuilder;
import me.lifea.libs.triumphgui.builder.gui.ScrollingBuilder;
import me.lifea.libs.triumphgui.builder.gui.StorageBuilder;
import me.lifea.libs.triumphgui.builder.gui.TypedGuiBuilder;
import me.lifea.libs.triumphgui.components.GuiContainer;
import me.lifea.libs.triumphgui.components.GuiType;
import me.lifea.libs.triumphgui.components.InteractionModifier;
import me.lifea.libs.triumphgui.components.ScrollType;
import me.lifea.libs.triumphgui.guis.BaseGui;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class Gui
extends BaseGui {
    public Gui(@NotNull GuiContainer guiContainer, @NotNull Set<InteractionModifier> interactionModifiers) {
        super(guiContainer, interactionModifiers);
    }

    @Contract(value="_ -> new")
    @NotNull
    public static TypedGuiBuilder gui(@NotNull GuiType type) {
        return new TypedGuiBuilder(type);
    }

    @Contract(value=" -> new")
    @NotNull
    public static ChestGuiBuilder gui() {
        return new ChestGuiBuilder();
    }

    @Contract(value=" -> new")
    @NotNull
    public static StorageBuilder storage() {
        return new StorageBuilder();
    }

    @Contract(value=" -> new")
    @NotNull
    public static PaginatedBuilder paginated() {
        return new PaginatedBuilder();
    }

    @Contract(value="_ -> new")
    @NotNull
    public static ScrollingBuilder scrolling(@NotNull ScrollType scrollType) {
        return new ScrollingBuilder(scrollType);
    }

    @Contract(value=" -> new")
    @NotNull
    public static ScrollingBuilder scrolling() {
        return Gui.scrolling(ScrollType.VERTICAL);
    }
}

