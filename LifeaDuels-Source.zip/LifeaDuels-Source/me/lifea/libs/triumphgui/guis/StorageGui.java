/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.guis;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import me.lifea.libs.triumphgui.components.GuiContainer;
import me.lifea.libs.triumphgui.components.InteractionModifier;
import me.lifea.libs.triumphgui.guis.BaseGui;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class StorageGui
extends BaseGui {
    public StorageGui(@NotNull GuiContainer guiContainer, @NotNull Set<InteractionModifier> interactionModifiers) {
        super(guiContainer, interactionModifiers);
    }

    @NotNull
    public @NotNull Map<@NotNull Integer, @NotNull ItemStack> addItem(ItemStack ... items) {
        return Collections.unmodifiableMap(this.getInventory().addItem(items));
    }

    public Map<@NotNull Integer, @NotNull ItemStack> addItem(@NotNull List<ItemStack> items) {
        return this.addItem(items.toArray(new ItemStack[0]));
    }

    @Override
    public void open(@NotNull HumanEntity player) {
        if (!player.isSleeping()) {
            this.populateGui();
            player.openInventory(this.getInventory());
        }
    }

    @Override
    protected void updateInventory(@NotNull Inventory inventory) {
        ItemStack[] contents = this.getInventory().getContents();
        super.updateInventory(inventory);
        this.getInventory().setContents(contents);
    }
}

