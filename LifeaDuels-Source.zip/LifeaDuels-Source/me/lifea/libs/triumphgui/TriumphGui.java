/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui;

import me.lifea.libs.triumphgui.guis.BaseGui;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

public final class TriumphGui {
    private static Plugin PLUGIN = null;

    private TriumphGui() {
    }

    public static void init(@NotNull Plugin plugin) {
        PLUGIN = plugin;
    }

    @NotNull
    public static Plugin getPlugin() {
        if (PLUGIN == null) {
            TriumphGui.init((Plugin)JavaPlugin.getProvidingPlugin(BaseGui.class));
        }
        return PLUGIN;
    }
}

