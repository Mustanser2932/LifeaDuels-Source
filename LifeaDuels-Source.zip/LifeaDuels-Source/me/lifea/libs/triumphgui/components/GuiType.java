/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.inventory.InventoryType
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.components;

import org.bukkit.event.inventory.InventoryType;
import org.jetbrains.annotations.NotNull;

public final class GuiType
extends Enum<GuiType> {
    public static final /* enum */ GuiType CHEST = new GuiType(InventoryType.CHEST, 9, 9);
    public static final /* enum */ GuiType WORKBENCH = new GuiType(InventoryType.WORKBENCH, 9, 10);
    public static final /* enum */ GuiType HOPPER = new GuiType(InventoryType.HOPPER, 5, 5);
    public static final /* enum */ GuiType DISPENSER = new GuiType(InventoryType.DISPENSER, 8, 9);
    public static final /* enum */ GuiType BREWING = new GuiType(InventoryType.BREWING, 4, 5);
    @NotNull
    private final InventoryType inventoryType;
    private final int limit;
    private final int fillSize;
    private static final /* synthetic */ GuiType[] $VALUES;

    public static GuiType[] values() {
        return (GuiType[])$VALUES.clone();
    }

    public static GuiType valueOf(String name) {
        return Enum.valueOf(GuiType.class, name);
    }

    private GuiType(InventoryType inventoryType, int limit, int fillSize) {
        this.inventoryType = inventoryType;
        this.limit = limit;
        this.fillSize = fillSize;
    }

    @NotNull
    public InventoryType getInventoryType() {
        return this.inventoryType;
    }

    public int getLimit() {
        return this.limit;
    }

    public int getFillSize() {
        return this.fillSize;
    }

    private static GuiType[] $values() {
        return new GuiType[]{CHEST, WORKBENCH, HOPPER, DISPENSER, BREWING};
    }

    private static GuiType[] $values$() {
        return new GuiType[]{CHEST, WORKBENCH, HOPPER, DISPENSER, BREWING};
    }

    private static /* synthetic */ GuiType[] $values$$() {
        return new GuiType[]{CHEST, WORKBENCH, HOPPER, DISPENSER, BREWING};
    }

    static {
        $VALUES = GuiType.$values$$();
    }
}

