/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
 */
package me.lifea.libs.triumphgui.components.util;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class Legacy {
    public static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.builder().hexColors().useUnusualXRepeatedCharacterHexFormat().build();

    private Legacy() {
        throw new UnsupportedOperationException("Class should not be instantiated!");
    }
}

