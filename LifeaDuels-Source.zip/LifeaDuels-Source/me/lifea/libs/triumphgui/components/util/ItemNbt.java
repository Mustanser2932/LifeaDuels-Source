/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.components.util;

import me.lifea.libs.triumphgui.components.nbt.LegacyNbt;
import me.lifea.libs.triumphgui.components.nbt.NbtWrapper;
import me.lifea.libs.triumphgui.components.nbt.Pdc;
import me.lifea.libs.triumphgui.components.util.VersionHelper;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public final class ItemNbt {
    private static final NbtWrapper nbt = ItemNbt.selectNbt();

    public static ItemStack setString(@NotNull ItemStack itemStack, @NotNull String key, @NotNull String value) {
        return nbt.setString(itemStack, key, value);
    }

    public static String getString(@NotNull ItemStack itemStack, @NotNull String key) {
        return nbt.getString(itemStack, key);
    }

    public static ItemStack setBoolean(@NotNull ItemStack itemStack, @NotNull String key, boolean value) {
        return nbt.setBoolean(itemStack, key, value);
    }

    public static ItemStack removeTag(@NotNull ItemStack itemStack, @NotNull String key) {
        return nbt.removeTag(itemStack, key);
    }

    private static NbtWrapper selectNbt() {
        return VersionHelper.IS_PDC_VERSION ? new Pdc() : new LegacyNbt();
    }
}

