/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.components;

import java.util.List;
import org.jetbrains.annotations.NotNull;

public interface Serializable {
    public List<String> encodeGui();

    public void decodeGui(@NotNull List<String> var1);
}

