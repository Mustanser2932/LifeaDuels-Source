/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.triumphgui.components;

public final class GuiPage {
}

