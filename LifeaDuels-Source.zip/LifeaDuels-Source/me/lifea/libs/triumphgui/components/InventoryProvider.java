/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.jetbrains.annotations.NotNull
 */
package me.lifea.libs.triumphgui.components;

import net.kyori.adventure.text.Component;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public final class InventoryProvider {

    @FunctionalInterface
    public static interface Typed {
        @NotNull
        public Inventory getInventory(@NotNull Component var1, @NotNull InventoryHolder var2, @NotNull InventoryType var3);
    }

    @FunctionalInterface
    public static interface Chest {
        @NotNull
        public Inventory getInventory(@NotNull Component var1, @NotNull InventoryHolder var2, int var3);
    }
}

