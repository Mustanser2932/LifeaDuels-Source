/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.triumphgui.components;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

public final class InteractionModifier
extends Enum<InteractionModifier> {
    public static final /* enum */ InteractionModifier PREVENT_ITEM_PLACE = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_ITEM_TAKE = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_ITEM_SWAP = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_ITEM_DROP = new InteractionModifier();
    public static final /* enum */ InteractionModifier PREVENT_OTHER_ACTIONS = new InteractionModifier();
    public static final Set<InteractionModifier> VALUES;
    private static final /* synthetic */ InteractionModifier[] $VALUES;

    public static InteractionModifier[] values() {
        return (InteractionModifier[])$VALUES.clone();
    }

    public static InteractionModifier valueOf(String name) {
        return Enum.valueOf(InteractionModifier.class, name);
    }

    private static InteractionModifier[] $values() {
        return new InteractionModifier[]{PREVENT_ITEM_PLACE, PREVENT_ITEM_TAKE, PREVENT_ITEM_SWAP, PREVENT_ITEM_DROP, PREVENT_OTHER_ACTIONS};
    }

    private static InteractionModifier[] $values$() {
        return new InteractionModifier[]{PREVENT_ITEM_PLACE, PREVENT_ITEM_TAKE, PREVENT_ITEM_SWAP, PREVENT_ITEM_DROP, PREVENT_OTHER_ACTIONS};
    }

    private static /* synthetic */ InteractionModifier[] $values$$() {
        return new InteractionModifier[]{PREVENT_ITEM_PLACE, PREVENT_ITEM_TAKE, PREVENT_ITEM_SWAP, PREVENT_ITEM_DROP, PREVENT_OTHER_ACTIONS};
    }

    static {
        $VALUES = InteractionModifier.$values$$();
        VALUES = Collections.unmodifiableSet(EnumSet.allOf(InteractionModifier.class));
    }
}

