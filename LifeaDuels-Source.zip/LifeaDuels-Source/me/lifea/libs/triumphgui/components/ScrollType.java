/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.triumphgui.components;

public final class ScrollType
extends Enum<ScrollType> {
    public static final /* enum */ ScrollType HORIZONTAL = new ScrollType();
    public static final /* enum */ ScrollType VERTICAL = new ScrollType();
    private static final /* synthetic */ ScrollType[] $VALUES;

    public static ScrollType[] values() {
        return (ScrollType[])$VALUES.clone();
    }

    public static ScrollType valueOf(String name) {
        return Enum.valueOf(ScrollType.class, name);
    }

    private static ScrollType[] $values() {
        return new ScrollType[]{HORIZONTAL, VERTICAL};
    }

    private static ScrollType[] $values$() {
        return new ScrollType[]{HORIZONTAL, VERTICAL};
    }

    private static /* synthetic */ ScrollType[] $values$$() {
        return new ScrollType[]{HORIZONTAL, VERTICAL};
    }

    static {
        $VALUES = ScrollType.$values$$();
    }
}

