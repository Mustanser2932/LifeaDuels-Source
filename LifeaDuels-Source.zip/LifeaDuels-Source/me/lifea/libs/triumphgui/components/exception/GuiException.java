/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.triumphgui.components.exception;

public final class GuiException
extends RuntimeException {
    public GuiException(String message) {
        super(message);
    }

    public GuiException(String message, Exception cause) {
        super(message, cause);
    }
}

