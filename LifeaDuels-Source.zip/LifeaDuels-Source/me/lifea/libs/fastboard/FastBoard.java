/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 */
package me.lifea.libs.fastboard;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Array;
import java.util.Objects;
import me.lifea.libs.fastboard.FastBoardBase;
import me.lifea.libs.fastboard.FastReflection;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class FastBoard
extends FastBoardBase<String> {
    private static final MethodHandle MESSAGE_FROM_STRING;
    private static final Object EMPTY_MESSAGE;

    public FastBoard(Player player) {
        super(player);
    }

    @Override
    public void updateTitle(String title) {
        Objects.requireNonNull(title, "title");
        if (!FastBoardBase.VersionType.V1_13.isHigherOrEqual() && title.length() > 32) {
            throw new IllegalArgumentException("Title is longer than 32 chars");
        }
        super.updateTitle(title);
    }

    public void updateLines(String ... lines) {
        Objects.requireNonNull(lines, "lines");
        if (!FastBoardBase.VersionType.V1_13.isHigherOrEqual()) {
            int lineCount = 0;
            for (String s : lines) {
                if (s != null && s.length() > 30) {
                    throw new IllegalArgumentException("Line " + lineCount + " is longer than 30 chars");
                }
                ++lineCount;
            }
        }
        super.updateLines(lines);
    }

    @Override
    protected void sendLineChange(int score) throws Throwable {
        Object prefix;
        int maxLength = this.hasLinesMaxLength() ? 16 : 1024;
        String line = (String)this.getLineByScore(score);
        Object suffix = "";
        if (line != null && !line.isEmpty()) {
            if (line.length() <= maxLength) {
                prefix = line;
            } else {
                boolean addColor;
                int index = line.charAt(maxLength - 1) == '\u00a7' ? maxLength - 1 : maxLength;
                prefix = line.substring(0, index);
                String suffixTmp = line.substring(index);
                ChatColor chatColor = null;
                if (suffixTmp.length() >= 2 && suffixTmp.charAt(0) == '\u00a7') {
                    chatColor = ChatColor.getByChar((char)suffixTmp.charAt(1));
                }
                String color = ChatColor.getLastColors((String)prefix);
                boolean bl = addColor = chatColor == null || chatColor.isFormat();
                String var11 = addColor ? (color.isEmpty() ? ChatColor.RESET.toString() : color) : "";
                suffix = var11 + suffixTmp;
            }
        } else {
            String var10000 = COLOR_CODES[score];
            prefix = var10000 + String.valueOf(ChatColor.RESET);
        }
        if (((String)prefix).length() > maxLength || ((String)suffix).length() > maxLength) {
            prefix = ((String)prefix).substring(0, Math.min(maxLength, ((String)prefix).length()));
            suffix = ((String)suffix).substring(0, Math.min(maxLength, ((String)suffix).length()));
        }
        this.sendTeamPacket(score, FastBoardBase.TeamMode.UPDATE, prefix, suffix);
    }

    @Override
    protected Object toMinecraftComponent(String line) throws Throwable {
        return line != null && !line.isEmpty() ? Array.get(MESSAGE_FROM_STRING.invoke(line), 0) : EMPTY_MESSAGE;
    }

    @Override
    protected String serializeLine(String value) {
        return value;
    }

    @Override
    protected String emptyLine() {
        return "";
    }

    protected boolean hasLinesMaxLength() {
        return !FastBoardBase.VersionType.V1_13.isHigherOrEqual();
    }

    static {
        try {
            MethodHandles.Lookup lookup = MethodHandles.lookup();
            Class<?> craftChatMessageClass = FastReflection.obcClass("util.CraftChatMessage");
            MESSAGE_FROM_STRING = lookup.unreflect(craftChatMessageClass.getMethod("fromString", String.class));
            EMPTY_MESSAGE = Array.get(MESSAGE_FROM_STRING.invoke(""), 0);
        }
        catch (Throwable t) {
            throw new ExceptionInInitializerError(t);
        }
    }
}

