/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari;

import java.sql.SQLException;

public interface SQLExceptionOverride {
    default public Override adjudicate(SQLException sqlException) {
        return Override.CONTINUE_EVICT;
    }

    public static final class Override
    extends Enum<Override> {
        public static final /* enum */ Override CONTINUE_EVICT = new Override();
        public static final /* enum */ Override DO_NOT_EVICT = new Override();
        private static final /* synthetic */ Override[] $VALUES;

        public static Override[] values() {
            return (Override[])$VALUES.clone();
        }

        public static Override valueOf(String name) {
            return Enum.valueOf(Override.class, name);
        }

        private static Override[] $values() {
            return new Override[]{CONTINUE_EVICT, DO_NOT_EVICT};
        }

        private static /* synthetic */ Override[] $values$() {
            return new Override[]{CONTINUE_EVICT, DO_NOT_EVICT};
        }

        static {
            $VALUES = Override.$values$();
        }
    }
}

