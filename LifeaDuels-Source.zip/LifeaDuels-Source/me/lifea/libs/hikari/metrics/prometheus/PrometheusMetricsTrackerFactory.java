/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.prometheus.client.Collector
 *  io.prometheus.client.CollectorRegistry
 */
package me.lifea.libs.hikari.metrics.prometheus;

import io.prometheus.client.Collector;
import io.prometheus.client.CollectorRegistry;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.libs.hikari.metrics.IMetricsTracker;
import me.lifea.libs.hikari.metrics.MetricsTrackerFactory;
import me.lifea.libs.hikari.metrics.PoolStats;
import me.lifea.libs.hikari.metrics.prometheus.HikariCPCollector;
import me.lifea.libs.hikari.metrics.prometheus.PrometheusMetricsTracker;

public class PrometheusMetricsTrackerFactory
implements MetricsTrackerFactory {
    private static final Map<CollectorRegistry, RegistrationStatus> registrationStatuses = new ConcurrentHashMap<CollectorRegistry, RegistrationStatus>();
    private final HikariCPCollector collector = new HikariCPCollector();
    private final CollectorRegistry collectorRegistry;

    public PrometheusMetricsTrackerFactory() {
        this(CollectorRegistry.defaultRegistry);
    }

    public PrometheusMetricsTrackerFactory(CollectorRegistry collectorRegistry) {
        this.collectorRegistry = collectorRegistry;
    }

    @Override
    public IMetricsTracker create(String poolName, PoolStats poolStats) {
        this.registerCollector(this.collector, this.collectorRegistry);
        this.collector.add(poolName, poolStats);
        return new PrometheusMetricsTracker(poolName, this.collectorRegistry, this.collector);
    }

    private void registerCollector(Collector collector, CollectorRegistry collectorRegistry) {
        if (registrationStatuses.putIfAbsent(collectorRegistry, RegistrationStatus.REGISTERED) == null) {
            collector.register(collectorRegistry);
        }
    }

    static final class RegistrationStatus
    extends Enum<RegistrationStatus> {
        public static final /* enum */ RegistrationStatus REGISTERED = new RegistrationStatus();
        private static final /* synthetic */ RegistrationStatus[] $VALUES;

        public static RegistrationStatus[] values() {
            return (RegistrationStatus[])$VALUES.clone();
        }

        public static RegistrationStatus valueOf(String name) {
            return Enum.valueOf(RegistrationStatus.class, name);
        }

        private static RegistrationStatus[] $values() {
            return new RegistrationStatus[]{REGISTERED};
        }

        private static /* synthetic */ RegistrationStatus[] $values$() {
            return new RegistrationStatus[]{REGISTERED};
        }

        static {
            $VALUES = RegistrationStatus.$values$();
        }
    }
}

