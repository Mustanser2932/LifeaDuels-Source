/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.metrics;

import me.lifea.libs.hikari.metrics.IMetricsTracker;
import me.lifea.libs.hikari.metrics.PoolStats;

public interface MetricsTrackerFactory {
    public IMetricsTracker create(String var1, PoolStats var2);
}

