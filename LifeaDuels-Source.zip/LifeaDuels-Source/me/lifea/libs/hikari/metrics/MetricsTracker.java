/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.metrics;

import me.lifea.libs.hikari.metrics.IMetricsTracker;

@Deprecated
public class MetricsTracker
implements IMetricsTracker {
}

