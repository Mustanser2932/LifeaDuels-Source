/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.pool;

import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.ShardingKey;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Wrapper;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;
import me.lifea.libs.hikari.pool.PoolEntry;
import me.lifea.libs.hikari.pool.ProxyConnection;
import me.lifea.libs.hikari.pool.ProxyLeakTask;
import me.lifea.libs.hikari.util.FastList;

public final class HikariProxyConnection
extends ProxyConnection
implements Wrapper,
AutoCloseable,
Connection {
    @Override
    public Statement createStatement() throws SQLException {
        try {
            return super.createStatement();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String var1) throws SQLException {
        try {
            return super.prepareStatement(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public CallableStatement prepareCall(String var1) throws SQLException {
        try {
            return super.prepareCall(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String nativeSQL(String var1) throws SQLException {
        try {
            return this.delegate.nativeSQL(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void setAutoCommit(boolean var1) throws SQLException {
        try {
            super.setAutoCommit(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        try {
            return this.delegate.getAutoCommit();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void commit() throws SQLException {
        try {
            super.commit();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void rollback() throws SQLException {
        try {
            super.rollback();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isClosed() throws SQLException {
        try {
            return super.isClosed();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public DatabaseMetaData getMetaData() throws SQLException {
        try {
            return super.getMetaData();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setReadOnly(boolean var1) throws SQLException {
        try {
            super.setReadOnly(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean isReadOnly() throws SQLException {
        try {
            return this.delegate.isReadOnly();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setCatalog(String var1) throws SQLException {
        try {
            super.setCatalog(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String getCatalog() throws SQLException {
        try {
            return this.delegate.getCatalog();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setTransactionIsolation(int var1) throws SQLException {
        try {
            super.setTransactionIsolation(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getTransactionIsolation() throws SQLException {
        try {
            return this.delegate.getTransactionIsolation();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        try {
            return this.delegate.getWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            this.delegate.clearWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Statement createStatement(int var1, int var2) throws SQLException {
        try {
            return super.createStatement(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String var1, int var2, int var3) throws SQLException {
        try {
            return super.prepareStatement(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public CallableStatement prepareCall(String var1, int var2, int var3) throws SQLException {
        try {
            return super.prepareCall(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    public Map getTypeMap() throws SQLException {
        try {
            return this.delegate.getTypeMap();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    public void setTypeMap(Map var1) throws SQLException {
        try {
            this.delegate.setTypeMap(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void setHoldability(int var1) throws SQLException {
        try {
            this.delegate.setHoldability(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getHoldability() throws SQLException {
        try {
            return this.delegate.getHoldability();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Savepoint setSavepoint() throws SQLException {
        try {
            return this.delegate.setSavepoint();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Savepoint setSavepoint(String var1) throws SQLException {
        try {
            return this.delegate.setSavepoint(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void rollback(Savepoint var1) throws SQLException {
        try {
            super.rollback(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void releaseSavepoint(Savepoint var1) throws SQLException {
        try {
            this.delegate.releaseSavepoint(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Statement createStatement(int var1, int var2, int var3) throws SQLException {
        try {
            return super.createStatement(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String var1, int var2, int var3, int var4) throws SQLException {
        try {
            return super.prepareStatement(var1, var2, var3, var4);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public CallableStatement prepareCall(String var1, int var2, int var3, int var4) throws SQLException {
        try {
            return super.prepareCall(var1, var2, var3, var4);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String var1, int var2) throws SQLException {
        try {
            return super.prepareStatement(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String var1, int[] var2) throws SQLException {
        try {
            return super.prepareStatement(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String var1, String[] var2) throws SQLException {
        try {
            return super.prepareStatement(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Clob createClob() throws SQLException {
        try {
            return this.delegate.createClob();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Blob createBlob() throws SQLException {
        try {
            return this.delegate.createBlob();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public NClob createNClob() throws SQLException {
        try {
            return this.delegate.createNClob();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public SQLXML createSQLXML() throws SQLException {
        try {
            return this.delegate.createSQLXML();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isValid(int var1) throws SQLException {
        try {
            return this.delegate.isValid(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void setClientInfo(String var1, String var2) throws SQLClientInfoException {
        this.delegate.setClientInfo(var1, var2);
    }

    @Override
    public void setClientInfo(Properties var1) throws SQLClientInfoException {
        this.delegate.setClientInfo(var1);
    }

    @Override
    public String getClientInfo(String var1) throws SQLException {
        try {
            return this.delegate.getClientInfo(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Properties getClientInfo() throws SQLException {
        try {
            return this.delegate.getClientInfo();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Array createArrayOf(String var1, Object[] var2) throws SQLException {
        try {
            return this.delegate.createArrayOf(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Struct createStruct(String var1, Object[] var2) throws SQLException {
        try {
            return this.delegate.createStruct(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setSchema(String var1) throws SQLException {
        try {
            super.setSchema(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String getSchema() throws SQLException {
        try {
            return this.delegate.getSchema();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void abort(Executor var1) throws SQLException {
        try {
            this.delegate.abort(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void setNetworkTimeout(Executor var1, int var2) throws SQLException {
        try {
            super.setNetworkTimeout(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int getNetworkTimeout() throws SQLException {
        try {
            return this.delegate.getNetworkTimeout();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void beginRequest() throws SQLException {
        try {
            this.delegate.beginRequest();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void endRequest() throws SQLException {
        try {
            this.delegate.endRequest();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean setShardingKeyIfValid(ShardingKey var1, ShardingKey var2, int var3) throws SQLException {
        try {
            return this.delegate.setShardingKeyIfValid(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public boolean setShardingKeyIfValid(ShardingKey var1, int var2) throws SQLException {
        try {
            return this.delegate.setShardingKeyIfValid(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setShardingKey(ShardingKey var1, ShardingKey var2) throws SQLException {
        try {
            this.delegate.setShardingKey(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setShardingKey(ShardingKey var1) throws SQLException {
        try {
            this.delegate.setShardingKey(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    protected HikariProxyConnection(PoolEntry var1, Connection var2, FastList var3, ProxyLeakTask var4, boolean var5, boolean var6) {
        super(var1, var2, var3, var4, var5, var6);
    }
}

