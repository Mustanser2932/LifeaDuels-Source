/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.pool;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Wrapper;
import java.util.Calendar;
import me.lifea.libs.hikari.pool.ProxyConnection;
import me.lifea.libs.hikari.pool.ProxyPreparedStatement;

public final class HikariProxyPreparedStatement
extends ProxyPreparedStatement
implements Wrapper,
AutoCloseable,
Statement,
PreparedStatement {
    public boolean isWrapperFor(Class var1) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).isWrapperFor(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet executeQuery(String var1) throws SQLException {
        try {
            return super.executeQuery(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int executeUpdate(String var1) throws SQLException {
        try {
            return super.executeUpdate(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getMaxFieldSize() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getMaxFieldSize();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setMaxFieldSize(int var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setMaxFieldSize(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getMaxRows() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getMaxRows();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setMaxRows(int var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setMaxRows(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void setEscapeProcessing(boolean var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setEscapeProcessing(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getQueryTimeout() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getQueryTimeout();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setQueryTimeout(int var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setQueryTimeout(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void cancel() throws SQLException {
        try {
            ((PreparedStatement)this.delegate).cancel();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            ((PreparedStatement)this.delegate).clearWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setCursorName(String var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setCursorName(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean execute(String var1) throws SQLException {
        try {
            return super.execute(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet getResultSet() throws SQLException {
        try {
            return super.getResultSet();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getUpdateCount() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getUpdateCount();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean getMoreResults() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getMoreResults();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setFetchDirection(int var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setFetchDirection(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getFetchDirection() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getFetchDirection();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setFetchSize(int var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setFetchSize(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getFetchSize() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getFetchSize();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getResultSetConcurrency() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getResultSetConcurrency();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getResultSetType() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getResultSetType();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void addBatch(String var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).addBatch(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void clearBatch() throws SQLException {
        try {
            ((PreparedStatement)this.delegate).clearBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int[] executeBatch() throws SQLException {
        try {
            return super.executeBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Connection getConnection() throws SQLException {
        try {
            return super.getConnection();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean getMoreResults(int var1) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getMoreResults(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        try {
            return super.getGeneratedKeys();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int executeUpdate(String var1, int var2) throws SQLException {
        try {
            return super.executeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int executeUpdate(String var1, int[] var2) throws SQLException {
        try {
            return super.executeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int executeUpdate(String var1, String[] var2) throws SQLException {
        try {
            return super.executeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute(String var1, int var2) throws SQLException {
        try {
            return super.execute(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute(String var1, int[] var2) throws SQLException {
        try {
            return super.execute(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute(String var1, String[] var2) throws SQLException {
        try {
            return super.execute(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int getResultSetHoldability() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getResultSetHoldability();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isClosed() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).isClosed();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setPoolable(boolean var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setPoolable(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean isPoolable() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).isPoolable();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void closeOnCompletion() throws SQLException {
        try {
            ((PreparedStatement)this.delegate).closeOnCompletion();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isCloseOnCompletion() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).isCloseOnCompletion();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public long getLargeUpdateCount() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getLargeUpdateCount();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setLargeMaxRows(long var1) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setLargeMaxRows(var1);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public long getLargeMaxRows() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getLargeMaxRows();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public long[] executeLargeBatch() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).executeLargeBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public long executeLargeUpdate(String var1) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).executeLargeUpdate(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public long executeLargeUpdate(String var1, int var2) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).executeLargeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public long executeLargeUpdate(String var1, int[] var2) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).executeLargeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public long executeLargeUpdate(String var1, String[] var2) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).executeLargeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public String enquoteLiteral(String var1) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).enquoteLiteral(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String enquoteIdentifier(String var1, boolean var2) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).enquoteIdentifier(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean isSimpleIdentifier(String var1) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).isSimpleIdentifier(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String enquoteNCharLiteral(String var1) throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).enquoteNCharLiteral(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet executeQuery() throws SQLException {
        try {
            return super.executeQuery();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int executeUpdate() throws SQLException {
        try {
            return super.executeUpdate();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setNull(int var1, int var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNull(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setBoolean(int var1, boolean var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBoolean(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setByte(int var1, byte var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setByte(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setShort(int var1, short var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setShort(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setInt(int var1, int var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setInt(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setLong(int var1, long var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setLong(var1, var2);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setFloat(int var1, float var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setFloat(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setDouble(int var1, double var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setDouble(var1, var2);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setBigDecimal(int var1, BigDecimal var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBigDecimal(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setString(int var1, String var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setString(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setBytes(int var1, byte[] var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBytes(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setDate(int var1, Date var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setDate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setTime(int var1, Time var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setTime(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setTimestamp(int var1, Timestamp var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setTimestamp(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setAsciiStream(int var1, InputStream var2, int var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setAsciiStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setUnicodeStream(int var1, InputStream var2, int var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setUnicodeStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setBinaryStream(int var1, InputStream var2, int var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBinaryStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void clearParameters() throws SQLException {
        try {
            ((PreparedStatement)this.delegate).clearParameters();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setObject(int var1, Object var2, int var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setObject(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setObject(int var1, Object var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute() throws SQLException {
        try {
            return super.execute();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void addBatch() throws SQLException {
        try {
            ((PreparedStatement)this.delegate).addBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setCharacterStream(int var1, Reader var2, int var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setCharacterStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setRef(int var1, Ref var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setRef(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setBlob(int var1, Blob var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBlob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setClob(int var1, Clob var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setArray(int var1, Array var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setArray(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getMetaData();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setDate(int var1, Date var2, Calendar var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setDate(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setTime(int var1, Time var2, Calendar var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setTime(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setTimestamp(int var1, Timestamp var2, Calendar var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setTimestamp(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setNull(int var1, int var2, String var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNull(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void setURL(int var1, URL var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setURL(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public ParameterMetaData getParameterMetaData() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).getParameterMetaData();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setRowId(int var1, RowId var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setRowId(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setNString(int var1, String var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNString(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setNCharacterStream(int var1, Reader var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNCharacterStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setNClob(int var1, NClob var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setClob(int var1, Reader var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setClob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setBlob(int var1, InputStream var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBlob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setNClob(int var1, Reader var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNClob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setSQLXML(int var1, SQLXML var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setSQLXML(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setObject(int var1, Object var2, int var3, int var4) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setObject(var1, var2, var3, var4);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setAsciiStream(int var1, InputStream var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setAsciiStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setBinaryStream(int var1, InputStream var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBinaryStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setCharacterStream(int var1, Reader var2, long var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setCharacterStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setAsciiStream(int var1, InputStream var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setAsciiStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setBinaryStream(int var1, InputStream var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBinaryStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setCharacterStream(int var1, Reader var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setCharacterStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setNCharacterStream(int var1, Reader var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNCharacterStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setClob(int var1, Reader var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setBlob(int var1, InputStream var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setBlob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setNClob(int var1, Reader var2) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setNClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void setObject(int var1, Object var2, SQLType var3, int var4) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setObject(var1, var2, var3, var4);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void setObject(int var1, Object var2, SQLType var3) throws SQLException {
        try {
            ((PreparedStatement)this.delegate).setObject(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public long executeLargeUpdate() throws SQLException {
        try {
            return ((PreparedStatement)this.delegate).executeLargeUpdate();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    HikariProxyPreparedStatement(ProxyConnection var1, PreparedStatement var2) {
        super(var1, var2);
    }
}

