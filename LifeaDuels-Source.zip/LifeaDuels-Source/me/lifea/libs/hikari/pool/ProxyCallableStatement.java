/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.pool;

import java.sql.CallableStatement;
import me.lifea.libs.hikari.pool.ProxyConnection;
import me.lifea.libs.hikari.pool.ProxyPreparedStatement;

public abstract class ProxyCallableStatement
extends ProxyPreparedStatement
implements CallableStatement {
    protected ProxyCallableStatement(ProxyConnection connection, CallableStatement statement) {
        super(connection, statement);
    }
}

