/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.pool;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.Wrapper;
import me.lifea.libs.hikari.pool.ProxyConnection;
import me.lifea.libs.hikari.pool.ProxyStatement;

public final class HikariProxyStatement
extends ProxyStatement
implements Wrapper,
AutoCloseable,
Statement {
    public boolean isWrapperFor(Class var1) throws SQLException {
        try {
            return this.delegate.isWrapperFor(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet executeQuery(String var1) throws SQLException {
        try {
            return super.executeQuery(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int executeUpdate(String var1) throws SQLException {
        try {
            return super.executeUpdate(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getMaxFieldSize() throws SQLException {
        try {
            return this.delegate.getMaxFieldSize();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setMaxFieldSize(int var1) throws SQLException {
        try {
            this.delegate.setMaxFieldSize(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getMaxRows() throws SQLException {
        try {
            return this.delegate.getMaxRows();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setMaxRows(int var1) throws SQLException {
        try {
            this.delegate.setMaxRows(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void setEscapeProcessing(boolean var1) throws SQLException {
        try {
            this.delegate.setEscapeProcessing(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getQueryTimeout() throws SQLException {
        try {
            return this.delegate.getQueryTimeout();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setQueryTimeout(int var1) throws SQLException {
        try {
            this.delegate.setQueryTimeout(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void cancel() throws SQLException {
        try {
            this.delegate.cancel();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        try {
            return this.delegate.getWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            this.delegate.clearWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setCursorName(String var1) throws SQLException {
        try {
            this.delegate.setCursorName(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean execute(String var1) throws SQLException {
        try {
            return super.execute(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet getResultSet() throws SQLException {
        try {
            return super.getResultSet();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getUpdateCount() throws SQLException {
        try {
            return this.delegate.getUpdateCount();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean getMoreResults() throws SQLException {
        try {
            return this.delegate.getMoreResults();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setFetchDirection(int var1) throws SQLException {
        try {
            this.delegate.setFetchDirection(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getFetchDirection() throws SQLException {
        try {
            return this.delegate.getFetchDirection();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setFetchSize(int var1) throws SQLException {
        try {
            this.delegate.setFetchSize(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getFetchSize() throws SQLException {
        try {
            return this.delegate.getFetchSize();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getResultSetConcurrency() throws SQLException {
        try {
            return this.delegate.getResultSetConcurrency();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getResultSetType() throws SQLException {
        try {
            return this.delegate.getResultSetType();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void addBatch(String var1) throws SQLException {
        try {
            this.delegate.addBatch(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void clearBatch() throws SQLException {
        try {
            this.delegate.clearBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int[] executeBatch() throws SQLException {
        try {
            return super.executeBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Connection getConnection() throws SQLException {
        try {
            return super.getConnection();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean getMoreResults(int var1) throws SQLException {
        try {
            return this.delegate.getMoreResults(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        try {
            return super.getGeneratedKeys();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int executeUpdate(String var1, int var2) throws SQLException {
        try {
            return super.executeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int executeUpdate(String var1, int[] var2) throws SQLException {
        try {
            return super.executeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int executeUpdate(String var1, String[] var2) throws SQLException {
        try {
            return super.executeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute(String var1, int var2) throws SQLException {
        try {
            return super.execute(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute(String var1, int[] var2) throws SQLException {
        try {
            return super.execute(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean execute(String var1, String[] var2) throws SQLException {
        try {
            return super.execute(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int getResultSetHoldability() throws SQLException {
        try {
            return this.delegate.getResultSetHoldability();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isClosed() throws SQLException {
        try {
            return this.delegate.isClosed();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setPoolable(boolean var1) throws SQLException {
        try {
            this.delegate.setPoolable(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean isPoolable() throws SQLException {
        try {
            return this.delegate.isPoolable();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void closeOnCompletion() throws SQLException {
        try {
            this.delegate.closeOnCompletion();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isCloseOnCompletion() throws SQLException {
        try {
            return this.delegate.isCloseOnCompletion();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public long getLargeUpdateCount() throws SQLException {
        try {
            return this.delegate.getLargeUpdateCount();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setLargeMaxRows(long var1) throws SQLException {
        try {
            this.delegate.setLargeMaxRows(var1);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public long getLargeMaxRows() throws SQLException {
        try {
            return this.delegate.getLargeMaxRows();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public long[] executeLargeBatch() throws SQLException {
        try {
            return this.delegate.executeLargeBatch();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public long executeLargeUpdate(String var1) throws SQLException {
        try {
            return this.delegate.executeLargeUpdate(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public long executeLargeUpdate(String var1, int var2) throws SQLException {
        try {
            return this.delegate.executeLargeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public long executeLargeUpdate(String var1, int[] var2) throws SQLException {
        try {
            return this.delegate.executeLargeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public long executeLargeUpdate(String var1, String[] var2) throws SQLException {
        try {
            return this.delegate.executeLargeUpdate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public String enquoteLiteral(String var1) throws SQLException {
        try {
            return this.delegate.enquoteLiteral(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String enquoteIdentifier(String var1, boolean var2) throws SQLException {
        try {
            return this.delegate.enquoteIdentifier(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public boolean isSimpleIdentifier(String var1) throws SQLException {
        try {
            return this.delegate.isSimpleIdentifier(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String enquoteNCharLiteral(String var1) throws SQLException {
        try {
            return this.delegate.enquoteNCharLiteral(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    HikariProxyStatement(ProxyConnection var1, Statement var2) {
        super(var1, var2);
    }
}

