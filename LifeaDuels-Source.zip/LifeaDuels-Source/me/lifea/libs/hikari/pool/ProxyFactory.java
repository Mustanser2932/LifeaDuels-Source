/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.pool;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import me.lifea.libs.hikari.pool.HikariProxyCallableStatement;
import me.lifea.libs.hikari.pool.HikariProxyConnection;
import me.lifea.libs.hikari.pool.HikariProxyDatabaseMetaData;
import me.lifea.libs.hikari.pool.HikariProxyPreparedStatement;
import me.lifea.libs.hikari.pool.HikariProxyResultSet;
import me.lifea.libs.hikari.pool.HikariProxyStatement;
import me.lifea.libs.hikari.pool.PoolEntry;
import me.lifea.libs.hikari.pool.ProxyConnection;
import me.lifea.libs.hikari.pool.ProxyLeakTask;
import me.lifea.libs.hikari.pool.ProxyStatement;
import me.lifea.libs.hikari.util.FastList;

public final class ProxyFactory {
    private ProxyFactory() {
    }

    static ProxyConnection getProxyConnection(PoolEntry var0, Connection var1, FastList<Statement> var2, ProxyLeakTask var3, boolean var4, boolean var5) {
        return new HikariProxyConnection(var0, var1, (FastList)var2, var3, var4, var5);
    }

    static Statement getProxyStatement(ProxyConnection var0, Statement var1) {
        return new HikariProxyStatement(var0, var1);
    }

    static CallableStatement getProxyCallableStatement(ProxyConnection var0, CallableStatement var1) {
        return new HikariProxyCallableStatement(var0, var1);
    }

    static PreparedStatement getProxyPreparedStatement(ProxyConnection var0, PreparedStatement var1) {
        return new HikariProxyPreparedStatement(var0, var1);
    }

    static ResultSet getProxyResultSet(ProxyConnection var0, ProxyStatement var1, ResultSet var2) {
        return new HikariProxyResultSet(var0, var1, var2);
    }

    static DatabaseMetaData getProxyDatabaseMetaData(ProxyConnection var0, DatabaseMetaData var1) {
        return new HikariProxyDatabaseMetaData(var0, var1);
    }
}

