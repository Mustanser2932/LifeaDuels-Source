/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.pool;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Wrapper;
import java.util.Calendar;
import java.util.Map;
import me.lifea.libs.hikari.pool.ProxyConnection;
import me.lifea.libs.hikari.pool.ProxyResultSet;
import me.lifea.libs.hikari.pool.ProxyStatement;

public final class HikariProxyResultSet
extends ProxyResultSet
implements Wrapper,
AutoCloseable,
ResultSet {
    public boolean isWrapperFor(Class var1) throws SQLException {
        try {
            return this.delegate.isWrapperFor(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void close() throws SQLException {
        this.delegate.close();
    }

    @Override
    public boolean next() throws SQLException {
        try {
            return this.delegate.next();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean wasNull() throws SQLException {
        try {
            return this.delegate.wasNull();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public String getString(int var1) throws SQLException {
        try {
            return this.delegate.getString(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean getBoolean(int var1) throws SQLException {
        try {
            return this.delegate.getBoolean(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public byte getByte(int var1) throws SQLException {
        try {
            return this.delegate.getByte(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public short getShort(int var1) throws SQLException {
        try {
            return this.delegate.getShort(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getInt(int var1) throws SQLException {
        try {
            return this.delegate.getInt(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public long getLong(int var1) throws SQLException {
        try {
            return this.delegate.getLong(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public float getFloat(int var1) throws SQLException {
        try {
            return this.delegate.getFloat(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public double getDouble(int var1) throws SQLException {
        try {
            return this.delegate.getDouble(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public BigDecimal getBigDecimal(int var1, int var2) throws SQLException {
        try {
            return this.delegate.getBigDecimal(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public byte[] getBytes(int var1) throws SQLException {
        try {
            return this.delegate.getBytes(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Date getDate(int var1) throws SQLException {
        try {
            return this.delegate.getDate(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Time getTime(int var1) throws SQLException {
        try {
            return this.delegate.getTime(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Timestamp getTimestamp(int var1) throws SQLException {
        try {
            return this.delegate.getTimestamp(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public InputStream getAsciiStream(int var1) throws SQLException {
        try {
            return this.delegate.getAsciiStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public InputStream getUnicodeStream(int var1) throws SQLException {
        try {
            return this.delegate.getUnicodeStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public InputStream getBinaryStream(int var1) throws SQLException {
        try {
            return this.delegate.getBinaryStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String getString(String var1) throws SQLException {
        try {
            return this.delegate.getString(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean getBoolean(String var1) throws SQLException {
        try {
            return this.delegate.getBoolean(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public byte getByte(String var1) throws SQLException {
        try {
            return this.delegate.getByte(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public short getShort(String var1) throws SQLException {
        try {
            return this.delegate.getShort(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getInt(String var1) throws SQLException {
        try {
            return this.delegate.getInt(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public long getLong(String var1) throws SQLException {
        try {
            return this.delegate.getLong(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public float getFloat(String var1) throws SQLException {
        try {
            return this.delegate.getFloat(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public double getDouble(String var1) throws SQLException {
        try {
            return this.delegate.getDouble(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public BigDecimal getBigDecimal(String var1, int var2) throws SQLException {
        try {
            return this.delegate.getBigDecimal(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public byte[] getBytes(String var1) throws SQLException {
        try {
            return this.delegate.getBytes(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Date getDate(String var1) throws SQLException {
        try {
            return this.delegate.getDate(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Time getTime(String var1) throws SQLException {
        try {
            return this.delegate.getTime(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Timestamp getTimestamp(String var1) throws SQLException {
        try {
            return this.delegate.getTimestamp(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public InputStream getAsciiStream(String var1) throws SQLException {
        try {
            return this.delegate.getAsciiStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public InputStream getUnicodeStream(String var1) throws SQLException {
        try {
            return this.delegate.getUnicodeStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public InputStream getBinaryStream(String var1) throws SQLException {
        try {
            return this.delegate.getBinaryStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        try {
            return this.delegate.getWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            this.delegate.clearWarnings();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public String getCursorName() throws SQLException {
        try {
            return this.delegate.getCursorName();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        try {
            return this.delegate.getMetaData();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public Object getObject(int var1) throws SQLException {
        try {
            return this.delegate.getObject(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Object getObject(String var1) throws SQLException {
        try {
            return this.delegate.getObject(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int findColumn(String var1) throws SQLException {
        try {
            return this.delegate.findColumn(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Reader getCharacterStream(int var1) throws SQLException {
        try {
            return this.delegate.getCharacterStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Reader getCharacterStream(String var1) throws SQLException {
        try {
            return this.delegate.getCharacterStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public BigDecimal getBigDecimal(int var1) throws SQLException {
        try {
            return this.delegate.getBigDecimal(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public BigDecimal getBigDecimal(String var1) throws SQLException {
        try {
            return this.delegate.getBigDecimal(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        try {
            return this.delegate.isBeforeFirst();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isAfterLast() throws SQLException {
        try {
            return this.delegate.isAfterLast();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isFirst() throws SQLException {
        try {
            return this.delegate.isFirst();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isLast() throws SQLException {
        try {
            return this.delegate.isLast();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void beforeFirst() throws SQLException {
        try {
            this.delegate.beforeFirst();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void afterLast() throws SQLException {
        try {
            this.delegate.afterLast();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean first() throws SQLException {
        try {
            return this.delegate.first();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean last() throws SQLException {
        try {
            return this.delegate.last();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getRow() throws SQLException {
        try {
            return this.delegate.getRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean absolute(int var1) throws SQLException {
        try {
            return this.delegate.absolute(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean relative(int var1) throws SQLException {
        try {
            return this.delegate.relative(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public boolean previous() throws SQLException {
        try {
            return this.delegate.previous();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setFetchDirection(int var1) throws SQLException {
        try {
            this.delegate.setFetchDirection(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getFetchDirection() throws SQLException {
        try {
            return this.delegate.getFetchDirection();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void setFetchSize(int var1) throws SQLException {
        try {
            this.delegate.setFetchSize(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public int getFetchSize() throws SQLException {
        try {
            return this.delegate.getFetchSize();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getType() throws SQLException {
        try {
            return this.delegate.getType();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public int getConcurrency() throws SQLException {
        try {
            return this.delegate.getConcurrency();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean rowUpdated() throws SQLException {
        try {
            return this.delegate.rowUpdated();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean rowInserted() throws SQLException {
        try {
            return this.delegate.rowInserted();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean rowDeleted() throws SQLException {
        try {
            return this.delegate.rowDeleted();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void updateNull(int var1) throws SQLException {
        try {
            this.delegate.updateNull(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void updateBoolean(int var1, boolean var2) throws SQLException {
        try {
            this.delegate.updateBoolean(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateByte(int var1, byte var2) throws SQLException {
        try {
            this.delegate.updateByte(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateShort(int var1, short var2) throws SQLException {
        try {
            this.delegate.updateShort(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateInt(int var1, int var2) throws SQLException {
        try {
            this.delegate.updateInt(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateLong(int var1, long var2) throws SQLException {
        try {
            this.delegate.updateLong(var1, var2);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateFloat(int var1, float var2) throws SQLException {
        try {
            this.delegate.updateFloat(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateDouble(int var1, double var2) throws SQLException {
        try {
            this.delegate.updateDouble(var1, var2);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateBigDecimal(int var1, BigDecimal var2) throws SQLException {
        try {
            this.delegate.updateBigDecimal(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateString(int var1, String var2) throws SQLException {
        try {
            this.delegate.updateString(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBytes(int var1, byte[] var2) throws SQLException {
        try {
            this.delegate.updateBytes(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateDate(int var1, Date var2) throws SQLException {
        try {
            this.delegate.updateDate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateTime(int var1, Time var2) throws SQLException {
        try {
            this.delegate.updateTime(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateTimestamp(int var1, Timestamp var2) throws SQLException {
        try {
            this.delegate.updateTimestamp(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateAsciiStream(int var1, InputStream var2, int var3) throws SQLException {
        try {
            this.delegate.updateAsciiStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateBinaryStream(int var1, InputStream var2, int var3) throws SQLException {
        try {
            this.delegate.updateBinaryStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateCharacterStream(int var1, Reader var2, int var3) throws SQLException {
        try {
            this.delegate.updateCharacterStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateObject(int var1, Object var2, int var3) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateObject(int var1, Object var2) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNull(String var1) throws SQLException {
        try {
            this.delegate.updateNull(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void updateBoolean(String var1, boolean var2) throws SQLException {
        try {
            this.delegate.updateBoolean(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateByte(String var1, byte var2) throws SQLException {
        try {
            this.delegate.updateByte(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateShort(String var1, short var2) throws SQLException {
        try {
            this.delegate.updateShort(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateInt(String var1, int var2) throws SQLException {
        try {
            this.delegate.updateInt(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateLong(String var1, long var2) throws SQLException {
        try {
            this.delegate.updateLong(var1, var2);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateFloat(String var1, float var2) throws SQLException {
        try {
            this.delegate.updateFloat(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateDouble(String var1, double var2) throws SQLException {
        try {
            this.delegate.updateDouble(var1, var2);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateBigDecimal(String var1, BigDecimal var2) throws SQLException {
        try {
            this.delegate.updateBigDecimal(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateString(String var1, String var2) throws SQLException {
        try {
            this.delegate.updateString(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBytes(String var1, byte[] var2) throws SQLException {
        try {
            this.delegate.updateBytes(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateDate(String var1, Date var2) throws SQLException {
        try {
            this.delegate.updateDate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateTime(String var1, Time var2) throws SQLException {
        try {
            this.delegate.updateTime(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateTimestamp(String var1, Timestamp var2) throws SQLException {
        try {
            this.delegate.updateTimestamp(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateAsciiStream(String var1, InputStream var2, int var3) throws SQLException {
        try {
            this.delegate.updateAsciiStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateBinaryStream(String var1, InputStream var2, int var3) throws SQLException {
        try {
            this.delegate.updateBinaryStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateCharacterStream(String var1, Reader var2, int var3) throws SQLException {
        try {
            this.delegate.updateCharacterStream(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateObject(String var1, Object var2, int var3) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateObject(String var1, Object var2) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void insertRow() throws SQLException {
        try {
            super.insertRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void updateRow() throws SQLException {
        try {
            super.updateRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void deleteRow() throws SQLException {
        try {
            super.deleteRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void refreshRow() throws SQLException {
        try {
            this.delegate.refreshRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void cancelRowUpdates() throws SQLException {
        try {
            this.delegate.cancelRowUpdates();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void moveToInsertRow() throws SQLException {
        try {
            this.delegate.moveToInsertRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void moveToCurrentRow() throws SQLException {
        try {
            this.delegate.moveToCurrentRow();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    public Object getObject(int var1, Map var2) throws SQLException {
        try {
            return this.delegate.getObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Ref getRef(int var1) throws SQLException {
        try {
            return this.delegate.getRef(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Blob getBlob(int var1) throws SQLException {
        try {
            return this.delegate.getBlob(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Clob getClob(int var1) throws SQLException {
        try {
            return this.delegate.getClob(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Array getArray(int var1) throws SQLException {
        try {
            return this.delegate.getArray(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    public Object getObject(String var1, Map var2) throws SQLException {
        try {
            return this.delegate.getObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Ref getRef(String var1) throws SQLException {
        try {
            return this.delegate.getRef(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Blob getBlob(String var1) throws SQLException {
        try {
            return this.delegate.getBlob(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Clob getClob(String var1) throws SQLException {
        try {
            return this.delegate.getClob(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Array getArray(String var1) throws SQLException {
        try {
            return this.delegate.getArray(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Date getDate(int var1, Calendar var2) throws SQLException {
        try {
            return this.delegate.getDate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Date getDate(String var1, Calendar var2) throws SQLException {
        try {
            return this.delegate.getDate(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Time getTime(int var1, Calendar var2) throws SQLException {
        try {
            return this.delegate.getTime(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Time getTime(String var1, Calendar var2) throws SQLException {
        try {
            return this.delegate.getTime(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Timestamp getTimestamp(int var1, Calendar var2) throws SQLException {
        try {
            return this.delegate.getTimestamp(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public Timestamp getTimestamp(String var1, Calendar var2) throws SQLException {
        try {
            return this.delegate.getTimestamp(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public URL getURL(int var1) throws SQLException {
        try {
            return this.delegate.getURL(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public URL getURL(String var1) throws SQLException {
        try {
            return this.delegate.getURL(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void updateRef(int var1, Ref var2) throws SQLException {
        try {
            this.delegate.updateRef(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateRef(String var1, Ref var2) throws SQLException {
        try {
            this.delegate.updateRef(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBlob(int var1, Blob var2) throws SQLException {
        try {
            this.delegate.updateBlob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBlob(String var1, Blob var2) throws SQLException {
        try {
            this.delegate.updateBlob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateClob(int var1, Clob var2) throws SQLException {
        try {
            this.delegate.updateClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateClob(String var1, Clob var2) throws SQLException {
        try {
            this.delegate.updateClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateArray(int var1, Array var2) throws SQLException {
        try {
            this.delegate.updateArray(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateArray(String var1, Array var2) throws SQLException {
        try {
            this.delegate.updateArray(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public RowId getRowId(int var1) throws SQLException {
        try {
            return this.delegate.getRowId(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public RowId getRowId(String var1) throws SQLException {
        try {
            return this.delegate.getRowId(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void updateRowId(int var1, RowId var2) throws SQLException {
        try {
            this.delegate.updateRowId(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateRowId(String var1, RowId var2) throws SQLException {
        try {
            this.delegate.updateRowId(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public int getHoldability() throws SQLException {
        try {
            return this.delegate.getHoldability();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public boolean isClosed() throws SQLException {
        try {
            return this.delegate.isClosed();
        }
        catch (SQLException var2) {
            throw this.checkException(var2);
        }
    }

    @Override
    public void updateNString(int var1, String var2) throws SQLException {
        try {
            this.delegate.updateNString(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNString(String var1, String var2) throws SQLException {
        try {
            this.delegate.updateNString(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNClob(int var1, NClob var2) throws SQLException {
        try {
            this.delegate.updateNClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNClob(String var1, NClob var2) throws SQLException {
        try {
            this.delegate.updateNClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public NClob getNClob(int var1) throws SQLException {
        try {
            return this.delegate.getNClob(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public NClob getNClob(String var1) throws SQLException {
        try {
            return this.delegate.getNClob(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public SQLXML getSQLXML(int var1) throws SQLException {
        try {
            return this.delegate.getSQLXML(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public SQLXML getSQLXML(String var1) throws SQLException {
        try {
            return this.delegate.getSQLXML(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void updateSQLXML(int var1, SQLXML var2) throws SQLException {
        try {
            this.delegate.updateSQLXML(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateSQLXML(String var1, SQLXML var2) throws SQLException {
        try {
            this.delegate.updateSQLXML(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public String getNString(int var1) throws SQLException {
        try {
            return this.delegate.getNString(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public String getNString(String var1) throws SQLException {
        try {
            return this.delegate.getNString(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Reader getNCharacterStream(int var1) throws SQLException {
        try {
            return this.delegate.getNCharacterStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public Reader getNCharacterStream(String var1) throws SQLException {
        try {
            return this.delegate.getNCharacterStream(var1);
        }
        catch (SQLException var3) {
            throw this.checkException(var3);
        }
    }

    @Override
    public void updateNCharacterStream(int var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateNCharacterStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateNCharacterStream(String var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateNCharacterStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateAsciiStream(int var1, InputStream var2, long var3) throws SQLException {
        try {
            this.delegate.updateAsciiStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateBinaryStream(int var1, InputStream var2, long var3) throws SQLException {
        try {
            this.delegate.updateBinaryStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateCharacterStream(int var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateCharacterStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateAsciiStream(String var1, InputStream var2, long var3) throws SQLException {
        try {
            this.delegate.updateAsciiStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateBinaryStream(String var1, InputStream var2, long var3) throws SQLException {
        try {
            this.delegate.updateBinaryStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateCharacterStream(String var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateCharacterStream(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateBlob(int var1, InputStream var2, long var3) throws SQLException {
        try {
            this.delegate.updateBlob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateBlob(String var1, InputStream var2, long var3) throws SQLException {
        try {
            this.delegate.updateBlob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateClob(int var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateClob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateClob(String var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateClob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateNClob(int var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateNClob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateNClob(String var1, Reader var2, long var3) throws SQLException {
        try {
            this.delegate.updateNClob(var1, var2, var3);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateNCharacterStream(int var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateNCharacterStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNCharacterStream(String var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateNCharacterStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateAsciiStream(int var1, InputStream var2) throws SQLException {
        try {
            this.delegate.updateAsciiStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBinaryStream(int var1, InputStream var2) throws SQLException {
        try {
            this.delegate.updateBinaryStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateCharacterStream(int var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateCharacterStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateAsciiStream(String var1, InputStream var2) throws SQLException {
        try {
            this.delegate.updateAsciiStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBinaryStream(String var1, InputStream var2) throws SQLException {
        try {
            this.delegate.updateBinaryStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateCharacterStream(String var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateCharacterStream(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBlob(int var1, InputStream var2) throws SQLException {
        try {
            this.delegate.updateBlob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateBlob(String var1, InputStream var2) throws SQLException {
        try {
            this.delegate.updateBlob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateClob(int var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateClob(String var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNClob(int var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateNClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateNClob(String var1, Reader var2) throws SQLException {
        try {
            this.delegate.updateNClob(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    public Object getObject(int var1, Class var2) throws SQLException {
        try {
            return this.delegate.getObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    public Object getObject(String var1, Class var2) throws SQLException {
        try {
            return this.delegate.getObject(var1, var2);
        }
        catch (SQLException var4) {
            throw this.checkException(var4);
        }
    }

    @Override
    public void updateObject(int var1, Object var2, SQLType var3, int var4) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2, var3, var4);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateObject(String var1, Object var2, SQLType var3, int var4) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2, var3, var4);
        }
        catch (SQLException var6) {
            throw this.checkException(var6);
        }
    }

    @Override
    public void updateObject(int var1, Object var2, SQLType var3) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    @Override
    public void updateObject(String var1, Object var2, SQLType var3) throws SQLException {
        try {
            this.delegate.updateObject(var1, var2, var3);
        }
        catch (SQLException var5) {
            throw this.checkException(var5);
        }
    }

    protected HikariProxyResultSet(ProxyConnection var1, ProxyStatement var2, ResultSet var3) {
        super(var1, var2, var3);
    }
}

