/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.libs.hikari.util;

public final class IsolationLevel
extends Enum<IsolationLevel> {
    public static final /* enum */ IsolationLevel TRANSACTION_NONE = new IsolationLevel(0);
    public static final /* enum */ IsolationLevel TRANSACTION_READ_UNCOMMITTED = new IsolationLevel(1);
    public static final /* enum */ IsolationLevel TRANSACTION_READ_COMMITTED = new IsolationLevel(2);
    public static final /* enum */ IsolationLevel TRANSACTION_CURSOR_STABILITY = new IsolationLevel(3);
    public static final /* enum */ IsolationLevel TRANSACTION_REPEATABLE_READ = new IsolationLevel(4);
    public static final /* enum */ IsolationLevel TRANSACTION_LAST_COMMITTED = new IsolationLevel(5);
    public static final /* enum */ IsolationLevel TRANSACTION_SERIALIZABLE = new IsolationLevel(8);
    public static final /* enum */ IsolationLevel TRANSACTION_SQL_SERVER_SNAPSHOT_ISOLATION_LEVEL = new IsolationLevel(4096);
    private final int levelId;
    private static final /* synthetic */ IsolationLevel[] $VALUES;

    public static IsolationLevel[] values() {
        return (IsolationLevel[])$VALUES.clone();
    }

    public static IsolationLevel valueOf(String name) {
        return Enum.valueOf(IsolationLevel.class, name);
    }

    private IsolationLevel(int levelId) {
        this.levelId = levelId;
    }

    public int getLevelId() {
        return this.levelId;
    }

    private static IsolationLevel[] $values() {
        return new IsolationLevel[]{TRANSACTION_NONE, TRANSACTION_READ_UNCOMMITTED, TRANSACTION_READ_COMMITTED, TRANSACTION_CURSOR_STABILITY, TRANSACTION_REPEATABLE_READ, TRANSACTION_LAST_COMMITTED, TRANSACTION_SERIALIZABLE, TRANSACTION_SQL_SERVER_SNAPSHOT_ISOLATION_LEVEL};
    }

    private static /* synthetic */ IsolationLevel[] $values$() {
        return new IsolationLevel[]{TRANSACTION_NONE, TRANSACTION_READ_UNCOMMITTED, TRANSACTION_READ_COMMITTED, TRANSACTION_CURSOR_STABILITY, TRANSACTION_REPEATABLE_READ, TRANSACTION_LAST_COMMITTED, TRANSACTION_SERIALIZABLE, TRANSACTION_SQL_SERVER_SNAPSHOT_ISOLATION_LEVEL};
    }

    static {
        $VALUES = IsolationLevel.$values$();
    }
}

