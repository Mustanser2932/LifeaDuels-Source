/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerChangedWorldEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package me.lifea.visibility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.spawn.SpawnManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.spectate.SpectateSession;
import me.lifea.util.TabRole;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class MatchVisibilityManager
implements Listener {
    private static final Map<UUID, Set<UUID>> matchPlayers = new ConcurrentHashMap<UUID, Set<UUID>>();
    private static final Map<UUID, Map<UUID, Boolean>> visibilityCache = new ConcurrentHashMap<UUID, Map<UUID, Boolean>>();
    private static BukkitTask refreshTask;
    private static volatile boolean fullRefreshNeeded;
    private static volatile boolean needsRefresh;
    private static final Set<UUID> pendingRestore;
    private static final Map<UUID, Set<UUID>> recentOpponents;
    private static final Map<UUID, Set<UUID>> nearbySelection;
    private static final int DEFAULT_NEARBY_CHUNKS = 8;
    private static final int DEFAULT_NEARBY_LIMIT = 25;

    private MatchVisibilityManager() {
    }

    private static UUID getMatchIdOrNull(UUID playerId) {
        Match match = MatchManager.getMatch(playerId);
        if (match != null && match.isActive()) {
            return match.getMatchId();
        }
        DuelSession duelSession = DuelSession.getSession(playerId);
        if (duelSession != null && !duelSession.isEnded()) {
            return duelSession.getMatch().getMatchId();
        }
        PartyDuelSession partySession = PartyDuelSession.getSession(playerId);
        return partySession != null && !partySession.isEnded() ? partySession.getMatch().getMatchId() : null;
    }

    private static boolean canSee(UUID viewerId, UUID targetId) {
        SpectateSession viewerSession;
        Player targetOfTarget;
        if (viewerId.equals(targetId)) {
            return true;
        }
        UUID viewerMatchId = MatchVisibilityManager.getMatchIdOrNull(viewerId);
        UUID targetMatchId = MatchVisibilityManager.getMatchIdOrNull(targetId);
        SpectateSession targetSession = SpectateManager.getSession(targetId);
        UUID targetEffectiveMatchId = targetMatchId;
        if (targetMatchId == null && targetSession != null && (targetOfTarget = Bukkit.getPlayer((UUID)targetSession.getTargetId())) != null) {
            targetEffectiveMatchId = MatchVisibilityManager.getMatchIdOrNull(targetOfTarget.getUniqueId());
        }
        if ((viewerSession = SpectateManager.getSession(viewerId)) != null) {
            UUID viewerSpectateMatchId;
            Player viewerTarget = Bukkit.getPlayer((UUID)viewerSession.getTargetId());
            if (viewerTarget != null && (viewerSpectateMatchId = MatchVisibilityManager.getMatchIdOrNull(viewerTarget.getUniqueId())) != null) {
                UUID targetTargetMatchId;
                Player targetTarget;
                if (viewerSpectateMatchId.equals(targetEffectiveMatchId)) {
                    return true;
                }
                if (targetEffectiveMatchId == null && targetSession != null && (targetTarget = Bukkit.getPlayer((UUID)targetSession.getTargetId())) != null && viewerSpectateMatchId.equals(targetTargetMatchId = MatchVisibilityManager.getMatchIdOrNull(targetTarget.getUniqueId()))) {
                    return true;
                }
            }
            return false;
        }
        if (viewerMatchId != null) {
            return viewerMatchId.equals(targetEffectiveMatchId);
        }
        Player viewer = Bukkit.getPlayer((UUID)viewerId);
        Player target = Bukkit.getPlayer((UUID)targetId);
        if (viewer != null && target != null && MatchVisibilityManager.isLobbyPlayer(viewer) && MatchVisibilityManager.isLobbyPlayer(target)) {
            if (MatchVisibilityManager.isRecentOpponent(viewerId, targetId)) {
                return true;
            }
            return MatchVisibilityManager.isNearbySelected(viewer, target);
        }
        return true;
    }

    private static boolean isLobbyPlayer(Player player) {
        return SpawnManager.isMainWorld(player) && MatchVisibilityManager.getMatchIdOrNull(player.getUniqueId()) == null && !SpectateManager.isSpectating(player.getUniqueId());
    }

    private static boolean isRecentOpponent(UUID viewer, UUID target) {
        Set<UUID> opponents = recentOpponents.get(viewer);
        return opponents != null && opponents.contains(target);
    }

    private static int nearbyChunkRadius() {
        return Math.max(0, ConfigManager.config().getInt("nearby-players.chunks", 8));
    }

    private static int nearbyPlayerLimit() {
        return Math.max(0, ConfigManager.config().getInt("nearby-players.limit", 25));
    }

    private static boolean isWithinNearbyChunks(Player viewer, Player target) {
        if (!viewer.getWorld().equals((Object)target.getWorld())) {
            return false;
        }
        int radius = MatchVisibilityManager.nearbyChunkRadius();
        return Math.abs(viewer.getLocation().getChunk().getX() - target.getLocation().getChunk().getX()) <= radius && Math.abs(viewer.getLocation().getChunk().getZ() - target.getLocation().getChunk().getZ()) <= radius;
    }

    private static boolean isNearbySelected(Player viewer, Player target) {
        if (!MatchVisibilityManager.isWithinNearbyChunks(viewer, target)) {
            return false;
        }
        UUID viewerId = viewer.getUniqueId();
        Set<UUID> selected = nearbySelection.get(viewerId);
        if (selected == null) {
            MatchVisibilityManager.refreshNearbySelection(viewer, false);
            selected = nearbySelection.get(viewerId);
        }
        return selected != null && selected.contains(target.getUniqueId());
    }

    private static void refreshNearbySelection(Player viewer, boolean randomize) {
        if (!MatchVisibilityManager.isLobbyPlayer(viewer)) {
            nearbySelection.remove(viewer.getUniqueId());
            return;
        }
        UUID viewerId = viewer.getUniqueId();
        int limit = MatchVisibilityManager.nearbyPlayerLimit();
        ArrayList<Player> candidates = new ArrayList<Player>();
        for (Player candidate2 : Bukkit.getOnlinePlayers()) {
            if (candidate2.equals((Object)viewer) || !MatchVisibilityManager.isLobbyPlayer(candidate2) || !MatchVisibilityManager.isWithinNearbyChunks(viewer, candidate2)) continue;
            candidates.add(candidate2);
        }
        HashSet<UUID> selected = new HashSet<UUID>();
        Set<UUID> previous = nearbySelection.get(viewerId);
        if (!randomize && previous != null) {
            for (Player player : candidates) {
                if (selected.size() >= limit) break;
                if (!previous.contains(player.getUniqueId())) continue;
                selected.add(player.getUniqueId());
            }
        }
        if (ConfigManager.config().getBoolean("nearby-players.randomize", true)) {
            if (!randomize && previous != null) {
                ArrayList<Player> newCandidates = new ArrayList<Player>();
                for (Player candidate4 : candidates) {
                    if (selected.contains(candidate4.getUniqueId())) continue;
                    newCandidates.add(candidate4);
                }
                Collections.shuffle(newCandidates);
                for (Player candidate2 : newCandidates) {
                    if (selected.size() < limit) {
                        selected.add(candidate2.getUniqueId());
                        continue;
                    }
                    break;
                }
            } else {
                Collections.shuffle(candidates);
                for (Player player : candidates) {
                    if (selected.size() < limit) {
                        selected.add(player.getUniqueId());
                        continue;
                    }
                    break;
                }
            }
        } else {
            candidates.sort(Comparator.comparingDouble(candidate -> candidate.getLocation().distanceSquared(viewer.getLocation())));
            selected.clear();
            for (Player player : candidates) {
                if (selected.size() < limit) {
                    selected.add(player.getUniqueId());
                    continue;
                }
                break;
            }
        }
        nearbySelection.put(viewerId, selected);
    }

    public static void rememberDuelOpponents(Map<UUID, Set<UUID>> opponentsByPlayer) {
        if (opponentsByPlayer == null) {
            return;
        }
        opponentsByPlayer.forEach((playerId, opponents) -> {
            if (playerId != null) {
                ConcurrentHashMap.KeySetView stored = ConcurrentHashMap.newKeySet();
                if (opponents != null) {
                    stored.addAll(opponents);
                }
                recentOpponents.put((UUID)playerId, stored);
            }
        });
        MatchVisibilityManager.scheduleFullRefresh();
    }

    public static void rememberDuelOpponents(UUID playerOne, UUID playerTwo) {
        ConcurrentHashMap<UUID, Set<UUID>> opponents = new ConcurrentHashMap<UUID, Set<UUID>>();
        opponents.put(playerOne, Set.of(playerTwo));
        opponents.put(playerTwo, Set.of(playerOne));
        MatchVisibilityManager.rememberDuelOpponents(opponents);
    }

    public static void applyRole(Player player, Match match, TabRole role) {
        if (player != null && match != null && role != null) {
            UUID matchId = match.getMatchId();
            matchPlayers.computeIfAbsent(matchId, k -> new CopyOnWriteArraySet()).add(player.getUniqueId());
            MatchVisibilityManager.scheduleFullRefresh();
        }
    }

    public static void reset(Player player) {
        if (player != null) {
            UUID playerId = player.getUniqueId();
            for (Set<UUID> set : matchPlayers.values()) {
                set.remove(playerId);
            }
            visibilityCache.remove(playerId);
            for (Map map : visibilityCache.values()) {
                map.remove(playerId);
            }
            visibilityCache.entrySet().removeIf(e -> ((Map)e.getValue()).isEmpty());
            pendingRestore.add(playerId);
            MatchVisibilityManager.scheduleFullRefresh();
            if (player.isOnline()) {
                MatchVisibilityManager.updatePlayer(player);
            }
        }
    }

    public static void dispose(Match match) {
        if (match != null) {
            UUID matchId = match.getMatchId();
            Set<UUID> members = matchPlayers.remove(matchId);
            if (members != null) {
                for (UUID uUID : members) {
                    visibilityCache.remove(uUID);
                }
                for (Map map : visibilityCache.values()) {
                    for (UUID memberId : members) {
                        map.remove(memberId);
                    }
                }
                pendingRestore.addAll(members);
            }
            visibilityCache.entrySet().removeIf(e -> ((Map)e.getValue()).isEmpty());
            MatchVisibilityManager.scheduleFullRefresh();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.isOnline()) continue;
                MatchVisibilityManager.updatePlayer(player);
            }
        }
    }

    public static void updateAll() {
        MatchVisibilityManager.scheduleFullRefresh();
    }

    private static void updatePlayer(Player viewer) {
        if (viewer != null && viewer.isOnline()) {
            UUID viewerId = viewer.getUniqueId();
            Map viewerCache = visibilityCache.computeIfAbsent(viewerId, k -> new ConcurrentHashMap());
            for (Player target : Bukkit.getOnlinePlayers()) {
                if (viewer.equals((Object)target)) continue;
                UUID targetId = target.getUniqueId();
                boolean visible = MatchVisibilityManager.canSee(viewerId, targetId);
                Boolean previous = (Boolean)viewerCache.get(targetId);
                if (previous != null && previous == visible) continue;
                viewerCache.put(targetId, visible);
                try {
                    if (visible) {
                        viewer.showEntity((Plugin)Lifea.getInstance(), (Entity)target);
                        continue;
                    }
                    viewer.hideEntity((Plugin)Lifea.getInstance(), (Entity)target);
                }
                catch (Exception exception) {}
            }
        }
    }

    private static void processScheduledRefresh() {
        block4: {
            if (!needsRefresh && !fullRefreshNeeded) break block4;
            boolean wasFullRefresh = fullRefreshNeeded;
            needsRefresh = false;
            fullRefreshNeeded = false;
            if (wasFullRefresh) {
                for (Player viewer : Bukkit.getOnlinePlayers()) {
                    MatchVisibilityManager.refreshNearbySelection(viewer, false);
                    MatchVisibilityManager.updatePlayer(viewer);
                    pendingRestore.remove(viewer.getUniqueId());
                }
            } else {
                for (Player viewer : Bukkit.getOnlinePlayers()) {
                    UUID viewerId = viewer.getUniqueId();
                    if (MatchVisibilityManager.getMatchIdOrNull(viewerId) == null && !SpectateManager.isSpectating(viewerId) && !visibilityCache.containsKey(viewerId) && !pendingRestore.contains(viewerId)) continue;
                    MatchVisibilityManager.refreshNearbySelection(viewer, false);
                    MatchVisibilityManager.updatePlayer(viewer);
                    pendingRestore.remove(viewerId);
                }
            }
        }
    }

    private static void scheduleRefresh() {
        needsRefresh = true;
    }

    private static void scheduleFullRefresh() {
        fullRefreshNeeded = true;
        needsRefresh = true;
    }

    public static void start() {
        Lifea plugin = Lifea.getInstance();
        if (plugin != null) {
            plugin.getServer().getPluginManager().registerEvents((Listener)new MatchVisibilityManager(), (Plugin)plugin);
            refreshTask = plugin.getServer().getScheduler().runTaskTimer((Plugin)plugin, MatchVisibilityManager::processScheduledRefresh, 20L, 40L);
        }
    }

    public static void stop() {
        if (refreshTask != null) {
            refreshTask.cancel();
            refreshTask = null;
        }
        matchPlayers.clear();
        visibilityCache.clear();
        recentOpponents.clear();
        nearbySelection.clear();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Lifea.getInstance().getServer().getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (event.getPlayer().isOnline()) {
                MatchVisibilityManager.refreshNearbySelection(event.getPlayer(), true);
                MatchVisibilityManager.updatePlayer(event.getPlayer());
                MatchVisibilityManager.scheduleFullRefresh();
            }
        }, 5L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        Lifea.getInstance().getServer().getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (player.isOnline()) {
                if (SpawnManager.isMainWorld(player)) {
                    MatchVisibilityManager.refreshNearbySelection(player, true);
                } else {
                    nearbySelection.remove(player.getUniqueId());
                }
                MatchVisibilityManager.scheduleFullRefresh();
            }
        }, 1L);
    }

    @EventHandler
    public void onChunkChange(PlayerMoveEvent event) {
        if (event.getTo() != null && (event.getFrom().getWorld() != event.getTo().getWorld() || event.getFrom().getChunk().getX() != event.getTo().getChunk().getX() || event.getFrom().getChunk().getZ() != event.getTo().getChunk().getZ())) {
            MatchVisibilityManager.scheduleFullRefresh();
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID quitterId = event.getPlayer().getUniqueId();
        for (Set<UUID> set : matchPlayers.values()) {
            set.remove(quitterId);
        }
        visibilityCache.remove(quitterId);
        nearbySelection.remove(quitterId);
        recentOpponents.remove(quitterId);
        for (Map map : visibilityCache.values()) {
            map.remove(quitterId);
        }
        MatchVisibilityManager.scheduleFullRefresh();
    }

    static {
        fullRefreshNeeded = false;
        needsRefresh = false;
        pendingRestore = ConcurrentHashMap.newKeySet();
        recentOpponents = new ConcurrentHashMap<UUID, Set<UUID>>();
        nearbySelection = new ConcurrentHashMap<UUID, Set<UUID>>();
    }
}

