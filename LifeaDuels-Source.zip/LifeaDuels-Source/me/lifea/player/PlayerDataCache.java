/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.player;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerDataCache {
    private static final ConcurrentHashMap<UUID, Boolean> ensuredElo = new ConcurrentHashMap();
    private static final ConcurrentHashMap<UUID, Boolean> ensuredStats = new ConcurrentHashMap();

    private PlayerDataCache() {
    }

    public static boolean isEloEnsured(UUID uuid) {
        return ensuredElo.containsKey(uuid);
    }

    public static void markEloEnsured(UUID uuid) {
        ensuredElo.put(uuid, Boolean.TRUE);
    }

    public static boolean isStatsEnsured(UUID uuid) {
        return ensuredStats.containsKey(uuid);
    }

    public static void markStatsEnsured(UUID uuid) {
        ensuredStats.put(uuid, Boolean.TRUE);
    }

    public static void evict(UUID uuid) {
        ensuredElo.remove(uuid);
        ensuredStats.remove(uuid);
    }

    public static void clearAll() {
        ensuredElo.clear();
        ensuredStats.clear();
    }
}

