/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package me.lifea.player;

import java.util.Locale;
import java.util.UUID;
import me.lifea.player.CachedPlayer;
import me.lifea.player.PlayerCache;
import me.lifea.storage.AsyncQueue;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PlayerSettingsManager {
    public static boolean get(UUID uuid, Setting setting) {
        return PlayerCache.get(uuid).map(cp -> PlayerSettingsManager.resolveFromCachedPlayer(cp, setting)).orElse(setting.defaultValue());
    }

    public static void preload(UUID uuid) {
        Player p = Bukkit.getPlayer((UUID)uuid);
        PlayerCache.loadAsync(uuid, p != null ? p.getName() : null);
    }

    public static void set(UUID uuid, Setting setting, boolean value) {
        AsyncQueue.executeUpdate("INSERT OR IGNORE INTO player_settings (uuid) VALUES (?)", uuid.toString());
        String var10000 = setting.column();
        AsyncQueue.executeUpdate("UPDATE player_settings SET " + var10000 + "=? WHERE uuid=?", value ? 1 : 0, uuid.toString());
        PlayerCache.get(uuid).ifPresent(cp -> {
            switch (setting.ordinal()) {
                case 0: {
                    cp.setDuelRequests(value);
                    break;
                }
                case 1: {
                    cp.setScoreboard(value);
                    break;
                }
                case 2: {
                    cp.setAutoGG(value);
                    break;
                }
                case 3: {
                    cp.setPrivateMessages(value);
                    break;
                }
                case 4: {
                    cp.setChatMentions(value);
                    break;
                }
                case 5: {
                    cp.setPartyInvites(value);
                    break;
                }
                case 6: {
                    cp.setHealthIndicator(value);
                    break;
                }
                case 7: {
                    cp.setElytra(value);
                    break;
                }
                case 8: {
                    cp.setChatIsolation(value);
                    break;
                }
                case 9: {
                    cp.setPingDisplay(value);
                }
            }
        });
    }

    public static boolean getPingDisplay(UUID uuid) {
        return PlayerSettingsManager.get(uuid, Setting.PING_DISPLAY);
    }

    public static PingRange getPingRange(UUID uuid) {
        String key = PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getPingRange).orElse("ALL");
        return PingRange.fromKey(key);
    }

    public static void setPingRange(Player player, PingRange range) {
        if (player == null || range == null) {
            return;
        }
        UUID uuid = player.getUniqueId();
        PlayerCache.getOrLoadSync(uuid).ifPresent(cp -> cp.setPingRange(range.name()));
        AsyncQueue.executeUpdate("INSERT OR IGNORE INTO player_settings (uuid) VALUES (?)", uuid.toString());
        AsyncQueue.executeUpdate("UPDATE player_settings SET ping_range=? WHERE uuid=?", range.name(), uuid.toString());
    }

    public static void evict(UUID uuid) {
    }

    public static TimeOfDay getTimeOfDay(UUID uuid) {
        String key = PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getTimeOfDay).orElse("DEFAULT");
        return TimeOfDay.fromKey(key);
    }

    public static void setTimeOfDay(Player player, TimeOfDay timeOfDay) {
        if (player == null || timeOfDay == null) {
            return;
        }
        UUID uuid = player.getUniqueId();
        PlayerCache.getOrLoadSync(uuid).ifPresent(cp -> cp.setTimeOfDay(timeOfDay.name()));
        AsyncQueue.executeUpdate("INSERT OR IGNORE INTO player_settings (uuid) VALUES (?)", uuid.toString());
        AsyncQueue.executeUpdate("UPDATE player_settings SET time_of_day=? WHERE uuid=?", timeOfDay.name(), uuid.toString());
        PlayerSettingsManager.applyTimeOfDay(player, timeOfDay.name());
    }

    public static void applyTimeOfDay(Player player, String key) {
        if (player == null || !player.isOnline()) {
            return;
        }
        TimeOfDay timeOfDay = TimeOfDay.fromKey(key);
        if (timeOfDay == TimeOfDay.DEFAULT) {
            player.resetPlayerTime();
        } else {
            player.setPlayerTime(timeOfDay.ticks(), false);
        }
    }

    private static boolean resolveFromCachedPlayer(CachedPlayer cp, Setting setting) {
        return switch (setting.ordinal()) {
            case 0 -> cp.isDuelRequests();
            case 1 -> cp.isScoreboard();
            case 2 -> cp.isAutoGG();
            case 3 -> cp.isPrivateMessages();
            case 4 -> cp.isChatMentions();
            case 5 -> cp.isPartyInvites();
            case 6 -> cp.isHealthIndicator();
            case 7 -> cp.isElytra();
            case 8 -> cp.isChatIsolation();
            case 9 -> cp.isPingDisplay();
            default -> throw new MatchException(null, null);
        };
    }

    public static final class Setting
    extends Enum<Setting> {
        public static final /* enum */ Setting DUEL_REQUESTS = new Setting("duel_requests");
        public static final /* enum */ Setting SCOREBOARD = new Setting("scoreboard");
        public static final /* enum */ Setting AUTO_GG = new Setting("auto_gg", false);
        public static final /* enum */ Setting PRIVATE_MESSAGES = new Setting("private_messages");
        public static final /* enum */ Setting CHAT_MENTIONS = new Setting("chat_mentions");
        public static final /* enum */ Setting PARTY_INVITES = new Setting("party_invites");
        public static final /* enum */ Setting HEALTH_INDICATOR = new Setting("health_indicator");
        public static final /* enum */ Setting ELYTRA = new Setting("elytra");
        public static final /* enum */ Setting CHAT_ISOLATION = new Setting("chat_isolation", false);
        public static final /* enum */ Setting PING_DISPLAY = new Setting("ping_display", false);
        private final String column;
        private final boolean defaultValue;
        private static final /* synthetic */ Setting[] $VALUES;

        public static Setting[] values() {
            return (Setting[])$VALUES.clone();
        }

        public static Setting valueOf(String name) {
            return Enum.valueOf(Setting.class, name);
        }

        private Setting(String column) {
            this.column = column;
            this.defaultValue = true;
        }

        private Setting(String column, boolean defaultValue) {
            this.column = column;
            this.defaultValue = defaultValue;
        }

        public String column() {
            return this.column;
        }

        public boolean defaultValue() {
            return this.defaultValue;
        }

        private static Setting[] $values() {
            return new Setting[]{DUEL_REQUESTS, SCOREBOARD, AUTO_GG, PRIVATE_MESSAGES, CHAT_MENTIONS, PARTY_INVITES, HEALTH_INDICATOR, ELYTRA, CHAT_ISOLATION, PING_DISPLAY};
        }

        private static /* synthetic */ Setting[] $values$() {
            return new Setting[]{DUEL_REQUESTS, SCOREBOARD, AUTO_GG, PRIVATE_MESSAGES, CHAT_MENTIONS, PARTY_INVITES, HEALTH_INDICATOR, ELYTRA, CHAT_ISOLATION, PING_DISPLAY};
        }

        static {
            $VALUES = Setting.$values$();
        }
    }

    public static enum PingRange {
        MS_30_50("0-50ms", 0, 50),
        MS_60_90("60-90ms", 60, 90),
        MS_90_120("90-120ms", 90, 120),
        MS_120_250("120-250ms", 120, 250),
        ALL("All of Above", 0, Integer.MAX_VALUE);

        private final String displayName;
        private final int min;
        private final int max;

        private PingRange(String displayName, int min, int max) {
            this.displayName = displayName;
            this.min = min;
            this.max = max;
        }

        public String displayName() {
            return this.displayName;
        }

        public boolean matches(int ping) {
            return this == ALL || ping >= this.min && ping <= this.max;
        }

        public static PingRange fromKey(String key) {
            if (key != null) {
                try {
                    return PingRange.valueOf(key.toUpperCase(Locale.ROOT));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    // empty catch block
                }
            }
            return ALL;
        }
    }

    public static enum TimeOfDay {
        DEFAULT("Default", -1L),
        DAYTIME("DayTime", 6000L),
        DUSK("Dusk", 12000L),
        NIGHT_TIME("Night Time", 18000L),
        SUNRISE("SunRise", 23000L);

        private final String displayName;
        private final long ticks;

        private TimeOfDay(String displayName, long ticks) {
            this.displayName = displayName;
            this.ticks = ticks;
        }

        public String displayName() {
            return this.displayName;
        }

        public long ticks() {
            return this.ticks;
        }

        public String sprite() {
            return switch (this.ordinal()) {
                default -> throw new MatchException(null, null);
                case 0 -> "item/clock_00";
                case 1 -> "\u2600";
                case 2 -> "item/orange_dye";
                case 3 -> "item/ender_eye";
                case 4 -> "item/glowstone_dust";
            };
        }

        public static TimeOfDay fromKey(String key) {
            if (key != null) {
                try {
                    return TimeOfDay.valueOf(key.toUpperCase(Locale.ROOT));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    // empty catch block
                }
            }
            return DEFAULT;
        }
    }
}

