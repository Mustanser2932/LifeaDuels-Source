/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.player;

import java.util.EnumSet;
import java.util.UUID;

public final class CachedPlayer {
    private final UUID uuid;
    private String username;
    private int matches = 0;
    private int wins = 0;
    private int losses = 0;
    private int kills = 0;
    private int deaths = 0;
    private int winstreak = 0;
    private int beststreak = 0;
    private boolean duelRequests = true;
    private boolean scoreboard = true;
    private boolean autoGG = true;
    private boolean privateMessages = true;
    private boolean chatMentions = true;
    private boolean partyInvites = true;
    private boolean healthIndicator = true;
    private boolean elytra = true;
    private boolean chatIsolation = false;
    private String timeOfDay = "DEFAULT";
    private boolean pingDisplay = false;
    private String pingRange = "ALL";
    private final EnumSet<DirtyFlag> dirty = EnumSet.noneOf(DirtyFlag.class);
    private volatile long lastAccessedAt = System.currentTimeMillis();

    public CachedPlayer(UUID uuid, String username) {
        this.uuid = uuid;
        this.username = username;
    }

    public void touch() {
        this.lastAccessedAt = System.currentTimeMillis();
    }

    public long getLastAccessedAt() {
        return this.lastAccessedAt;
    }

    public UUID getUuid() {
        return this.uuid;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getMatches() {
        return this.matches;
    }

    public void setMatches(int matches) {
        this.matches = matches;
        this.dirty.add(DirtyFlag.STATS);
    }

    public int getWins() {
        return this.wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
        this.dirty.add(DirtyFlag.STATS);
    }

    public int getLosses() {
        return this.losses;
    }

    public void setLosses(int losses) {
        this.losses = losses;
        this.dirty.add(DirtyFlag.STATS);
    }

    public int getKills() {
        return this.kills;
    }

    public void setKills(int kills) {
        this.kills = kills;
        this.dirty.add(DirtyFlag.STATS);
    }

    public int getDeaths() {
        return this.deaths;
    }

    public void setDeaths(int deaths) {
        this.deaths = deaths;
        this.dirty.add(DirtyFlag.STATS);
    }

    public int getWinstreak() {
        return this.winstreak;
    }

    public void setWinstreak(int winstreak) {
        this.winstreak = winstreak;
        this.dirty.add(DirtyFlag.STATS);
    }

    public int getBeststreak() {
        return this.beststreak;
    }

    public void setBeststreak(int beststreak) {
        this.beststreak = beststreak;
        this.dirty.add(DirtyFlag.STATS);
    }

    public void addWin() {
        ++this.wins;
        ++this.matches;
        ++this.winstreak;
        this.beststreak = Math.max(this.beststreak, this.winstreak);
        this.dirty.add(DirtyFlag.STATS);
    }

    public void addLoss() {
        ++this.losses;
        ++this.matches;
        this.winstreak = 0;
        this.dirty.add(DirtyFlag.STATS);
    }

    public void addKill() {
        ++this.kills;
        this.dirty.add(DirtyFlag.STATS);
    }

    public void addDeath() {
        ++this.deaths;
        this.dirty.add(DirtyFlag.STATS);
    }

    public boolean isDuelRequests() {
        return this.duelRequests;
    }

    public void setDuelRequests(boolean v) {
        this.duelRequests = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isScoreboard() {
        return this.scoreboard;
    }

    public void setScoreboard(boolean v) {
        this.scoreboard = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isAutoGG() {
        return this.autoGG;
    }

    public void setAutoGG(boolean v) {
        this.autoGG = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isPrivateMessages() {
        return this.privateMessages;
    }

    public void setPrivateMessages(boolean v) {
        this.privateMessages = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isChatMentions() {
        return this.chatMentions;
    }

    public void setChatMentions(boolean v) {
        this.chatMentions = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isPartyInvites() {
        return this.partyInvites;
    }

    public void setPartyInvites(boolean v) {
        this.partyInvites = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isHealthIndicator() {
        return this.healthIndicator;
    }

    public void setHealthIndicator(boolean v) {
        this.healthIndicator = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isElytra() {
        return this.elytra;
    }

    public void setElytra(boolean v) {
        this.elytra = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isChatIsolation() {
        return this.chatIsolation;
    }

    public void setChatIsolation(boolean v) {
        this.chatIsolation = v;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public String getTimeOfDay() {
        return this.timeOfDay;
    }

    public void setTimeOfDay(String timeOfDay) {
        this.timeOfDay = timeOfDay == null ? "DEFAULT" : timeOfDay;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isPingDisplay() {
        return this.pingDisplay;
    }

    public void setPingDisplay(boolean pingDisplay) {
        this.pingDisplay = pingDisplay;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public String getPingRange() {
        return this.pingRange;
    }

    public void setPingRange(String pingRange) {
        this.pingRange = pingRange == null ? "ALL" : pingRange;
        this.dirty.add(DirtyFlag.SETTINGS);
    }

    public boolean isDirty() {
        return !this.dirty.isEmpty();
    }

    public boolean isDirty(DirtyFlag flag) {
        return this.dirty.contains((Object)flag);
    }

    public void markClean() {
        this.dirty.clear();
    }

    public void markClean(DirtyFlag flag) {
        this.dirty.remove((Object)flag);
    }

    public static final class DirtyFlag
    extends Enum<DirtyFlag> {
        public static final /* enum */ DirtyFlag STATS = new DirtyFlag();
        public static final /* enum */ DirtyFlag SETTINGS = new DirtyFlag();
        private static final /* synthetic */ DirtyFlag[] $VALUES;

        public static DirtyFlag[] values() {
            return (DirtyFlag[])$VALUES.clone();
        }

        public static DirtyFlag valueOf(String name) {
            return Enum.valueOf(DirtyFlag.class, name);
        }

        private static DirtyFlag[] $values() {
            return new DirtyFlag[]{STATS, SETTINGS};
        }

        private static DirtyFlag[] $values$() {
            return new DirtyFlag[]{STATS, SETTINGS};
        }

        private static /* synthetic */ DirtyFlag[] $values$$() {
            return new DirtyFlag[]{STATS, SETTINGS};
        }

        static {
            $VALUES = DirtyFlag.$values$$();
        }
    }
}

