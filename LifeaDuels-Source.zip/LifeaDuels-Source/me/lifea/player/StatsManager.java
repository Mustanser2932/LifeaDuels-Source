/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Statistic
 *  org.bukkit.entity.Player
 */
package me.lifea.player;

import java.util.UUID;
import me.lifea.player.CachedPlayer;
import me.lifea.player.PlayerCache;
import me.lifea.player.PlayerDataCache;
import me.lifea.storage.AsyncQueue;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;

public class StatsManager {
    public static void load() {
    }

    public static void shutdown() {
    }

    public static void evictCache(UUID uuid) {
    }

    public static void preload(UUID uuid) {
        Player p = Bukkit.getPlayer((UUID)uuid);
        PlayerCache.loadAsync(uuid, p != null ? p.getName() : null);
    }

    public static int getCachedWins(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getWins).orElse(0);
    }

    public static int getCachedLosses(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getLosses).orElse(0);
    }

    public static int getCachedKills(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getKills).orElse(0);
    }

    public static int getCachedDeaths(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getDeaths).orElse(0);
    }

    public static int getCachedWinStreak(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getWinstreak).orElse(0);
    }

    public static int getCachedBestStreak(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getBeststreak).orElse(0);
    }

    public static int getCachedMatches(UUID uuid) {
        return PlayerCache.get(uuid).map(CachedPlayer::getMatches).orElse(0);
    }

    public static double getCachedKDR(UUID uuid) {
        return StatsManager.kdr(StatsManager.getCachedKills(uuid), StatsManager.getCachedDeaths(uuid));
    }

    public static int getWins(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getWins).orElse(0);
    }

    public static int getLosses(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getLosses).orElse(0);
    }

    public static int getKills(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getKills).orElse(0);
    }

    public static int getDeaths(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getDeaths).orElse(0);
    }

    public static int getWinStreak(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getWinstreak).orElse(0);
    }

    public static int getBestStreak(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getBeststreak).orElse(0);
    }

    public static int getMatches(UUID uuid) {
        return PlayerCache.getOrLoadSync(uuid).map(CachedPlayer::getMatches).orElse(0);
    }

    public static double getKDR(UUID uuid) {
        return StatsManager.kdr(StatsManager.getKills(uuid), StatsManager.getDeaths(uuid));
    }

    private static double kdr(int kills, int deaths) {
        return deaths <= 0 ? (double)kills : (double)Math.round((double)kills / (double)deaths * 100.0) / 100.0;
    }

    public static int getStat(UUID uuid, String stat) {
        return switch (stat.toLowerCase()) {
            case "wins" -> StatsManager.getWins(uuid);
            case "losses" -> StatsManager.getLosses(uuid);
            case "kills" -> StatsManager.getKills(uuid);
            case "deaths" -> StatsManager.getDeaths(uuid);
            case "winstreak", "win_streak" -> StatsManager.getWinStreak(uuid);
            case "beststreak", "best_streak" -> StatsManager.getBestStreak(uuid);
            case "matches" -> StatsManager.getMatches(uuid);
            default -> 0;
        };
    }

    public static double getWinRate(UUID uuid) {
        int matches = StatsManager.getMatches(uuid);
        return matches == 0 ? 0.0 : (double)Math.round((double)StatsManager.getWins(uuid) / (double)matches * 1000.0) / 10.0;
    }

    public static void addWin(UUID uuid) {
        StatsManager.ensureRow(uuid);
        PlayerCache.get(uuid).ifPresent(cp -> {
            cp.addWin();
            PlayerCache.saveAsync(cp);
        });
    }

    public static void addLoss(UUID uuid) {
        StatsManager.ensureRow(uuid);
        PlayerCache.get(uuid).ifPresent(cp -> {
            cp.addLoss();
            PlayerCache.saveAsync(cp);
        });
    }

    public static void addKill(UUID uuid) {
        StatsManager.ensureRow(uuid);
        PlayerCache.get(uuid).ifPresent(cp -> {
            cp.addKill();
            PlayerCache.saveAsync(cp);
        });
        StatsManager.incrementStat(uuid, Statistic.PLAYER_KILLS);
    }

    public static void addDeath(UUID uuid) {
        StatsManager.ensureRow(uuid);
        PlayerCache.get(uuid).ifPresent(cp -> {
            cp.addDeath();
            PlayerCache.saveAsync(cp);
        });
        StatsManager.incrementStat(uuid, Statistic.DEATHS);
    }

    private static void incrementStat(UUID uuid, Statistic stat) {
        Player p = Bukkit.getPlayer((UUID)uuid);
        if (p != null) {
            p.incrementStatistic(stat);
        }
    }

    public static void resetAll() {
        AsyncQueue.executeUpdate("DELETE FROM stats", new Object[0]);
        PlayerCache.resetAllStats();
    }

    public static void resetPlayer(UUID uuid) {
        AsyncQueue.executeUpdate("DELETE FROM stats WHERE uuid=?", uuid.toString());
        PlayerCache.resetStats(uuid);
    }

    private static void ensureRow(UUID uuid) {
        if (!PlayerDataCache.isStatsEnsured(uuid)) {
            PlayerDataCache.markStatsEnsured(uuid);
            AsyncQueue.executeUpdate("INSERT OR IGNORE INTO stats(uuid, wins, losses, kills, deaths, winstreak, beststreak, matches) VALUES (?, 0, 0, 0, 0, 0, 0, 0)", uuid.toString());
        }
    }
}

