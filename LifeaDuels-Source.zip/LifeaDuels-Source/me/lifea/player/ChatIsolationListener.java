/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 */
package me.lifea.player;

import java.util.Set;
import java.util.UUID;
import me.lifea.duel.DuelSession;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.spectate.SpectateSession;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public final class ChatIsolationListener
implements Listener {
    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        MatchScope senderScope = ChatIsolationListener.scopeOf(sender.getUniqueId());
        boolean senderIsolated = senderScope != null && PlayerSettingsManager.get(sender.getUniqueId(), PlayerSettingsManager.Setting.CHAT_ISOLATION);
        Set recipients = event.getRecipients();
        recipients.removeIf(recipient -> {
            boolean recipientIsolated;
            MatchScope recipientScope = ChatIsolationListener.scopeOf(recipient.getUniqueId());
            boolean bl = recipientIsolated = recipientScope != null && PlayerSettingsManager.get(recipient.getUniqueId(), PlayerSettingsManager.Setting.CHAT_ISOLATION);
            if (senderIsolated) {
                return !senderScope.equals(recipientScope);
            }
            return recipientIsolated && !ChatIsolationListener.senderScopeEquals(senderScope, recipientScope);
        });
    }

    private static boolean senderScopeEquals(MatchScope senderScope, MatchScope recipientScope) {
        return senderScope != null && senderScope.equals(recipientScope);
    }

    private static MatchScope scopeOf(UUID uuid) {
        DuelSession duel = DuelSession.getSession(uuid);
        if (duel != null && duel.getMatch() != null) {
            return new MatchScope(duel.getMatch().getMatchId());
        }
        PartyDuelSession partyDuel = PartyDuelSession.getSession(uuid);
        if (partyDuel != null && partyDuel.getMatch() != null) {
            return new MatchScope(partyDuel.getMatch().getMatchId());
        }
        SpectateSession spectator = SpectateManager.getSession(uuid);
        if (spectator != null) {
            return ChatIsolationListener.scopeOf(spectator.getTargetId());
        }
        return null;
    }

    private record MatchScope(UUID matchId) {
    }
}

