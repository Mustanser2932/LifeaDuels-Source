/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.player;

import java.util.Collection;
import java.util.UUID;
import me.lifea.duel.KitRulesListener;
import me.lifea.player.PlayerDataCache;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.StatsManager;

public final class PlayerCacheEvictor {
    private PlayerCacheEvictor() {
    }

    public static void evict(UUID uuid) {
        StatsManager.evictCache(uuid);
        PlayerSettingsManager.evict(uuid);
        PlayerDataCache.evict(uuid);
        KitRulesListener.clearPlayerKitCache(uuid);
    }

    public static void evictAll(Collection<UUID> uuids) {
        for (UUID uuid : uuids) {
            PlayerCacheEvictor.evict(uuid);
        }
    }
}

