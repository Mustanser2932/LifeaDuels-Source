/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 */
package me.lifea.player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.lifea.player.PlayerSettingsManager;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ChatMentionListener
implements Listener {
    private static final Map<String, UUID> NAME_TO_UUID = new ConcurrentHashMap<String, UUID>();

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        NAME_TO_UUID.put(p.getName().toLowerCase(), p.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        NAME_TO_UUID.remove(event.getPlayer().getName().toLowerCase());
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onChat(AsyncPlayerChatEvent event) {
        String message = event.getMessage();
        String messageLower = message.toLowerCase();
        boolean changed = false;
        for (Map.Entry<String, UUID> entry : NAME_TO_UUID.entrySet()) {
            Player online;
            UUID uuid;
            if (!messageLower.contains(entry.getKey()) || !PlayerSettingsManager.get(uuid = entry.getValue(), PlayerSettingsManager.Setting.CHAT_MENTIONS) || (online = Bukkit.getPlayer((UUID)uuid)) == null || !event.getRecipients().contains(online)) continue;
            String highlighted = "\u00a7r\u00a7e" + online.getName() + "\u00a7r";
            String regex = "(?i)" + Pattern.quote(online.getName());
            message = Pattern.compile(regex).matcher(message).replaceAll(Matcher.quoteReplacement(highlighted));
            changed = true;
            online.playSound(online.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
        }
        if (changed) {
            event.setMessage(message);
        }
    }
}

