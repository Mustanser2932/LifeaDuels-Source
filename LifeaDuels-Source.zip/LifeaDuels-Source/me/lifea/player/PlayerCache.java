/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.config.PerformanceConfig;
import me.lifea.player.CachedPlayer;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.storage.DataPool;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class PlayerCache {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final ConcurrentHashMap<UUID, CachedPlayer> cache = new ConcurrentHashMap();
    private static ScheduledExecutorService scheduler;
    private static final String UPSERT_STATS = "INSERT INTO stats (uuid, wins, losses, kills, deaths, winstreak, beststreak, matches) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(uuid) DO UPDATE SET wins=excluded.wins, losses=excluded.losses, kills=excluded.kills, deaths=excluded.deaths, winstreak=excluded.winstreak, beststreak=excluded.beststreak, matches=excluded.matches";
    private static final String UPSERT_SETTINGS = "INSERT INTO player_settings (uuid, duel_requests, scoreboard, auto_gg, private_messages, chat_mentions, party_invites, health_indicator, elytra, chat_isolation, time_of_day, ping_display, ping_range) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(uuid) DO UPDATE SET duel_requests=excluded.duel_requests, scoreboard=excluded.scoreboard, auto_gg=excluded.auto_gg, private_messages=excluded.private_messages, chat_mentions=excluded.chat_mentions, party_invites=excluded.party_invites, health_indicator=excluded.health_indicator, elytra=excluded.elytra, chat_isolation=excluded.chat_isolation, time_of_day=excluded.time_of_day, ping_display=excluded.ping_display, ping_range=excluded.ping_range";

    private PlayerCache() {
    }

    public static void init() {
        if (scheduler == null || scheduler.isShutdown()) {
            scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "Lifea-PlayerCache");
                t.setDaemon(true);
                return t;
            });
            scheduler.scheduleAtFixedRate(PlayerCache::maintain, 60L, 60L, TimeUnit.SECONDS);
        }
    }

    public static void shutdown() {
        if (scheduler != null) {
            scheduler.execute(PlayerCache::saveDirty);
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(5L, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            }
            catch (InterruptedException var1) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
            scheduler = null;
        }
        cache.clear();
    }

    public static Optional<CachedPlayer> get(UUID uuid) {
        CachedPlayer cp = cache.get(uuid);
        if (cp != null) {
            cp.touch();
        }
        return Optional.ofNullable(cp);
    }

    public static void loadAsync(UUID uuid, String name, Consumer<CachedPlayer> callback) {
        CachedPlayer existing = cache.get(uuid);
        if (existing != null) {
            existing.touch();
            if (callback != null) {
                callback.accept(existing);
            }
        } else {
            scheduler.execute(() -> {
                CachedPlayer cp = cache.computeIfAbsent(uuid, k -> {
                    CachedPlayer fresh = new CachedPlayer(uuid, name != null ? name : "Unknown");
                    PlayerCache.loadFromDb(fresh);
                    fresh.touch();
                    return fresh;
                });
                if (callback != null) {
                    Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> callback.accept(cp));
                }
            });
        }
    }

    public static void loadAsync(UUID uuid, String name) {
        PlayerCache.loadAsync(uuid, name, null);
    }

    public static void loadOnJoin(Player player) {
        PlayerCache.loadAsync(player.getUniqueId(), player.getName(), cp -> {
            if (!cp.isScoreboard()) {
                ScoreboardManager.remove(player);
            }
            PlayerSettingsManager.applyTimeOfDay(player, cp.getTimeOfDay());
        });
    }

    public static Optional<CachedPlayer> getOrLoadSync(UUID uuid) {
        CachedPlayer existing = cache.get(uuid);
        if (existing != null) {
            existing.touch();
            return Optional.of(existing);
        }
        String name = PlayerCache.resolveName(uuid);
        CachedPlayer cp = cache.computeIfAbsent(uuid, k -> {
            CachedPlayer fresh = new CachedPlayer(uuid, name);
            PlayerCache.loadFromDb(fresh);
            fresh.touch();
            return fresh;
        });
        return Optional.ofNullable(cp);
    }

    public static void resetStats(UUID uuid) {
        CachedPlayer cp = cache.get(uuid);
        if (cp != null) {
            PlayerCache.zeroStats(cp);
            PlayerCache.saveAsync(cp);
        }
    }

    public static void resetAllStats() {
        for (CachedPlayer cp : cache.values()) {
            PlayerCache.zeroStats(cp);
            if (!cp.isDirty()) continue;
            PlayerCache.saveAsync(cp);
        }
    }

    private static void zeroStats(CachedPlayer cp) {
        cp.setWins(0);
        cp.setLosses(0);
        cp.setKills(0);
        cp.setDeaths(0);
        cp.setWinstreak(0);
        cp.setBeststreak(0);
        cp.setMatches(0);
    }

    public static void remove(UUID uuid) {
        CachedPlayer cp = cache.remove(uuid);
        if (cp != null && cp.isDirty()) {
            PlayerCache.saveAsync(cp);
        }
    }

    public static void saveAsync(CachedPlayer cp) {
        scheduler.execute(() -> PlayerCache.save(cp));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void save(CachedPlayer cp) {
        block20: {
            if (cp.isDirty()) {
                try (Connection conn = DataPool.getConnection();){
                    PreparedStatement ps;
                    if (cp.isDirty(CachedPlayer.DirtyFlag.STATS)) {
                        ps = conn.prepareStatement(UPSERT_STATS);
                        try {
                            ps.setString(1, cp.getUuid().toString());
                            ps.setInt(2, cp.getWins());
                            ps.setInt(3, cp.getLosses());
                            ps.setInt(4, cp.getKills());
                            ps.setInt(5, cp.getDeaths());
                            ps.setInt(6, cp.getWinstreak());
                            ps.setInt(7, cp.getBeststreak());
                            ps.setInt(8, cp.getMatches());
                            ps.executeUpdate();
                        }
                        finally {
                            if (ps != null) {
                                ps.close();
                            }
                        }
                        cp.markClean(CachedPlayer.DirtyFlag.STATS);
                    }
                    if (!cp.isDirty(CachedPlayer.DirtyFlag.SETTINGS)) break block20;
                    ps = conn.prepareStatement(UPSERT_SETTINGS);
                    try {
                        ps.setString(1, cp.getUuid().toString());
                        ps.setInt(2, cp.isDuelRequests() ? 1 : 0);
                        ps.setInt(3, cp.isScoreboard() ? 1 : 0);
                        ps.setInt(4, cp.isAutoGG() ? 1 : 0);
                        ps.setInt(5, cp.isPrivateMessages() ? 1 : 0);
                        ps.setInt(6, cp.isChatMentions() ? 1 : 0);
                        ps.setInt(7, cp.isPartyInvites() ? 1 : 0);
                        ps.setInt(8, cp.isHealthIndicator() ? 1 : 0);
                        ps.setInt(9, cp.isElytra() ? 1 : 0);
                        ps.setInt(10, cp.isChatIsolation() ? 1 : 0);
                        ps.setString(11, cp.getTimeOfDay());
                        ps.setInt(12, cp.isPingDisplay() ? 1 : 0);
                        ps.setString(13, cp.getPingRange());
                        ps.executeUpdate();
                    }
                    finally {
                        if (ps != null) {
                            ps.close();
                        }
                    }
                    cp.markClean(CachedPlayer.DirtyFlag.SETTINGS);
                }
                catch (SQLException e) {
                    LOG.log(Level.WARNING, "[PlayerCache] Failed to save " + String.valueOf(cp.getUuid()), e);
                }
            }
        }
    }

    public static int size() {
        return cache.size();
    }

    public static String getStats() {
        return String.format("[PlayerCache] Cached: %d/%d", cache.size(), PerformanceConfig.getPlayerCacheMaxSize());
    }

    private static void maintain() {
        PlayerCache.saveDirty();
        PlayerCache.evictOfflinePlayers();
        PlayerCache.enforceMaxSize();
    }

    private static void evictOfflinePlayers() {
        long cutoff = System.currentTimeMillis() - (long)PerformanceConfig.getStatsCacheExpirySeconds() * 1000L;
        for (Map.Entry<UUID, CachedPlayer> entry : cache.entrySet()) {
            CachedPlayer removed;
            CachedPlayer cp = entry.getValue();
            if (Bukkit.getPlayer((UUID)entry.getKey()) != null || cp.getLastAccessedAt() >= cutoff || (removed = cache.remove(entry.getKey())) == null || !removed.isDirty()) continue;
            PlayerCache.save(removed);
        }
    }

    private static void enforceMaxSize() {
        int maxSize = PerformanceConfig.getPlayerCacheMaxSize();
        if (maxSize > 0 && cache.size() > maxSize) {
            cache.entrySet().stream().filter(e -> Bukkit.getPlayer((UUID)((UUID)e.getKey())) == null).sorted(Map.Entry.comparingByValue(Comparator.comparingLong(CachedPlayer::getLastAccessedAt))).limit(cache.size() - maxSize).forEach(e -> {
                CachedPlayer removed = cache.remove(e.getKey());
                if (removed != null && removed.isDirty()) {
                    PlayerCache.save(removed);
                }
            });
        }
    }

    private static void saveDirty() {
        for (CachedPlayer cp : cache.values()) {
            if (!cp.isDirty()) continue;
            PlayerCache.save(cp);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void loadFromDb(CachedPlayer cp) {
        try (Connection conn = DataPool.getConnection();){
            ResultSet rs;
            try (PreparedStatement ps = conn.prepareStatement("SELECT wins, losses, kills, deaths, winstreak, beststreak, matches FROM stats WHERE uuid=?");){
                ps.setString(1, cp.getUuid().toString());
                rs = ps.executeQuery();
                try {
                    if (rs.next()) {
                        cp.setMatches(rs.getInt("matches"));
                        cp.setWins(rs.getInt("wins"));
                        cp.setLosses(rs.getInt("losses"));
                        cp.setKills(rs.getInt("kills"));
                        cp.setDeaths(rs.getInt("deaths"));
                        cp.setWinstreak(rs.getInt("winstreak"));
                        cp.setBeststreak(rs.getInt("beststreak"));
                    }
                }
                finally {
                    if (rs != null) {
                        rs.close();
                    }
                }
            }
            ps = conn.prepareStatement("SELECT duel_requests, scoreboard, auto_gg, private_messages, chat_mentions, party_invites, health_indicator, elytra, chat_isolation, time_of_day, ping_display, ping_range FROM player_settings WHERE uuid=?");
            try {
                ps.setString(1, cp.getUuid().toString());
                rs = ps.executeQuery();
                try {
                    if (rs.next()) {
                        cp.setDuelRequests(rs.getInt("duel_requests") == 1);
                        cp.setScoreboard(rs.getInt("scoreboard") == 1);
                        cp.setAutoGG(rs.getInt("auto_gg") == 1);
                        cp.setPrivateMessages(rs.getInt("private_messages") == 1);
                        cp.setChatMentions(rs.getInt("chat_mentions") == 1);
                        cp.setPartyInvites(rs.getInt("party_invites") == 1);
                        cp.setHealthIndicator(rs.getInt("health_indicator") == 1);
                        cp.setElytra(rs.getInt("elytra") == 1);
                        cp.setChatIsolation(rs.getInt("chat_isolation") == 1);
                        cp.setTimeOfDay(rs.getString("time_of_day"));
                        cp.setPingDisplay(rs.getInt("ping_display") == 1);
                        cp.setPingRange(rs.getString("ping_range"));
                    }
                }
                finally {
                    if (rs != null) {
                        rs.close();
                    }
                }
            }
            finally {
                if (ps != null) {
                    ps.close();
                }
            }
            cp.markClean();
        }
        catch (SQLException e) {
            LOG.log(Level.WARNING, "[PlayerCache] Failed to load " + String.valueOf(cp.getUuid()), e);
        }
    }

    private static String resolveName(UUID uuid) {
        Player p = Bukkit.getPlayer((UUID)uuid);
        return p != null ? p.getName() : "Unknown";
    }
}

