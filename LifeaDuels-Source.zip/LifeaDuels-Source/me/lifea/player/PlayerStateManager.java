/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.player;

import me.lifea.Lifea;
import me.lifea.duel.DuelSession;
import me.lifea.hotbar.HotbarManager;
import me.lifea.match.MatchManager;
import me.lifea.match.RematchManager;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.queue.QueueManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spawn.SpawnElytraManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.TabManager;
import me.lifea.util.WorldBorderUtil;
import me.lifea.visibility.MatchVisibilityManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class PlayerStateManager {
    private PlayerStateManager() {
    }

    public static PlayerState getState(Player player) {
        if (!DuelSession.inSession(player.getUniqueId()) && !PartyDuelSession.inSession(player.getUniqueId())) {
            if (MatchManager.inMatch(player.getUniqueId())) {
                return PlayerState.MATCH;
            }
            if (SpectateManager.isSpectating(player.getUniqueId())) {
                return PlayerState.SPECTATOR;
            }
            if (!PartyManager.inParty(player.getUniqueId())) {
                return QueueManager.inQueue(player) ? PlayerState.QUEUE : PlayerState.LOBBY;
            }
            Party party = PartyManager.getParty(player.getUniqueId());
            return party != null && party.isLeader(player.getUniqueId()) ? PlayerState.PARTY_LEADER : PlayerState.PARTY_MEMBER;
        }
        return PlayerState.MATCH;
    }

    public static boolean shouldHaveLobbyItems(Player player) {
        PlayerState state = PlayerStateManager.getState(player);
        return state == PlayerState.LOBBY || state == PlayerState.QUEUE || state == PlayerState.PARTY_LEADER || state == PlayerState.PARTY_MEMBER;
    }

    public static void resetToLobby(Player player) {
        PlayerStateManager.resetToLobby(player, true);
    }

    public static void resetToLobby(Player player, boolean teleportToSpawn) {
        PlayerStateManager.resetToLobby(player, teleportToSpawn, true);
    }

    public static void resetToLobby(Player player, boolean teleportToSpawn, boolean scheduleLobbyCosmetics) {
        WorldBorderUtil.remove(player);
        player.getInventory().clear();
        player.getInventory().setArmorContents((ItemStack[])null);
        player.getInventory().setItemInOffHand((ItemStack)null);
        player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
        player.setHealth(player.getAttribute(Attribute.MAX_HEALTH).getValue());
        player.setFoodLevel(20);
        player.setSaturation(20.0f);
        player.setExhaustion(0.0f);
        player.setFireTicks(0);
        player.setInvulnerable(false);
        player.setGameMode(GameMode.SURVIVAL);
        if (teleportToSpawn) {
            SpawnManager.teleportToSpawn(player);
        }
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> TabManager.forceResend(player.getUniqueId()), 5L);
        if (PartyManager.inParty(player.getUniqueId())) {
            ScoreboardManager.create(player);
            ScoreboardManager.setType(player, ScoreboardManager.Type.PARTY, null);
        } else {
            ScoreboardManager.create(player);
            ScoreboardManager.setType(player, ScoreboardManager.Type.OVERALL, null);
        }
        MatchVisibilityManager.reset(player);
        PlayerStateManager.refreshInventory(player);
        if (scheduleLobbyCosmetics) {
            PlayerStateManager.scheduleLobbyCosmetics(player);
        }
    }

    public static void refreshLobbyCosmetics(Player player) {
        if (SpawnManager.isMainWorld(player) && player.hasPermission("lifea.cosmetics.elytra") && PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA)) {
            SpawnElytraManager.give(player);
        }
    }

    public static void scheduleLobbyCosmetics(Player player) {
        if (player == null) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (!player.isOnline()) {
                return;
            }
            PlayerState state = PlayerStateManager.getState(player);
            if (state != PlayerState.LOBBY && state != PlayerState.PARTY_LEADER && state != PlayerState.PARTY_MEMBER) {
                return;
            }
            PlayerStateManager.refreshLobbyCosmetics(player);
        }, 10L);
    }

    public static void refreshInventory(Player player) {
        RematchManager.removeRematchItem(player);
        switch (PlayerStateManager.getState(player).ordinal()) {
            case 0: {
                HotbarManager.give(player, HotbarManager.HotbarType.SPAWN);
                break;
            }
            case 1: {
                HotbarManager.give(player, HotbarManager.HotbarType.QUEUE);
                break;
            }
            case 2: 
            case 3: {
                return;
            }
            case 4: {
                HotbarManager.give(player, HotbarManager.HotbarType.PARTY_LEADER);
                break;
            }
            case 5: {
                HotbarManager.give(player, HotbarManager.HotbarType.PARTY_MEMBER);
            }
        }
    }

    public static final class PlayerState
    extends Enum<PlayerState> {
        public static final /* enum */ PlayerState LOBBY = new PlayerState();
        public static final /* enum */ PlayerState QUEUE = new PlayerState();
        public static final /* enum */ PlayerState MATCH = new PlayerState();
        public static final /* enum */ PlayerState SPECTATOR = new PlayerState();
        public static final /* enum */ PlayerState PARTY_LEADER = new PlayerState();
        public static final /* enum */ PlayerState PARTY_MEMBER = new PlayerState();
        private static final /* synthetic */ PlayerState[] $VALUES;

        public static PlayerState[] values() {
            return (PlayerState[])$VALUES.clone();
        }

        public static PlayerState valueOf(String name) {
            return Enum.valueOf(PlayerState.class, name);
        }

        private static PlayerState[] $values() {
            return new PlayerState[]{LOBBY, QUEUE, MATCH, SPECTATOR, PARTY_LEADER, PARTY_MEMBER};
        }

        private static PlayerState[] $values$() {
            return new PlayerState[]{LOBBY, QUEUE, MATCH, SPECTATOR, PARTY_LEADER, PARTY_MEMBER};
        }

        private static /* synthetic */ PlayerState[] $values$$() {
            return new PlayerState[]{LOBBY, QUEUE, MATCH, SPECTATOR, PARTY_LEADER, PARTY_MEMBER};
        }

        static {
            $VALUES = PlayerState.$values$$();
        }
    }
}

