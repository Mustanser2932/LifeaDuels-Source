/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerQuitEvent
 */
package me.lifea.player;

import java.util.UUID;
import me.lifea.command.MessageCommand;
import me.lifea.command.SettingsCommand;
import me.lifea.cosmetic.BannerManager;
import me.lifea.duel.DuelRequestManager;
import me.lifea.duel.KitRulesListener;
import me.lifea.duel.custom.CustomKitRulesListener;
import me.lifea.gui.DuelRequestGUI;
import me.lifea.gui.GUIManager;
import me.lifea.gui.admin.ArenaEditorGUI;
import me.lifea.gui.admin.KitSettingsGUI;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.hotbar.HotbarManager;
import me.lifea.match.RematchManager;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelRequestManager;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.player.PlayerDataCache;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.WorldBorderUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerCleanupListener
implements Listener {
    public static void cleanup(UUID uuid, Player player) {
        if (player != null) {
            QueueManager.removePlayerFromQueues(player);
            HotbarManager.clearCache(uuid);
            ScoreboardManager.remove(player);
            WorldBorderUtil.remove(player);
        }
        GUIManager.remove(uuid);
        SettingsCommand.clearCooldown(uuid);
        if (player != null) {
            DuelRequestGUI.closeFor(player);
        }
        StatsManager.evictCache(uuid);
        PlayerSettingsManager.evict(uuid);
        PlayerDataCache.evict(uuid);
        SpectateManager.removeDisconnected(uuid);
        DuelRequestManager.clearFor(uuid);
        PartyManager.clearInvites(uuid);
        PartyManager.removePlayer(uuid);
        PartyDuelRequestManager.clearFor(uuid);
        PartyMatchContext.clearFor(uuid);
        RematchManager.clearFor(uuid);
        if (player != null) {
            KitEditorGUI.cleanupOnQuit(player);
            CustomKitEditorGUI.cleanupOnQuit(player);
        } else {
            KitEditorGUI.remove(uuid);
        }
        ArenaEditorGUI.clearPending(uuid);
        KitSettingsGUI.clearPending(uuid);
        KitRulesListener.clearBoxingHits(uuid);
        KitRulesListener.clearPlayerKitCache(uuid);
        KitRulesListener.clearSumoWaterDeath(uuid);
        CustomKitRulesListener.clearPlacedBlocks(uuid);
        BannerManager.remove(uuid);
        MessageCommand.clearReplyTarget(uuid);
    }

    public static void cleanupAllOnline() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerCleanupListener.cleanup(player.getUniqueId(), player);
        }
        PlayerDataCache.clearAll();
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        PlayerCleanupListener.cleanup(event.getPlayer().getUniqueId(), event.getPlayer());
    }
}

