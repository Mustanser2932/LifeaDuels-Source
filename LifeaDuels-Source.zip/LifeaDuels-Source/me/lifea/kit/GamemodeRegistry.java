/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 */
package me.lifea.kit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.kit.KitManager;
import org.bukkit.configuration.ConfigurationSection;

public class GamemodeRegistry {
    private static List<GamemodeEntry> registry = null;

    private static void addEntry(Set<String> seen, List<GamemodeEntry> entries, String tier, String gamemode, String displayName) {
        String key = tier + ":" + gamemode;
        if (seen.add(key)) {
            entries.add(new GamemodeEntry(tier, gamemode, displayName));
        }
    }

    public static List<GamemodeEntry> getAll() {
        if (registry != null) {
            return registry;
        }
        HashSet<String> seen = new HashSet<String>();
        ArrayList<GamemodeEntry> entries = new ArrayList<GamemodeEntry>();
        for (String tier : DuelMenuGUI.PLAYABLE_TIERS) {
            ConfigurationSection sec = DuelMenuGUI.tierSection(tier);
            if (sec == null) continue;
            String kitFormat = sec.getString("kit-format", "");
            ConfigurationSection items = sec.getConfigurationSection("items");
            if (items == null) continue;
            for (String key : items.getKeys(false)) {
                String[] tg;
                String kit;
                ConfigurationSection it = items.getConfigurationSection(key);
                if (it == null || (kit = it.getString("kit")) == null || kit.isBlank() || (tg = DuelMenuGUI.resolveKit(kit, kitFormat))[1].isBlank()) continue;
                String rawName = it.getString("name", tg[1]);
                GamemodeRegistry.addEntry(seen, entries, tg[0], tg[1], GamemodeRegistry.collapseSpreadHex(rawName));
            }
        }
        registry = Collections.unmodifiableList(entries);
        return registry;
    }

    public static List<GamemodeEntry> getEnabled() {
        return GamemodeRegistry.getAll().stream().filter(e -> KitManager.isKitEnabled(e.tier(), e.gamemode())).collect(Collectors.toList());
    }

    public static List<String> getEnabledKitKeys() {
        return GamemodeRegistry.getEnabled().stream().map(GamemodeEntry::kitKey).collect(Collectors.toList());
    }

    public static String getDisplayName(String tier, String gamemode) {
        String configured = GamemodeRegistry.getAll().stream().filter(e -> e.tier().equals(tier) && e.gamemode().equals(gamemode)).map(GamemodeEntry::displayName).findFirst().orElse(gamemode);
        return gamemode != null && gamemode.equalsIgnoreCase("BedPvP") ? "&x&f&b&0&0&0&0&l\u0299\u1d07\u1d05 \u1d18\u1d20\u1d18" : configured;
    }

    private static String collapseSpreadHex(String text) {
        if (text == null) {
            return "";
        }
        Matcher m = Pattern.compile("[&\u00a7]x([&\u00a7][A-Fa-f0-9]){6}").matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String match = m.group();
            String hex = match.replace("&", "").replace("\u00a7", "").substring(1);
            m.appendReplacement(sb, Matcher.quoteReplacement("&#" + hex));
        }
        m.appendTail(sb);
        return sb.toString().replace('\u00a7', '&');
    }

    public static void invalidate() {
        registry = null;
    }

    public record GamemodeEntry(String tier, String gamemode, String displayName) {
        public String kitKey() {
            return KitManager.buildKitKey(this.tier, this.gamemode);
        }
    }
}

