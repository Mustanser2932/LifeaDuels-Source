/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.kit.custom;

import java.util.Map;
import org.bukkit.inventory.ItemStack;

public class CustomKit {
    private final int slot;
    private final ItemStack[] content;
    private final Map<String, String> settings;
    private final Map<String, String> potions;

    public CustomKit(int slot, ItemStack[] content, Map<String, String> settings, Map<String, String> potions) {
        this.slot = slot;
        this.content = content;
        this.settings = settings;
        this.potions = potions;
    }

    public int getSlot() {
        return this.slot;
    }

    public ItemStack[] getContent() {
        return this.content;
    }

    public Map<String, String> getSettings() {
        return this.settings;
    }

    public Map<String, String> getPotions() {
        return this.potions;
    }

    public boolean isSettingEnabled(String key) {
        return "true".equalsIgnoreCase(this.settings.getOrDefault(key, "false"));
    }
}

