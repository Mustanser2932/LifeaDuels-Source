/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.reflect.TypeToken
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.kit.custom;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import me.lifea.storage.DatabaseManager;
import me.lifea.storage.ItemStackSerializer;
import org.bukkit.inventory.ItemStack;

public final class CustomKitShareManager {
    private static final Gson GSON = new Gson();
    private static final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int CODE_LENGTH = 6;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Type MAP_TYPE = new TypeToken<Map<String, String>>(){}.getType();

    private CustomKitShareManager() {
    }

    public static String encode(ItemStack[] content, Map<String, String> settings, Map<String, String> potions) {
        byte[] serialized = ItemStackSerializer.serialize(content);
        String settingsJson = GSON.toJson(settings != null ? settings : Map.of());
        String potionsJson = GSON.toJson(potions != null ? potions : Map.of());
        String code = CustomKitShareManager.generateUniqueCode();
        try {
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement st = conn.prepareStatement("INSERT INTO shared_kits (code, content, settings, potions, created_at) VALUES (?, ?, ?, ?, ?)");){
                st.setString(1, code);
                st.setBytes(2, serialized);
                st.setString(3, settingsJson);
                st.setString(4, potionsJson);
                st.setLong(5, System.currentTimeMillis());
                st.executeUpdate();
            }
            return code;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to save shared kit", e);
        }
    }

    private static String generateUniqueCode() {
        for (int attempt = 0; attempt < 20; ++attempt) {
            StringBuilder sb = new StringBuilder(6);
            for (int i = 0; i < 6; ++i) {
                sb.append(CHARS.charAt(RANDOM.nextInt(CHARS.length())));
            }
            String code = sb.toString();
            if (CustomKitShareManager.codeExists(code)) continue;
            return code;
        }
        throw new RuntimeException("Failed to generate unique share code after 20 attempts");
    }

    private static boolean codeExists(String code) {
        try {
            boolean var4;
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement st = conn.prepareStatement("SELECT 1 FROM shared_kits WHERE code=?");){
                st.setString(1, code);
                try (ResultSet rs = st.executeQuery();){
                    var4 = rs.next();
                }
            }
            return var4;
        }
        catch (SQLException var13) {
            return true;
        }
    }

    public static ShareData decode(String code) {
        try {
            block23: {
                ShareData var10;
                try (Connection conn = DatabaseManager.connection();
                     PreparedStatement st = conn.prepareStatement("SELECT content, settings, potions FROM shared_kits WHERE code=?");){
                    st.setString(1, code);
                    try (ResultSet rs = st.executeQuery();){
                        HashMap<String, String> potions;
                        HashMap<String, String> settings;
                        if (!rs.next()) {
                            Object serialized = null;
                            break block23;
                        }
                        byte[] serialized = rs.getBytes("content");
                        String settingsJson = rs.getString("settings");
                        String potionsJson = rs.getString("potions");
                        ItemStack[] content = ItemStackSerializer.deserialize(serialized);
                        Map<String, String> map = settings = settingsJson != null ? (Map)GSON.fromJson(settingsJson, MAP_TYPE) : new HashMap<String, String>();
                        if (settings == null) {
                            settings = new HashMap();
                        }
                        Map<String, String> map2 = potions = potionsJson != null ? (Map)GSON.fromJson(potionsJson, MAP_TYPE) : new HashMap<String, String>();
                        if (potions == null) {
                            potions = new HashMap();
                        }
                        var10 = new ShareData(content, settings, potions);
                    }
                }
                return var10;
            }
            return null;
        }
        catch (SQLException var17) {
            return null;
        }
    }

    public static class ShareData {
        public final ItemStack[] content;
        public final Map<String, String> settings;
        public final Map<String, String> potions;

        public ShareData(ItemStack[] content, Map<String, String> settings, Map<String, String> potions) {
            this.content = content;
            this.settings = settings;
            this.potions = potions;
        }
    }
}

