/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.reflect.TypeToken
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package me.lifea.kit.custom;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.kit.custom.CustomKit;
import me.lifea.storage.DatabaseManager;
import me.lifea.storage.ItemStackSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class CustomKitManager {
    private static final Gson GSON = new Gson();
    private static final int MIN_SLOT = 1;
    private static final int MAX_SLOT = 10;
    public static final int INVENTORY_SIZE = 36;
    public static final int ARMOR_SLOTS = 4;
    public static final int OFFHAND_SLOT = 1;
    public static final int BOOTS_INDEX = 36;
    public static final int LEGGINGS_INDEX = 37;
    public static final int CHESTPLATE_INDEX = 38;
    public static final int HELMET_INDEX = 39;
    public static final int OFFHAND_INDEX = 40;
    public static final int CONTENT_SIZE = 41;

    public static boolean isEnabled() {
        return ConfigManager.config().getBoolean("custom-kits.enabled", false);
    }

    private static Connection getConnection() {
        Connection connection = DatabaseManager.connection();
        if (connection == null) {
            throw new IllegalStateException("Database connection is null");
        }
        return connection;
    }

    private static void validateSlot(int slot) {
        if (slot < 1 || slot > 10) {
            throw new IllegalArgumentException("Invalid custom kit slot: " + slot);
        }
    }

    private static String mapToJson(Map<String, String> map) {
        return GSON.toJson(map == null ? Collections.emptyMap() : map);
    }

    private static Map<String, String> jsonToMap(String json) {
        if (json != null && !json.isBlank()) {
            Type type = new TypeToken<Map<String, String>>(){}.getType();
            Map map = (Map)GSON.fromJson(json, type);
            return map == null ? new HashMap() : map;
        }
        return new HashMap<String, String>();
    }

    public static boolean hasKit(UUID uuid, int slot) {
        CustomKitManager.validateSlot(slot);
        try {
            boolean var5;
            try (Connection conn = CustomKitManager.getConnection();
                 PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM custom_kits WHERE uuid = ? AND slot = ?");){
                ps.setString(1, uuid.toString());
                ps.setInt(2, slot);
                try (ResultSet rs = ps.executeQuery();){
                    var5 = rs.next();
                }
            }
            return var5;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to check custom kit", e);
        }
    }

    public static CustomKit getKit(UUID uuid, int slot) {
        CustomKitManager.validateSlot(slot);
        try {
            block23: {
                CustomKit var9;
                try (Connection conn = CustomKitManager.getConnection();
                     PreparedStatement ps = conn.prepareStatement("SELECT content, potion_data, settings FROM custom_kits WHERE uuid = ? AND slot = ?");){
                    ps.setString(1, uuid.toString());
                    ps.setInt(2, slot);
                    try (ResultSet rs = ps.executeQuery();){
                        ItemStack[] content;
                        if (!rs.next()) {
                            Object data = null;
                            break block23;
                        }
                        byte[] data = rs.getBytes("content");
                        ItemStack[] itemStackArray = content = data != null ? ItemStackSerializer.deserialize(data) : null;
                        if (content == null || content.length < 41) {
                            ItemStack[] normalized = new ItemStack[41];
                            if (content != null) {
                                System.arraycopy(content, 0, normalized, 0, Math.min(content.length, 41));
                            }
                            content = normalized;
                        }
                        Map<String, String> settings = CustomKitManager.jsonToMap(rs.getString("settings"));
                        Map<String, String> potions = CustomKitManager.jsonToMap(rs.getString("potion_data"));
                        var9 = new CustomKit(slot, content, settings, potions);
                    }
                }
                return var9;
            }
            return null;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load custom kit", e);
        }
    }

    public static List<Integer> getOccupiedSlots(UUID uuid) {
        ArrayList<Integer> slots = new ArrayList<Integer>();
        try {
            try (Connection conn = CustomKitManager.getConnection();
                 PreparedStatement ps = conn.prepareStatement("SELECT slot FROM custom_kits WHERE uuid = ? ORDER BY slot");){
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery();){
                    while (rs.next()) {
                        slots.add(rs.getInt("slot"));
                    }
                }
            }
            return slots;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to list custom kit slots", e);
        }
    }

    public static void saveKit(UUID uuid, int slot, ItemStack[] content, Map<String, String> settings, Map<String, String> potions) {
        CustomKitManager.validateSlot(slot);
        settings = settings == null ? Collections.emptyMap() : settings;
        potions = potions == null ? Collections.emptyMap() : potions;
        try (Connection conn = CustomKitManager.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO custom_kits(uuid, slot, content, potion_data, settings) VALUES (?,?,?,?,?)");){
            ps.setString(1, uuid.toString());
            ps.setInt(2, slot);
            ps.setBytes(3, ItemStackSerializer.serialize(content != null ? content : new ItemStack[41]));
            ps.setString(4, CustomKitManager.mapToJson(potions));
            ps.setString(5, CustomKitManager.mapToJson(settings));
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to save custom kit", e);
        }
    }

    public static void deleteKit(UUID uuid, int slot) {
        CustomKitManager.validateSlot(slot);
        try (Connection conn = CustomKitManager.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM custom_kits WHERE uuid = ? AND slot = ?");){
            ps.setString(1, uuid.toString());
            ps.setInt(2, slot);
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete custom kit", e);
        }
    }

    public static void applyCustomKit(Player player, UUID kitOwner, int slot) {
        ItemStack[] content;
        CustomKit kit = CustomKitManager.getKit(kitOwner, slot);
        if (kit != null && (content = kit.getContent()) != null) {
            player.getInventory().clear();
            player.getInventory().setArmorContents((ItemStack[])null);
            player.getInventory().setItemInOffHand((ItemStack)null);
            PlayerInventory inv = player.getInventory();
            if (content.length > 36) {
                inv.setBoots(content[36] != null ? content[36].clone() : null);
            }
            if (content.length > 37) {
                inv.setLeggings(content[37] != null ? content[37].clone() : null);
            }
            if (content.length > 38) {
                inv.setChestplate(content[38] != null ? content[38].clone() : null);
            }
            if (content.length > 39) {
                inv.setHelmet(content[39] != null ? content[39].clone() : null);
            }
            if (content.length > 40 && content[40] != null && content[40].getType() != Material.AIR) {
                inv.setItemInOffHand(content[40].clone());
            }
            for (int i = 0; i < Math.min(36, content.length); ++i) {
                if (content[i] == null || content[i].getType() == Material.AIR) continue;
                inv.setItem(i, content[i].clone());
            }
        }
    }

    public static void deleteAllForPlayer(UUID uuid) {
        try (Connection conn = CustomKitManager.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM custom_kits WHERE uuid = ?");){
            ps.setString(1, uuid.toString());
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete all custom kits for player", e);
        }
    }

    public static Set<String> getBlockWhitelist() {
        HashSet<String> materials = new HashSet<String>();
        try {
            try (Connection conn = CustomKitManager.getConnection();
                 PreparedStatement st = conn.prepareStatement("SELECT material FROM custom_kit_block_whitelist");
                 ResultSet rs = st.executeQuery();){
                while (rs.next()) {
                    materials.add(rs.getString("material"));
                }
            }
            return materials;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load custom kit block whitelist", e);
        }
    }

    public static void addBlockWhitelist(String material) {
        try (Connection conn = CustomKitManager.getConnection();
             PreparedStatement st = conn.prepareStatement("INSERT OR IGNORE INTO custom_kit_block_whitelist (material) VALUES (?)");){
            st.setString(1, material);
            int affected = st.executeUpdate();
            if (affected <= 0) {
                // empty if block
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to add custom kit block whitelist", e);
        }
    }

    public static void removeBlockWhitelist(String material) {
        try (Connection conn = CustomKitManager.getConnection();
             PreparedStatement st = conn.prepareStatement("DELETE FROM custom_kit_block_whitelist WHERE material = ?");){
            st.setString(1, material);
            int affected = st.executeUpdate();
            if (affected <= 0) {
                // empty if block
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to remove custom kit block whitelist", e);
        }
    }
}

