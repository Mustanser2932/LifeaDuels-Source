/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.kit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.config.ConfigManager;
import me.lifea.storage.DatabaseManager;
import me.lifea.storage.ItemStackSerializer;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class KitManager {
    private static final Map<String, ItemStack[]> baseKits = new ConcurrentHashMap<String, ItemStack[]>();
    private static final int BASE_BOOTS_INDEX = 36;
    private static final int BASE_LEGGINGS_INDEX = 37;
    private static final int BASE_CHESTPLATE_INDEX = 38;
    private static final int BASE_HELMET_INDEX = 39;
    private static final int BASE_OFFHAND_INDEX = 40;
    private static final Map<String, String> SUFFIX_TO_TIER = Map.of("COM", "MCTiers", "IO", "PvPTiers", "Sub", "SubTiers", "Cactus", "CactusTiers", "Extra", "Extra");

    public static void load() {
        baseKits.clear();
        int count = 0;
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("SELECT tier, gamemode, content FROM kits WHERE uuid = 'base' AND is_base = 1");
             ResultSet rs = ps.executeQuery();){
            while (rs.next()) {
                int i;
                ItemStack[] items;
                String tier = rs.getString("tier");
                String gamemode = rs.getString("gamemode");
                byte[] data = rs.getBytes("content");
                if (data == null || data.length == 0 || (items = ItemStackSerializer.deserialize(data)) == null) continue;
                items = KitManager.normalizeKit(items);
                String k = KitManager.key(tier, gamemode);
                baseKits.put(k, items);
                ++count;
                boolean hasInv = false;
                boolean hasArmor = false;
                boolean hasOffhand = false;
                for (i = 0; i < Math.min(36, items.length); ++i) {
                    if (items[i] == null || items[i].getType() == Material.AIR) continue;
                    hasInv = true;
                    break;
                }
                if (items.length > 36) {
                    for (i = 36; i < Math.min(40, items.length); ++i) {
                        if (items[i] == null || items[i].getType() == Material.AIR) continue;
                        hasArmor = true;
                        break;
                    }
                }
                if (items.length <= 40 || items[40] == null || items[40].getType() == Material.AIR) continue;
                hasOffhand = true;
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load base kits", e);
        }
    }

    public static void save() {
    }

    private static ItemStack cloneItem(ItemStack item) {
        return item != null ? item.clone() : null;
    }

    public static ItemStack[] captureCurrentKitLayout(Player player, String tier, String gamemode) {
        int i;
        ItemStack[] base = KitManager.getBaseKit(tier, gamemode);
        ItemStack[] layout = new ItemStack[41];
        ItemStack[] contents = player.getInventory().getContents();
        for (i = 0; i < Math.min(contents.length, 36); ++i) {
            layout[i] = KitManager.cloneItem(contents[i]);
        }
        for (i = 36; i <= 39; ++i) {
            layout[i] = i < base.length ? KitManager.cloneItem(base[i]) : null;
        }
        ItemStack playerOffhand = player.getInventory().getItemInOffHand();
        layout[40] = playerOffhand != null && playerOffhand.getType() != Material.AIR ? KitManager.cloneItem(playerOffhand) : (base.length > 40 ? KitManager.cloneItem(base[40]) : null);
        return layout;
    }

    private static boolean isHelmet(ItemStack item) {
        return item != null && item.getType().name().endsWith("_HELMET");
    }

    private static boolean isChestplate(ItemStack item) {
        return item != null && item.getType().name().endsWith("_CHESTPLATE");
    }

    private static boolean isLeggings(ItemStack item) {
        return item != null && item.getType().name().endsWith("_LEGGINGS");
    }

    private static boolean isBoots(ItemStack item) {
        return item != null && item.getType().name().endsWith("_BOOTS");
    }

    private static boolean looksLikeFullInventoryArmorOrder(ItemStack[] items) {
        return items != null && items.length > 39 && KitManager.isHelmet(items[36]) && KitManager.isChestplate(items[37]) && KitManager.isLeggings(items[38]) && KitManager.isBoots(items[39]);
    }

    private static ItemStack[] normalizeBaseKit(ItemStack[] items) {
        ItemStack[] normalized = new ItemStack[41];
        if (items == null) {
            return normalized;
        }
        for (int i = 0; i < Math.min(36, items.length); ++i) {
            normalized[i] = KitManager.cloneItem(items[i]);
        }
        if (items.length > 39) {
            normalized[36] = KitManager.cloneItem(items[39]);
            normalized[37] = KitManager.cloneItem(items[38]);
            normalized[38] = KitManager.cloneItem(items[37]);
            normalized[39] = KitManager.cloneItem(items[36]);
        }
        if (items.length > 40) {
            normalized[40] = KitManager.cloneItem(items[40]);
        }
        return normalized;
    }

    private static ItemStack[] normalizeKit(ItemStack[] items) {
        if (items == null) {
            return new ItemStack[41];
        }
        ItemStack[] normalized = new ItemStack[41];
        int limit = Math.min(items.length, 36);
        for (int i = 0; i < limit; ++i) {
            normalized[i] = KitManager.cloneItem(items[i]);
        }
        if (items.length == 37) {
            normalized[40] = KitManager.cloneItem(items[36]);
        } else {
            int max = Math.min(items.length, 41);
            for (int i = 36; i < max; ++i) {
                normalized[i] = KitManager.cloneItem(items[i]);
            }
        }
        if (KitManager.looksLikeFullInventoryArmorOrder(items)) {
            normalized[36] = KitManager.cloneItem(items[39]);
            normalized[37] = KitManager.cloneItem(items[38]);
            normalized[38] = KitManager.cloneItem(items[37]);
            normalized[39] = KitManager.cloneItem(items[36]);
        }
        return normalized;
    }

    public static void setBaseKit(String tier, String gamemode, ItemStack[] items) {
        ItemStack[] normalized = KitManager.normalizeBaseKit(items);
        KitManager.upsertKit(null, tier, gamemode, true, normalized);
        ItemStack[] fromDb = KitManager.readKit(null, tier, gamemode, true);
        baseKits.put(KitManager.key(tier, gamemode), fromDb != null ? fromDb : normalized);
        KitManager.deletePlayerKits(tier, gamemode);
    }

    public static ItemStack[] getBaseKit(String tier, String gamemode) {
        ItemStack[] cached = baseKits.get(KitManager.key(tier, gamemode));
        if (cached != null) {
            return (ItemStack[])cached.clone();
        }
        ItemStack[] fromDb = KitManager.readKit(null, tier, gamemode, true);
        if (fromDb != null) {
            baseKits.put(KitManager.key(tier, gamemode), fromDb);
            return (ItemStack[])fromDb.clone();
        }
        return new ItemStack[41];
    }

    public static boolean hasBaseKit(String tier, String gamemode) {
        if (baseKits.containsKey(KitManager.key(tier, gamemode))) {
            return true;
        }
        ItemStack[] fromDb = KitManager.readKit(null, tier, gamemode, true);
        if (fromDb != null) {
            baseKits.put(KitManager.key(tier, gamemode), fromDb);
            return true;
        }
        return false;
    }

    public static void deleteBaseKit(String tier, String gamemode) {
        baseKits.remove(KitManager.key(tier, gamemode));
        KitManager.deleteKit(null, tier, gamemode, true);
        KitManager.deletePlayerKits(tier, gamemode);
    }

    public static void resetAll() {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM kits WHERE is_base = 0");){
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to reset player kits", e);
        }
    }

    public static void savePlayerKit(UUID uuid, String tier, String gamemode, ItemStack[] items) {
        KitManager.upsertKit(uuid, tier, gamemode, false, items);
    }

    public static void savePlayerKitLayout(Player player, String tier, String gamemode) {
        KitManager.savePlayerKit(player.getUniqueId(), tier, gamemode, KitManager.captureCurrentKitLayout(player, tier, gamemode));
    }

    public static ItemStack[] getPlayerKit(UUID uuid, String tier, String gamemode) {
        ItemStack[] kit = KitManager.readKit(uuid, tier, gamemode, false);
        return kit != null ? kit : KitManager.getBaseKit(tier, gamemode);
    }

    public static boolean hasPlayerKit(UUID uuid, String tier, String gamemode) {
        return KitManager.readKit(uuid, tier, gamemode, false) != null;
    }

    public static boolean hasPlayerKit(UUID uuid, String tier, String gamemode, int kitSlot) {
        return KitManager.readKit(uuid, tier, gamemode, false) != null;
    }

    public static void resetPlayerKit(UUID uuid, String tier, String gamemode) {
        KitManager.deleteKit(uuid, tier, gamemode, false);
    }

    public static int resetAllPlayerKits(String tier, String gamemode) {
        return KitManager.deletePlayerKits(tier, gamemode);
    }

    public static int resetAllPlayerKits() {
        try {
            int var2;
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement ps = conn.prepareStatement("DELETE FROM kits WHERE is_base = 0");){
                var2 = ps.executeUpdate();
            }
            return var2;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete all player kits", e);
        }
    }

    public static int resetPlayerAllKits(UUID uuid) {
        try {
            int var3;
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement ps = conn.prepareStatement("DELETE FROM kits WHERE uuid = ? AND is_base = 0");){
                ps.setString(1, uuid.toString());
                var3 = ps.executeUpdate();
            }
            return var3;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete all kits for player", e);
        }
    }

    public static int getPrimaryKitSlot(UUID uuid, String tier, String gamemode) {
        try {
            int var6;
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement ps = conn.prepareStatement("SELECT kit_slot FROM kit_primary WHERE uuid = ? AND tier = ? AND gamemode = ?");){
                ps.setString(1, uuid.toString());
                ps.setString(2, tier);
                ps.setString(3, gamemode);
                try (ResultSet rs = ps.executeQuery();){
                    var6 = rs.next() ? rs.getInt("kit_slot") : 1;
                }
            }
            return var6;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to read primary kit slot", e);
        }
    }

    public static void setPrimaryKitSlot(UUID uuid, String tier, String gamemode, int kitSlot) {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO kit_primary(uuid, tier, gamemode, kit_slot) VALUES(?,?,?,?) ON CONFLICT(uuid, tier, gamemode) DO UPDATE SET kit_slot = excluded.kit_slot");){
            ps.setString(1, uuid.toString());
            ps.setString(2, tier);
            ps.setString(3, gamemode);
            ps.setInt(4, kitSlot);
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to set primary kit slot", e);
        }
    }

    public static ItemStack extractOffhand(ItemStack[] playerKit, ItemStack[] baseKit) {
        if (playerKit != null) {
            if (playerKit.length > 40) {
                if (playerKit[40] != null && playerKit[40].getType() != Material.AIR) {
                    return playerKit[40];
                }
            } else if (playerKit.length == 37 && playerKit[36] != null && playerKit[36].getType() != Material.AIR) {
                return playerKit[36];
            }
        }
        return baseKit != null && baseKit.length > 40 && baseKit[40] != null && baseKit[40].getType() != Material.AIR ? baseKit[40] : null;
    }

    public static void applyKit(Player player, String tier, String gamemode) {
        ItemStack[] base = KitManager.getBaseKit(tier, gamemode);
        boolean hasCustomKit = KitManager.hasPlayerKit(player.getUniqueId(), tier, gamemode);
        ItemStack[] kit = hasCustomKit ? KitManager.readKit(player.getUniqueId(), tier, gamemode, false) : null;
        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[]{KitManager.cloneItem(base[36]), KitManager.cloneItem(base[37]), KitManager.cloneItem(base[38]), KitManager.cloneItem(base[39])});
        ItemStack offhand = KitManager.extractOffhand(kit, base);
        if (offhand != null) {
            player.getInventory().setItemInOffHand(offhand);
        }
        ItemStack[] source = hasCustomKit ? kit : base;
        for (int i = 0; i < 36; ++i) {
            if (source == null || i >= source.length || source[i] == null || source[i].getType() == Material.AIR) continue;
            player.getInventory().setItem(i, KitManager.cloneItem(source[i]));
        }
    }

    public static void applyKitEditor(Player player, String tier, String gamemode) {
        ItemStack[] kit = KitManager.getPlayerKit(player.getUniqueId(), tier, gamemode);
        ItemStack[] base = KitManager.getBaseKit(tier, gamemode);
        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[]{KitManager.cloneItem(base[36]), KitManager.cloneItem(base[37]), KitManager.cloneItem(base[38]), KitManager.cloneItem(base[39])});
        ItemStack offhand = KitManager.extractOffhand(kit, base);
        player.getInventory().setItemInOffHand(offhand != null ? KitManager.cloneItem(offhand) : null);
        for (int i = 0; i < Math.min(36, kit != null ? kit.length : 0); ++i) {
            if (kit[i] == null || kit[i].getType() == Material.AIR) continue;
            player.getInventory().setItem(i, KitManager.cloneItem(kit[i]));
        }
    }

    public static void applySpecificPlayerKit(Player target, UUID sourceUuid, String tier, String gamemode) {
        ItemStack[] base = KitManager.getBaseKit(tier, gamemode);
        boolean hasCustomKit = KitManager.hasPlayerKit(sourceUuid, tier, gamemode);
        ItemStack[] kit = hasCustomKit ? KitManager.readKit(sourceUuid, tier, gamemode, false) : null;
        target.getInventory().clear();
        target.getInventory().setArmorContents(new ItemStack[]{KitManager.cloneItem(base[36]), KitManager.cloneItem(base[37]), KitManager.cloneItem(base[38]), KitManager.cloneItem(base[39])});
        ItemStack offhand = KitManager.extractOffhand(kit, base);
        if (offhand != null) {
            target.getInventory().setItemInOffHand(offhand);
        }
        ItemStack[] source = hasCustomKit ? kit : base;
        for (int i = 0; i < 36; ++i) {
            if (source == null || i >= source.length || source[i] == null || source[i].getType() == Material.AIR) continue;
            target.getInventory().setItem(i, KitManager.cloneItem(source[i]));
        }
    }

    private static String key(String tier, String gamemode) {
        return tier + ":" + gamemode;
    }

    public static String buildKitKey(String tier, String gamemode) {
        Map<String, String> tierToSuffix = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus", "Extra", "Extra");
        String suffix = tierToSuffix.get(tier);
        return suffix != null ? gamemode + "-" + suffix : gamemode;
    }

    public static boolean isKitEnabled(String tier, String gamemode) {
        String kitKey = KitManager.buildKitKey(tier, gamemode);
        return ConfigManager.config().getBoolean("kit-settings." + kitKey + ".enabled", true);
    }

    public static String[] parseKitKey(String kitKey) {
        String[] stringArray;
        int idx = kitKey.lastIndexOf(45);
        if (idx < 0) {
            return null;
        }
        String gamemode = kitKey.substring(0, idx);
        String suffix = kitKey.substring(idx + 1);
        String tier = SUFFIX_TO_TIER.get(suffix);
        if (tier != null) {
            String[] stringArray2 = new String[2];
            stringArray2[0] = tier;
            stringArray = stringArray2;
            stringArray2[1] = gamemode;
        } else {
            stringArray = null;
        }
        return stringArray;
    }

    public static List<String> getKitKeys() {
        ArrayList<String> keys = new ArrayList<String>();
        Map<String, String> tierSuffix = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus", "Extra", "Extra");
        FileConfiguration ke = ConfigManager.kitEditor();
        for (Map.Entry<String, String> ts : tierSuffix.entrySet()) {
            List gms = ke.getList("gamemodes." + ts.getKey());
            if (gms == null) continue;
            for (Object o : gms) {
                Map m;
                String name;
                if (!(o instanceof Map) || (name = (String)(m = (Map)o).get("name")) == null) continue;
                String clean = name.replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-FklmnorKLMNOR]", "").replaceAll("\\s*[\\(\\[\\{][^\\)\\]\\}]*\\{tier\\}[^\\)\\]\\}]*[\\)\\]\\}]\\s*", "").replace("{tier}", "").replace("{gamemode}", "").replaceAll("[()\\[\\]]", "").replaceAll("\\s+", " ").trim();
                keys.add(clean + "-" + ts.getValue());
            }
        }
        return keys;
    }

    private static void upsertKit(UUID uuid, String tier, String gamemode, boolean isBase, ItemStack[] items) {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO kits(uuid, tier, gamemode, is_base, content) VALUES (?, ?, ?, ?, ?)");){
            ps.setString(1, uuid != null ? uuid.toString() : "base");
            ps.setString(2, tier);
            ps.setString(3, gamemode);
            ps.setInt(4, isBase ? 1 : 0);
            ps.setBytes(5, ItemStackSerializer.serialize(items != null ? items : new ItemStack[]{}));
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to save kit", e);
        }
    }

    private static ItemStack[] readKit(UUID uuid, String tier, String gamemode, boolean isBase) {
        try {
            block21: {
                ItemStack[] var9;
                try (Connection conn = DatabaseManager.connection();
                     PreparedStatement ps = conn.prepareStatement("SELECT content FROM kits WHERE uuid = ? AND tier = ? AND gamemode = ? AND is_base = ?");){
                    ps.setString(1, uuid != null ? uuid.toString() : "base");
                    ps.setString(2, tier);
                    ps.setString(3, gamemode);
                    ps.setInt(4, isBase ? 1 : 0);
                    try (ResultSet rs = ps.executeQuery();){
                        if (!rs.next()) {
                            Object data = null;
                            break block21;
                        }
                        byte[] data = rs.getBytes("content");
                        ItemStack[] items = data != null ? ItemStackSerializer.deserialize(data) : null;
                        var9 = KitManager.normalizeKit(items);
                    }
                }
                return var9;
            }
            return null;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to read kit", e);
        }
    }

    private static void deleteKit(UUID uuid, String tier, String gamemode, boolean isBase) {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM kits WHERE uuid = ? AND tier = ? AND gamemode = ? AND is_base = ?");){
            ps.setString(1, uuid != null ? uuid.toString() : "base");
            ps.setString(2, tier);
            ps.setString(3, gamemode);
            ps.setInt(4, isBase ? 1 : 0);
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete kit", e);
        }
    }

    private static int deletePlayerKits(String tier, String gamemode) {
        try {
            int var4;
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement ps = conn.prepareStatement("DELETE FROM kits WHERE tier = ? AND gamemode = ? AND is_base = 0");){
                ps.setString(1, tier);
                ps.setString(2, gamemode);
                var4 = ps.executeUpdate();
            }
            return var4;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete player kits for " + tier + ":" + gamemode, e);
        }
    }
}

