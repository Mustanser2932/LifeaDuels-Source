/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.kit.ffa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.storage.DatabaseManager;
import me.lifea.storage.ItemStackSerializer;
import org.bukkit.inventory.ItemStack;

public final class FfaKitManager {
    public static final int SIZE = 41;
    private static final Map<String, ItemStack[]> CACHE = new ConcurrentHashMap<String, ItemStack[]>();

    private FfaKitManager() {
    }

    public static void load() {
        CACHE.clear();
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("SELECT name, items FROM ffa_kits");
             ResultSet rs = ps.executeQuery();){
            while (rs.next()) {
                String name = rs.getString("name");
                byte[] data = rs.getBytes("items");
                ItemStack[] items = data != null ? FfaKitManager.normalize(ItemStackSerializer.deserialize(data)) : FfaKitManager.empty();
                CACHE.put(name.toLowerCase(), items);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load FFA kits", e);
        }
    }

    public static boolean exists(String name) {
        return CACHE.containsKey(name.toLowerCase());
    }

    public static boolean create(String name) {
        String key = name.toLowerCase();
        if (CACHE.containsKey(key)) {
            return false;
        }
        FfaKitManager.setItems(name, FfaKitManager.empty());
        return true;
    }

    public static boolean delete(String name) {
        String key = name.toLowerCase();
        if (CACHE.remove(key) == null) {
            return false;
        }
        try {
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement ps = conn.prepareStatement("DELETE FROM ffa_kits WHERE name = ?");){
                ps.setString(1, key);
                ps.executeUpdate();
            }
            return true;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete FFA kit", e);
        }
    }

    public static ItemStack[] getItems(String name) {
        ItemStack[] items = CACHE.get(name.toLowerCase());
        return items != null ? (ItemStack[])items.clone() : null;
    }

    public static void setItems(String name, ItemStack[] items) {
        String key = name.toLowerCase();
        ItemStack[] normalized = FfaKitManager.normalize(items);
        CACHE.put(key, normalized);
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO ffa_kits (name, items) VALUES (?, ?)");){
            ps.setString(1, key);
            ps.setBytes(2, ItemStackSerializer.serialize(normalized));
            ps.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to save FFA kit", e);
        }
    }

    public static Collection<String> names() {
        return CACHE.keySet();
    }

    private static ItemStack[] empty() {
        return new ItemStack[41];
    }

    private static ItemStack[] normalize(ItemStack[] items) {
        ItemStack[] out = new ItemStack[41];
        if (items != null) {
            for (int i = 0; i < 41 && i < items.length; ++i) {
                out[i] = items[i];
            }
        }
        return out;
    }
}

