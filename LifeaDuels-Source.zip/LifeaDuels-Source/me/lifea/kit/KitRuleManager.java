/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.kit;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.storage.DatabaseManager;

public class KitRuleManager {
    private static final Map<String, Map<String, Boolean>> ruleCache = new ConcurrentHashMap<String, Map<String, Boolean>>();
    private static final Map<String, Set<String>> whitelistCache = new ConcurrentHashMap<String, Set<String>>();

    public static boolean isRuleEnabled(String kitKey, String ruleKey) {
        Map kitRules = ruleCache.computeIfAbsent(ruleKey, key -> new ConcurrentHashMap());
        return kitRules.computeIfAbsent(kitKey, key -> DatabaseManager.getKitRule(key, ruleKey));
    }

    public static boolean isBlockPlacingEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "block-placing");
    }

    public static boolean isBlockBreakingEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "block-breaking");
    }

    public static boolean isHealthIndicatorEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "health-indicator");
    }

    public static boolean isHungerDisabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "disable-hunger");
    }

    public static boolean isHealthRegenDisabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "disable-health-regen");
    }

    public static boolean isCraftingEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "enable-crafting");
    }

    public static boolean isFallDamageDisabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "disable-fall-damage");
    }

    public static boolean isDamageBoost33Enabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "damage-boost-33");
    }

    public static boolean isPlayerMinedBlocksEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "player-mined-blocks");
    }

    public static boolean isNoXpRandomnessEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "no-xp-randomness");
    }

    public static boolean isSumoEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "sumo");
    }

    public static boolean isBoxingEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "boxing");
    }

    public static boolean isBedFightEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "bed-fight");
    }

    public static boolean isBedwarsEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "bedwars");
    }

    public static boolean isFireballFightEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "fireball-fight");
    }

    public static boolean isBridgesEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "bridges");
    }

    public static boolean isCagesEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "cages");
    }

    public static boolean isRoundDragAnimationEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "round-drag-animation");
    }

    public static boolean isAutoTameEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "auto-tame");
    }

    public static boolean isAdventureModeEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "adventure-mode");
    }

    public static boolean isNoDamageEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "no-damage");
    }

    public static boolean isImmortalityEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "immortality");
    }

    public static boolean isCreeperPvpEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "creeper-pvp");
    }

    public static boolean isTntPvpEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "tnt-pvp");
    }

    public static boolean isTntTagEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "tnt-tag");
    }

    public static boolean isCustomScoreboardEnabled(String kitKey) {
        return KitRuleManager.isRuleEnabled(kitKey, "custom-scoreboard");
    }

    public static Set<String> getBlockWhitelist(String kitKey) {
        return whitelistCache.computeIfAbsent(kitKey, DatabaseManager::getKitBlockWhitelist);
    }

    public static void invalidate(String kitKey) {
        ruleCache.values().forEach(m -> m.remove(kitKey));
        whitelistCache.remove(kitKey);
    }

    public static void invalidateAll() {
        ruleCache.clear();
        whitelistCache.clear();
    }
}

