/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package me.lifea.kit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.config.ConfigManager;
import me.lifea.duel.PotionHandler;
import me.lifea.storage.DatabaseManager;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PotionManager {
    private static final Map<String, List<GamemodePotion>> cache = new ConcurrentHashMap<String, List<GamemodePotion>>();
    private static final Map<String, String> SUFFIX_MAP = Map.of("COM", "MCTiers", "IO", "PvPTiers", "Sub", "SubTiers", "Extra", "Extra");
    private static final Map<String, String> TIER_TO_SUFFIX = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "Extra", "Extra");

    public static void load() {
        cache.clear();
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement st = conn.prepareStatement("SELECT gamemode_key, effect, amplifier, duration FROM gamemode_potions");
             ResultSet rs = st.executeQuery();){
            while (rs.next()) {
                String key = rs.getString("gamemode_key");
                PotionEffectType type = PotionEffectType.getByName((String)rs.getString("effect"));
                if (type == null) continue;
                int amp = rs.getInt("amplifier");
                int dur = rs.getInt("duration");
                cache.computeIfAbsent(key, k -> new ArrayList()).add(new GamemodePotion(type, amp, dur));
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load gamemode potions", e);
        }
    }

    public static boolean addPotion(String gamemodeKey, PotionEffectType type, int amplifier, int duration) {
        int amp = amplifier - 1;
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement st = conn.prepareStatement("INSERT OR REPLACE INTO gamemode_potions (gamemode_key, effect, amplifier, duration) VALUES (?, ?, ?, ?)");){
            st.setString(1, gamemodeKey);
            st.setString(2, type.getName());
            st.setInt(3, amp);
            st.setInt(4, duration);
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to add potion", e);
        }
        List list = cache.computeIfAbsent(gamemodeKey, k -> new ArrayList());
        list.removeIf(p -> p.type().equals(type));
        list.add(new GamemodePotion(type, amp, duration));
        return true;
    }

    public static boolean removePotion(String gamemodeKey, PotionEffectType type) {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement st = conn.prepareStatement("DELETE FROM gamemode_potions WHERE gamemode_key=? AND effect=?");){
            st.setString(1, gamemodeKey);
            st.setString(2, type.getName());
            st.executeUpdate();
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to remove potion", e);
        }
        List<GamemodePotion> list = cache.get(gamemodeKey);
        return list == null ? false : list.removeIf(p -> p.type().equals(type));
    }

    public static List<GamemodePotion> getPotions(String gamemodeKey) {
        return cache.getOrDefault(gamemodeKey, new ArrayList());
    }

    public static boolean isValidKey(String key) {
        int lastDash = key.lastIndexOf(45);
        return lastDash == -1 ? false : SUFFIX_MAP.containsKey(key.substring(lastDash + 1));
    }

    public static List<String> getValidKeys() {
        return new ArrayList<String>(cache.keySet());
    }

    public static List<String> getAllPossibleKeys() {
        ArrayList<String> keys = new ArrayList<String>();
        ConfigurationSection gamemodes = ConfigManager.kitEditor().getConfigurationSection("gamemodes");
        if (gamemodes == null) {
            return keys;
        }
        for (String tier : gamemodes.getKeys(false)) {
            List list;
            String suffix = TIER_TO_SUFFIX.get(tier);
            if (suffix == null || (list = gamemodes.getList(tier)) == null) continue;
            for (Object obj : list) {
                Map m;
                String name;
                if (!(obj instanceof Map) || (name = (String)(m = (Map)obj).get("name")) == null) continue;
                String clean = name.replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-FklmnorKLMNOR]", "").replaceAll("\\s*[\\(\\[\\{][^\\)\\]\\}]*\\{tier\\}[^\\)\\]\\}]*[\\)\\]\\}]\\s*", "").replace("{tier}", "").replace("{gamemode}", "").replaceAll("[()\\[\\]]", "").replaceAll("\\s+", " ").trim().replace(' ', '-');
                keys.add(clean + "-" + suffix);
            }
        }
        return keys;
    }

    public static String parseTier(String key) {
        int lastDash = key.lastIndexOf(45);
        return lastDash == -1 ? null : (String)TIER_TO_SUFFIX.entrySet().stream().filter(e -> ((String)e.getValue()).equals(key.substring(lastDash + 1))).map(Map.Entry::getKey).findFirst().orElse(null);
    }

    public static String parseGamemode(String key) {
        int lastDash = key.lastIndexOf(45);
        return lastDash == -1 ? key : key.substring(0, lastDash);
    }

    public static String buildKey(String tier, String gamemode) {
        String suffix = TIER_TO_SUFFIX.get(tier);
        if (suffix == null) {
            return null;
        }
        String var10000 = gamemode.replace(' ', '-');
        return var10000 + "-" + suffix;
    }

    public static void applyPotions(Player player, String gamemodeKey) {
        List<GamemodePotion> list = PotionManager.getPotions(gamemodeKey);
        if (!list.isEmpty()) {
            ArrayList<PotionHandler.PotionData> data = new ArrayList<PotionHandler.PotionData>(list.size());
            for (GamemodePotion gp : list) {
                int ticks = gp.duration() <= 0 ? Integer.MAX_VALUE : gp.duration() * 20;
                data.add(new PotionHandler.PotionData(new PotionEffect(gp.type(), ticks, gp.amplifier(), false, false, true)));
            }
            PotionHandler.apply(player, data);
        }
    }

    public record GamemodePotion(PotionEffectType type, int amplifier, int duration) {
    }
}

