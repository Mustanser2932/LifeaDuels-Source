/*
 * Decompiled with CFR 0.152.
 */
package me.lifea;

import java.util.UUID;
import me.lifea.player.StatsManager;

public class LifeaAPI {
    private static LifeaAPI instance;

    private LifeaAPI() {
    }

    static LifeaAPI get() {
        if (instance == null) {
            instance = new LifeaAPI();
        }
        return instance;
    }

    public int getKills(UUID uuid) {
        return StatsManager.getCachedKills(uuid);
    }

    public int getDeaths(UUID uuid) {
        return StatsManager.getCachedDeaths(uuid);
    }

    public int getWins(UUID uuid) {
        return StatsManager.getCachedWins(uuid);
    }

    public int getLosses(UUID uuid) {
        return StatsManager.getCachedLosses(uuid);
    }

    public int getMatches(UUID uuid) {
        return StatsManager.getCachedMatches(uuid);
    }

    public int getWinStreak(UUID uuid) {
        return StatsManager.getCachedWinStreak(uuid);
    }
}

