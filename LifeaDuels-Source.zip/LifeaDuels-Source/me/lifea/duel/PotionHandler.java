/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 */
package me.lifea.duel;

import java.util.List;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

public final class PotionHandler {
    private static final Set<Material> POTION_ITEMS = Set.of(Material.POTION, Material.SPLASH_POTION, Material.LINGERING_POTION);

    private PotionHandler() {
    }

    public static void apply(Player player, List<PotionData> potions) {
        if (player != null && potions != null && !potions.isEmpty()) {
            boolean applied = false;
            for (PotionData data : potions) {
                if (data.effect().getType() == null) continue;
                player.addPotionEffect(data.effect(), true);
                applied = true;
            }
            if (applied) {
                player.playSound(player.getLocation(), Sound.ENTITY_SPLASH_POTION_BREAK, 1.0f, 1.0f);
            }
        }
    }

    public static void removePotionItems(Player player) {
        if (player != null) {
            for (int i = 0; i < player.getInventory().getSize(); ++i) {
                ItemStack item = player.getInventory().getItem(i);
                if (item == null || !POTION_ITEMS.contains(item.getType())) continue;
                player.getInventory().setItem(i, (ItemStack)null);
            }
        }
    }

    public record PotionData(PotionEffect effect) {
    }
}

