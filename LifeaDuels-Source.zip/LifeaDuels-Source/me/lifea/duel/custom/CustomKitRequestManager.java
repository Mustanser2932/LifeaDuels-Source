/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.duel.custom;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.gui.GUIManager;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.queue.QueueManager;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class CustomKitRequestManager {
    private static final Map<UUID, CustomKitRequest> pending = new HashMap<UUID, CustomKitRequest>();

    public static CustomKitRequest getPending(UUID uuid) {
        return pending.get(uuid);
    }

    public static void sendRequest(Player sender, Player target, int kitSlot, int rounds) {
        CustomKitRequestManager.sendRequest(sender, target, kitSlot, kitSlot, rounds, null);
    }

    public static void sendRequest(Player sender, Player target, int kitSlot, int rounds, String arenaBaseName) {
        CustomKitRequestManager.sendRequest(sender, target, kitSlot, kitSlot, rounds, arenaBaseName);
    }

    public static void sendRequest(Player sender, Player target, int kitSlotSender, int kitSlotTarget, int rounds) {
        CustomKitRequestManager.sendRequest(sender, target, kitSlotSender, kitSlotTarget, rounds, null);
    }

    public static void sendRequest(Player sender, Player target, int kitSlotSender, int kitSlotTarget, int rounds, String arenaBaseName) {
        if (!CustomKitManager.isEnabled()) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
        } else if (pending.containsKey(target.getUniqueId())) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-has-request")));
        } else {
            pending.put(target.getUniqueId(), new CustomKitRequest(sender.getUniqueId(), target.getUniqueId(), kitSlotSender, kitSlotTarget, rounds, arenaBaseName));
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kit-request-sent").replace("%target%", target.getName())));
            String ft = "FT" + rounds;
            for (String line : ConfigManager.msgs("duel.request-notify-lines")) {
                if (line.contains("%arena%") && (arenaBaseName == null || arenaBaseName.isBlank())) continue;
                String resolved = line.replace("%sender%", sender.getName()).replace("%tier%", "Custom Kits").replace("%gamemode%", "Kit " + kitSlotSender).replace("%rounds%", ft).replace("%arena%", arenaBaseName != null ? arenaBaseName : "");
                String stripped = resolved.replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-FklmnorKLMNOR]", "");
                if (!stripped.contains("\u1d04\u029f\u026a\u1d04\u1d0b \u029c\u1d07\u0280\u1d07") && !stripped.contains("Click Here")) {
                    target.sendMessage(ColorUtil.parse(resolved));
                    continue;
                }
                target.sendMessage(ColorUtil.parse(resolved).clickEvent(ClickEvent.runCommand((String)"/duelaccept")).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse(ConfigManager.msg("duel.request-notify-click-hover")))));
            }
            CustomKitRequest stored = pending.get(target.getUniqueId());
            long ticks = (long)ConfigManager.requestTimeout() * 20L;
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (pending.remove(target.getUniqueId(), stored)) {
                    sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-expired-sender").replace("%target%", target.getName())));
                    target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-expired-target").replace("%sender%", sender.getName())));
                }
            }, ticks);
        }
    }

    public static void acceptRequest(Player target) {
        CustomKitRequest req = pending.remove(target.getUniqueId());
        if (req == null) {
            target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-pending-request")));
        } else {
            Player sender = Bukkit.getPlayer((UUID)req.sender());
            if (sender != null && sender.isOnline()) {
                sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-accepted-sender").replace("%target%", target.getName())));
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-accepted-target").replace("%sender%", sender.getName())));
                GUIManager.closeMenus(sender, target);
                QueueManager.removePlayerFromQueues(sender);
                QueueManager.removePlayerFromQueues(target);
                DuelSession.startCustomKitDuel(sender, target, req.kitSlotSender(), req.rounds(), req.arenaBaseName());
            } else {
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.sender-offline")));
            }
        }
    }

    public static void denyRequest(Player target) {
        CustomKitRequest req = pending.remove(target.getUniqueId());
        if (req != null) {
            Player sender = Bukkit.getPlayer((UUID)req.sender());
            target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-declined-target")));
            if (sender != null && sender.isOnline()) {
                sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-declined-sender").replace("%target%", target.getName())));
            }
        }
    }

    public static void clearFor(UUID uuid) {
        pending.remove(uuid);
        pending.entrySet().removeIf(entry -> ((CustomKitRequest)entry.getValue()).sender().equals(uuid));
    }

    public record CustomKitRequest(UUID sender, UUID target, int kitSlotSender, int kitSlotTarget, int rounds, String arenaBaseName) {
        public CustomKitRequest(UUID sender, UUID target, int kitSlotSender, int kitSlotTarget, int rounds) {
            this(sender, target, kitSlotSender, kitSlotTarget, rounds, null);
        }
    }
}

