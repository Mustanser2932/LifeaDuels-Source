/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityRegainHealthEvent
 *  org.bukkit.event.entity.EntityRegainHealthEvent$RegainReason
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 */
package me.lifea.duel.custom;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.storage.DatabaseManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;

public class CustomKitRulesListener
implements Listener {
    private static final Map<UUID, Set<Location>> playerPlacedBlocks = new HashMap<UUID, Set<Location>>();
    private static final Set<String> whitelistCache = new HashSet<String>();
    private static long lastWhitelistFetch = 0L;
    private static final Map<String, Set<String>> arenaBlockCache = new HashMap<String, Set<String>>();
    private static long lastArenaBlockFetch = 0L;

    private static void refreshWhitelist() {
        if (System.currentTimeMillis() - lastWhitelistFetch > 5000L) {
            whitelistCache.clear();
            whitelistCache.addAll(CustomKitManager.getBlockWhitelist());
            lastWhitelistFetch = System.currentTimeMillis();
        }
    }

    private static Set<String> getArenaBlocks(String arenaName) {
        if (System.currentTimeMillis() - lastArenaBlockFetch > 5000L) {
            arenaBlockCache.clear();
            lastArenaBlockFetch = System.currentTimeMillis();
        }
        return arenaBlockCache.computeIfAbsent(arenaName, DatabaseManager::getArenaCustomKitBlocks);
    }

    public static boolean isInCustomKitMatch(Player player) {
        DuelSession session = DuelSession.getSession(player.getUniqueId());
        return session != null && session.isCustomKitDuel();
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockPlace(BlockPlaceEvent e) {
        DuelSession session;
        Player player = e.getPlayer();
        if (CustomKitRulesListener.isInCustomKitMatch(player) && (session = DuelSession.getSession(player.getUniqueId())) != null) {
            int kitSlot = session.getCustomKitSlot();
            UUID kitOwner = session.getCustomKitOwner();
            CustomKit kit = CustomKitManager.getKit(kitOwner, kitSlot);
            if (kit != null && !kit.isSettingEnabled("block-placing")) {
                e.setCancelled(true);
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.block-place-disabled")));
            } else {
                CustomKitRulesListener.trackPlacedBlock(player.getUniqueId(), e.getBlock().getLocation());
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent e) {
        Material blockType;
        DuelSession session;
        Player player = e.getPlayer();
        if (CustomKitRulesListener.isInCustomKitMatch(player) && (session = DuelSession.getSession(player.getUniqueId())) != null && (blockType = e.getBlock().getType()) != Material.FIRE && blockType != Material.SOUL_FIRE && blockType != Material.WATER && blockType != Material.LAVA && blockType != Material.ICE && blockType != Material.PACKED_ICE && blockType != Material.BLUE_ICE && blockType != Material.FROSTED_ICE) {
            int kitSlot = session.getCustomKitSlot();
            UUID kitOwner = session.getCustomKitOwner();
            CustomKit kit = CustomKitManager.getKit(kitOwner, kitSlot);
            if (kit != null && !kit.isSettingEnabled("block-breaking")) {
                e.setCancelled(true);
            } else {
                CustomKitRulesListener.refreshWhitelist();
                if (!(whitelistCache.contains(blockType.name()) || CustomKitRulesListener.getArenaBlocks(session.getArena().getName()).contains(blockType.name()) || CustomKitRulesListener.isPlayerPlaced(player.getUniqueId(), e.getBlock().getLocation()))) {
                    e.setCancelled(true);
                }
            }
        }
    }

    private static CustomKit getCustomKitForPlayer(Player player) {
        DuelSession session = DuelSession.getSession(player.getUniqueId());
        return session != null && session.isCustomKitDuel() ? CustomKitManager.getKit(session.getCustomKitOwner(), session.getCustomKitSlot()) : null;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        Player p;
        CustomKit kit;
        HumanEntity var3 = event.getEntity();
        if (var3 instanceof Player && (kit = CustomKitRulesListener.getCustomKitForPlayer(p = (Player)var3)) != null && kit.isSettingEnabled("disable-hunger")) {
            event.setCancelled(true);
            p.setFoodLevel(20);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityRegen(EntityRegainHealthEvent event) {
        Player p;
        CustomKit kit;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && (kit = CustomKitRulesListener.getCustomKitForPlayer(p = (Player)var3)) != null && kit.isSettingEnabled("disable-health-regen") && event.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onFallDamage(EntityDamageEvent event) {
        Player p;
        CustomKit kit;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && (kit = CustomKitRulesListener.getCustomKitForPlayer(p = (Player)var3)) != null && kit.isSettingEnabled("disable-fall-damage") && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
        }
    }

    public static void removeHealthIndicator(Player player) {
    }

    public static void refreshHealthIndicators(Collection<Player> players) {
    }

    public static void trackPlacedBlock(UUID playerUuid, Location location) {
        playerPlacedBlocks.computeIfAbsent(playerUuid, k -> new HashSet()).add(location);
    }

    public static boolean isPlayerPlaced(UUID playerUuid, Location location) {
        Set<Location> blocks = playerPlacedBlocks.get(playerUuid);
        return blocks != null && blocks.contains(location);
    }

    public static void clearPlacedBlocks(UUID playerUuid) {
        playerPlacedBlocks.remove(playerUuid);
    }

    public static void clearAllPlacedBlocks() {
        playerPlacedBlocks.clear();
    }
}

