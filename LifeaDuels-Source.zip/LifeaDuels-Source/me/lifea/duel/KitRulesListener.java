/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.format.NamedTextColor
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Keyed
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Tag
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.block.Block
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.AnimalTamer
 *  org.bukkit.entity.Creeper
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Fireball
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.entity.TNTPrimed
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockExplodeEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.CreatureSpawnEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.entity.EntityRegainHealthEvent
 *  org.bukkit.event.entity.EntityRegainHealthEvent$RegainReason
 *  org.bukkit.event.entity.EntityResurrectEvent
 *  org.bukkit.event.entity.EntityTameEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.PlayerBucketEmptyEvent
 *  org.bukkit.event.player.PlayerExpChangeEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemConsumeEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.Damageable
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.projectiles.ProjectileSource
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.util.Vector
 */
package me.lifea.duel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.kit.KitRuleManager;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.party.match.PartyMatchType;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.NametagManager;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.AnimalTamer;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.EntityTameEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.util.Vector;

public class KitRulesListener
implements Listener {
    private static final Map<UUID, Integer> boxingHits = new ConcurrentHashMap<UUID, Integer>();
    private static final Map<UUID, String> playerKitCache = new ConcurrentHashMap<UUID, String>();
    private static final Set<UUID> recentPearlTeleport = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> sumoWaterDeath = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> pendingHealthRefreshes = ConcurrentHashMap.newKeySet();
    private static final Map<String, String> TIER_SUFFIX = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus", "Extra", "Extra");
    private static KitRulesListener instance;
    private static final String OBJ_NAME = "dv_hp";

    public KitRulesListener() {
        instance = this;
    }

    private boolean inDuel(Player p) {
        if (!MatchManager.inMatch(p.getUniqueId())) {
            return false;
        }
        DuelSession session = DuelSession.getSession(p.getUniqueId());
        return session == null || !session.isCustomKitDuel();
    }

    private static String getKitKey(Player p) {
        PartyDuelSession partySession = PartyDuelSession.getSession(p.getUniqueId());
        if (partySession != null && partySession.getMatchType() == PartyMatchType.JUGGERNAUT) {
            String suffix;
            String gamemode;
            int teamIndex = partySession.getPlayerTeamIndex(p.getUniqueId());
            String tier = teamIndex == 0 ? partySession.getTier() : partySession.getOthersTier();
            String string = gamemode = teamIndex == 0 ? partySession.getGamemode() : partySession.getOthersGamemode();
            if (tier == null || gamemode == null) {
                tier = partySession.getTier();
                gamemode = partySession.getGamemode();
            }
            String kit = (suffix = TIER_SUFFIX.get(tier)) != null ? gamemode + "-" + suffix : gamemode;
            playerKitCache.put(p.getUniqueId(), kit);
            return kit;
        }
        Match match = MatchManager.getMatch(p.getUniqueId());
        if (match == null) {
            playerKitCache.remove(p.getUniqueId());
            return null;
        }
        String tier = match.getTier();
        String gamemode = match.getGamemode();
        String suffix = TIER_SUFFIX.get(tier);
        String kit = suffix != null ? gamemode + "-" + suffix : gamemode;
        playerKitCache.put(p.getUniqueId(), kit);
        return kit;
    }

    private boolean rule(Player p, String key) {
        String kit = KitRulesListener.getKitKey(p);
        return kit == null ? false : KitRuleManager.isRuleEnabled(kit, key);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p)) {
            boolean bedwarsBed;
            Arena arena = this.getArenaFor(p);
            if (arena == null) {
                return;
            }
            if (!arena.isInside(event.getBlock().getLocation())) {
                event.setCancelled(true);
                p.sendActionBar(ColorUtil.parse("&cYou can only build inside the arena region."));
                return;
            }
            Integer buildLimit = arena.getBuildLimitY();
            if (buildLimit != null && event.getBlock().getY() > buildLimit) {
                event.setCancelled(true);
                p.sendActionBar(ColorUtil.parse("&cYou cannot build above &e" + buildLimit + "&c in this arena."));
                return;
            }
            DuelSession session = DuelSession.getSession(p.getUniqueId());
            boolean bl = bedwarsBed = session != null && session.isBedwarsMatch() && Tag.BEDS.isTagged((Keyed)event.getBlockPlaced().getType());
            if (bedwarsBed) {
                event.setCancelled(true);
                p.sendActionBar(ColorUtil.parse("&cBeds are pre-placed objectives in this arena."));
            } else if (!this.rule(p, "block-placing") && !this.rule(p, "player-mined-blocks")) {
                event.setCancelled(true);
            } else {
                if (this.rule(p, "tnt-pvp") && event.getBlockPlaced().getType() == Material.TNT) {
                    Block b = event.getBlockPlaced();
                    Lifea.getInstance().getServer().getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                        if (b.getType() == Material.TNT) {
                            b.setType(Material.AIR);
                            TNTPrimed tnt = (TNTPrimed)b.getWorld().spawn(b.getLocation().add(0.5, 0.0, 0.5), TNTPrimed.class);
                            tnt.setFuseTicks(40);
                        }
                    });
                }
                if (!this.isPartyFfa(p) && this.rule(p, "bed-fight") && Tag.BEDS.isTagged((Keyed)event.getBlockPlaced().getType())) {
                    Block bed = event.getBlockPlaced();
                    Lifea.getInstance().getServer().getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                        if (Tag.BEDS.isTagged((Keyed)bed.getType())) {
                            bed.getWorld().createExplosion(bed.getLocation().add(0.5, 0.5, 0.5), 5.0f, true, true);
                            bed.setType(Material.AIR);
                        }
                    }, 1L);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p)) {
            Arena arena = this.getArenaFor(p);
            if (arena != null && !arena.isInside(event.getBlock().getLocation())) {
                event.setCancelled(true);
                p.sendActionBar(ColorUtil.parse("&cYou can only break blocks inside the arena region."));
                return;
            }
            String kit = KitRulesListener.getKitKey(p);
            if (kit != null) {
                Material type = event.getBlock().getType();
                DuelSession session = DuelSession.getSession(p.getUniqueId());
                if (session != null && session.isBedwarsMatch() && Tag.BEDS.isTagged((Keyed)type)) {
                    if (session.onBedBroken(p, event.getBlock())) {
                        event.setDropItems(false);
                        event.setExpToDrop(0);
                    } else {
                        event.setCancelled(true);
                    }
                    return;
                }
                if (type != Material.FIRE && type != Material.SOUL_FIRE && type != Material.SHORT_GRASS && type != Material.TALL_GRASS && type != Material.SNOW && type != Material.VINE && type != Material.TWISTING_VINES && type != Material.WEEPING_VINES) {
                    boolean playerMinedBlocks = KitRuleManager.isRuleEnabled(kit, "player-mined-blocks");
                    boolean blockBreaking = KitRuleManager.isRuleEnabled(kit, "block-breaking");
                    Set<String> whitelist = KitRuleManager.getBlockWhitelist(kit);
                    if (whitelist.isEmpty() || !whitelist.contains(type.name())) {
                        if (playerMinedBlocks && arena != null) {
                            boolean isPersonalBlock = arena.getModifiedBlockTracker().isPersonalPlaced(event.getBlock().getX(), event.getBlock().getY(), event.getBlock().getZ());
                            if (isPersonalBlock) {
                                arena.getModifiedBlockTracker().unmarkPersonalPlaced(event.getBlock().getX(), event.getBlock().getY(), event.getBlock().getZ());
                            } else {
                                event.setCancelled(true);
                                p.sendActionBar(ColorUtil.parse(ConfigManager.msg("duel.block-break-personal-only")));
                            }
                        } else if (arena != null && arena.getModifiedBlockTracker().isPersonalPlaced(event.getBlock().getX(), event.getBlock().getY(), event.getBlock().getZ())) {
                            arena.getModifiedBlockTracker().unmarkPersonalPlaced(event.getBlock().getX(), event.getBlock().getY(), event.getBlock().getZ());
                        } else if (!blockBreaking) {
                            event.setCancelled(true);
                        }
                    }
                    if (!event.isCancelled()) {
                        // empty if block
                    }
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p)) {
            Block placedBlock;
            Integer buildLimit;
            Arena arena = this.getArenaFor(p);
            if (arena == null) {
                return;
            }
            if (!arena.isInside(event.getBlock().getLocation())) {
                event.setCancelled(true);
                p.sendActionBar(ColorUtil.parse("&cYou can only build inside the arena region."));
            }
            if ((buildLimit = arena.getBuildLimitY()) != null && (placedBlock = event.getBlockClicked().getRelative(event.getBlockFace())).getY() > buildLimit) {
                event.setCancelled(true);
                p.sendActionBar(ColorUtil.parse("&cYou cannot build above &e" + buildLimit + "&c in this arena."));
                return;
            }
        }
    }

    private Arena getArenaFor(Player p) {
        DuelSession session = DuelSession.getSession(p.getUniqueId());
        if (session != null) {
            return session.getArena();
        }
        PartyDuelSession partySession = PartyDuelSession.getSession(p.getUniqueId());
        return partySession != null ? partySession.getArena() : null;
    }

    private boolean isPartyFfa(Player p) {
        PartyDuelSession partySession = PartyDuelSession.getSession(p.getUniqueId());
        return partySession != null && partySession.getMatchType() == PartyMatchType.FFA;
    }

    private String getKitKeyFromLocation(Location loc) {
        for (Map.Entry<UUID, String> entry : playerKitCache.entrySet()) {
            Player p = Bukkit.getPlayer((UUID)entry.getKey());
            if (p == null || !p.getWorld().equals((Object)loc.getWorld()) || !(p.getLocation().distanceSquared(loc) < 2500.0)) continue;
            return entry.getValue();
        }
        return null;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityExplode(EntityExplodeEvent event) {
        String kit = this.getKitKeyFromLocation(event.getLocation());
        if (kit != null) {
            boolean blockBreaking = KitRuleManager.isRuleEnabled(kit, "block-breaking");
            Set<String> allowedBlocks = KitRuleManager.getBlockWhitelist(kit);
            event.blockList().removeIf(block -> {
                Material type = block.getType();
                if (type != Material.FIRE && type != Material.SOUL_FIRE && type != Material.SHORT_GRASS && type != Material.TALL_GRASS && type != Material.SNOW && type != Material.VINE && type != Material.TWISTING_VINES && type != Material.WEEPING_VINES) {
                    if (!allowedBlocks.isEmpty() && allowedBlocks.contains(type.name())) {
                        return false;
                    }
                    if (!blockBreaking) {
                        return true;
                    }
                    return !allowedBlocks.isEmpty() && !allowedBlocks.contains(type.name());
                }
                return false;
            });
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockExplode(BlockExplodeEvent event) {
        String kit = this.getKitKeyFromLocation(event.getBlock().getLocation());
        if (kit != null) {
            boolean blockBreaking = KitRuleManager.isRuleEnabled(kit, "block-breaking");
            Set<String> allowedBlocks = KitRuleManager.getBlockWhitelist(kit);
            event.blockList().removeIf(block -> {
                Material type = block.getType();
                if (type != Material.FIRE && type != Material.SOUL_FIRE && type != Material.SHORT_GRASS && type != Material.TALL_GRASS && type != Material.SNOW && type != Material.VINE && type != Material.TWISTING_VINES && type != Material.WEEPING_VINES) {
                    if (!allowedBlocks.isEmpty() && allowedBlocks.contains(type.name())) {
                        return false;
                    }
                    if (!blockBreaking) {
                        return true;
                    }
                    return !allowedBlocks.isEmpty() && !allowedBlocks.contains(type.name());
                }
                return false;
            });
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onChorusFruit(PlayerTeleportEvent event) {
        Player p;
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT && this.inDuel(p = event.getPlayer())) {
            Arena arena = null;
            DuelSession session = DuelSession.getSession(p.getUniqueId());
            if (session != null) {
                arena = session.getArena();
            } else {
                PartyDuelSession partySession = PartyDuelSession.getSession(p.getUniqueId());
                if (partySession != null) {
                    arena = partySession.getArena();
                }
            }
            if (arena != null) {
                Location to = event.getTo();
                if (to == null) {
                    event.setCancelled(true);
                } else if (!arena.isInside(to)) {
                    double cx = Math.max((double)(arena.getRegionMinX() + 1), Math.min((double)(arena.getRegionMaxX() - 1), to.getX()));
                    double cy = Math.max((double)(arena.getRegionMinY() + 1), Math.min((double)(arena.getRegionMaxY() - 1), to.getY()));
                    double cz = Math.max((double)(arena.getRegionMinZ() + 1), Math.min((double)(arena.getRegionMaxZ() - 1), to.getZ()));
                    event.setTo(new Location(to.getWorld(), cx, cy, cz, to.getYaw(), to.getPitch()));
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        Player p;
        HumanEntity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "disable-hunger")) {
            event.setCancelled(true);
            p.setFoodLevel(20);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityRegen(EntityRegainHealthEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.inDuel(p) && this.rule(p, "disable-health-regen") && event.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onCraftingTableOpen(PlayerInteractEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p) && event.getClickedBlock() != null && event.getClickedBlock().getType() == Material.CRAFTING_TABLE && !this.rule(p, "enable-crafting")) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPearlTeleport(PlayerTeleportEvent event) {
        Player p;
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL && this.inDuel(p = event.getPlayer())) {
            recentPearlTeleport.add(p.getUniqueId());
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> recentPearlTeleport.remove(p.getUniqueId()), 10L);
            if (ConfigManager.config().getBoolean("pearl-protection.enabled", true)) {
                int dist = (int)Math.ceil(ConfigManager.config().getDouble("pearl-protection.barrier-distance", 2.5));
                Location loc = p.getLocation();
                for (int dx = -dist; dx <= dist; ++dx) {
                    for (int dy = -dist; dy <= dist; ++dy) {
                        for (int dz = -dist; dz <= dist; ++dz) {
                            if (loc.getWorld().getBlockAt(loc.getBlockX() + dx, loc.getBlockY() + dy, loc.getBlockZ() + dz).getType() != Material.BARRIER) continue;
                            event.setCancelled(true);
                            p.sendActionBar(ColorUtil.parse("&cYou cannot pearl near a barrier."));
                            return;
                        }
                    }
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onFallDamage(EntityDamageEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "disable-fall-damage") && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            if (recentPearlTeleport.remove(p.getUniqueId())) {
                return;
            }
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onDamageBoost(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player) {
            Player attacker = null;
            Entity var6 = event.getDamager();
            if (var6 instanceof Player) {
                Player a;
                attacker = a = (Player)var6;
            } else {
                Projectile proj;
                ProjectileSource var8;
                var6 = event.getDamager();
                if (var6 instanceof Projectile && (var8 = (proj = (Projectile)var6).getShooter()) instanceof Player) {
                    Player a;
                    attacker = a = (Player)var8;
                }
            }
            if (attacker != null && this.inDuel(attacker) && this.rule(attacker, "damage-boost-33")) {
                event.setDamage(event.getDamage() * 1.33);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onBoxingHit(EntityDamageByEntityEvent event) {
        Entity var4 = event.getDamager();
        if (var4 instanceof Player) {
            Player attacker = (Player)var4;
            var4 = event.getEntity();
            if (var4 instanceof Player) {
                Player victim = (Player)var4;
                if (this.inDuel(attacker) && this.rule(attacker, "boxing")) {
                    event.setDamage(0.0);
                    victim.setHealth(victim.getAttribute(Attribute.MAX_HEALTH).getValue());
                    int hits = boxingHits.getOrDefault(attacker.getUniqueId(), 0) + 1;
                    boxingHits.put(attacker.getUniqueId(), hits);
                    int remaining = 100 - hits;
                    if (remaining > 0) {
                        attacker.sendActionBar(ColorUtil.parse("&f" + hits + " &f/ &f100 &fhits &8| &f" + remaining + " &fto win"));
                    } else {
                        boxingHits.remove(attacker.getUniqueId());
                        boxingHits.remove(victim.getUniqueId());
                        victim.setHealth(0.0);
                    }
                    return;
                }
                return;
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onNoDamage(EntityDamageEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "no-damage") && !sumoWaterDeath.remove(p.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBedFightDamage(EntityDamageEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && !this.isPartyFfa(p) && this.rule(p, "bed-fight") && event.getCause() != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION && event.getCause() != EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onFireballInteract(PlayerInteractEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p) && this.rule(p, "fireball-fight") && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && p.getInventory().getItemInMainHand().getType() == Material.FIRE_CHARGE) {
            event.setCancelled(true);
            Vector dir = p.getLocation().getDirection().normalize().multiply(2);
            Fireball fb = (Fireball)p.getWorld().spawn(p.getEyeLocation().add(dir), Fireball.class);
            fb.setShooter((ProjectileSource)p);
            fb.setDirection(dir);
            fb.setYield(0.0f);
            fb.setIsIncendiary(false);
            ItemStack held = p.getInventory().getItemInMainHand();
            if (held.getAmount() > 1) {
                held.setAmount(held.getAmount() - 1);
            } else {
                p.getInventory().setItemInMainHand((ItemStack)null);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onFireballHit(EntityDamageByEntityEvent event) {
        Player shooter;
        Fireball fb;
        ProjectileSource var4;
        Entity var3 = event.getDamager();
        if (var3 instanceof Fireball && (var4 = (fb = (Fireball)var3).getShooter()) instanceof Player && this.inDuel(shooter = (Player)var4) && this.rule(shooter, "fireball-fight")) {
            event.setCancelled(true);
            Entity var5 = event.getEntity();
            if (var5 instanceof Player) {
                Player hit = (Player)var5;
                Vector push = hit.getLocation().toVector().subtract(fb.getLocation().toVector()).normalize().multiply(2).setY(0.5);
                hit.setVelocity(push);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onSumoMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p) && this.rule(p, "sumo") && !sumoWaterDeath.contains(p.getUniqueId())) {
            Location loc = p.getLocation();
            Material feet = loc.getBlock().getType();
            Material below = loc.clone().subtract(0.0, 1.0, 0.0).getBlock().getType();
            if (feet == Material.WATER || feet == Material.BUBBLE_COLUMN || below == Material.WATER || below == Material.BUBBLE_COLUMN || loc.getBlock().isLiquid()) {
                sumoWaterDeath.add(p.getUniqueId());
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                    if (p.isOnline() && !p.isDead()) {
                        p.damage(p.getHealth() + 1.0);
                    }
                });
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onSumoDrowning(EntityDamageEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "sumo") && (event.getCause() == EntityDamageEvent.DamageCause.DROWNING || event.getCause() == EntityDamageEvent.DamageCause.SUFFOCATION)) {
            sumoWaterDeath.add(p.getUniqueId());
            event.setDamage(p.getHealth() + 1.0);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onImmortality(EntityDamageEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "immortality")) {
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                if (p.isOnline() && !p.isDead()) {
                    p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
                }
            });
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onAdventureMode(EntityDamageByEntityEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "adventure-mode") && p.getGameMode() != GameMode.ADVENTURE) {
            p.setGameMode(GameMode.ADVENTURE);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onTame(EntityTameEvent event) {
        Player p;
        AnimalTamer var3 = event.getOwner();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && this.rule(p, "auto-tame")) {
            event.setCancelled(false);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onCreeperSpawn(CreatureSpawnEvent event) {
        LivingEntity var3 = event.getEntity();
        if (var3 instanceof Creeper) {
            Creeper creeper = (Creeper)var3;
            for (Player p : creeper.getWorld().getPlayers()) {
                if (!this.inDuel(p) || !this.rule(p, "creeper-pvp") || !(creeper.getLocation().distanceSquared(p.getLocation()) <= 100.0)) continue;
                creeper.ignite();
                break;
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onExpPickup(PlayerExpChangeEvent event) {
        int xp;
        Player p = event.getPlayer();
        if (this.inDuel(p) && this.rule(p, "no-xp-randomness") && (xp = event.getAmount()) > 0) {
            ArrayList<ItemStack> mendingItems = new ArrayList<ItemStack>();
            for (ItemStack item : p.getInventory().getContents()) {
                if (item == null || !item.containsEnchantment(Enchantment.MENDING)) continue;
                mendingItems.add(item);
            }
            for (ItemStack item : p.getInventory().getArmorContents()) {
                if (item == null || !item.containsEnchantment(Enchantment.MENDING)) continue;
                mendingItems.add(item);
            }
            if (!mendingItems.isEmpty()) {
                event.setAmount(0);
                int perItem = xp / mendingItems.size();
                int remainder = xp % mendingItems.size();
                for (int i = 0; i < mendingItems.size(); ++i) {
                    ItemStack item;
                    item = (ItemStack)mendingItems.get(i);
                    int repair = (perItem + (i < remainder ? 1 : 0)) * 2;
                    Damageable meta = (Damageable)item.getItemMeta();
                    if (meta == null) continue;
                    meta.setDamage(Math.max(0, meta.getDamage() - repair));
                    item.setItemMeta((ItemMeta)meta);
                }
            }
        }
    }

    private static void updateHealthOnBoard(Player target, Player viewer) {
        Scoreboard board = viewer.getScoreboard();
        if (board != Bukkit.getScoreboardManager().getMainScoreboard()) {
            KitRulesListener.ensureObjective(board);
            int hp = KitRulesListener.healthIndicatorValue(target);
            board.getObjective(OBJ_NAME).getScore(target.getName()).setScore(hp);
        }
    }

    private static void ensureObjective(Scoreboard board) {
        if (board.getObjective(OBJ_NAME) == null) {
            Objective obj = board.registerNewObjective(OBJ_NAME, "dummy", ColorUtil.parse("&#FB0000\u2764"));
            obj.setDisplaySlot(DisplaySlot.BELOW_NAME);
        }
    }

    public static void removeHealthIndicator(Player player) {
        Scoreboard board = player.getScoreboard();
        Objective obj = board.getObjective(OBJ_NAME);
        if (obj != null) {
            obj.unregister();
        }
    }

    public static void refreshHealthIndicators(Collection<Player> players) {
        for (Player viewer : players) {
            boolean enabled = PlayerSettingsManager.get(viewer.getUniqueId(), PlayerSettingsManager.Setting.HEALTH_INDICATOR);
            String kit = KitRulesListener.getKitKey(viewer);
            if (!enabled || kit == null || !KitRuleManager.isHealthIndicatorEnabled(kit)) {
                KitRulesListener.removeHealthIndicator(viewer);
                continue;
            }
            Scoreboard board = viewer.getScoreboard();
            if (board == Bukkit.getScoreboardManager().getMainScoreboard()) continue;
            KitRulesListener.ensureObjective(board);
            for (Player target : players) {
                int hp = KitRulesListener.healthIndicatorValue(target);
                board.getObjective(OBJ_NAME).getScore(target.getName()).setScore(hp);
            }
        }
        NametagManager.refreshTextFor(players);
    }

    public static int healthIndicatorValue(Player player) {
        return (int)Math.ceil(player.getHealth() + Math.max(0.0, player.getAbsorptionAmount()));
    }

    public static NamedTextColor healthIndicatorColor(Player viewer, Player target) {
        if (viewer == null || target == null || !PlayerSettingsManager.get(viewer.getUniqueId(), PlayerSettingsManager.Setting.HEALTH_INDICATOR) || !KitRulesListener.isHealthIndicatorPair(viewer, target)) {
            return null;
        }
        String kit = KitRulesListener.getKitKey(viewer);
        if (kit == null || !KitRuleManager.isHealthIndicatorEnabled(kit)) {
            return null;
        }
        return target.getAbsorptionAmount() > 0.0 ? NamedTextColor.YELLOW : NamedTextColor.RED;
    }

    private static boolean isHealthIndicatorPair(Player viewer, Player target) {
        PartyDuelSession partySession = PartyDuelSession.getSession(viewer.getUniqueId());
        if (partySession != null) {
            return partySession.getParticipants().contains(target.getUniqueId());
        }
        Match match = MatchManager.getMatch(viewer.getUniqueId());
        return match != null && (match.getPlayer1().equals(target.getUniqueId()) || match.getPlayer2().equals(target.getUniqueId()));
    }

    public static void refreshHealthIndicatorsFor(Player player) {
        PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
        if (partySession != null) {
            ArrayList<Player> players = new ArrayList<Player>();
            for (UUID uuid : partySession.getParticipants()) {
                Player participant = Bukkit.getPlayer((UUID)uuid);
                if (participant == null || !participant.isOnline()) continue;
                players.add(participant);
            }
            KitRulesListener.refreshHealthIndicators(players);
            return;
        }
        DuelSession duelSession = DuelSession.getSession(player.getUniqueId());
        if (duelSession != null) {
            ArrayList<Player> players = new ArrayList<Player>();
            Player p1 = Bukkit.getPlayer((UUID)duelSession.getPlayer1Id());
            Player p2 = Bukkit.getPlayer((UUID)duelSession.getPlayer2Id());
            if (p1 != null && p1.isOnline()) {
                players.add(p1);
            }
            if (p2 != null && p2.isOnline()) {
                players.add(p2);
            }
            KitRulesListener.refreshHealthIndicators(players);
        } else {
            KitRulesListener.removeHealthIndicator(player);
        }
    }

    private void updateHealthForMatchOf(Player p) {
        String kit;
        Match match;
        if (PartyDuelSession.getSession(p.getUniqueId()) != null) {
            KitRulesListener.refreshHealthIndicatorsFor(p);
            return;
        }
        if (PlayerSettingsManager.get(p.getUniqueId(), PlayerSettingsManager.Setting.HEALTH_INDICATOR) && (match = MatchManager.getMatch(p.getUniqueId())) != null && (kit = KitRulesListener.getKitKey(p)) != null && KitRuleManager.isHealthIndicatorEnabled(kit)) {
            Player p1 = Bukkit.getPlayer((UUID)match.getPlayer1());
            Player p2 = Bukkit.getPlayer((UUID)match.getPlayer2());
            if (p1 != null) {
                KitRulesListener.updateHealthOnBoard(p, p1);
            }
            if (p2 != null) {
                KitRulesListener.updateHealthOnBoard(p, p2);
            }
        }
    }

    private void scheduleHealthRefresh(Player player) {
        UUID playerId = player.getUniqueId();
        if (!pendingHealthRefreshes.add(playerId)) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            pendingHealthRefreshes.remove(playerId);
            if (!player.isOnline()) {
                return;
            }
            this.updateHealthForMatchOf(player);
            NametagManager.refreshTextFor(List.of(player));
        }, 1L);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onHealthIndicatorDamage(EntityDamageEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3)) {
            this.scheduleHealthRefresh(p);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onHealthIndicatorRegen(EntityRegainHealthEvent event) {
        Player p;
        Entity var3 = event.getEntity();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3)) {
            this.scheduleHealthRefresh(p);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onHealthIndicatorConsume(PlayerItemConsumeEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p)) {
            this.scheduleHealthRefresh(p);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onHealthIndicatorTotem(EntityResurrectEvent event) {
        Player p;
        LivingEntity livingEntity = event.getEntity();
        if (livingEntity instanceof Player && this.inDuel(p = (Player)livingEntity)) {
            this.scheduleHealthRefresh(p);
        }
    }

    public static void cachePlayerKit(UUID uuid, String kitKey) {
        if (kitKey != null) {
            playerKitCache.put(uuid, kitKey);
        }
    }

    public static void clearPlayerKitCache(UUID uuid) {
        playerKitCache.remove(uuid);
    }

    public static void clearBoxingHits(UUID uuid) {
        boxingHits.remove(uuid);
    }

    public static void clearBoxingHitsForPlayers(UUID uuid1, UUID uuid2) {
        boxingHits.remove(uuid1);
        if (uuid2 != null) {
            boxingHits.remove(uuid2);
        }
    }

    public static void clearSumoWaterDeath(UUID uuid) {
        sumoWaterDeath.remove(uuid);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onSwapOffhand(PlayerSwapHandItemsEvent event) {
        Player p = event.getPlayer();
        if (this.inDuel(p) && this.rule(p, "no-offhand")) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInventorySwapOffhand(InventoryClickEvent event) {
        Player p;
        HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof Player && this.inDuel(p = (Player)var3) && event.getClick() == ClickType.SWAP_OFFHAND && this.rule(p, "no-offhand")) {
            event.setCancelled(true);
        }
    }
}

