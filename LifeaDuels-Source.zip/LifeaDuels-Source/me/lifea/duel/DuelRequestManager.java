/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.duel;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.duel.custom.CustomKitRequestManager;
import me.lifea.gui.DuelRequestGUI;
import me.lifea.gui.GUIManager;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.match.Match;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.queue.QueueManager;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class DuelRequestManager {
    private static final Map<UUID, DuelRequest> pending = new ConcurrentHashMap<UUID, DuelRequest>();

    public static void sendRequest(Player sender, Player target, String tier, String gamemode, int rounds) {
        DuelRequestManager.sendRequest(sender, target, tier, gamemode, rounds, null);
    }

    public static void sendRequest(Player sender, Player target, String tier, String gamemode, int rounds, String arenaBaseName) {
        if (!KitManager.isKitEnabled(tier, gamemode)) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.kit-disabled").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
        } else if (!PlayerSettingsManager.get(target.getUniqueId(), PlayerSettingsManager.Setting.DUEL_REQUESTS)) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("settings.duel-requests-disabled").replace("%player%", target.getName())));
        } else if (pending.containsKey(target.getUniqueId())) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-has-request")));
        } else {
            long timeoutMs = (long)ConfigManager.requestTimeout() * 1000L;
            long expiresAt = System.currentTimeMillis() + timeoutMs;
            pending.put(target.getUniqueId(), new DuelRequest(sender.getUniqueId(), tier, gamemode, rounds, arenaBaseName, expiresAt));
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-sent").replace("%target%", target.getName()).replace("%tier%", tier).replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%rounds%", "FT" + rounds)));
            String ft = "FT" + rounds;
            for (String line : ConfigManager.msgs("duel.request-notify-lines")) {
                if (line.contains("%arena%") && (arenaBaseName == null || arenaBaseName.isBlank())) continue;
                String resolved = line.replace("%sender%", sender.getName()).replace("%tier%", tier).replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%rounds%", ft).replace("%arena%", arenaBaseName != null ? arenaBaseName : "");
                String stripped = resolved.replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-FklmnorKLMNOR]", "");
                if (!stripped.contains("\u1d04\u029f\u026a\u1d04\u1d0b \u029c\u1d07\u0280\u1d07") && !stripped.contains("Click Here")) {
                    target.sendMessage(ColorUtil.parse(resolved));
                    continue;
                }
                target.sendMessage(ColorUtil.parse(resolved).clickEvent(ClickEvent.runCommand((String)"/duelaccept")).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse(ConfigManager.msg("duel.request-notify-click-hover")))));
            }
            DuelRequest stored = pending.get(target.getUniqueId());
            long ticks = (long)ConfigManager.requestTimeout() * 20L;
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (pending.remove(target.getUniqueId(), stored)) {
                    sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-expired-sender").replace("%target%", target.getName())));
                    target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-expired-target").replace("%sender%", sender.getName())));
                }
            }, ticks);
        }
    }

    public static void openRequestGUI(Player target) {
        CustomKitRequestManager.CustomKitRequest customReq = CustomKitRequestManager.getPending(target.getUniqueId());
        if (customReq != null) {
            CustomKitRequestManager.acceptRequest(target);
        } else {
            DuelRequest req = pending.get(target.getUniqueId());
            if (req != null && !req.isExpired()) {
                Player sender = Bukkit.getPlayer((UUID)req.sender());
                if (sender != null && sender.isOnline()) {
                    new DuelRequestGUI(sender, req.tier(), req.gamemode()).open(target);
                } else {
                    pending.remove(target.getUniqueId());
                    target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.sender-offline")));
                }
            } else {
                pending.remove(target.getUniqueId());
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-pending-request")));
            }
        }
    }

    public static void acceptRequest(Player target) {
        CustomKitRequestManager.CustomKitRequest customReq = CustomKitRequestManager.getPending(target.getUniqueId());
        if (customReq != null) {
            CustomKitRequestManager.acceptRequest(target);
        } else {
            DuelRequest req = pending.remove(target.getUniqueId());
            if (req == null) {
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-pending-request")));
            } else if (req.isExpired()) {
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-pending-request")));
            } else {
                Player sender = Bukkit.getPlayer((UUID)req.sender());
                if (sender != null && sender.isOnline()) {
                    GUIManager.closeMenus(sender, target);
                    QueueManager.removePlayerFromQueues(sender);
                    QueueManager.removePlayerFromQueues(target);
                    DuelSession session = DuelSession.startDuel(sender, target, req.tier(), req.gamemode(), req.rounds(), Match.MatchType.DUEL, false, req.arenaBaseName());
                    if (session != null) {
                        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-accepted-sender").replace("%target%", target.getName())));
                        target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-accepted-target").replace("%sender%", sender.getName())));
                    }
                } else {
                    target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.sender-offline")));
                }
            }
        }
    }

    public static void denyRequest(Player target) {
        CustomKitRequestManager.CustomKitRequest customReq = CustomKitRequestManager.getPending(target.getUniqueId());
        if (customReq != null) {
            CustomKitRequestManager.denyRequest(target);
        } else {
            DuelRequest req = pending.remove(target.getUniqueId());
            if (req == null) {
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-pending-request")));
            } else {
                Player sender = Bukkit.getPlayer((UUID)req.sender());
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-declined-target")));
                if (sender != null && sender.isOnline()) {
                    sender.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.request-declined-sender").replace("%target%", target.getName())));
                }
            }
        }
    }

    public static void clearFor(UUID uuid) {
        pending.remove(uuid);
        pending.entrySet().removeIf(entry -> ((DuelRequest)entry.getValue()).sender().equals(uuid));
    }

    public record DuelRequest(UUID sender, String tier, String gamemode, int rounds, String arenaBaseName, long expiresAt) {
        public DuelRequest(UUID sender, String tier, String gamemode, int rounds) {
            this(sender, tier, gamemode, rounds, null, 0L);
        }

        public DuelRequest(UUID sender, String tier, String gamemode, int rounds, String arenaBaseName) {
            this(sender, tier, gamemode, rounds, arenaBaseName, 0L);
        }

        public boolean isExpired() {
            return this.expiresAt > 0L && System.currentTimeMillis() > this.expiresAt;
        }
    }
}

