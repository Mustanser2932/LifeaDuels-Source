/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.key.Key
 *  net.kyori.adventure.sound.Sound
 *  net.kyori.adventure.sound.Sound$Source
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.entity.EnderPearl
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.entity.ProjectileHitEvent
 *  org.bukkit.event.entity.ProjectileLaunchEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemConsumeEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.event.player.PlayerToggleSneakEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.projectiles.ProjectileSource
 */
package me.lifea.duel;

import java.util.ArrayList;
import java.util.UUID;
import me.lifea.command.MessageCommand;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.hotbar.HotbarManager;
import me.lifea.match.Match;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.PacketUtil;
import me.lifea.util.WorldBorderUtil;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.projectiles.ProjectileSource;

public class DuelListener
implements Listener {
    private static String fastskipActionbar;
    private static String fastskipAskingActionbar;

    private static String fastskipActionbar() {
        if (fastskipActionbar == null) {
            fastskipActionbar = ConfigManager.msg("duel.fastskip-actionbar");
        }
        return fastskipActionbar;
    }

    private static String fastskipAskingActionbar() {
        if (fastskipAskingActionbar == null) {
            fastskipAskingActionbar = ConfigManager.msg("duel.fastskip-asking-actionbar");
        }
        return fastskipAskingActionbar;
    }

    private boolean isInCooldown(Player player) {
        DuelSession session = DuelSession.getSession(player.getUniqueId());
        PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
        if (session != null) {
            return session.isFrozen() || !session.isFighting();
        }
        if (partySession == null) {
            return false;
        }
        return partySession.isFrozen() || !partySession.isFighting();
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        DuelSession session = DuelSession.getSession(dead.getUniqueId());
        PartyDuelSession partySession = PartyDuelSession.getSession(dead.getUniqueId());
        if (session != null || partySession != null) {
            Player partyKiller;
            Player killer = this.resolveKiller(dead);
            if (killer != null && !killer.getUniqueId().equals(dead.getUniqueId())) {
                StatsManager.addKill(killer.getUniqueId());
            }
            StatsManager.addDeath(dead.getUniqueId());
            if (session != null && killer != null && session.isFighting() && session.getMatch().isPlayer(killer.getUniqueId())) {
                Player victim;
                String killMsg = this.killMessage(killer.getName(), dead.getName());
                killer.sendMessage(ColorUtil.parse(killMsg));
                Object object = victim = dead.isOnline() ? dead : null;
                if (victim != null && !victim.getUniqueId().equals(killer.getUniqueId())) {
                    victim.sendMessage(ColorUtil.parse(killMsg));
                }
            }
            event.setCancelled(true);
            PacketUtil.sendDeathAnimation(dead);
            dead.getWorld().playSound(dead.getLocation(), Sound.ENTITY_PLAYER_DEATH, 1.0f, 1.0f);
            dead.getInventory().clear();
            dead.getInventory().setArmorContents((ItemStack[])null);
            dead.getInventory().setItemInOffHand((ItemStack)null);
            if (dead.getAttribute(Attribute.MAX_HEALTH) != null) {
                dead.setHealth(dead.getAttribute(Attribute.MAX_HEALTH).getValue());
            }
            dead.setFoodLevel(20);
            dead.setSaturation(5.0f);
            dead.setFireTicks(0);
            for (PotionEffect effect : dead.getActivePotionEffects()) {
                dead.removePotionEffect(effect.getType());
            }
            dead.setInvulnerable(true);
            Object object = partyKiller = partySession != null ? killer : null;
            if (session != null) {
                session.onPlayerDeath(dead, dead.getLocation());
            } else if (partySession != null) {
                partySession.onPlayerDeath(dead, dead.getLocation(), partyKiller);
            }
        }
    }

    private Player resolveKiller(Player dead) {
        Player killer = dead.getKiller();
        if (killer != null) {
            return killer;
        }
        EntityDamageEvent lastDamage = dead.getLastDamageCause();
        if (lastDamage != null && (lastDamage.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION || lastDamage.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION)) {
            return dead;
        }
        return null;
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player) {
            Projectile projectile;
            ProjectileSource shooter;
            Player victim = (Player)var3;
            Player attacker = null;
            Entity damager = event.getDamager();
            if (damager instanceof Player) {
                Player p;
                attacker = p = (Player)damager;
            } else if (damager instanceof EnderPearl) {
                EnderPearl pearl = (EnderPearl)damager;
                shooter = pearl.getShooter();
                if (shooter instanceof Player) {
                    Player p;
                    attacker = p = (Player)shooter;
                }
            } else if (damager instanceof Projectile && (shooter = (projectile = (Projectile)damager).getShooter()) instanceof Player) {
                Player p;
                attacker = p = (Player)shooter;
            }
            if (attacker != null) {
                DuelSession attackerSession = DuelSession.getSession(attacker.getUniqueId());
                DuelSession victimSession = DuelSession.getSession(victim.getUniqueId());
                PartyDuelSession attackerPartySession = PartyDuelSession.getSession(attacker.getUniqueId());
                PartyDuelSession victimPartySession = PartyDuelSession.getSession(victim.getUniqueId());
                if (attackerPartySession == null && victimPartySession == null) {
                    if (attackerSession != null && victimSession != null && attackerSession == victimSession) {
                        if (!attackerSession.isFighting() || attackerSession.isFrozen()) {
                            event.setCancelled(true);
                        }
                    } else if (attackerSession != null && victimSession != null && attackerSession != victimSession) {
                        event.setCancelled(true);
                    } else if (attackerSession != null || victimSession != null) {
                        event.setCancelled(true);
                    }
                } else if (attackerPartySession != null && victimPartySession != null && attackerPartySession == victimPartySession) {
                    if (!attackerPartySession.isFighting() || attackerPartySession.isFrozen() || attackerPartySession.isSameTeam(attacker, victim)) {
                        event.setCancelled(true);
                    }
                } else {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent event) {
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        WorldBorderUtil.remove(player);
        MessageCommand.clearReplyTarget(uuid);
        DuelSession session = DuelSession.getSession(uuid);
        PartyDuelSession partySession = PartyDuelSession.getSession(uuid);
        if (session != null) {
            session.onPlayerQuit(player);
            session.sneakingPlayersDuringCountdown.remove(uuid);
        } else if (partySession != null) {
            partySession.onPlayerQuit(player);
        }
        Party party = PartyManager.getParty(uuid);
        if (party != null) {
            if (party.isLeader(uuid)) {
                for (UUID memberUuid : party.getMembers()) {
                    if (memberUuid.equals(uuid)) continue;
                    party.setLeader(memberUuid);
                    Player newLeader = Bukkit.getPlayer((UUID)memberUuid);
                    if (newLeader == null) break;
                    newLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("leader-transferred").replace("%old%", player.getName()).replace("%new%", newLeader.getName())));
                    if (!HotbarManager.shouldHaveLobbyItems(newLeader)) break;
                    HotbarManager.give(newLeader, HotbarManager.HotbarType.PARTY_LEADER);
                    break;
                }
            }
            PartyManager.leaveParty(player);
        }
        QueueManager.removePlayerFromQueues(player);
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (DuelSession.getSession(player.getUniqueId()) != null || PartyDuelSession.getSession(player.getUniqueId()) != null) {
            if (player.isOp() || player.hasPermission("lifea.commandbypass")) {
                return;
            }
            String msg = event.getMessage().toLowerCase();
            String command = msg.split(" ")[0].replace("/", "");
            ArrayList allowed = ConfigManager.config().getStringList("match.allowed-commands");
            if (allowed == null) {
                allowed = new ArrayList();
            }
            for (String allowedCmd : allowed) {
                if (!command.equalsIgnoreCase(allowedCmd)) continue;
                return;
            }
            event.setCancelled(true);
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.no-commands")));
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (this.isInCooldown(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (this.shouldBlockInteraction(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (this.shouldBlockInteraction(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onSwapHand(PlayerSwapHandItemsEvent event) {
        if (this.isInCooldown(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (event.getItem().getType() == Material.GOLDEN_APPLE) {
            DuelSession session = DuelSession.getSession(player.getUniqueId());
            if (session != null && session.useGappleBoost(player.getUniqueId())) {
                player.setSaturation(20.0f);
                return;
            }
            PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
            if (partySession != null && partySession.useGappleBoost(player.getUniqueId())) {
                player.setSaturation(20.0f);
                return;
            }
        }
        if (this.isInCooldown(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (event.getClickedBlock() != null && this.shouldBlockInteraction(event.getPlayer(), event.getClickedBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        Player player;
        ProjectileSource var3 = event.getEntity().getShooter();
        if (var3 instanceof Player && this.isInCooldown(player = (Player)var3)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEnderPearlLand(ProjectileHitEvent event) {
    }

    private boolean shouldBlockInteraction(Player player, Location location) {
        DuelSession session = DuelSession.getSession(player.getUniqueId());
        PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
        if (session != null || partySession != null) {
            boolean fighting;
            boolean frozen = session != null ? session.isFrozen() : partySession.isFrozen();
            boolean bl = fighting = session != null ? session.isFighting() : partySession.isFighting();
            if (frozen || !fighting) {
                return true;
            }
        }
        return false;
    }

    private String killMessage(String killerName, String victimName) {
        String msg = ConfigManager.msg("duel.kill-message");
        return msg != null && !msg.startsWith("&cMissing message:") ? msg.replace("%killer%", killerName).replace("%victim%", victimName) : "&f\u2139 &#FB0000" + killerName + " &fhas killed &#FB0000" + victimName;
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPickupItem(EntityPickupItemEvent event) {
        LivingEntity var3 = event.getEntity();
        if (var3 instanceof Player) {
            Player player = (Player)var3;
            DuelSession var6 = DuelSession.getSession(player.getUniqueId());
            PartyDuelSession partySession = PartyDuelSession.getSession(player.getUniqueId());
            if (var6 != null || partySession != null) {
                if (player.getGameMode() == GameMode.SPECTATOR) {
                    event.setCancelled(true);
                } else {
                    boolean ended;
                    boolean bl = ended = var6 != null ? var6.isEnded() : partySession.isEnded();
                    if (ended) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerToggleSneak(PlayerToggleSneakEvent event) {
        Match.MatchType type;
        Player player = event.getPlayer();
        DuelSession session = DuelSession.getSession(player.getUniqueId());
        if (!(session == null || (type = session.getMatch().getType()) != Match.MatchType.DUEL && type != Match.MatchType.QUEUE || session.countdownTask == null || session.countdownTask.isCancelled() || !session.isFrozen() || session.isFighting() || session.isEnded())) {
            long now = System.currentTimeMillis();
            Long last = session.lastSneakToggle.get(player.getUniqueId());
            if (last == null || now - last >= 250L) {
                session.lastSneakToggle.put(player.getUniqueId(), now);
                Player opponent = Bukkit.getPlayer((UUID)(session.getMatch().getPlayer1().equals(player.getUniqueId()) ? session.getMatch().getPlayer2() : session.getMatch().getPlayer1()));
                if (event.isSneaking()) {
                    boolean added = session.sneakingPlayersDuringCountdown.add(player.getUniqueId());
                    if (added) {
                        player.playSound(net.kyori.adventure.sound.Sound.sound((Key)Key.key((String)"minecraft:entity.zombie.attack_wooden_door"), (Sound.Source)Sound.Source.MASTER, (float)1.0f, (float)1.0f));
                    }
                } else {
                    session.sneakingPlayersDuringCountdown.remove(player.getUniqueId());
                }
                if (session.sneakingPlayersDuringCountdown.size() == 2) {
                    player.sendActionBar(ColorUtil.parse(DuelListener.fastskipActionbar()));
                    if (opponent != null) {
                        opponent.sendActionBar(ColorUtil.parse(DuelListener.fastskipActionbar()));
                    }
                    session.countdownTask.cancel();
                    session.onCountdownEnd();
                } else {
                    String askingBar = DuelListener.fastskipAskingActionbar().replace("%count%", String.valueOf(session.sneakingPlayersDuringCountdown.size()));
                    player.sendActionBar(ColorUtil.parse(askingBar));
                    if (opponent != null) {
                        opponent.sendActionBar(ColorUtil.parse(askingBar));
                    }
                }
            }
        }
    }
}

