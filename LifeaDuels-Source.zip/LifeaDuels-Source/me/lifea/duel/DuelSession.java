/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.sound.Sound$Source
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Keyed
 *  org.bukkit.Location
 *  org.bukkit.Tag
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.block.data.type.Bed
 *  org.bukkit.block.data.type.Bed$Part
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package me.lifea.duel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.ArenaRestore;
import me.lifea.arena.ClipboardCache;
import me.lifea.config.ConfigManager;
import me.lifea.cosmetic.BannerManager;
import me.lifea.cosmetic.TrimManager;
import me.lifea.duel.KitRulesListener;
import me.lifea.duel.custom.CustomKitRulesListener;
import me.lifea.gui.GUIManager;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.hotbar.HotbarManager;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.kit.KitRuleManager;
import me.lifea.kit.PotionManager;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.match.RematchManager;
import me.lifea.player.PlayerDataCache;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.ScoreboardUtil;
import me.lifea.util.SoundUtil;
import me.lifea.util.TabRole;
import me.lifea.util.TitleUtil;
import me.lifea.util.WorldBorderUtil;
import me.lifea.visibility.MatchVisibilityManager;
import net.kyori.adventure.sound.Sound;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Tag;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Bed;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class DuelSession {
    private static final Map<UUID, DuelSession> sessions = new ConcurrentHashMap<UUID, DuelSession>();
    private final Match match;
    private final Arena arena;
    private final String tier;
    private final String gamemode;
    private final UUID player1Id;
    private final UUID player2Id;
    private final UUID customKitOwner;
    private final int customKitSlot;
    private boolean fighting = false;
    private boolean frozen = false;
    private boolean ended = false;
    private final AtomicBoolean ending;
    private long fightStartMillis = -1L;
    public BukkitTask countdownTask;
    private BukkitTask liftTask;
    private final Map<UUID, BukkitTask> throwTasks = new HashMap<UUID, BukkitTask>();
    private final Map<UUID, BukkitTask> respawnTasks = new ConcurrentHashMap<UUID, BukkitTask>();
    final Set<UUID> sneakingPlayersDuringCountdown;
    final Map<UUID, Long> lastSneakToggle;
    final Set<UUID> gappleBoostUsed = new HashSet<UUID>();
    final Set<UUID> brokenBeds = new HashSet<UUID>();
    final Map<Long, UUID> placedBedOwners = new HashMap<Long, UUID>();

    public DuelSession(Player p1, Player p2, Arena arena, String tier, String gamemode, int rounds, Match.MatchType type, boolean competitive) {
        this(p1, p2, arena, tier, gamemode, rounds, type, competitive, null, -1);
    }

    public DuelSession(Player p1, Player p2, Arena arena, String tier, String gamemode, int rounds, Match.MatchType type, boolean competitive, UUID customKitOwner, int customKitSlot) {
        this.ending = new AtomicBoolean(false);
        this.sneakingPlayersDuringCountdown = new HashSet<UUID>();
        this.lastSneakToggle = new HashMap<UUID, Long>();
        this.player1Id = p1.getUniqueId();
        this.player2Id = p2.getUniqueId();
        this.arena = arena;
        this.tier = tier;
        this.gamemode = gamemode;
        this.customKitOwner = customKitOwner;
        this.customKitSlot = customKitSlot;
        arena.setInUse(true);
        this.match = MatchManager.createMatch(p1, p2, tier, gamemode, rounds, type, arena.getName(), competitive);
        sessions.put(p1.getUniqueId(), this);
        sessions.put(p2.getUniqueId(), this);
    }

    private Player player1() {
        return Bukkit.getPlayer((UUID)this.player1Id);
    }

    private Player player2() {
        return Bukkit.getPlayer((UUID)this.player2Id);
    }

    public UUID getPlayer1Id() {
        return this.player1Id;
    }

    public UUID getPlayer2Id() {
        return this.player2Id;
    }

    public static DuelSession getSession(UUID uuid) {
        return sessions.get(uuid);
    }

    public static boolean inSession(UUID uuid) {
        return sessions.containsKey(uuid);
    }

    public static Collection<DuelSession> getActiveSessions() {
        return Collections.unmodifiableCollection(sessions.values());
    }

    public Match getMatch() {
        return this.match;
    }

    public Arena getArena() {
        return this.arena;
    }

    public boolean isFighting() {
        return this.fighting;
    }

    public boolean isFrozen() {
        return this.frozen;
    }

    public boolean isEnded() {
        return this.ended;
    }

    public boolean isInCountdown() {
        return this.countdownTask != null && !this.countdownTask.isCancelled() && this.frozen && !this.fighting && !this.ended;
    }

    public boolean useGappleBoost(UUID uuid) {
        return this.gappleBoostUsed.add(uuid);
    }

    public String getTier() {
        return this.tier;
    }

    public String getGamemode() {
        return this.gamemode;
    }

    public boolean isCustomKitDuel() {
        return this.customKitOwner != null;
    }

    public UUID getCustomKitOwner() {
        return this.customKitOwner;
    }

    public int getCustomKitSlot() {
        return this.customKitSlot;
    }

    public long getFightingTicksElapsed() {
        return this.fighting && this.fightStartMillis >= 0L ? (System.currentTimeMillis() - this.fightStartMillis) / 50L : 0L;
    }

    public String getDurationString() {
        if (this.fightStartMillis < 0L) {
            return "00:00";
        }
        long secs = (System.currentTimeMillis() - this.fightStartMillis) / 1000L;
        return String.format("%02d:%02d", secs / 60L, secs % 60L);
    }

    public static DuelSession startDuel(Player p1, Player p2, String tier, String gamemode, int rounds, Match.MatchType type, boolean competitive) {
        return DuelSession.startDuel(p1, p2, tier, gamemode, rounds, type, competitive, null);
    }

    public static DuelSession startDuel(Player p1, Player p2, String tier, String gamemode, int rounds, Match.MatchType type, boolean competitive, String arenaBaseName) {
        boolean bedwarsKit;
        String kitKey;
        boolean explicitArena;
        if (!KitManager.isKitEnabled(tier, gamemode)) {
            p1.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.kit-disabled").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
            p2.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.kit-disabled").replace("%gamemode%", GamemodeRegistry.getDisplayName(tier, gamemode)).replace("%tier%", tier)));
            return null;
        }
        if (MatchManager.inMatch(p1.getUniqueId())) {
            p1.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
            return null;
        }
        if (MatchManager.inMatch(p2.getUniqueId())) {
            p2.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
            return null;
        }
        QueueManager.removePlayerFromQueues(p1);
        QueueManager.removePlayerFromQueues(p2);
        KitEditorGUI.removeIfEditing(p1);
        KitEditorGUI.removeIfEditing(p2);
        GUIManager.closeMenus(p1, p2);
        QueueManager.invalidateDuelCountCache();
        Arena arena = null;
        boolean bl = explicitArena = arenaBaseName != null && !arenaBaseName.isBlank();
        if (explicitArena) {
            arena = ArenaManager.getAvailableForBase(arenaBaseName, DuelSession.isBedwarsKit(tier, gamemode)).orElse(null);
        }
        if (arena == null && !explicitArena) {
            kitKey = DuelSession.buildKitKey(tier, gamemode);
            arena = ArenaManager.getAvailableForKit(kitKey, DuelSession.isBedwarsKit(tier, gamemode)).orElse(null);
        }
        if (arena == null) {
            p1.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-arena")));
            p2.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-arena")));
            return null;
        }
        kitKey = DuelSession.buildKitKey(tier, gamemode);
        boolean bl2 = bedwarsKit = kitKey != null && KitRuleManager.isBedwarsEnabled(kitKey);
        if (bedwarsKit && !DuelSession.hasValidBedObjectives(arena)) {
            ArenaRestore.restoreBedObjectives(arena);
        }
        if (bedwarsKit && !DuelSession.hasValidBedObjectives(arena)) {
            p1.sendMessage(ColorUtil.parse("&cThis &x&f&b&0&0&0&0&l\u0299\u1d07\u1d05 \u1d18\u1d20\u1d18&r&c arena needs both pre-placed home beds configured in Arena Region."));
            p2.sendMessage(ColorUtil.parse("&cThis &x&f&b&0&0&0&0&l\u0299\u1d07\u1d05 \u1d18\u1d20\u1d18&r&c arena needs both pre-placed home beds configured in Arena Region."));
            return null;
        }
        GUIManager.clearSelectedArena(p1.getUniqueId());
        GUIManager.clearSelectedArena(p2.getUniqueId());
        DuelSession session = new DuelSession(p1, p2, arena, tier, gamemode, rounds, type, competitive);
        session.beginDuel();
        return session;
    }

    public static DuelSession startCustomKitDuel(Player p1, Player p2, int kitSlot, int rounds) {
        return DuelSession.startCustomKitDuel(p1, p2, kitSlot, rounds, null);
    }

    public static DuelSession startCustomKitDuel(Player p1, Player p2, int kitSlot, int rounds, String arenaBaseName) {
        boolean explicitArena;
        if (!CustomKitManager.isEnabled()) {
            p1.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
            return null;
        }
        if (MatchManager.inMatch(p1.getUniqueId())) {
            p1.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
            return null;
        }
        if (MatchManager.inMatch(p2.getUniqueId())) {
            p2.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
            return null;
        }
        QueueManager.removePlayerFromQueues(p1);
        QueueManager.removePlayerFromQueues(p2);
        KitEditorGUI.removeIfEditing(p1);
        KitEditorGUI.removeIfEditing(p2);
        GUIManager.closeMenus(p1, p2);
        GUIManager.clearSelectedArena(p1.getUniqueId());
        GUIManager.clearSelectedArena(p2.getUniqueId());
        QueueManager.invalidateDuelCountCache();
        Arena arena = null;
        boolean bl = explicitArena = arenaBaseName != null && !arenaBaseName.isBlank();
        if (explicitArena) {
            arena = ArenaManager.getAvailableForBase(arenaBaseName).orElse(null);
        }
        if (arena == null && !explicitArena) {
            arena = ArenaManager.getAvailableForKit("CUSTOM_KITS").orElse(null);
        }
        if (arena == null) {
            p1.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-arena")));
            p2.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.no-arena")));
            return null;
        }
        DuelSession session = new DuelSession(p1, p2, arena, "CustomKits", "Custom Kit", rounds, Match.MatchType.DUEL, false, p1.getUniqueId(), kitSlot);
        session.beginDuel();
        return session;
    }

    private void beginDuel() {
        this.arena.getModifiedBlockTracker().clear();
        this.brokenBeds.clear();
        this.placedBedOwners.clear();
        this.registerArenaBedObjectives();
        this.cancelBedwarsRespawn();
        String acceptedMsg = ConfigManager.msg("duel.accepted-both");
        Player p1 = this.player1();
        Player p2 = this.player2();
        if (p1 != null && p2 != null) {
            MatchVisibilityManager.rememberDuelOpponents(p1.getUniqueId(), p2.getUniqueId());
            p1.sendMessage(ColorUtil.parse(acceptedMsg));
            p2.sendMessage(ColorUtil.parse(acceptedMsg));
            this.sendDuelInfo(p1, p2);
            this.sendDuelInfo(p2, p1);
            p1.closeInventory();
            p2.closeInventory();
            p1.teleport(this.arena.getSpawn1());
            p2.teleport(this.arena.getSpawn2());
            if (this.match.getType() == Match.MatchType.QUEUE) {
                p1.removePotionEffect(PotionEffectType.BLINDNESS);
                p2.removePotionEffect(PotionEffectType.BLINDNESS);
            }
            p1.getInventory().clear();
            p1.getInventory().setArmorContents((ItemStack[])null);
            p1.getInventory().setItemInOffHand((ItemStack)null);
            p2.getInventory().clear();
            p2.getInventory().setArmorContents((ItemStack[])null);
            p2.getInventory().setItemInOffHand((ItemStack)null);
            p1.setGameMode(GameMode.SURVIVAL);
            p2.setGameMode(GameMode.SURVIVAL);
            p1.setInvulnerable(false);
            p2.setInvulnerable(false);
            this.healPlayer(p1);
            this.healPlayer(p2);
            if (this.isCustomKitDuel()) {
                CustomKitManager.applyCustomKit(p1, this.customKitOwner, this.customKitSlot);
                CustomKitManager.applyCustomKit(p2, this.customKitOwner, this.customKitSlot);
                this.applyCustomKitEffects(p1);
                this.applyCustomKitEffects(p2);
            } else {
                KitManager.applyKit(p1, this.tier, this.gamemode);
                KitManager.applyKit(p2, this.tier, this.gamemode);
            }
            TrimManager.applyTrims(p1);
            TrimManager.applyTrims(p2);
            BannerManager.applyBanner(p1);
            BannerManager.applyBanner(p2);
            ScoreboardUtil.createDuelBoard(p1);
            ScoreboardUtil.createDuelBoard(p2);
            MatchVisibilityManager.applyRole(p1, this.match, TabRole.TEAM_B);
            MatchVisibilityManager.applyRole(p2, this.match, TabRole.TEAM_R);
            this.updateScoreboards();
            if (!this.isCustomKitDuel()) {
                String kitKey = DuelSession.buildKitKey(this.tier, this.gamemode);
                Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                    if (!this.ended) {
                        Player pp1 = this.player1();
                        Player pp2 = this.player2();
                        if (pp1 != null && pp2 != null) {
                            KitRulesListener.refreshHealthIndicators(List.of(pp1, pp2));
                        }
                    }
                }, 1L);
            }
            this.frozen = true;
            this.fighting = false;
            WorldBorderUtil.set(p1, this.arena);
            WorldBorderUtil.set(p2, this.arena);
            this.startCountdown();
        } else {
            this.endMatch();
        }
    }

    private void sendDuelInfo(Player player, Player opponent) {
        List<String> lines = ConfigManager.msgs("duel.duel-info");
        String roundsStr = "FT" + this.match.getTotalRounds();
        String kitDisplay = this.isCustomKitDuel() ? "Custom Kit" : GamemodeRegistry.getDisplayName(this.tier, this.gamemode);
        String arenaName = this.getArena() != null ? this.getArena().getName() : null;
        for (String line : lines) {
            if (line.contains("%arena%") && arenaName == null) continue;
            player.sendMessage(ColorUtil.parse(line.replace("%rounds%", roundsStr).replace("%opponent%", opponent.getName()).replace("%kit%", kitDisplay).replace("%duelrounds%", roundsStr).replace("%arena%", arenaName != null ? arenaName : "")));
        }
    }

    private void startCountdown() {
        final int countdownSeconds = ConfigManager.config().getInt("duel.countdown-seconds", 5);
        this.sneakingPlayersDuringCountdown.clear();
        this.countdownTask = Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), new Runnable(){
            int seconds;
            final /* synthetic */ DuelSession this$0;
            {
                this.this$0 = this$0;
                this.seconds = countdownSeconds;
            }

            @Override
            public void run() {
                if (this.this$0.ended) {
                    this.this$0.countdownTask.cancel();
                } else if (this.seconds > 0) {
                    Player p1 = this.this$0.player1();
                    Player p2 = this.this$0.player2();
                    if (p1 != null) {
                        TitleUtil.send(p1, "duel-countdown", new String[][]{{"%seconds%", String.valueOf(this.seconds)}});
                        SoundUtil.play(p1, "duel-countdown");
                        p1.sendActionBar(ColorUtil.parse(ConfigManager.msg("duel.fastskip-asking-actionbar").replace("%count%", String.valueOf(this.this$0.sneakingPlayersDuringCountdown.size()))));
                    }
                    if (p2 != null) {
                        TitleUtil.send(p2, "duel-countdown", new String[][]{{"%seconds%", String.valueOf(this.seconds)}});
                        SoundUtil.play(p2, "duel-countdown");
                        p2.sendActionBar(ColorUtil.parse(ConfigManager.msg("duel.fastskip-asking-actionbar").replace("%count%", String.valueOf(this.this$0.sneakingPlayersDuringCountdown.size()))));
                    }
                    --this.seconds;
                } else {
                    this.this$0.countdownTask.cancel();
                    this.this$0.onCountdownEnd();
                }
            }
        }, 0L, 20L);
    }

    void onCountdownEnd() {
        if (!this.ended) {
            this.sneakingPlayersDuringCountdown.clear();
            this.showRoundScoreActionBar();
            Player p1 = this.player1();
            Player p2 = this.player2();
            if (p1 != null) {
                TitleUtil.send(p1, "duel-go", new String[][]{{"%player%", p1.getName()}, {"%opponent%", p2 != null ? p2.getName() : "Unknown"}});
                SoundUtil.play(p1, "duel-go");
                SoundUtil.playRaw(p1, "minecraft:block.note_block.iron_xylophone", Sound.Source.AMBIENT, 3.0f, 1.2f);
            }
            if (p2 != null) {
                TitleUtil.send(p2, "duel-go", new String[][]{{"%player%", p2.getName()}, {"%opponent%", p1 != null ? p1.getName() : "Unknown"}});
                SoundUtil.play(p2, "duel-go");
                SoundUtil.playRaw(p2, "minecraft:block.note_block.iron_xylophone", Sound.Source.AMBIENT, 3.0f, 1.2f);
            }
            this.frozen = false;
            this.fighting = true;
            this.fightStartMillis = System.currentTimeMillis();
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (!this.ended) {
                    Player pp1 = this.player1();
                    Player pp2 = this.player2();
                    if (pp1 != null) {
                        this.applyPotions(pp1);
                    }
                    if (pp2 != null) {
                        this.applyPotions(pp2);
                    }
                }
            }, 20L);
        }
    }

    private void applyPotions(Player player) {
        if (player != null) {
            if (this.isCustomKitDuel()) {
                this.applyCustomKitPotions(player);
            } else {
                String potionKey = this.buildPotionKey();
                if (potionKey != null) {
                    PotionManager.applyPotions(player, potionKey);
                }
            }
        }
    }

    public void onPlayerDeath(Player dead, Location deathLocation) {
        if (!this.ended && this.fighting) {
            Player winner;
            if (this.isBedwarsMatch() && !this.isBedBroken(dead.getUniqueId())) {
                this.respawnAfterDeath(dead);
                return;
            }
            this.fighting = false;
            this.frozen = true;
            Player player = winner = dead.getUniqueId().equals(this.match.getPlayer1()) ? Bukkit.getPlayer((UUID)this.match.getPlayer2()) : Bukkit.getPlayer((UUID)this.match.getPlayer1());
            if (winner == null) {
                this.endMatch(null);
            } else {
                boolean matchOver = this.match.recordRoundWin(winner.getUniqueId());
                if (matchOver) {
                    this.endMatch(winner);
                } else {
                    this.onRoundEnd(winner, dead, deathLocation);
                }
            }
        }
    }

    public boolean isBedwarsMatch() {
        if (this.isCustomKitDuel()) {
            return false;
        }
        String kit = DuelSession.buildKitKey(this.tier, this.gamemode);
        return kit != null && KitRuleManager.isBedwarsEnabled(kit);
    }

    private void showRoundScoreActionBar() {
        BukkitTask[] taskRef;
        taskRef = new BukkitTask[]{Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), new Runnable(){
            private int updates;
            final /* synthetic */ DuelSession this$0;
            {
                this.this$0 = this$0;
            }

            @Override
            public void run() {
                if (this.this$0.ended || this.updates++ >= 5) {
                    taskRef[0].cancel();
                    return;
                }
                Player p1 = this.this$0.player1();
                Player p2 = this.this$0.player2();
                if (p1 != null) {
                    this.this$0.sendRoundScoreActionBar(p1);
                }
                if (p2 != null) {
                    this.this$0.sendRoundScoreActionBar(p2);
                }
            }
        }, 0L, 10L)};
    }

    private void sendRoundScoreActionBar(Player player) {
        UUID opponentId = this.match.getOpponent(player.getUniqueId());
        String message = ConfigManager.msg("duel.round-score-actionbar").replace("%player_head%", "<head:" + player.getName() + ">").replace("%opponent_head%", this.playerHead(opponentId)).replace("%score%", String.valueOf(this.match.getWins(player.getUniqueId()))).replace("%score_opp%", String.valueOf(opponentId != null ? this.match.getWins(opponentId) : 0));
        player.sendActionBar(ColorUtil.parse(message));
    }

    private String playerHead(UUID playerId) {
        Player player = playerId == null ? null : Bukkit.getPlayer((UUID)playerId);
        return player == null ? "<head:entity/player/wide/steve>" : "<head:" + player.getName() + ">";
    }

    public boolean isBedBroken(UUID uuid) {
        return uuid != null && this.brokenBeds.contains(uuid);
    }

    public void registerBedPlacement(Player owner, Block bed) {
        if (!this.ended && owner != null && bed != null && !this.isBedBroken(owner.getUniqueId())) {
            this.placedBedOwners.put(DuelSession.packBedPosition(bed.getX(), bed.getY(), bed.getZ()), owner.getUniqueId());
            Block otherHalf = DuelSession.getOtherBedHalf(bed);
            if (otherHalf != null) {
                this.placedBedOwners.put(DuelSession.packBedPosition(otherHalf.getX(), otherHalf.getY(), otherHalf.getZ()), owner.getUniqueId());
            }
        }
    }

    private void registerArenaBed(UUID owner, Block bed) {
        if (owner != null && bed != null && Tag.BEDS.isTagged((Keyed)bed.getType())) {
            this.placedBedOwners.put(DuelSession.packBedPosition(bed.getX(), bed.getY(), bed.getZ()), owner);
            Block otherHalf = DuelSession.getOtherBedHalf(bed);
            if (otherHalf != null) {
                this.placedBedOwners.put(DuelSession.packBedPosition(otherHalf.getX(), otherHalf.getY(), otherHalf.getZ()), owner);
            }
        }
    }

    private void registerArenaBedObjectives() {
        if (this.isBedwarsMatch()) {
            this.registerArenaBed(this.player1Id, this.arena.getBlueBed());
            this.registerArenaBed(this.player2Id, this.arena.getRedBed());
        }
    }

    private static boolean hasValidBedObjectives(Arena arena) {
        Block blueBed = arena.getBlueBed();
        Block redBed = arena.getRedBed();
        return arena.hasBedObjectives() && blueBed != null && redBed != null && !blueBed.equals((Object)redBed) && Tag.BEDS.isTagged((Keyed)blueBed.getType()) && Tag.BEDS.isTagged((Keyed)redBed.getType());
    }

    public boolean onBedBroken(Player breaker, Block bed) {
        if (!this.ended && breaker != null && bed != null) {
            String ownerName;
            UUID owner = this.placedBedOwners.remove(DuelSession.packBedPosition(bed.getX(), bed.getY(), bed.getZ()));
            if (owner == null) {
                return false;
            }
            if (owner.equals(breaker.getUniqueId())) {
                breaker.sendActionBar(ColorUtil.parse("&cYou cannot break your own bed."));
                this.placedBedOwners.put(DuelSession.packBedPosition(bed.getX(), bed.getY(), bed.getZ()), owner);
                return false;
            }
            Block otherHalf = DuelSession.getOtherBedHalf(bed);
            if (otherHalf != null) {
                this.placedBedOwners.remove(DuelSession.packBedPosition(otherHalf.getX(), otherHalf.getY(), otherHalf.getZ()));
            }
            this.brokenBeds.add(owner);
            Player ownerPlayer = Bukkit.getPlayer((UUID)owner);
            String string = ownerName = ownerPlayer != null ? ownerPlayer.getName() : "Player";
            if (ownerPlayer != null) {
                ownerPlayer.sendMessage(ColorUtil.parse(DuelSession.messageOrDefault("duel.bed-broken", "&cYour bed was destroyed! You will not respawn after your next death.")));
                TitleUtil.send(ownerPlayer, "duel-bed-broken");
            }
            breaker.sendMessage(ColorUtil.parse(DuelSession.messageOrDefault("duel.bed-broken-enemy", "&aYou destroyed &f%player%&a's bed!").replace("%player%", ownerName)));
            return true;
        }
        return false;
    }

    private static String messageOrDefault(String key, String fallback) {
        String message = ConfigManager.msg(key);
        return message != null && !message.startsWith("&cMissing message:") ? message : fallback;
    }

    private void respawnAfterDeath(Player dead) {
        final Location spawn = dead.getUniqueId().equals(this.player1Id) ? this.arena.getSpawn1() : this.arena.getSpawn2();
        final UUID deadId = dead.getUniqueId();
        final int respawnSeconds = ConfigManager.config().getInt("duel.bedwars-respawn-seconds", 5);
        this.cancelBedwarsRespawn(deadId);
        dead.setInvulnerable(true);
        dead.setGameMode(GameMode.SPECTATOR);
        dead.teleport(spawn);
        this.respawnTasks.put(deadId, Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), new Runnable(){
            int secondsLeft;
            final /* synthetic */ DuelSession this$0;
            {
                this.this$0 = this$0;
                this.secondsLeft = respawnSeconds;
            }

            @Override
            public void run() {
                if (this.this$0.ended) {
                    this.this$0.cancelBedwarsRespawn();
                } else {
                    Player p = Bukkit.getPlayer((UUID)deadId);
                    if (this.secondsLeft > 0) {
                        if (p != null && p.isOnline()) {
                            TitleUtil.send(p, "duel-respawn", new String[][]{{"%seconds%", String.valueOf(this.secondsLeft)}});
                            SoundUtil.play(p, "duel-respawn");
                            p.sendMessage(ColorUtil.parse(DuelSession.messageOrDefault("duel.bed-respawn-countdown", "&fRespawning in &c%seconds% &fseconds...").replace("%seconds%", String.valueOf(this.secondsLeft))));
                        }
                        --this.secondsLeft;
                    } else {
                        this.this$0.cancelBedwarsRespawn(deadId);
                        this.this$0.bedwarsFinishRespawn(deadId, spawn);
                    }
                }
            }
        }, 1L, 20L));
    }

    private void bedwarsFinishRespawn(UUID deadId, Location spawn) {
        Player p = Bukkit.getPlayer((UUID)deadId);
        if (p != null && p.isOnline() && !this.ended) {
            p.setInvulnerable(false);
            p.setGameMode(GameMode.SURVIVAL);
            p.teleport(spawn);
            if (this.isCustomKitDuel()) {
                CustomKitManager.applyCustomKit(p, this.customKitOwner, this.customKitSlot);
                this.applyCustomKitEffects(p);
            } else {
                KitManager.applyKit(p, this.tier, this.gamemode);
            }
            TrimManager.applyTrims(p);
            BannerManager.applyBanner(p);
            this.applyPotions(p);
        }
    }

    private void cancelBedwarsRespawn() {
        for (BukkitTask task : this.respawnTasks.values()) {
            task.cancel();
        }
        this.respawnTasks.clear();
    }

    private void cancelBedwarsRespawn(UUID playerId) {
        BukkitTask task;
        if (playerId != null && (task = this.respawnTasks.remove(playerId)) != null) {
            task.cancel();
        }
    }

    private static Block getOtherBedHalf(Block bed) {
        BlockData var2 = bed.getBlockData();
        if (var2 instanceof Bed) {
            Bed bedData = (Bed)var2;
            BlockFace direction = bedData.getPart() == Bed.Part.FOOT ? bedData.getFacing() : bedData.getFacing().getOppositeFace();
            Block other = bed.getRelative(direction);
            return other.getBlockData() instanceof Bed ? other : null;
        }
        return null;
    }

    private static long packBedPosition(int x, int y, int z) {
        return (long)(x & 0x1FFFFF) << 43 | (long)(y & 0xFFF) << 31 | (long)(z & 0x1FFFFF) << 10;
    }

    private void onRoundEnd(Player winner, Player loser, Location deathLocation) {
        int roundWon = this.match.getCurrentRound() - 1;
        int winsNeeded = this.match.getTotalRounds();
        TitleUtil.send(winner, "duel-round-win", new String[][]{{"%score%", String.valueOf(this.match.getWins(winner.getUniqueId()))}, {"%opponent_score%", String.valueOf(this.match.getLosses(winner.getUniqueId()))}});
        TitleUtil.send(loser, "duel-round-lose", new String[][]{{"%score%", String.valueOf(this.match.getWins(loser.getUniqueId()))}, {"%opponent_score%", String.valueOf(this.match.getLosses(loser.getUniqueId()))}});
        SoundUtil.play(winner, "duel-round-win");
        SoundUtil.play(loser, "duel-round-lose");
        List<String> roundMsgs = ConfigManager.msgs("duel.round-win-msg");
        int winnerLeft = winsNeeded - this.match.getWins(winner.getUniqueId());
        int loserLeft = winsNeeded - this.match.getWins(loser.getUniqueId());
        for (String line : roundMsgs) {
            winner.sendMessage(ColorUtil.parse(line.replace("%round%", String.valueOf(roundWon)).replace("%winner%", winner.getName()).replace("%looser%", loser.getName()).replace("%red_score%", String.valueOf(this.match.getWins(winner.getUniqueId()))).replace("%blue_score%", String.valueOf(this.match.getWins(loser.getUniqueId()))).replace("%player%", winner.getName()).replace("%leftrounds%", String.valueOf(winnerLeft)).replace("%round_winner_left_round%", String.valueOf(winnerLeft))));
            loser.sendMessage(ColorUtil.parse(line.replace("%round%", String.valueOf(roundWon)).replace("%winner%", winner.getName()).replace("%looser%", loser.getName()).replace("%red_score%", String.valueOf(this.match.getWins(winner.getUniqueId()))).replace("%blue_score%", String.valueOf(this.match.getWins(loser.getUniqueId()))).replace("%player%", loser.getName()).replace("%leftrounds%", String.valueOf(loserLeft)).replace("%round_winner_left_round%", String.valueOf(winnerLeft))));
        }
        this.updateScoreboards();
        boolean dragAnimation = this.isRoundDragAnimationEnabled();
        if (this.arena.isRegeneration()) {
            UUID loserId = loser.getUniqueId();
            if (loser.isOnline()) {
                loser.setGameMode(GameMode.SPECTATOR);
            }
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (!this.ended) {
                    Player l = Bukkit.getPlayer((UUID)loserId);
                    if (l != null && l.isOnline()) {
                        l.setGameMode(GameMode.SURVIVAL);
                    }
                    if (dragAnimation) {
                        this.dragToSpawnAndRegenerate();
                    } else {
                        this.startRegenAndProceed();
                    }
                }
            }, 30L);
        } else {
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (!this.ended) {
                    if (dragAnimation) {
                        this.dragToRoundSpawnsAndProceed();
                    } else {
                        this.proceedToNextRound();
                    }
                }
            }, 30L);
        }
    }

    private boolean isRoundDragAnimationEnabled() {
        String kitKey = DuelSession.buildKitKey(this.tier, this.gamemode);
        return kitKey != null && KitRuleManager.isRoundDragAnimationEnabled(kitKey);
    }

    private void dragToSpawnAndRegenerate() {
        this.dragPlayersToLocations(this.arena.getSpawn1(), this.arena.getSpawn2(), this::startRegenAndProceed);
    }

    private void dragToRoundSpawnsAndProceed() {
        this.dragPlayersToLocations(this.arena.getSpawn1(), this.arena.getSpawn2(), this::proceedToNextRound);
    }

    private void dragPlayersToLocations(Location target1, Location target2, Runnable onComplete) {
        Player p1 = Bukkit.getPlayer((UUID)this.match.getPlayer1());
        Player p2 = Bukkit.getPlayer((UUID)this.match.getPlayer2());
        int playerCount = (p1 != null && p1.isOnline() ? 1 : 0) + (p2 != null && p2.isOnline() ? 1 : 0);
        AtomicInteger arrivals = new AtomicInteger(0);
        Runnable onBothArrived = () -> {
            if (arrivals.incrementAndGet() >= playerCount) {
                this.clearArenaEntities();
                onComplete.run();
            }
        };
        if (p1 != null && p1.isOnline()) {
            this.prepForDrag(p1);
            this.dragToSpawn(p1, target1, onBothArrived);
        }
        if (p2 != null && p2.isOnline()) {
            this.prepForDrag(p2);
            this.dragToSpawn(p2, target2, onBothArrived);
        }
        if (playerCount == 0) {
            this.clearArenaEntities();
            onComplete.run();
        }
    }

    private void startRegenAndProceed() {
        AtomicBoolean roundStarted = new AtomicBoolean(false);
        ArenaRestore.restoreAsync(this.arena, () -> Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
            if (!this.ended && roundStarted.compareAndSet(false, true)) {
                this.proceedToNextRound();
            }
        }));
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (!this.ended && roundStarted.compareAndSet(false, true)) {
                Lifea.getInstance().getLogger().warning("[DuelSession] Arena restore timed out for '" + this.arena.getName() + "', forcing next round");
                this.proceedToNextRound();
            }
        }, 200L);
    }

    private void prepForDrag(Player player) {
        player.setInvulnerable(true);
        player.setAllowFlight(false);
        player.setFlying(false);
        player.setFallDistance(0.0f);
        player.setVelocity(new Vector(0.0, 0.0, 0.0));
        player.getInventory().clear();
        player.getInventory().setArmorContents((ItemStack[])null);
        player.getInventory().setItemInOffHand((ItemStack)null);
        this.clearPotions(player);
    }

    private void dragToSpawn(Player player, Location spawn) {
        this.dragToSpawn(player, spawn, null);
    }

    private void dragToSpawn(Player player, final Location spawn, final Runnable onComplete) {
        if (player != null && player.isOnline() && spawn != null) {
            this.cancelThrowTask(player.getUniqueId());
            player.setGravity(true);
            player.setVelocity(new Vector(0.0, 0.0, 0.0));
            player.setFallDistance(0.0f);
            Location start = player.getLocation().clone();
            Vector horizontalOffset = spawn.toVector().subtract(start.toVector()).setY(0.0);
            double distance = horizontalOffset.length();
            if (distance < 1.0) {
                this.arriveAtSpawn(player, spawn);
                if (onComplete != null) {
                    onComplete.run();
                }
            } else {
                int liftTimeout = 14;
                int cruiseDuration = 28;
                final double liftVelocity = Math.min(1.45, Math.max(1.2, 1.25 + Math.max(0.0, spawn.getY() - start.getY()) * 0.06));
                final UUID playerId = player.getUniqueId();
                this.throwTasks.put(playerId, Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), new Runnable(){
                    private int tick;
                    private boolean launched;
                    private boolean cruising;
                    private Location cruiseStart;
                    final /* synthetic */ DuelSession this$0;
                    {
                        this.this$0 = this$0;
                    }

                    @Override
                    public void run() {
                        Player p = Bukkit.getPlayer((UUID)playerId);
                        if (this.this$0.ended || p == null || !p.isOnline()) {
                            if (p != null) {
                                p.setGravity(true);
                            }
                            this.this$0.cancelThrowTask(playerId);
                            return;
                        }
                        p.setFallDistance(0.0f);
                        if (!this.cruising) {
                            if (!this.launched) {
                                this.launched = true;
                                p.setGravity(true);
                                p.setVelocity(new Vector(0.0, liftVelocity, 0.0));
                                return;
                            }
                            ++this.tick;
                            if (p.getVelocity().getY() <= 0.05 || this.tick >= 14) {
                                this.cruiseStart = p.getLocation().clone();
                                this.cruising = true;
                                this.tick = 0;
                                p.setGravity(false);
                            }
                            return;
                        }
                        ++this.tick;
                        double progress = Math.min(1.0, (double)this.tick / 28.0);
                        Location target = this.cruiseStart.clone();
                        target.setX(this.cruiseStart.getX() + (spawn.getX() - this.cruiseStart.getX()) * progress);
                        target.setZ(this.cruiseStart.getZ() + (spawn.getZ() - this.cruiseStart.getZ()) * progress);
                        target.setY(this.cruiseStart.getY() + (spawn.getY() - this.cruiseStart.getY()) * progress);
                        target.setYaw(spawn.getYaw());
                        target.setPitch(spawn.getPitch());
                        Vector push = target.toVector().subtract(p.getLocation().toVector());
                        if (push.lengthSquared() > 0.01) {
                            int ticksRemaining = Math.max(1, 28 - this.tick + 1);
                            p.setVelocity(push.multiply(1.0 / (double)ticksRemaining));
                        }
                        if (progress >= 1.0) {
                            this.this$0.cancelThrowTask(playerId);
                            this.this$0.arriveAtSpawn(p, spawn);
                            if (onComplete != null) {
                                onComplete.run();
                            }
                        }
                    }
                }, 1L, 1L));
            }
        }
    }

    private void arriveAtSpawn(Player player, Location spawn) {
        if (player != null && player.isOnline()) {
            player.setGravity(true);
            player.setFallDistance(0.0f);
            player.setVelocity(new Vector(0.0, 0.0, 0.0));
            player.teleport(spawn);
            player.setInvulnerable(false);
        }
    }

    private void cancelLiftTask() {
        if (this.liftTask != null) {
            this.liftTask.cancel();
            this.liftTask = null;
        }
    }

    private void cancelThrowTask(UUID playerId) {
        BukkitTask task = this.throwTasks.remove(playerId);
        if (task != null) {
            task.cancel();
        }
    }

    private void cancelDragTasks() {
        this.cancelLiftTask();
        for (UUID playerId : new ArrayList<UUID>(this.throwTasks.keySet())) {
            Player player = Bukkit.getPlayer((UUID)playerId);
            if (player != null) {
                player.setGravity(true);
            }
            this.cancelThrowTask(playerId);
        }
    }

    private void sendToNextSpawn(Player player, Location spawn) {
        if (player != null && player.isOnline() && spawn != null) {
            player.setFallDistance(0.0f);
            player.setVelocity(new Vector(0.0, 0.0, 0.0));
            player.teleport(spawn);
            player.setInvulnerable(false);
        }
    }

    private void proceedToNextRound() {
        this.cancelDragTasks();
        this.arena.getModifiedBlockTracker().clear();
        this.brokenBeds.clear();
        this.placedBedOwners.clear();
        this.registerArenaBedObjectives();
        Player p1 = Bukkit.getPlayer((UUID)this.match.getPlayer1());
        Player p2 = Bukkit.getPlayer((UUID)this.match.getPlayer2());
        if (p1 != null) {
            p1.setFlying(false);
            p1.setAllowFlight(false);
            p1.setGameMode(GameMode.SURVIVAL);
            p1.getInventory().clear();
            p1.getInventory().setArmorContents((ItemStack[])null);
            p1.getInventory().setItemInOffHand((ItemStack)null);
            this.healPlayer(p1);
            this.clearPotions(p1);
            this.sendToNextSpawn(p1, this.arena.getSpawn1());
            if (this.isCustomKitDuel()) {
                CustomKitManager.applyCustomKit(p1, this.customKitOwner, this.customKitSlot);
                this.applyCustomKitEffects(p1);
            } else {
                KitManager.applyKit(p1, this.tier, this.gamemode);
            }
            TrimManager.applyTrims(p1);
            BannerManager.applyBanner(p1);
        }
        if (p2 != null) {
            p2.setFlying(false);
            p2.setAllowFlight(false);
            p2.setGameMode(GameMode.SURVIVAL);
            p2.getInventory().clear();
            p2.getInventory().setArmorContents((ItemStack[])null);
            p2.getInventory().setItemInOffHand((ItemStack)null);
            this.healPlayer(p2);
            this.clearPotions(p2);
            this.sendToNextSpawn(p2, this.arena.getSpawn2());
            if (this.isCustomKitDuel()) {
                CustomKitManager.applyCustomKit(p2, this.customKitOwner, this.customKitSlot);
                this.applyCustomKitEffects(p2);
            } else {
                KitManager.applyKit(p2, this.tier, this.gamemode);
            }
            TrimManager.applyTrims(p2);
            BannerManager.applyBanner(p2);
        }
        if (p1 != null) {
            MatchVisibilityManager.applyRole(p1, this.match, TabRole.TEAM_B);
        }
        if (p2 != null) {
            MatchVisibilityManager.applyRole(p2, this.match, TabRole.TEAM_R);
        }
        if (!this.isCustomKitDuel()) {
            String kitKey = DuelSession.buildKitKey(this.tier, this.gamemode);
            ArrayList<Player> alive = new ArrayList<Player>();
            if (p1 != null) {
                alive.add(p1);
            }
            if (p2 != null) {
                alive.add(p2);
            }
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (!this.ended) {
                    KitRulesListener.refreshHealthIndicators(alive);
                }
            }, 1L);
        }
        this.gappleBoostUsed.clear();
        this.frozen = true;
        this.fighting = false;
        this.startCountdown();
    }

    public void onPlayerQuit(Player quitter) {
        if (!this.ended) {
            Player opponent = quitter.getUniqueId().equals(this.match.getPlayer1()) ? Bukkit.getPlayer((UUID)this.match.getPlayer2()) : Bukkit.getPlayer((UUID)this.match.getPlayer1());
            this.ended = true;
            this.fighting = false;
            this.frozen = false;
            if (this.countdownTask != null) {
                this.countdownTask.cancel();
                this.countdownTask = null;
            }
            this.sneakingPlayersDuringCountdown.clear();
            this.lastSneakToggle.clear();
            if (opponent == null) {
                this.cleanupSessionRefs();
                KitRulesListener.clearBoxingHitsForPlayers(this.player1Id, this.player2Id);
                this.clearArenaEntities();
                ArenaRestore.restoreAsync(this.arena, () -> this.arena.setInUse(false));
                SpectateManager.removeSpectatorsForArena(this.arena.getName());
            } else {
                this.match.recordRoundWin(opponent.getUniqueId());
                while (this.match.isActive()) {
                    this.match.recordRoundWin(opponent.getUniqueId());
                }
                opponent.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.forfeit-opponent").replace("{player}", quitter.getName())));
                this.endMatch(opponent);
            }
            MatchVisibilityManager.reset(quitter);
        }
    }

    public void endMatch(Player winner) {
        if (this.ending.compareAndSet(false, true)) {
            this.ended = true;
            this.fighting = false;
            this.frozen = false;
            if (this.countdownTask != null) {
                this.countdownTask.cancel();
                this.countdownTask = null;
            }
            this.cancelBedwarsRespawn();
            this.cancelDragTasks();
            this.cleanupSpectators();
            this.restoreAllVisibility();
            Player player1 = Bukkit.getPlayer((UUID)this.match.getPlayer1());
            Player player2 = Bukkit.getPlayer((UUID)this.match.getPlayer2());
            if (winner == null) {
                this.performCleanup(player1, player2);
            } else {
                Player loser;
                Player player = loser = winner.getUniqueId().equals(this.match.getPlayer1()) ? player2 : player1;
                if (player1 != null) {
                    player1.setGameMode(GameMode.SPECTATOR);
                }
                if (player2 != null) {
                    player2.setGameMode(GameMode.SPECTATOR);
                }
                this.safeRun("[MATCH END] Sending titles", () -> {
                    TitleUtil.send(winner, "duel-win", new String[][]{{"%score%", String.valueOf(this.match.getWins(winner.getUniqueId()))}, {"%opponent_score%", String.valueOf(this.match.getLosses(winner.getUniqueId()))}});
                    if (loser != null) {
                        TitleUtil.send(loser, "duel-lose", new String[][]{{"%score%", String.valueOf(this.match.getWins(loser.getUniqueId()))}, {"%opponent_score%", String.valueOf(this.match.getLosses(loser.getUniqueId()))}});
                    }
                });
                this.safeRun("[MATCH END] Playing sounds", () -> {
                    SoundUtil.play(winner, "duel-win");
                    if (loser != null) {
                        SoundUtil.play(loser, "duel-lose");
                    }
                });
                this.safeRun("[MATCH END] Saving stats", () -> {
                    StatsManager.addWin(winner.getUniqueId());
                    if (loser != null) {
                        StatsManager.addLoss(loser.getUniqueId());
                    }
                });
                boolean isComp = this.match.isCompetitive();
                try {
                    String resultKey = "duel." + (isComp ? "comp-result" : "duel-result");
                    List<String> resultMsgs = ConfigManager.msgs(resultKey);
                    for (String line : resultMsgs) {
                        winner.sendMessage(ColorUtil.parse(line.replace("%score%", this.match.getScoreString()).replace("%winner%", winner.getName()).replace("%looser%", loser != null ? loser.getName() : "").replace("%loser%", loser != null ? loser.getName() : "").replace("%winner_score%", String.valueOf(this.match.getWins(winner.getUniqueId()))).replace("%winnerScore%", String.valueOf(this.match.getWins(winner.getUniqueId()))).replace("%loser_score%", String.valueOf(loser != null ? this.match.getWins(loser.getUniqueId()) : 0)).replace("%loserScore%", String.valueOf(loser != null ? this.match.getWins(loser.getUniqueId()) : 0)).replace("%kit%", this.isCustomKitDuel() ? "Custom Kit" : GamemodeRegistry.getDisplayName(this.tier, this.gamemode)).replace("%rounds%", "FT" + this.match.getTotalRounds())));
                    }
                    if (loser != null) {
                        for (String line : resultMsgs) {
                            loser.sendMessage(ColorUtil.parse(line.replace("%score%", this.match.getScoreString()).replace("%winner%", winner.getName()).replace("%looser%", loser.getName()).replace("%loser%", loser.getName()).replace("%winner_score%", String.valueOf(this.match.getWins(winner.getUniqueId()))).replace("%winnerScore%", String.valueOf(this.match.getWins(winner.getUniqueId()))).replace("%loser_score%", String.valueOf(this.match.getWins(loser.getUniqueId()))).replace("%loserScore%", String.valueOf(this.match.getWins(loser.getUniqueId()))).replace("%kit%", this.isCustomKitDuel() ? "Custom Kit" : GamemodeRegistry.getDisplayName(this.tier, this.gamemode)).replace("%rounds%", "FT" + this.match.getTotalRounds())));
                        }
                        if (PlayerSettingsManager.get(winner.getUniqueId(), PlayerSettingsManager.Setting.AUTO_GG)) {
                            winner.chat("gg");
                        }
                        if (PlayerSettingsManager.get(loser.getUniqueId(), PlayerSettingsManager.Setting.AUTO_GG)) {
                            loser.chat("gg");
                        }
                    }
                }
                catch (Exception e) {
                    Lifea.getInstance().getLogger().severe("[MATCH END] Sending result messages failed: " + e.getMessage());
                    e.printStackTrace();
                }
                MatchManager.logMatch(this.match, winner.getUniqueId(), loser != null ? loser.getUniqueId() : null);
                Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                    this.performCleanup(winner, loser);
                    if (this.match.getType() != Match.MatchType.PARTY && !this.isCustomKitDuel() && loser != null) {
                        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> RematchManager.offerRematch(winner, loser, this.tier, this.gamemode, this.match.getTotalRounds()), 5L);
                    }
                }, 40L);
            }
        }
    }

    private void performCleanup(Player p1, Player p2) {
        this.safeRun("[MATCH CLEANUP] Player 1", () -> {
            if (p1 != null) {
                this.cleanupPlayer(p1);
            }
        });
        this.safeRun("[MATCH CLEANUP] Player 2", () -> {
            if (p2 != null) {
                this.cleanupPlayer(p2);
            }
        });
        this.safeRun("[MATCH CLEANUP] Session refs", this::cleanupSessionRefs);
        this.safeRun("[MATCH CLEANUP] Items", () -> ArenaRestore.clearItems(this.arena));
        this.safeRun("[MATCH CLEANUP] Arena restore", () -> ArenaRestore.restoreAsync(this.arena, () -> {
            this.arena.setInUse(false);
            ClipboardCache.releaseForMatch(this.arena);
        }));
        this.safeRun("[MATCH CLEANUP] Spectators", () -> SpectateManager.removeSpectatorsForArena(this.arena.getName()));
        this.safeRun("[MATCH CLEANUP] Visibility", () -> MatchVisibilityManager.dispose(this.match));
    }

    private void cleanupPlayer(Player player) {
        player.setInvulnerable(false);
        KitRulesListener.removeHealthIndicator(player);
        KitRulesListener.clearSumoWaterDeath(player.getUniqueId());
        MatchVisibilityManager.reset(player);
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> PlayerStateManager.resetToLobby(player), 3L);
    }

    private void cleanupSessionRefs() {
        this.sneakingPlayersDuringCountdown.clear();
        this.lastSneakToggle.clear();
        this.ended = true;
        this.fighting = false;
        this.frozen = false;
        if (this.countdownTask != null) {
            this.countdownTask.cancel();
            this.countdownTask = null;
        }
        this.cancelBedwarsRespawn();
        this.cancelDragTasks();
        CustomKitRulesListener.clearPlacedBlocks(this.player1Id);
        CustomKitRulesListener.clearPlacedBlocks(this.player2Id);
        sessions.remove(this.match.getPlayer1());
        sessions.remove(this.match.getPlayer2());
        MatchManager.disposeMatch(this.match);
        StatsManager.evictCache(this.player1Id);
        StatsManager.evictCache(this.player2Id);
        PlayerSettingsManager.evict(this.player1Id);
        PlayerSettingsManager.evict(this.player2Id);
        PlayerDataCache.evict(this.player1Id);
        PlayerDataCache.evict(this.player2Id);
        KitRulesListener.clearPlayerKitCache(this.player1Id);
        KitRulesListener.clearPlayerKitCache(this.player2Id);
        KitRulesListener.clearBoxingHitsForPlayers(this.player1Id, this.player2Id);
        KitRulesListener.clearSumoWaterDeath(this.player1Id);
        KitRulesListener.clearSumoWaterDeath(this.player2Id);
        HotbarManager.clearCache(this.player1Id);
        HotbarManager.clearCache(this.player2Id);
    }

    private void applyCustomKitEffects(Player player) {
        CustomKit kit;
        if (this.isCustomKitDuel() && player != null && (kit = CustomKitManager.getKit(this.customKitOwner, this.customKitSlot)) != null && kit.isSettingEnabled("adventure-mode")) {
            player.setGameMode(GameMode.ADVENTURE);
        }
    }

    private void applyCustomKitPotions(Player player) {
        CustomKit kit;
        if (this.isCustomKitDuel() && player != null && (kit = CustomKitManager.getKit(this.customKitOwner, this.customKitSlot)) != null) {
            for (Map.Entry<String, String> entry : kit.getPotions().entrySet()) {
                String effectName = entry.getKey();
                String[] parts = entry.getValue().split(":");
                try {
                    int durationSec;
                    int amplifier = Integer.parseInt(parts[0]);
                    int n = durationSec = parts.length > 1 ? Integer.parseInt(parts[1]) : -1;
                    PotionEffectType type = PotionEffectType.getByName((String)effectName);
                    if (type == null) continue;
                    int ticks = durationSec <= 0 ? Integer.MAX_VALUE : durationSec * 20;
                    player.addPotionEffect(new PotionEffect(type, ticks, amplifier, false, false, true));
                }
                catch (NumberFormatException numberFormatException) {}
            }
        }
    }

    private void restoreAllVisibility() {
    }

    private void safeRun(String step, Runnable action) {
        try {
            action.run();
        }
        catch (Exception e) {
            Lifea.getInstance().getLogger().severe(step + " failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void forfeit(Player player) {
        if (!this.ended && !this.ending.get()) {
            Player opponent = Bukkit.getPlayer((UUID)(player.getUniqueId().equals(this.match.getPlayer1()) ? this.match.getPlayer2() : this.match.getPlayer1()));
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.forfeit")));
            if (opponent != null) {
                opponent.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.forfeit-opponent").replace("{player}", player.getName())));
                while (this.match.isActive()) {
                    this.match.recordRoundWin(opponent.getUniqueId());
                }
                this.endMatch(opponent);
            } else {
                this.endMatch(null);
            }
        }
    }

    public void endMatch() {
        this.endMatch(null);
    }

    private void cleanupSpectators() {
        try {
            for (UUID specId : this.match.getSpectators()) {
                Player spec = Bukkit.getPlayer((UUID)specId);
                if (spec != null && spec.isOnline()) {
                    SpectateManager.stopSpectating(spec);
                    continue;
                }
                SpectateManager.removeDisconnected(specId);
            }
            this.match.clearSpectators();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void healPlayer(Player player) {
        player.setHealth(player.getAttribute(Attribute.MAX_HEALTH).getValue());
        player.setFoodLevel(20);
        player.setSaturation(5.0f);
        player.setFireTicks(0);
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
    }

    private void clearPotions(Player player) {
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
    }

    private void clearArenaEntities() {
        ArenaRestore.clearItems(this.arena);
    }

    private void updateScoreboards() {
        Map<String, String> ph;
        Player p1 = Bukkit.getPlayer((UUID)this.match.getPlayer1());
        Player p2 = Bukkit.getPlayer((UUID)this.match.getPlayer2());
        if (p1 != null) {
            ph = this.buildPlaceholders(this.match, this.match.getPlayer1());
            ScoreboardManager.setType(p1, ScoreboardManager.Type.DUEL, ph);
        }
        if (p2 != null) {
            ph = this.buildPlaceholders(this.match, this.match.getPlayer2());
            ScoreboardManager.setType(p2, ScoreboardManager.Type.DUEL, ph);
        }
    }

    private Map<String, String> buildPlaceholders(Match match, UUID uuid) {
        HashMap<String, String> ph = new HashMap<String, String>();
        Player opponent = Bukkit.getPlayer((UUID)match.getOpponent(uuid));
        ph.put("%opponent%", opponent != null ? opponent.getName() : "Unknown");
        ph.put("%tier%", match.getTier());
        ph.put("%gamemode%", match.getGamemode());
        ph.put("%kit%", match.getGamemode());
        int var10002 = match.getTotalRounds();
        ph.put("%rounds%", "FT" + var10002);
        ph.put("%wins%", String.valueOf(match.getWins(uuid)));
        ph.put("%losses%", String.valueOf(match.getLosses(uuid)));
        boolean blue = uuid.equals(match.getPlayer1());
        ph.put("%team_prefix%", blue ? "&8[&#007BFB&lB&8] " : "&8[&#FB0000&lR&8] ");
        ph.put("%team_color%", blue ? "&#007BFB" : "&#FB0000");
        return ph;
    }

    private String buildPotionKey() {
        return PotionManager.buildKey(this.tier, this.gamemode);
    }

    private static boolean isBedwarsKit(String tier, String gamemode) {
        String kitKey = DuelSession.buildKitKey(tier, gamemode);
        return kitKey != null && KitRuleManager.isBedwarsEnabled(kitKey);
    }

    private static String buildKitKey(String tier, String gamemode) {
        if (tier != null && gamemode != null) {
            Map<String, String> tierToSuffix = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus", "Extra", "Extra");
            String suffix = tierToSuffix.get(tier);
            return suffix != null ? gamemode + "-" + suffix : gamemode;
        }
        return null;
    }
}

