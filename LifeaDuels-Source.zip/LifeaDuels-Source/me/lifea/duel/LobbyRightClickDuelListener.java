/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.inventory.EquipmentSlot
 */
package me.lifea.duel;

import me.lifea.config.ConfigManager;
import me.lifea.match.MatchManager;
import me.lifea.party.PartyManager;
import me.lifea.queue.QueueManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.util.ColorUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;

public class LobbyRightClickDuelListener
implements Listener {
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onInteract(PlayerInteractEntityEvent e) {
        Entity var3 = e.getRightClicked();
        if (var3 instanceof Player) {
            Player target = (Player)var3;
            Player clicker = e.getPlayer();
            if (!(!SpawnManager.isMainWorld(clicker) || e.getHand() != EquipmentSlot.HAND || MatchManager.inMatch(clicker.getUniqueId()) || QueueManager.inQueue(clicker) || target.getUniqueId().equals(clicker.getUniqueId()) || PartyManager.inParty(clicker.getUniqueId()) || clicker.isSneaking())) {
                if (MatchManager.inMatch(target.getUniqueId())) {
                    clicker.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.target-in-match").replace("%target%", target.getName())));
                } else {
                    clicker.performCommand("duel " + target.getName());
                }
            }
        }
    }
}

