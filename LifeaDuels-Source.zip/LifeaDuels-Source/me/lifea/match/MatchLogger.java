/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.match;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.lifea.storage.AsyncQueue;
import me.lifea.storage.DataPool;

public final class MatchLogger {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static volatile boolean tableEnsured = false;
    private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS match_history (\n    match_id TEXT NOT NULL,\n    winner_uuid TEXT NOT NULL,\n    loser_uuid TEXT NOT NULL,\n    gamemode TEXT NOT NULL,\n    tier TEXT NOT NULL DEFAULT '',\n    competitive INTEGER NOT NULL DEFAULT 0,\n    timestamp INTEGER NOT NULL\n)\n";
    private static final String INSERT = "INSERT INTO match_history\n    (match_id, winner_uuid, loser_uuid, gamemode, tier, competitive, timestamp)\nVALUES (?, ?, ?, ?, ?, ?, ?)\n";

    private MatchLogger() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void ensureTable() {
        if (tableEnsured) return;
        Class<MatchLogger> clazz = MatchLogger.class;
        synchronized (MatchLogger.class) {
            if (tableEnsured) return;
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement ps = conn.prepareStatement(CREATE_TABLE);){
                ps.execute();
                tableEnsured = true;
            }
            catch (SQLException e) {
                LOG.log(Level.WARNING, "[MatchLogger] Failed to create match_history table", e);
            }
            // ** MonitorExit[var0] (shouldn't be in output)
            return;
        }
    }

    public static void log(UUID matchId, UUID winnerId, UUID loserId, String gamemode, String tier, boolean competitive) {
        MatchLogger.ensureTable();
        long now = System.currentTimeMillis() / 1000L;
        AsyncQueue.execute(() -> {
            try (Connection conn = DataPool.getConnection();
                 PreparedStatement ps = conn.prepareStatement(INSERT);){
                ps.setString(1, matchId.toString());
                ps.setString(2, winnerId.toString());
                ps.setString(3, loserId.toString());
                ps.setString(4, gamemode);
                ps.setString(5, tier != null ? tier : "");
                ps.setInt(6, competitive ? 1 : 0);
                ps.setLong(7, now);
                ps.executeUpdate();
            }
            catch (SQLException e) {
                LOG.log(Level.WARNING, "[MatchLogger] Failed to log match " + String.valueOf(matchId), e);
            }
        });
    }
}

