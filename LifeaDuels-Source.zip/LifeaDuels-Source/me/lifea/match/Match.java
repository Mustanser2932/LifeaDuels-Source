/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package me.lifea.match;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import me.lifea.gui.CompGUI;
import org.bukkit.entity.Player;

public class Match {
    private final UUID matchId = UUID.randomUUID();
    private final UUID player1;
    private final UUID player2;
    private final String tier;
    private final String gamemode;
    private final int totalRounds;
    private final MatchType type;
    private final String arenaName;
    private final boolean competitive;
    private int winsPlayer1 = 0;
    private int winsPlayer2 = 0;
    private int currentRound = 1;
    private boolean active = true;
    private final Set<UUID> spectators = new HashSet<UUID>();

    public Match(Player p1, Player p2, String tier, String gamemode, int totalRounds, MatchType type, String arenaName, boolean competitive) {
        this.player1 = p1.getUniqueId();
        this.player2 = p2.getUniqueId();
        this.tier = tier;
        this.gamemode = gamemode;
        this.totalRounds = totalRounds;
        this.type = type;
        this.arenaName = arenaName;
        this.competitive = competitive;
    }

    public UUID getPlayer1() {
        return this.player1;
    }

    public UUID getPlayer2() {
        return this.player2;
    }

    public String getTier() {
        return this.tier;
    }

    public String getGamemode() {
        return this.gamemode;
    }

    public int getTotalRounds() {
        return this.totalRounds;
    }

    public int getCurrentRound() {
        return this.currentRound;
    }

    public int getWinsP1() {
        return this.winsPlayer1;
    }

    public int getWinsP2() {
        return this.winsPlayer2;
    }

    public MatchType getType() {
        return this.type;
    }

    public String getArenaName() {
        return this.arenaName;
    }

    public boolean isActive() {
        return this.active;
    }

    public boolean isCompetitive() {
        return this.type == MatchType.QUEUE && this.competitive && CompGUI.getCompGamemodes().contains(this.gamemode);
    }

    public boolean getCompetitive() {
        return this.competitive;
    }

    public boolean isPlayer(UUID uuid) {
        return this.player1.equals(uuid) || this.player2.equals(uuid);
    }

    public UUID getOpponent(UUID uuid) {
        return this.player1.equals(uuid) ? this.player2 : this.player1;
    }

    public int getWins(UUID uuid) {
        return this.player1.equals(uuid) ? this.winsPlayer1 : this.winsPlayer2;
    }

    public int getLosses(UUID uuid) {
        return this.player1.equals(uuid) ? this.winsPlayer2 : this.winsPlayer1;
    }

    public boolean recordRoundWin(UUID winner) {
        if (this.player1.equals(winner)) {
            ++this.winsPlayer1;
        } else {
            ++this.winsPlayer2;
        }
        ++this.currentRound;
        int needed = this.totalRounds;
        if (this.winsPlayer1 < needed && this.winsPlayer2 < needed) {
            return false;
        }
        this.active = false;
        return true;
    }

    public UUID getMatchWinner() {
        return this.winsPlayer1 > this.winsPlayer2 ? this.player1 : this.player2;
    }

    public UUID getMatchLoser() {
        return this.winsPlayer1 > this.winsPlayer2 ? this.player2 : this.player1;
    }

    public String getScoreString() {
        return this.winsPlayer1 + " - " + this.winsPlayer2;
    }

    public UUID getMatchId() {
        return this.matchId;
    }

    public void addSpectator(UUID uuid) {
        if (uuid != null) {
            this.spectators.add(uuid);
        }
    }

    public void removeSpectator(UUID uuid) {
        if (uuid != null) {
            this.spectators.remove(uuid);
        }
    }

    public Set<UUID> getSpectators() {
        return Set.copyOf(this.spectators);
    }

    public void clearSpectators() {
        this.spectators.clear();
    }

    public static final class MatchType
    extends Enum<MatchType> {
        public static final /* enum */ MatchType DUEL = new MatchType();
        public static final /* enum */ MatchType PARTY = new MatchType();
        public static final /* enum */ MatchType QUEUE = new MatchType();
        private static final /* synthetic */ MatchType[] $VALUES;

        public static MatchType[] values() {
            return (MatchType[])$VALUES.clone();
        }

        public static MatchType valueOf(String name) {
            return Enum.valueOf(MatchType.class, name);
        }

        private static MatchType[] $values() {
            return new MatchType[]{DUEL, PARTY, QUEUE};
        }

        private static MatchType[] $values$() {
            return new MatchType[]{DUEL, PARTY, QUEUE};
        }

        private static /* synthetic */ MatchType[] $values$$() {
            return new MatchType[]{DUEL, PARTY, QUEUE};
        }

        static {
            $VALUES = MatchType.$values$$();
        }
    }
}

