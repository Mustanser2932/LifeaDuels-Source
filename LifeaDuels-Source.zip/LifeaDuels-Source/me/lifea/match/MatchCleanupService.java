/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package me.lifea.match;

import java.util.UUID;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.config.PerformanceConfig;
import me.lifea.duel.DuelSession;
import me.lifea.party.match.PartyDuelSession;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class MatchCleanupService {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static BukkitTask cleanupTask = null;
    private static final long MATCH_TIMEOUT_TICKS = 3600L;

    public static void init() {
        if (PerformanceConfig.isAggressiveCleanupEnabled()) {
            long interval = Math.max(1, PerformanceConfig.getMatchCleanupDelay());
            cleanupTask = Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), MatchCleanupService::runCleanup, interval, interval);
        }
    }

    public static void shutdown() {
        if (cleanupTask != null) {
            cleanupTask.cancel();
            cleanupTask = null;
        }
    }

    private static void runCleanup() {
        try {
            MatchCleanupService.checkStuckMatches();
            MatchCleanupService.checkOrphanedPlayers();
        }
        catch (Exception e) {
            LOG.warning("[CleanupService] Error during cleanup: " + e.getMessage());
        }
    }

    private static void checkStuckMatches() {
        for (DuelSession duelSession : DuelSession.getActiveSessions()) {
            long elapsedTicks;
            if (duelSession.isEnded() || !duelSession.isFighting() || (elapsedTicks = duelSession.getFightingTicksElapsed()) < 3600L) continue;
            LOG.warning("[CleanupService] Force ending stuck match");
            try {
                duelSession.endMatch();
            }
            catch (Exception e) {
                LOG.warning("[CleanupService] Failed to force end: " + e.getMessage());
            }
        }
        for (PartyDuelSession partyDuelSession : PartyDuelSession.getActiveSessions()) {
            if (!partyDuelSession.isFighting() || partyDuelSession.getFightingTicksElapsed() < 3600L) continue;
            LOG.warning("[CleanupService] Force ending stuck party match (timeout)");
            try {
                partyDuelSession.endMatch();
            }
            catch (Exception e) {
                LOG.warning("[CleanupService] Failed to force end party match: " + e.getMessage());
            }
        }
    }

    private static void checkOrphanedPlayers() {
        for (DuelSession session : DuelSession.getActiveSessions()) {
            if (session.isEnded()) continue;
            Player p1 = Bukkit.getPlayer((UUID)session.getMatch().getPlayer1());
            Player p2 = Bukkit.getPlayer((UUID)session.getMatch().getPlayer2());
            if (p1 != null && p1.isOnline() || p2 != null && p2.isOnline()) continue;
            LOG.warning("[CleanupService] Cleaning up match with both players offline");
            try {
                session.endMatch();
            }
            catch (Exception e) {
                LOG.warning("[CleanupService] Failed to cleanup: " + e.getMessage());
            }
        }
    }

    public static void recover() {
        for (Arena arena : ArenaManager.getAll()) {
            boolean hasActiveSession;
            if (!arena.isInUse() || (hasActiveSession = DuelSession.getActiveSessions().stream().anyMatch(s -> !s.isEnded() && s.getArena() != null && s.getArena().getName().equals(arena.getName())) || PartyDuelSession.getActiveSessions().stream().anyMatch(s -> s.getArena() != null && s.getArena().getName().equals(arena.getName())))) continue;
            arena.setInUse(false);
        }
    }
}

