/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.match;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelRequestManager;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class RematchManager {
    public static final NamespacedKey REMATCH_KEY = new NamespacedKey((Plugin)Lifea.getInstance(), "rematch_item");
    private static final Map<UUID, RematchRequest> pending = new HashMap<UUID, RematchRequest>();

    public static void offerRematch(Player winner, Player loser, String tier, String gamemode, int rounds) {
        RematchManager.giveRematchItem(winner, loser, tier, gamemode, rounds);
        RematchManager.giveRematchItem(loser, winner, tier, gamemode, rounds);
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            RematchManager.removeRematchItem(winner);
            RematchManager.removeRematchItem(loser);
            pending.remove(winner.getUniqueId());
            pending.remove(loser.getUniqueId());
        }, 900L);
    }

    private static void giveRematchItem(Player player, Player opponent, String tier, String gamemode, int rounds) {
        ItemStack item;
        SkullMeta meta;
        ConfigurationSection sec = ConfigManager.config().getConfigurationSection("match.rematch-item");
        int slot = 8;
        String name = "&6Rematch";
        List loreStrings = new ArrayList();
        if (sec != null) {
            slot = Math.max(0, Math.min(8, sec.getInt("slot", 9) - 1));
            name = sec.getString("name", "&6Rematch");
            loreStrings = sec.getStringList("lore");
        }
        if ((meta = (SkullMeta)(item = new ItemStack(Material.PLAYER_HEAD)).getItemMeta()) != null) {
            meta.setOwningPlayer((OfflinePlayer)opponent);
            meta.displayName(ColorUtil.parse(name));
            if (!loreStrings.isEmpty()) {
                ArrayList<Component> lore = new ArrayList<Component>();
                for (String line : loreStrings) {
                    lore.add(ColorUtil.parse(line));
                }
                meta.lore(lore);
            }
            meta.getPersistentDataContainer().set(REMATCH_KEY, PersistentDataType.STRING, (Object)(String.valueOf(opponent.getUniqueId()) + ":" + tier + ":" + gamemode + ":" + rounds));
            item.setItemMeta((ItemMeta)meta);
        }
        player.getInventory().setItem(slot, item);
    }

    public static void handleRematchClick(Player player) {
        String[] parts;
        String data;
        ItemMeta meta;
        ItemStack item = player.getInventory().getItem(player.getInventory().getHeldItemSlot());
        if (item != null && item.getType() == Material.PLAYER_HEAD && (meta = item.getItemMeta()) != null && (data = (String)meta.getPersistentDataContainer().get(REMATCH_KEY, PersistentDataType.STRING)) != null && (parts = data.split(":", 4)).length >= 4) {
            UUID opponentUUID;
            try {
                opponentUUID = UUID.fromString(parts[0]);
            }
            catch (Exception var121) {
                return;
            }
            Player opponent = Bukkit.getPlayer((UUID)opponentUUID);
            if (opponent != null && opponent.isOnline()) {
                int rounds;
                String tier = parts[1];
                String gamemode = parts[2];
                try {
                    rounds = Integer.parseInt(parts[3]);
                }
                catch (NumberFormatException var11) {
                    return;
                }
                DuelRequestManager.sendRequest(player, opponent, tier, gamemode, rounds);
                RematchManager.removeRematchItem(player);
            } else {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("rematch.opponent-offline")));
                RematchManager.removeRematchItem(player);
            }
        }
    }

    public static void removeRematchItem(Player player) {
        for (int i = 0; i < 9; ++i) {
            ItemMeta meta;
            ItemStack item = player.getInventory().getItem(i);
            if (item == null || (meta = item.getItemMeta()) == null || !meta.getPersistentDataContainer().has(REMATCH_KEY, PersistentDataType.STRING)) continue;
            player.getInventory().setItem(i, (ItemStack)null);
        }
    }

    public static boolean isRematchItem(ItemStack item) {
        if (item != null && item.getType() == Material.PLAYER_HEAD) {
            ItemMeta meta = item.getItemMeta();
            return meta != null && meta.getPersistentDataContainer().has(REMATCH_KEY, PersistentDataType.STRING);
        }
        return false;
    }

    public static void clearFor(UUID uuid) {
        pending.remove(uuid);
        pending.entrySet().removeIf(entry -> ((RematchRequest)entry.getValue()).opponent().equals(uuid));
    }

    public record RematchRequest(UUID opponent, String tier, String gamemode, int rounds) {
    }
}

