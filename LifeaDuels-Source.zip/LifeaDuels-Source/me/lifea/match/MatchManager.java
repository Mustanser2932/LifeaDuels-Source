/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.match;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.gui.CompGUI;
import me.lifea.match.Match;
import me.lifea.match.MatchLogger;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.queue.QueueManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.NametagManager;
import me.lifea.util.TabManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class MatchManager {
    private static final Map<UUID, Match> matches = new ConcurrentHashMap<UUID, Match>();
    private static final Map<Match, Set<UUID>> participantsByMatch = new ConcurrentHashMap<Match, Set<UUID>>();

    public static Match createMatch(Player p1, Player p2, String tier, String gamemode, int rounds, Match.MatchType type, String arenaName, boolean competitive) {
        Match match = new Match(p1, p2, tier, gamemode, rounds, type, arenaName, competitive);
        matches.put(p1.getUniqueId(), match);
        matches.put(p2.getUniqueId(), match);
        HashSet<UUID> participants = new HashSet<UUID>();
        participants.add(p1.getUniqueId());
        participants.add(p2.getUniqueId());
        participantsByMatch.put(match, participants);
        QueueManager.invalidateDuelCountCache();
        CompGUI.refreshOpenViews();
        return match;
    }

    public static void registerMatchParticipants(Collection<UUID> participants, Match match) {
        Set set = participantsByMatch.computeIfAbsent(match, k -> new HashSet());
        for (UUID uuid : participants) {
            matches.put(uuid, match);
            set.add(uuid);
        }
        QueueManager.invalidateDuelCountCache();
        CompGUI.refreshOpenViews();
    }

    public static Match getMatch(UUID uuid) {
        return matches.get(uuid);
    }

    public static boolean inMatch(UUID uuid) {
        return matches.containsKey(uuid);
    }

    public static void removeMatch(UUID uuid) {
        Set<UUID> ids;
        Match match = matches.remove(uuid);
        if (match != null && (ids = participantsByMatch.get(match)) != null) {
            ids.remove(uuid);
            if (ids.isEmpty()) {
                participantsByMatch.remove(match);
            }
        }
        QueueManager.invalidateDuelCountCache();
        CompGUI.refreshOpenViews();
    }

    public static void disposeMatch(Match match) {
        if (match != null) {
            Set<UUID> participants = participantsByMatch.remove(match);
            if (participants != null) {
                for (UUID uuid : participants) {
                    matches.remove(uuid);
                }
            }
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                NametagManager.refreshAll();
                TabManager.refreshAll();
            });
            QueueManager.invalidateDuelCountCache();
            CompGUI.refreshOpenViews();
        }
    }

    public static void disposeAll() {
        for (Match match : Set.copyOf(participantsByMatch.keySet())) {
            MatchManager.disposeMatch(match);
        }
        matches.clear();
        participantsByMatch.clear();
    }

    public static Collection<Match> getAll() {
        return matches.values();
    }

    public static Set<Match> getUniqueActiveMatches() {
        HashSet<Match> active = new HashSet<Match>();
        for (Map.Entry<Match, Set<UUID>> entry : participantsByMatch.entrySet()) {
            Match match = entry.getKey();
            if (match == null || !match.isActive() || entry.getValue().isEmpty()) continue;
            active.add(match);
        }
        return active;
    }

    public static boolean hasActiveMatches() {
        for (Match match : participantsByMatch.keySet()) {
            if (match == null || !match.isActive()) continue;
            return true;
        }
        return false;
    }

    public static Map<UUID, Match> buildActivePlayerMatchIndex() {
        HashMap<UUID, Match> index = new HashMap<UUID, Match>();
        for (Map.Entry<Match, Set<UUID>> entry : participantsByMatch.entrySet()) {
            Match match = entry.getKey();
            if (match == null || !match.isActive()) continue;
            for (UUID id : entry.getValue()) {
                index.put(id, match);
            }
        }
        return index;
    }

    public static Set<UUID> getParticipantIds(Match match) {
        Set<UUID> ids = participantsByMatch.get(match);
        return ids != null && !ids.isEmpty() ? Collections.unmodifiableSet(ids) : Set.of();
    }

    public static void logMatch(Match match, UUID winnerId, UUID loserId) {
        if (winnerId != null && loserId != null) {
            MatchLogger.log(match.getMatchId(), winnerId, loserId, match.getGamemode(), match.getTier(), match.isCompetitive());
        }
    }

    public static void forfeit(Player forfeiter) {
        DuelSession session = DuelSession.getSession(forfeiter.getUniqueId());
        if (session != null) {
            session.forfeit(forfeiter);
        } else {
            PartyDuelSession partySession = PartyDuelSession.getSession(forfeiter.getUniqueId());
            if (partySession != null) {
                partySession.forfeit(forfeiter);
            } else {
                Match match = matches.get(forfeiter.getUniqueId());
                if (match != null && match.isActive()) {
                    forfeiter.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.forfeit")));
                    Player opponent = Bukkit.getPlayer((UUID)match.getOpponent(forfeiter.getUniqueId()));
                    if (opponent != null) {
                        opponent.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.forfeit-opponent").replace("{player}", forfeiter.getName())));
                    }
                    MatchManager.removeMatch(forfeiter.getUniqueId());
                    MatchManager.removeMatch(match.getOpponent(forfeiter.getUniqueId()));
                }
            }
        }
    }
}

