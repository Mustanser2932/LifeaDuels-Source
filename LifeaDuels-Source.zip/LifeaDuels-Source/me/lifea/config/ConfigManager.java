/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.Configuration
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package me.lifea.config;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import me.lifea.Lifea;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigManager {
    private static FileConfiguration config;
    private static FileConfiguration messages;
    private static FileConfiguration coreSystem;
    private static FileConfiguration kitEditor;
    private static FileConfiguration duelGui;
    private static FileConfiguration queue;
    private static FileConfiguration customKits;
    private static FileConfiguration party;
    private static FileConfiguration cosmetics;

    public static void load() {
        Lifea plugin = Lifea.getInstance();
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();
        messages = ConfigManager.loadFile(plugin, "messages.yml");
        coreSystem = ConfigManager.loadFile(plugin, "core-system.yml");
        kitEditor = ConfigManager.loadFile(plugin, "kiteditor.yml", true);
        duelGui = ConfigManager.loadFile(plugin, "duel.yml");
        queue = ConfigManager.loadFile(plugin, "queue.yml", true);
        customKits = ConfigManager.loadFile(plugin, "custom-kits.yml");
        party = ConfigManager.loadFile(plugin, "party.yml");
        cosmetics = ConfigManager.loadFile(plugin, "cosmetics.yml");
    }

    public static void reload() {
        ConfigManager.load();
    }

    public static void reloadFile(String fileName) {
        Lifea plugin = Lifea.getInstance();
        File file = new File(plugin.getDataFolder(), fileName);
        if (file.exists()) {
            FileConfiguration cfg = ConfigManager.loadMergedWithJarDefaults(plugin, fileName, file);
            switch (fileName.toLowerCase()) {
                case "config.yml": {
                    plugin.reloadConfig();
                    config = plugin.getConfig();
                    break;
                }
                case "messages.yml": {
                    messages = cfg;
                    break;
                }
                case "core-system.yml": {
                    coreSystem = cfg;
                    break;
                }
                case "kiteditor.yml": {
                    kitEditor = cfg;
                    break;
                }
                case "duel.yml": {
                    duelGui = cfg;
                    break;
                }
                case "queue.yml": {
                    queue = cfg;
                    break;
                }
                case "custom-kits.yml": {
                    customKits = cfg;
                    break;
                }
                case "party.yml": {
                    party = cfg;
                    break;
                }
                case "cosmetics.yml": {
                    cosmetics = cfg;
                }
            }
        }
    }

    private static FileConfiguration loadFile(Lifea plugin, String name) {
        File file = new File(plugin.getDataFolder(), name);
        if (!file.exists()) {
            plugin.saveResource(name, false);
        }
        return ConfigManager.loadMergedWithJarDefaults(plugin, name, file);
    }

    private static FileConfiguration loadMergedWithJarDefaults(Lifea plugin, String name, File file) {
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        InputStream in = plugin.getResource(name);
        if (in != null) {
            cfg.setDefaults((Configuration)YamlConfiguration.loadConfiguration((Reader)new InputStreamReader(in, StandardCharsets.UTF_8)));
            cfg.options().copyDefaults(true);
        }
        return cfg;
    }

    private static FileConfiguration loadFile(Lifea plugin, String name, boolean overwrite) {
        if (overwrite) {
            plugin.saveResource(name, true);
        }
        return ConfigManager.loadFile(plugin, name);
    }

    public static FileConfiguration config() {
        return config;
    }

    public static FileConfiguration messages() {
        return messages;
    }

    public static FileConfiguration kitEditor() {
        return kitEditor;
    }

    public static FileConfiguration duelGui() {
        return duelGui;
    }

    public static FileConfiguration queue() {
        return queue;
    }

    public static FileConfiguration customKits() {
        return customKits;
    }

    public static FileConfiguration party() {
        return party;
    }

    public static FileConfiguration cosmetics() {
        return cosmetics;
    }

    public static ConfigurationSection titles() {
        return coreSystem.getConfigurationSection("titles");
    }

    public static ConfigurationSection scoreboard() {
        return coreSystem.getConfigurationSection("scoreboard");
    }

    public static ConfigurationSection sounds() {
        return coreSystem.getConfigurationSection("sounds");
    }

    public static List<String> blacklistedWorlds() {
        return config.getStringList("blacklisted-worlds");
    }

    public static int requestTimeout() {
        return config.getInt("duel.request-timeout", 30);
    }

    public static String msg(String path) {
        return messages.getString(path, "&cMissing message: " + path);
    }

    public static String partyMsg(String key) {
        return party.getString("messages." + key, "&cMissing party message: " + key);
    }

    public static List<String> partyMsgs(String key) {
        List list = party.getStringList("messages." + key);
        if (!list.isEmpty()) {
            return list;
        }
        String single = party.getString("messages." + key);
        return single != null ? List.of(single) : List.of("&cMissing party message: " + key);
    }

    public static List<String> msgs(String path) {
        List list = messages.getStringList(path);
        if (!list.isEmpty()) {
            return list;
        }
        String single = messages.getString(path);
        return single != null ? List.of(single) : List.of("&cMissing message: " + path);
    }

    public static String guiTitle(String key, String ... replacements) {
        String title = config.getString("gui.titles." + key, "&cMissing title: " + key);
        int i = 0;
        while (i + 1 < replacements.length) {
            title = title.replace(replacements[i], replacements[i + 1]);
            i += 2;
        }
        return title;
    }

    public static String partyGuiTitle(String key, String ... replacements) {
        String title = party.getString("gui-titles." + key, "&cMissing party gui title: " + key);
        int i = 0;
        while (i + 1 < replacements.length) {
            title = title.replace(replacements[i], replacements[i + 1]);
            i += 2;
        }
        return title;
    }
}

