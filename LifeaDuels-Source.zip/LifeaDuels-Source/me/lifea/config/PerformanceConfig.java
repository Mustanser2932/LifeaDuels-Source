/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.config;

import me.lifea.config.ConfigManager;

public class PerformanceConfig {
    private static String k(String key) {
        return "performance." + key;
    }

    public static boolean isAsyncDbEnabled() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("async-db-enabled"), true);
    }

    public static int getDbWriteQueueSize() {
        return ConfigManager.config().getInt(PerformanceConfig.k("db-write-queue-size"), 256);
    }

    public static boolean isPlayerCacheEnabled() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("player-cache-enabled"), true);
    }

    public static int getPlayerCacheMaxSize() {
        return ConfigManager.config().getInt(PerformanceConfig.k("player-cache-max-size"), 30);
    }

    public static int getScoreboardUpdateInterval() {
        return ConfigManager.config().getInt(PerformanceConfig.k("scoreboard-update-interval"), 40);
    }

    public static long getQueueStatsCacheTtlMs() {
        return ConfigManager.config().getLong(PerformanceConfig.k("queue-stats-cache-ttl-ms"), 2000L);
    }

    public static long getSpectateFailsafeInterval() {
        return ConfigManager.config().getLong(PerformanceConfig.k("spectate-failsafe-interval"), 60L);
    }

    public static boolean isAggressiveCleanupEnabled() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("aggressive-cleanup-enabled"), true);
    }

    public static int getMatchCleanupDelay() {
        return ConfigManager.config().getInt(PerformanceConfig.k("match-cleanup-delay-ticks"), 20);
    }

    public static boolean isProfilingEnabled() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("profiling-enabled"), false);
    }

    public static int getKitCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("kit-cache-expiry-seconds"), 600);
    }

    public static boolean isKitCacheEnabled() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("kit-cache-enabled"), true);
    }

    public static int getStatsCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("stats-cache-expiry-seconds"), 600);
    }

    public static int getNametagCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("nametag-cache-expiry-seconds"), 600);
    }

    public static int getPotionCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("potion-cache-expiry-seconds"), 600);
    }

    public static int getHotbarCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("hotbar-cache-expiry-seconds"), 600);
    }

    public static int getQueueCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("queue-cache-expiry-seconds"), 600);
    }

    public static int getPartyCacheExpirySeconds() {
        return ConfigManager.config().getInt(PerformanceConfig.k("party-cache-expiry-seconds"), 600);
    }

    public static boolean isOptimizedEntityCleanup() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("optimized-entity-cleanup"), true);
    }

    public static long getTimingThresholdMs() {
        return ConfigManager.config().getLong(PerformanceConfig.k("timing-threshold-ms"), 50L);
    }

    public static int getRestoreBlocksPerTick() {
        return ConfigManager.config().getInt(PerformanceConfig.k("restore-blocks-per-tick"), 100);
    }

    public static int getSchematicRestoreThreshold() {
        return ConfigManager.config().getInt(PerformanceConfig.k("schematic-restore-threshold-blocks"), 250);
    }

    public static int getMaxConcurrentRestores() {
        return ConfigManager.config().getInt(PerformanceConfig.k("max-concurrent-restores"), 1);
    }

    public static boolean isModifiedBlockTracking() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("enable-modified-block-tracking"), true);
    }

    public static boolean isCleanupEntitiesAfterMatch() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("cleanup-entities-after-match"), true);
    }

    public static boolean isRestoreDebugLogging() {
        return ConfigManager.config().getBoolean(PerformanceConfig.k("restore-debug-logging"), false);
    }
}

