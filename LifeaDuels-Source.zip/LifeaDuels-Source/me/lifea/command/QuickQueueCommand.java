/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import me.lifea.config.ConfigManager;
import me.lifea.queue.QueueManager;
import me.lifea.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class QuickQueueCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            QueueManager.quickQueue(player);
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }
}

