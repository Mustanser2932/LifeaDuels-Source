/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.List;
import java.util.stream.Collectors;
import me.lifea.config.ConfigManager;
import me.lifea.gui.kit.custom.CustomKitsMenuGUI;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.party.PartyManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class DuelsCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 0) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.usage")));
                return true;
            }
            Player target = Bukkit.getPlayer((String)args[0]);
            if (target != null && target.isOnline()) {
                if (PartyManager.inParty(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.duel-in-party")));
                    return true;
                }
                if (!CustomKitManager.isEnabled()) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
                    return true;
                }
                new CustomKitsMenuGUI(target).open(player);
                return true;
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found")));
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        return args.length == 1 ? Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals((Object)sender)).map(Player::getName).filter(name -> name.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList()) : List.of();
    }
}

