/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.JuggernautKitGUI;
import me.lifea.gui.party.PartyKickGUI;
import me.lifea.gui.party.PartyMatchGUI;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelRequestManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class PartyCommand
implements CommandExecutor,
TabCompleter {
    private static final List<String> SUBS = List.of("create", "disband", "leave", "info", "match", "invite", "join", "kick", "transfer", "public", "forceend", "juggernaut");
    private static final List<String> PLAYER_SUBS = List.of("invite", "join", "kick", "transfer");

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            this.sendUsage(player);
            return true;
        }
        block3 : switch (args[0].toLowerCase()) {
            case "forceend": {
                PartyDuelSession.forceEnd(player);
                break;
            }
            default: {
                if (PartyDuelSession.inSession(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.parse("&cYou cannot use party commands while in a party match. Use /party forceend to end it."));
                    return true;
                }
                switch (args[0].toLowerCase()) {
                    case "create": {
                        PartyManager.createParty(player);
                        break block3;
                    }
                    case "disband": {
                        PartyManager.disbandParty(player);
                        break block3;
                    }
                    case "leave": {
                        PartyManager.leaveParty(player);
                        break block3;
                    }
                    case "info": {
                        PartyManager.listParty(player);
                        break block3;
                    }
                    case "juggernaut": {
                        if (!player.hasPermission("lifea.party.juggernaut") && !player.isOp()) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.no-permission")));
                            return true;
                        }
                        if (args.length < 2) {
                            player.sendMessage(ColorUtil.parse("&cUsage: /party juggernaut <player1,player2,...>"));
                            return true;
                        }
                        Party jugParty = PartyManager.getParty(player.getUniqueId());
                        if (jugParty == null) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
                            return true;
                        }
                        if (!jugParty.isLeader(player.getUniqueId())) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
                            return true;
                        }
                        String[] jugNames = args[1].split(",");
                        ArrayList<UUID> juggernauts = new ArrayList<UUID>();
                        boolean jugError = false;
                        for (String jugName : jugNames) {
                            Player jugPlayer = Bukkit.getPlayer((String)jugName.trim());
                            if (jugPlayer == null || !jugPlayer.isOnline()) {
                                player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found").replace("%player%", jugName.trim())));
                                jugError = true;
                                break;
                            }
                            if (!jugParty.getMembers().contains(jugPlayer.getUniqueId())) {
                                player.sendMessage(ColorUtil.parse("&c" + jugPlayer.getName() + " is not in your party."));
                                jugError = true;
                                break;
                            }
                            juggernauts.add(jugPlayer.getUniqueId());
                        }
                        if (jugError) {
                            return true;
                        }
                        long othersCount = jugParty.getMembers().stream().filter(u -> !juggernauts.contains(u)).count();
                        if (othersCount < 1L) {
                            player.sendMessage(ColorUtil.parse("&cThere must be at least 1 player on the other side."));
                            return true;
                        }
                        new JuggernautKitGUI(juggernauts).open(player);
                        break block3;
                    }
                    case "match": {
                        Party party = PartyManager.getParty(player.getUniqueId());
                        if (party == null) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
                            return true;
                        }
                        if (!party.isLeader(player.getUniqueId())) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
                            return true;
                        }
                        new PartyMatchGUI().open(player);
                        break block3;
                    }
                    case "duelaccept": {
                        PartyDuelRequestManager.acceptRequest(player);
                        break block3;
                    }
                    case "dueldeny": {
                        PartyDuelRequestManager.denyRequest(player);
                        break block3;
                    }
                    case "invite": {
                        if (args.length < 2) {
                            player.sendMessage(ColorUtil.parse("&cUsage: /party invite <player>"));
                            return true;
                        }
                        Player target = Bukkit.getPlayer((String)args[1]);
                        if (target == null || !target.isOnline()) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found")));
                            return true;
                        }
                        if (target.equals((Object)player)) {
                            player.sendMessage(ColorUtil.parse("&cYou cannot invite yourself."));
                            return true;
                        }
                        PartyManager.invitePlayer(player, target);
                        break block3;
                    }
                    case "join": {
                        if (args.length < 2) {
                            player.sendMessage(ColorUtil.parse("&cUsage: /party join <leader>"));
                            return true;
                        }
                        Player leader = Bukkit.getPlayer((String)args[1]);
                        if (leader == null || !leader.isOnline()) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found")));
                            return true;
                        }
                        PartyManager.joinParty(player, leader);
                        break block3;
                    }
                    case "public": {
                        PartyManager.togglePublic(player);
                        break block3;
                    }
                    case "kick": {
                        Party kickParty = PartyManager.getParty(player.getUniqueId());
                        if (kickParty == null) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
                            return true;
                        }
                        if (!kickParty.isLeader(player.getUniqueId())) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
                            return true;
                        }
                        if (args.length >= 2) {
                            Player kickTarget = Bukkit.getPlayer((String)args[1]);
                            if (kickTarget == null || !kickTarget.isOnline()) {
                                player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found")));
                                return true;
                            }
                            PartyManager.kickMember(player, kickTarget);
                            break block3;
                        }
                        new PartyKickGUI().open(player, kickParty);
                        break block3;
                    }
                    case "transfer": {
                        if (args.length < 2) {
                            player.sendMessage(ColorUtil.parse("&cUsage: /party transfer <player>"));
                            return true;
                        }
                        Player transferTarget = Bukkit.getPlayer((String)args[1]);
                        if (transferTarget == null || !transferTarget.isOnline()) {
                            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found")));
                            return true;
                        }
                        PartyManager.transferLeader(player, transferTarget);
                        break block3;
                    }
                }
                this.sendUsage(player);
            }
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                boolean inParty = PartyManager.inParty(player.getUniqueId());
                List<String> subs = SUBS.stream().filter(s -> {
                    if (s.equals("create") && inParty) {
                        return false;
                    }
                    return !s.equals("join") || !inParty;
                }).collect(Collectors.toList());
                return this.filter(subs, args[0]);
            }
            return this.filter(SUBS, args[0]);
        }
        if (args.length == 2 && "juggernaut".equals(args[0].toLowerCase()) && sender instanceof Player) {
            Player player = (Player)sender;
            if (!player.hasPermission("lifea.party.juggernaut") && !player.isOp()) {
                return List.of();
            }
            Party jugParty = PartyManager.getParty(player.getUniqueId());
            if (jugParty == null) {
                return List.of();
            }
            String input = args[1];
            int lastComma = input.lastIndexOf(44);
            String prefix = lastComma >= 0 ? input.substring(0, lastComma + 1) : "";
            String current = lastComma >= 0 ? input.substring(lastComma + 1) : input;
            return jugParty.getMembers().stream().filter(u -> !u.equals(player.getUniqueId())).map(u -> Bukkit.getPlayer((UUID)u)).filter(p -> p != null && p.isOnline()).map(Player::getName).filter(n -> n.toLowerCase().startsWith(current.toLowerCase())).map(n -> prefix + n).collect(Collectors.toList());
        }
        return args.length == 2 && PLAYER_SUBS.contains(args[0].toLowerCase()) ? Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals((Object)sender)).map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList()) : List.of();
    }

    private List<String> filter(List<String> list, String input) {
        return list.stream().filter(s -> s.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }

    private void sendUsage(Player player) {
        player.sendMessage(ColorUtil.parse("&8&m                    "));
        player.sendMessage(ColorUtil.parse("  &6\ud83d\udc65 Party Commands"));
        player.sendMessage(ColorUtil.parse("  &e/party create &f- Create a party"));
        player.sendMessage(ColorUtil.parse("  &e/party invite <player> &f- Invite a player"));
        player.sendMessage(ColorUtil.parse("  &e/party join <leader> &f- Join a party you were invited to"));
        player.sendMessage(ColorUtil.parse("  &e/party kick [player] &f- Kick a member (GUI if no arg)"));
        player.sendMessage(ColorUtil.parse("  &e/party transfer <player> &f- Transfer leadership"));
        player.sendMessage(ColorUtil.parse("  &e/party juggernaut <player1,player2,...> &f- Start a Juggernaut match"));
        player.sendMessage(ColorUtil.parse("  &e/party match &f- Open match mode GUI"));
        player.sendMessage(ColorUtil.parse("  &e/party public &f- Toggle party public/private"));
        player.sendMessage(ColorUtil.parse("  &e/party forceend &f- Force-end the current party match"));
        player.sendMessage(ColorUtil.parse("  &e/party leave &f- Leave the party"));
        player.sendMessage(ColorUtil.parse("  &e/party disband &f- Disband the party"));
        player.sendMessage(ColorUtil.parse("  &e/party info &f- List party members"));
        player.sendMessage(ColorUtil.parse("&8&m                    "));
    }
}

