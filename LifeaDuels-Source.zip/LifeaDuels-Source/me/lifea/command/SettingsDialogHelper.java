/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.retrooper.packetevents.PacketEvents
 *  com.github.retrooper.packetevents.protocol.chat.clickevent.ClickEvent
 *  com.github.retrooper.packetevents.protocol.dialog.CommonDialogData
 *  com.github.retrooper.packetevents.protocol.dialog.Dialog
 *  com.github.retrooper.packetevents.protocol.dialog.DialogAction
 *  com.github.retrooper.packetevents.protocol.dialog.MultiActionDialog
 *  com.github.retrooper.packetevents.protocol.dialog.action.Action
 *  com.github.retrooper.packetevents.protocol.dialog.action.StaticAction
 *  com.github.retrooper.packetevents.protocol.dialog.body.PlainMessage
 *  com.github.retrooper.packetevents.protocol.dialog.body.PlainMessageDialogBody
 *  com.github.retrooper.packetevents.protocol.dialog.button.ActionButton
 *  com.github.retrooper.packetevents.protocol.dialog.button.CommonButtonData
 *  com.github.retrooper.packetevents.wrapper.PacketWrapper
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerClearDialog
 *  com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerShowDialog
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.format.NamedTextColor
 *  net.kyori.adventure.text.format.TextColor
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.chat.clickevent.ClickEvent;
import com.github.retrooper.packetevents.protocol.dialog.CommonDialogData;
import com.github.retrooper.packetevents.protocol.dialog.Dialog;
import com.github.retrooper.packetevents.protocol.dialog.DialogAction;
import com.github.retrooper.packetevents.protocol.dialog.MultiActionDialog;
import com.github.retrooper.packetevents.protocol.dialog.action.Action;
import com.github.retrooper.packetevents.protocol.dialog.action.StaticAction;
import com.github.retrooper.packetevents.protocol.dialog.body.PlainMessage;
import com.github.retrooper.packetevents.protocol.dialog.body.PlainMessageDialogBody;
import com.github.retrooper.packetevents.protocol.dialog.button.ActionButton;
import com.github.retrooper.packetevents.protocol.dialog.button.CommonButtonData;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerClearDialog;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerShowDialog;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import me.lifea.command.SettingsCommand;
import me.lifea.config.ConfigManager;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;

class SettingsDialogHelper {
    private static final int BUTTON_WIDTH = 300;

    SettingsDialogHelper() {
    }

    static void open(Player player, List<SettingsCommand.SettingEntry> settings) {
        List<ActionButton> buttons = settings.stream().map(entry -> {
            boolean isElytra;
            if (entry.setting() == null) {
                boolean timeSetting = entry.key().equals("time-of-day");
                boolean pingRangeSetting = entry.key().equals("ping-range");
                String labelText = timeSetting ? "&fTime of Day &8(&e" + PlayerSettingsManager.getTimeOfDay(player.getUniqueId()).displayName() + "&8)" : (pingRangeSetting ? "&fPing Range &8(&e" + PlayerSettingsManager.getPingRange(player.getUniqueId()).displayName() + "&8)" : "&f" + entry.label());
                Component label = ColorUtil.parse(SettingsDialogHelper.iconFor(player, entry) + " " + labelText).decoration(TextDecoration.ITALIC, false);
                Component tooltip = SettingsDialogHelper.buildTooltip(entry.key());
                CommonButtonData buttonData = new CommonButtonData(label, tooltip, 300);
                String command = timeSetting ? "/settings time-menu" : (pingRangeSetting ? "/settings pingrange-menu" : "/settings quickqueue");
                StaticAction action = new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)command)));
                return new ActionButton(buttonData, (Action)action);
            }
            boolean bl = isElytra = entry.setting() == PlayerSettingsManager.Setting.ELYTRA;
            if (isElytra && !player.hasPermission("lifea.cosmetics.elytra")) {
                Component label = ColorUtil.parse(SettingsDialogHelper.iconFor(player, entry) + " &fElytra &8(&6No Permission&8)").decoration(TextDecoration.ITALIC, false);
                return new ActionButton(new CommonButtonData(label, (Component)null, 300), (Action)new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)"/settings noop"))));
            }
            boolean enabled = PlayerSettingsManager.get(player.getUniqueId(), entry.setting());
            String mark = enabled ? "&a\u2714" : "&c\u2718";
            String name = entry.label();
            Component label = ColorUtil.parse(SettingsDialogHelper.iconFor(player, entry) + " &f" + name + " &8(" + mark + "&8)").decoration(TextDecoration.ITALIC, false);
            Component tooltip = SettingsDialogHelper.buildTooltip(entry.key());
            CommonButtonData buttonData = new CommonButtonData(label, tooltip, 300);
            StaticAction action = new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)("/settings toggle " + entry.key()))));
            return new ActionButton(buttonData, (Action)action);
        }).toList();
        Component title = ColorUtil.parse("&6Settings").decoration(TextDecoration.ITALIC, false);
        Component subtitle = ((TextComponent)((TextComponent)Component.text((String)"Toggle your preferences below.", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)).append((Component)Component.newline())).append(Component.text((String)"Click any of the buttons below to toggle settings!", (TextColor)NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        CommonDialogData common = new CommonDialogData(title, title, true, false, DialogAction.NONE, List.of(new PlainMessageDialogBody(new PlainMessage(subtitle, 200))), List.of());
        ActionButton closeButton = new ActionButton(new CommonButtonData(ColorUtil.parse("&c\u2718 Close").decoration(TextDecoration.ITALIC, false), (Component)null, 300), (Action)new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)"/settings close"))));
        MultiActionDialog dialog = new MultiActionDialog(common, buttons, closeButton, 2);
        PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerShowDialog((Dialog)dialog));
    }

    static void openTimeMenu(Player player) {
        PlayerSettingsManager.TimeOfDay current = PlayerSettingsManager.getTimeOfDay(player.getUniqueId());
        List<ActionButton> buttons = Arrays.stream(PlayerSettingsManager.TimeOfDay.values()).map(option -> {
            String mark = option == current ? " &8(&a\u2714&8)" : "";
            String icon = option == PlayerSettingsManager.TimeOfDay.DAYTIME ? "\u2600" : SettingsDialogHelper.sprite("minecraft:items", option.sprite());
            Component label = ColorUtil.parse(icon + " &f" + option.displayName() + mark).decoration(TextDecoration.ITALIC, false);
            Component tooltip = ColorUtil.parse(option == PlayerSettingsManager.TimeOfDay.DEFAULT ? "&7Use the world's normal time." : "&7Set this time just for you.").decoration(TextDecoration.ITALIC, false);
            CommonButtonData data = new CommonButtonData(label, tooltip, 300);
            String command = "/settings time " + option.name().toLowerCase(Locale.ROOT);
            StaticAction action = new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)command)));
            return new ActionButton(data, (Action)action);
        }).toList();
        Component title = ColorUtil.parse("&6Time of Day").decoration(TextDecoration.ITALIC, false);
        Component body = ColorUtil.parse("&7Choose a time that only you will see.").decoration(TextDecoration.ITALIC, false);
        CommonDialogData common = new CommonDialogData(title, title, true, false, DialogAction.NONE, List.of(new PlainMessageDialogBody(new PlainMessage(body, 200))), List.of());
        ActionButton closeButton = new ActionButton(new CommonButtonData(ColorUtil.parse("&c\u2718 Back to Settings").decoration(TextDecoration.ITALIC, false), null, 300), (Action)new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)"/settings noop"))));
        MultiActionDialog dialog = new MultiActionDialog(common, buttons, closeButton, 2);
        PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerShowDialog((Dialog)dialog));
    }

    static void openPingRangeMenu(Player player) {
        PlayerSettingsManager.PingRange current = PlayerSettingsManager.getPingRange(player.getUniqueId());
        List<ActionButton> buttons = Arrays.stream(PlayerSettingsManager.PingRange.values()).map(option -> {
            String mark = option == current ? " &8(&a\u2714&8)" : "";
            String icon = switch (option) {
                default -> throw new MatchException(null, null);
                case PlayerSettingsManager.PingRange.MS_30_50 -> "item/iron_ingot";
                case PlayerSettingsManager.PingRange.MS_60_90 -> "item/gold_ingot";
                case PlayerSettingsManager.PingRange.MS_90_120 -> "item/emerald";
                case PlayerSettingsManager.PingRange.MS_120_250 -> "item/diamond";
                case PlayerSettingsManager.PingRange.ALL -> "item/nether_star";
            };
            Component label = ColorUtil.parse(SettingsDialogHelper.sprite("minecraft:items", icon) + " &f" + option.displayName() + mark).decoration(TextDecoration.ITALIC, false);
            CommonButtonData data = new CommonButtonData(label, ColorUtil.parse("&7Queue only against opponents in this ping range.").decoration(TextDecoration.ITALIC, false), 300);
            String command = "/settings pingrange " + option.name().toLowerCase(Locale.ROOT);
            return new ActionButton(data, (Action)new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)command))));
        }).toList();
        Component title = ColorUtil.parse("&6Ping Range").decoration(TextDecoration.ITALIC, false);
        Component body = ColorUtil.parse("&7Choose which opponent ping range you accept in queues.").decoration(TextDecoration.ITALIC, false);
        CommonDialogData common = new CommonDialogData(title, title, true, false, DialogAction.NONE, List.of(new PlainMessageDialogBody(new PlainMessage(body, 200))), List.of());
        ActionButton back = new ActionButton(new CommonButtonData(ColorUtil.parse("&c\u2718 Back to Settings").decoration(TextDecoration.ITALIC, false), null, 300), (Action)new StaticAction(ClickEvent.fromAdventure((net.kyori.adventure.text.event.ClickEvent)net.kyori.adventure.text.event.ClickEvent.runCommand((String)"/settings noop"))));
        PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerShowDialog((Dialog)new MultiActionDialog(common, buttons, back, 2)));
    }

    private static String iconFor(Player player, SettingsCommand.SettingEntry entry) {
        if (entry.setting() == null) {
            return entry.key().equals("time-of-day") ? SettingsDialogHelper.sprite("minecraft:items", "item/clock_00") : (entry.key().equals("ping-range") ? SettingsDialogHelper.sprite("minecraft:items", "item/ender_eye") : SettingsDialogHelper.sprite("minecraft:items", "item/paper"));
        }
        return switch (entry.setting()) {
            default -> throw new MatchException(null, null);
            case PlayerSettingsManager.Setting.DUEL_REQUESTS -> SettingsDialogHelper.sprite("minecraft:items", "item/book");
            case PlayerSettingsManager.Setting.SCOREBOARD -> SettingsDialogHelper.sprite("minecraft:items", "item/clock_00");
            case PlayerSettingsManager.Setting.AUTO_GG -> SettingsDialogHelper.sprite("minecraft:items", "item/redstone");
            case PlayerSettingsManager.Setting.PRIVATE_MESSAGES -> SettingsDialogHelper.sprite("minecraft:items", "item/paper");
            case PlayerSettingsManager.Setting.CHAT_MENTIONS -> SettingsDialogHelper.sprite("minecraft:items", "item/bell");
            case PlayerSettingsManager.Setting.PARTY_INVITES -> "<head:" + player.getName() + ">";
            case PlayerSettingsManager.Setting.HEALTH_INDICATOR -> SettingsDialogHelper.sprite("minecraft:items", "item/heart_of_the_sea");
            case PlayerSettingsManager.Setting.ELYTRA -> SettingsDialogHelper.sprite("minecraft:items", "item/elytra");
            case PlayerSettingsManager.Setting.CHAT_ISOLATION -> SettingsDialogHelper.sprite("minecraft:blocks", "block/iron_bars");
            case PlayerSettingsManager.Setting.PING_DISPLAY -> SettingsDialogHelper.sprite("minecraft:items", "item/heart_of_the_sea");
        };
    }

    private static String sprite(String atlas, String sprite) {
        return "&f<sprite:\"" + atlas + "\":" + sprite + ">";
    }

    private static Component buildTooltip(String key) {
        List<String> lines = ConfigManager.msgs("settings.descriptions." + key);
        Component tooltip = ColorUtil.parse("&7\u2139 ").decoration(TextDecoration.ITALIC, false);
        for (String line : lines) {
            if (line.equals("&r") || line.isBlank()) continue;
            tooltip = tooltip.append(ColorUtil.parse("&7" + line).decoration(TextDecoration.ITALIC, false)).append((Component)Component.newline());
        }
        return tooltip;
    }

    static void close(Player player) {
        PacketEvents.getAPI().getPlayerManager().sendPacket((Object)player, (PacketWrapper)new WrapperPlayServerClearDialog());
    }
}

