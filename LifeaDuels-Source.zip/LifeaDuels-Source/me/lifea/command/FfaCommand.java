/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.command;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import me.lifea.gui.kit.ffa.FfaKitEditorGUI;
import me.lifea.gui.kit.ffa.FfaKitManagerGUI;
import me.lifea.kit.ffa.FfaKitManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class FfaCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ffa.admin")) {
            sender.sendMessage(ColorUtil.parse("&cYou don't have permission."));
            return true;
        }
        if (args.length < 1) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                FfaKitManagerGUI.open(player);
            } else {
                this.sendUsage(sender);
            }
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "create": {
                this.handleCreate(sender, args);
                break;
            }
            case "delete": {
                this.handleDelete(sender, args);
                break;
            }
            case "set-items": {
                this.handleSetItems(sender, args);
                break;
            }
            case "edit": {
                this.handleEdit(sender, args);
                break;
            }
            case "give": {
                this.handleGive(sender, args);
                break;
            }
            case "list": {
                this.handleList(sender);
                break;
            }
            case "gui": {
                this.handleGui(sender);
                break;
            }
            default: {
                this.sendUsage(sender);
            }
        }
        return true;
    }

    private void handleCreate(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&fUsage: &e/ffa-kit create <name>"));
        } else {
            String name = args[1];
            if (name.contains(" ")) {
                sender.sendMessage(ColorUtil.parse("&cKit names cannot contain spaces."));
            } else if (!FfaKitManager.create(name)) {
                sender.sendMessage(ColorUtil.parse("&cFFA kit &e" + name + "&c already exists."));
            } else {
                sender.sendMessage(ColorUtil.parse("&aCreated FFA kit &e" + name + "&a."));
            }
        }
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&fUsage: &e/ffa-kit delete <name>"));
        } else if (!FfaKitManager.delete(args[1])) {
            sender.sendMessage(ColorUtil.parse("&cFFA kit &e" + args[1] + "&c not found."));
        } else {
            sender.sendMessage(ColorUtil.parse("&aDeleted FFA kit &e" + args[1] + "&a."));
        }
    }

    private void handleSetItems(CommandSender sender, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length < 2) {
                sender.sendMessage(ColorUtil.parse("&fUsage: &e/ffa-kit set-items <name>"));
            } else if (!FfaKitManager.exists(args[1])) {
                sender.sendMessage(ColorUtil.parse("&cFFA kit &e" + args[1] + "&c not found. Create it first."));
            } else {
                ItemStack[] kit = new ItemStack[41];
                ItemStack[] storage = player.getInventory().getStorageContents();
                for (int i = 0; i < 36 && i < storage.length; ++i) {
                    kit[i] = storage[i];
                }
                ItemStack[] armor = player.getInventory().getArmorContents();
                kit[36] = armor[0];
                kit[37] = armor[1];
                kit[38] = armor[2];
                kit[39] = armor[3];
                kit[40] = player.getInventory().getItemInOffHand();
                FfaKitManager.setItems(args[1], kit);
                player.sendMessage(ColorUtil.parse("&aSaved your inventory into FFA kit &e" + args[1] + "&a."));
            }
        } else {
            sender.sendMessage(ColorUtil.parse("&fOnly players can use this."));
        }
    }

    private void handleEdit(CommandSender sender, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length < 2) {
                sender.sendMessage(ColorUtil.parse("&fUsage: &e/ffa-kit edit <name>"));
            } else if (!FfaKitManager.exists(args[1])) {
                sender.sendMessage(ColorUtil.parse("&cFFA kit &e" + args[1] + "&c not found. Create it first."));
            } else {
                FfaKitEditorGUI.open(player, args[1]);
            }
        } else {
            sender.sendMessage(ColorUtil.parse("&fOnly players can use this."));
        }
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&fUsage: &e/ffa-kit give <name> [player]"));
        } else {
            ItemStack[] kit = FfaKitManager.getItems(args[1]);
            if (kit == null) {
                sender.sendMessage(ColorUtil.parse("&cFFA kit &e" + args[1] + "&c not found."));
            } else {
                Player target;
                if (args.length >= 3) {
                    target = Bukkit.getPlayerExact((String)args[2]);
                    if (target == null) {
                        sender.sendMessage(ColorUtil.parse("&cPlayer &e" + args[2] + "&c is not online."));
                        return;
                    }
                } else {
                    Player p;
                    if (!(sender instanceof Player)) {
                        sender.sendMessage(ColorUtil.parse("&fConsole must specify a player."));
                        return;
                    }
                    target = p = (Player)sender;
                }
                this.applyKit(target, kit);
                sender.sendMessage(ColorUtil.parse("&aGave FFA kit &e" + args[1] + "&a to &e" + target.getName() + "&a."));
            }
        }
    }

    private void handleList(CommandSender sender) {
        Collection<String> names = FfaKitManager.names();
        if (names.isEmpty()) {
            sender.sendMessage(ColorUtil.parse("&fNo FFA kits exist yet."));
        } else {
            sender.sendMessage(ColorUtil.parse("&fFFA kits: &e" + String.join((CharSequence)"&f, &e", names)));
        }
    }

    private void handleGui(CommandSender sender) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            FfaKitManagerGUI.open(player);
        } else {
            sender.sendMessage(ColorUtil.parse("&fOnly players can open the FFA kit GUI."));
        }
    }

    private void applyKit(Player target, ItemStack[] kit) {
        ItemStack[] main = new ItemStack[36];
        for (int i = 0; i < 36; ++i) {
            main[i] = kit[i];
        }
        target.getInventory().setStorageContents(main);
        target.getInventory().setArmorContents(new ItemStack[]{kit[36], kit[37], kit[38], kit[39]});
        target.getInventory().setItemInOffHand(kit[40]);
        target.updateInventory();
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ColorUtil.parse("&8&m                    "));
        sender.sendMessage(ColorUtil.parse("  &6FFA Kits"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit create <name>"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit delete <name>"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit set-items <name> &f- save your inventory"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit edit <name> &f- open the editor GUI"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit give <name> [player]"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit list"));
        sender.sendMessage(ColorUtil.parse("  &e/ffa-kit gui &f- open FFA kit manager"));
        sender.sendMessage(ColorUtil.parse("&8&m                    "));
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        String sub;
        if (!sender.hasPermission("ffa.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.filter(List.of("create", "delete", "set-items", "edit", "give", "list", "gui"), args[0]);
        }
        if (args.length == 2 && ((sub = args[0].toLowerCase()).equals("delete") || sub.equals("set-items") || sub.equals("edit") || sub.equals("give"))) {
            return this.filter(new ArrayList<String>(FfaKitManager.names()), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }

    private List<String> filter(List<String> list, String input) {
        return list.stream().filter(s -> s.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}

