/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.command;

import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelRequestManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class DuelAcceptCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> DuelRequestManager.openRequestGUI(player));
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }
}

