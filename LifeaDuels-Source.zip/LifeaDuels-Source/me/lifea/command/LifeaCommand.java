/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffectType
 */
package me.lifea.command;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaCloner;
import me.lifea.arena.ArenaManager;
import me.lifea.config.ConfigManager;
import me.lifea.gui.admin.ArenaEditorGUI;
import me.lifea.gui.admin.ArenaListGUI;
import me.lifea.gui.admin.DuelKitDashboardGUI;
import me.lifea.gui.admin.KitSettingsGUI;
import me.lifea.hotbar.HotbarManager;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.kit.KitRuleManager;
import me.lifea.kit.PotionManager;
import me.lifea.player.StatsManager;
import me.lifea.queue.sign.QueueSignManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.storage.DatabaseManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.TabManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

public class LifeaCommand
implements CommandExecutor,
TabCompleter {
    private static final Map<String, String> SUFFIX_TO_TIER = Map.of("COM", "MCTiers", "IO", "PvPTiers", "Sub", "SubTiers", "Cactus", "CactusTiers", "Extra", "Extra");

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("lifea.admin")) {
            sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.no-permission")));
            return true;
        }
        if (args.length == 0) {
            this.sendUsage(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload": {
                this.handleReload(sender, args);
                break;
            }
            case "setlobby": {
                this.handleSetLobby(sender);
                break;
            }
            case "setqueue": {
                this.handleSetQueue(sender, args);
                break;
            }
            case "reset": {
                this.handleReset(sender, args);
                break;
            }
            case "arena": {
                this.handleArena(sender, args);
                break;
            }
            case "kit": {
                this.handleKit(sender, args);
                break;
            }
            case "spawnitems": {
                this.handleSpawnItems(sender, args);
                break;
            }
            case "potion": {
                this.handlePotion(sender, args);
                break;
            }
            case "auto-clone": {
                this.handleAutoClone(sender, args);
                break;
            }
            case "tpclone": {
                this.handleTpClone(sender, args);
                break;
            }
            default: {
                this.sendUsage(sender);
            }
        }
        return true;
    }

    private void handleReload(CommandSender sender, String[] args) {
        if (args.length >= 2) {
            Object fileName = args[1].toLowerCase().endsWith(".yml") ? args[1] : args[1] + ".yml";
            File file = new File(Lifea.getInstance().getDataFolder(), (String)fileName);
            if (!file.exists()) {
                sender.sendMessage(ColorUtil.parse("&fFile &e" + (String)fileName + " &fnot found."));
            } else {
                ConfigManager.reloadFile((String)fileName);
                this.applyReload();
                sender.sendMessage(ColorUtil.parse("&fReloaded &e" + (String)fileName + "&f."));
            }
        } else {
            ConfigManager.reload();
            this.applyReload();
            sender.sendMessage(ColorUtil.parse("&fReloaded all configuration files."));
        }
    }

    private void applyReload() {
        KitManager.load();
        GamemodeRegistry.invalidate();
        ArenaManager.load();
        StatsManager.load();
        PotionManager.load();
        for (Player online : Bukkit.getOnlinePlayers()) {
            ScoreboardManager.update(online);
        }
        TabManager.reload();
    }

    private void handleSetLobby(CommandSender sender) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            SpawnManager.setSpawn(player.getLocation());
            sender.sendMessage(ColorUtil.parse("&fLobby set in world &e" + player.getWorld().getName() + "&f."));
        } else {
            sender.sendMessage(ColorUtil.parse("&fOnly players can use this."));
        }
    }

    private void handleSetQueue(CommandSender sender, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length < 2) {
                sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea setqueue main"));
            } else if (!args[1].equalsIgnoreCase("main")) {
                sender.sendMessage(ColorUtil.parse("&fOnly &emain &fis a valid queue key."));
            } else {
                Block target = player.getTargetBlockExact(6);
                if (target == null) {
                    sender.sendMessage(ColorUtil.parse("&fLook at a sign within &e6 &fblocks."));
                } else if (!(target.getState() instanceof Sign)) {
                    sender.sendMessage(ColorUtil.parse("&fThat block is not a sign."));
                } else {
                    QueueSignManager.set(target.getLocation(), "main");
                    sender.sendMessage(ColorUtil.parse("&fQueue sign bound to &emain&f."));
                }
            }
        } else {
            sender.sendMessage(ColorUtil.parse("&fOnly players can use this."));
        }
    }

    private void handleReset(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea reset <all|stats|kiteditor>"));
        } else {
            switch (args[1].toLowerCase()) {
                case "all": {
                    this.resetKitEditor(sender);
                    StatsManager.resetAll();
                    this.refreshScoreboards();
                    sender.sendMessage(ColorUtil.parse("&fReset all stats and kit data."));
                    break;
                }
                case "stats": {
                    if (args.length >= 3 && !args[2].equalsIgnoreCase("all")) {
                        OfflinePlayer target = Bukkit.getOfflinePlayer((String)args[2]);
                        StatsManager.resetPlayer(target.getUniqueId());
                        this.refreshScoreboards();
                        sender.sendMessage(ColorUtil.parse("&fReset stats for &e" + target.getName() + "&f."));
                        break;
                    }
                    StatsManager.resetAll();
                    this.refreshScoreboards();
                    sender.sendMessage(ColorUtil.parse("&fReset stats for &eall players&f."));
                    break;
                }
                case "kiteditor": {
                    this.resetKitEditor(sender);
                    break;
                }
                default: {
                    sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea reset <all|stats|kiteditor>"));
                }
            }
        }
    }

    private void refreshScoreboards() {
        for (Player online : Bukkit.getOnlinePlayers()) {
            ScoreboardManager.update(online);
        }
    }

    private void resetKitEditor(CommandSender sender) {
        KitManager.resetAll();
        sender.sendMessage(ColorUtil.parse("&fReset kit editor for all players."));
    }

    private void handleArena(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&cUsage: /lifea arena <create|delete|enable-all|disable-all|editor|list|give> [name]"));
        } else {
            switch (args[1].toLowerCase()) {
                case "create": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea arena create <name>"));
                        return;
                    }
                    String name = args[2];
                    if (ArenaManager.exists(name)) {
                        sender.sendMessage(ColorUtil.parse("&fArena &e" + name + " &falready exists."));
                        return;
                    }
                    ArenaManager.create(name);
                    sender.sendMessage(ColorUtil.parse("&fArena &e" + name + " &fcreated. Configure it with &e/lifea arena editor " + name + "&f."));
                    break;
                }
                case "delete": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea arena delete <name>"));
                        return;
                    }
                    if (ArenaManager.delete(args[2])) {
                        sender.sendMessage(ColorUtil.parse("&fArena &e" + args[2] + " &fdeleted."));
                        break;
                    }
                    sender.sendMessage(ColorUtil.parse("&fArena &e" + args[2] + " &fnot found."));
                    break;
                }
                case "enable-all": {
                    int enableCount = 0;
                    for (Arena arena : ArenaManager.getAll()) {
                        if (arena.isEnabled()) continue;
                        arena.setEnabled(true);
                        arena.setDirty(true);
                        ArenaManager.saveArena(arena);
                        ++enableCount;
                    }
                    sender.sendMessage(ColorUtil.parse("&fEnabled &e" + enableCount + " &farena(s)."));
                    break;
                }
                case "disable-all": {
                    int disableCount = 0;
                    for (Arena arena : ArenaManager.getAll()) {
                        if (!arena.isEnabled()) continue;
                        arena.setEnabled(false);
                        arena.setDirty(true);
                        ArenaManager.saveArena(arena);
                        ++disableCount;
                    }
                    sender.sendMessage(ColorUtil.parse("&fDisabled &e" + disableCount + " &farena(s)."));
                    break;
                }
                case "list": {
                    if (sender instanceof Player) {
                        Player player = (Player)sender;
                        ArenaListGUI.open(player);
                        break;
                    }
                    sender.sendMessage(ColorUtil.parse("&fThe arena list GUI can only be opened by a player."));
                    break;
                }
                case "editor": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea arena editor <name>"));
                        return;
                    }
                    if (!(sender instanceof Player)) {
                        sender.sendMessage(ColorUtil.parse("&fOnly players can use this."));
                        return;
                    }
                    Player player = (Player)sender;
                    Arena editArena = ArenaManager.get(args[2]);
                    if (editArena == null) {
                        sender.sendMessage(ColorUtil.parse("&fArena &e" + args[2] + " &fnot found."));
                        return;
                    }
                    ArenaEditorGUI.open(player, args[2]);
                    break;
                }
                case "give": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea arena give <name>"));
                        return;
                    }
                    Arena giveArena = ArenaManager.get(args[2]);
                    if (giveArena == null) {
                        sender.sendMessage(ColorUtil.parse("&fArena &e" + args[2] + " &fnot found."));
                        return;
                    }
                    sender.sendMessage(ColorUtil.parse("&f&m                    "));
                    String var10001 = giveArena.getName();
                    sender.sendMessage(ColorUtil.parse("  &f" + var10001 + " &8| &f" + (giveArena.isEnabled() ? "&#FB0000Enabled" : "&#FB0000Disabled")));
                    var10001 = this.formatLoc(giveArena.getSpawn1());
                    sender.sendMessage(ColorUtil.parse("  &fSpawn 1: &f" + var10001));
                    var10001 = this.formatLoc(giveArena.getSpawn2());
                    sender.sendMessage(ColorUtil.parse("  &fSpawn 2: &f" + var10001));
                    int var17 = giveArena.getRegionMinX();
                    sender.sendMessage(ColorUtil.parse("  &fRegion: &f" + var17 + "," + giveArena.getRegionMinY() + "," + giveArena.getRegionMinZ() + " &8-> &f" + giveArena.getRegionMaxX() + "," + giveArena.getRegionMaxY() + "," + giveArena.getRegionMaxZ()));
                    if (giveArena.isBorderSet()) {
                        var17 = giveArena.getBorderMinX();
                        sender.sendMessage(ColorUtil.parse("  &fBorder: &f" + var17 + "," + giveArena.getBorderMinY() + "," + giveArena.getBorderMinZ() + " &8-> &f" + giveArena.getBorderMaxX() + "," + giveArena.getBorderMaxY() + "," + giveArena.getBorderMaxZ()));
                    } else {
                        sender.sendMessage(ColorUtil.parse("  &fBorder: &7(same as region)"));
                    }
                    sender.sendMessage(ColorUtil.parse("&f&m                    "));
                    break;
                }
                default: {
                    sender.sendMessage(ColorUtil.parse("&cUsage: /lifea arena <create|delete|enable-all|disable-all|editor|list|give> [name]"));
                }
            }
        }
    }

    private String[] parseKitKey(String key) {
        int last = key.lastIndexOf(45);
        if (last == -1) {
            return null;
        }
        String tier = SUFFIX_TO_TIER.get(key.substring(last + 1));
        if (tier == null) {
            return null;
        }
        String rawGamemode = key.substring(0, last);
        return new String[]{tier, rawGamemode};
    }

    private String joinArgs(String[] args, int from, int to) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i <= to && i < args.length; ++i) {
            if (i > from) {
                sb.append(' ');
            }
            sb.append(args[i]);
        }
        return sb.toString();
    }

    private Object[] resolveKitFromArgs(String[] args, int fromIndex) {
        for (int end = args.length - 1; end >= fromIndex; --end) {
            String joined = this.joinArgs(args, fromIndex, end);
            String[] k = this.parseKitKey(joined);
            if (k == null) continue;
            return new Object[]{k[0], k[1], joined, end};
        }
        return null;
    }

    private String resolveGamemodeForTier(String tier, String input) {
        List gms = ConfigManager.kitEditor().getList("gamemodes." + tier);
        if (gms == null) {
            return null;
        }
        String normInput = this.normalizeModeName(input);
        for (Object o : gms) {
            Map m;
            Object nameObj;
            if (!(o instanceof Map) || !((nameObj = (m = (Map)o).get("name")) instanceof String)) continue;
            String display = (String)nameObj;
            String clean = this.cleanGamemodeName(display).replace(' ', '-');
            if (clean.equalsIgnoreCase(input)) {
                return clean;
            }
            if (!this.normalizeModeName(clean).equals(normInput)) continue;
            return clean;
        }
        return null;
    }

    private String cleanGamemodeName(String name) {
        return name.replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-Fk-orK-OR]", "").replaceAll("\\s*[\\(\\[\\{][^\\)\\]\\}]*\\{tier\\}[^\\)\\]\\}]*[\\)\\]\\}]\\s*", "").replace("{tier}", "").replace("{gamemode}", "").replaceAll("[()\\[\\]]", "").replaceAll("\\s+", " ").trim();
    }

    private String normalizeModeName(String value) {
        return value.toLowerCase().replaceAll("[^a-z0-9]", "");
    }

    private void handleKit(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit <list|create|delete|edit|give|editor> <Gamemode-Suffix>"));
        } else {
            switch (args[1].toLowerCase()) {
                case "list": {
                    if (sender instanceof Player) {
                        Player player = (Player)sender;
                        DuelKitDashboardGUI.open(player);
                        break;
                    }
                    sender.sendMessage(ColorUtil.parse("&fOnly players can open the duel kit dashboard."));
                    break;
                }
                case "create": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit create <Gamemode-Suffix>"));
                        return;
                    }
                    if (!(sender instanceof Player)) {
                        sender.sendMessage("Only players can use this.");
                        return;
                    }
                    Player player = (Player)sender;
                    Object[] r = this.resolveKitFromArgs(args, 2);
                    if (r == null) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid format. Use e.g. &eSword-COM"));
                        return;
                    }
                    KitManager.setBaseKit((String)r[0], (String)r[1], this.fullInventory(player));
                    sender.sendMessage(ColorUtil.parse("&aBase kit created for &e" + String.valueOf(r[2]) + "&a."));
                    break;
                }
                case "delete": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit delete <Gamemode-Suffix>"));
                        return;
                    }
                    Object[] deleteR = this.resolveKitFromArgs(args, 2);
                    if (deleteR == null) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid format. Use e.g. &eSword-COM"));
                        return;
                    }
                    KitManager.deleteBaseKit((String)deleteR[0], (String)deleteR[1]);
                    sender.sendMessage(ColorUtil.parse("&aBase kit deleted for &e" + String.valueOf(deleteR[2]) + "&a."));
                    break;
                }
                case "edit": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit edit <Gamemode-Suffix>"));
                        return;
                    }
                    if (!(sender instanceof Player)) {
                        sender.sendMessage("Only players can use this.");
                        return;
                    }
                    Player editPlayer = (Player)sender;
                    Object[] editR = this.resolveKitFromArgs(args, 2);
                    if (editR == null) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid format. Use e.g. &eSword-COM"));
                        return;
                    }
                    KitManager.setBaseKit((String)editR[0], (String)editR[1], this.fullInventory(editPlayer));
                    sender.sendMessage(ColorUtil.parse("&aBase kit updated for &e" + String.valueOf(editR[2]) + "&a."));
                    break;
                }
                case "give": {
                    Player target;
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit give <Gamemode-Suffix> [target] [source]"));
                        return;
                    }
                    Object[] giveR = this.resolveKitFromArgs(args, 2);
                    if (giveR == null) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid format. Use e.g. &eSword-COM"));
                        return;
                    }
                    int kitEndIndex = (Integer)giveR[3];
                    if (args.length >= kitEndIndex + 2) {
                        target = Bukkit.getPlayer((String)args[kitEndIndex + 1]);
                        if (target == null) {
                            sender.sendMessage(ColorUtil.parse("&cTarget player not found."));
                            return;
                        }
                    } else {
                        if (!(sender instanceof Player)) {
                            sender.sendMessage("Only players can use this without specifying a target.");
                            return;
                        }
                        target = (Player)sender;
                    }
                    if (args.length >= kitEndIndex + 3) {
                        Player source = Bukkit.getPlayer((String)args[kitEndIndex + 2]);
                        if (source == null) {
                            sender.sendMessage(ColorUtil.parse("&cSource player not found."));
                            return;
                        }
                        KitManager.applySpecificPlayerKit(target, source.getUniqueId(), (String)giveR[0], (String)giveR[1]);
                        String var10001 = source.getName();
                        sender.sendMessage(ColorUtil.parse("&aApplied &e" + var10001 + "'s &akit &e" + String.valueOf(giveR[2]) + " &ato &e" + target.getName() + "&a."));
                        if (target.equals((Object)sender)) break;
                        var10001 = source.getName();
                        target.sendMessage(ColorUtil.parse("&aYou received &e" + var10001 + "'s &akit &e" + String.valueOf(giveR[2]) + "&a."));
                        break;
                    }
                    KitManager.applyKit(target, (String)giveR[0], (String)giveR[1]);
                    String var17 = String.valueOf(giveR[2]);
                    sender.sendMessage(ColorUtil.parse("&aApplied kit &e" + var17 + " &ato &e" + target.getName() + "&a."));
                    if (target.equals((Object)sender)) break;
                    target.sendMessage(ColorUtil.parse("&aYou received kit &e" + String.valueOf(giveR[2]) + "&a."));
                    break;
                }
                case "editor": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit editor <Gamemode-Suffix>"));
                        return;
                    }
                    if (!(sender instanceof Player)) {
                        sender.sendMessage("Only players can use this.");
                        return;
                    }
                    Player editorPlayer = (Player)sender;
                    Object[] editorR = this.resolveKitFromArgs(args, 2);
                    if (editorR == null) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid format. Use e.g. &eSword-COM"));
                        return;
                    }
                    KitSettingsGUI.open(editorPlayer, (String)editorR[2]);
                    break;
                }
                case "whitelist-block": {
                    this.handleKitWhitelistBlock(sender, args);
                    break;
                }
                default: {
                    sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit <list|create|delete|edit|give|editor|whitelist-block> <Gamemode-Suffix>"));
                }
            }
        }
    }

    private void handleKitWhitelistBlock(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit whitelist-block <add|remove|list> <Gamemode-Suffix> [BLOCK...]"));
        } else {
            String sub = args[2].toLowerCase();
            if (!sub.equals("list")) {
                if (!sub.equals("add") && !sub.equals("remove")) {
                    sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit whitelist-block <add|remove|list> <Gamemode-Suffix> [BLOCK...]"));
                } else if (args.length < 5) {
                    sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit whitelist-block " + sub + " <Gamemode-Suffix> <BLOCK...>"));
                } else {
                    Object[] r = this.resolveKitFromArgs(args, 3);
                    if (r == null) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid kit format. Use e.g. &eSword-COM"));
                    } else {
                        String kitKey = (String)r[2];
                        int blockStart = (Integer)r[3] + 1;
                        if (blockStart >= args.length) {
                            sender.sendMessage(ColorUtil.parse("&cProvide at least one block material."));
                        } else {
                            ArrayList<String> added = new ArrayList<String>();
                            ArrayList<String> invalid = new ArrayList<String>();
                            for (int i = blockStart; i < args.length; ++i) {
                                String name = args[i].toUpperCase();
                                if (Material.getMaterial((String)name) == null) {
                                    invalid.add(args[i]);
                                    continue;
                                }
                                if (sub.equals("add")) {
                                    DatabaseManager.addKitBlockWhitelist(kitKey, name);
                                } else {
                                    DatabaseManager.removeKitBlockWhitelist(kitKey, name);
                                }
                                added.add(name);
                            }
                            KitRuleManager.invalidate(kitKey);
                            if (!added.isEmpty()) {
                                String verb = sub.equals("add") ? "&aAdded" : "&aRemoved";
                                String prep = sub.equals("add") ? "&ato" : "&afrom";
                                sender.sendMessage(ColorUtil.parse(verb + " &e" + String.join((CharSequence)"&f, &e", added) + " " + prep + " whitelist for &e" + kitKey + "&a."));
                            }
                            if (!invalid.isEmpty()) {
                                sender.sendMessage(ColorUtil.parse("&cUnknown material(s): &e" + String.join((CharSequence)"&f, &e", invalid)));
                            }
                        }
                    }
                }
            } else if (args.length < 4) {
                sender.sendMessage(ColorUtil.parse("&cUsage: /lifea kit whitelist-block list <Gamemode-Suffix>"));
            } else {
                Object[] r = this.resolveKitFromArgs(args, 3);
                if (r == null) {
                    sender.sendMessage(ColorUtil.parse("&cInvalid kit format. Use e.g. &eSword-COM"));
                } else {
                    String kitKey = (String)r[2];
                    Set<String> blocks = DatabaseManager.getKitBlockWhitelist(kitKey);
                    sender.sendMessage(ColorUtil.parse("&8&m                    "));
                    sender.sendMessage(ColorUtil.parse("  &6Block Whitelist for &e" + kitKey));
                    if (blocks.isEmpty()) {
                        sender.sendMessage(ColorUtil.parse("  &fNone. &8(all blocks breakable by explosions/players)"));
                    } else {
                        for (String b : blocks) {
                            sender.sendMessage(ColorUtil.parse("  &e" + b));
                        }
                    }
                    sender.sendMessage(ColorUtil.parse("&8&m                    "));
                }
            }
        }
    }

    private void handleSpawnItems(CommandSender sender, String[] args) {
        if (args.length >= 3 && args[1].equalsIgnoreCase("give")) {
            Player target = Bukkit.getPlayer((String)args[2]);
            if (target == null) {
                sender.sendMessage(ColorUtil.parse("&cPlayer not found."));
            } else if (HotbarManager.shouldHaveLobbyItems(target)) {
                HotbarManager.give(target, HotbarManager.HotbarType.SPAWN);
                sender.sendMessage(ColorUtil.parse("&aGave spawn items to &e" + target.getName() + "&a."));
                target.sendMessage(ColorUtil.parse("&aYour spawn items have been restored."));
            } else {
                sender.sendMessage(ColorUtil.parse("&cThat player is currently in a match or spectating."));
            }
        } else {
            sender.sendMessage(ColorUtil.parse("&cUsage: /lifea spawnitems give <player>"));
        }
    }

    private void handlePotion(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&cUsage: /lifea potion <add|remove|list> <gamemode>"));
        } else {
            switch (args[1].toLowerCase()) {
                case "add": {
                    int duration;
                    int amp;
                    if (args.length < 6) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea potion add <gamemode> <effect> <amplifier> <duration>"));
                        sender.sendMessage(ColorUtil.parse("&fExample: &e/lifea potion add Sword-COM SPEED 2 60"));
                        sender.sendMessage(ColorUtil.parse("&fAmplifier: &e1, 2, 3, 4"));
                        sender.sendMessage(ColorUtil.parse("&fDuration: &eseconds &f(use &e-1 &ffor infinite)"));
                        return;
                    }
                    String key = args[2];
                    if (!PotionManager.isValidKey(key)) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid gamemode key. Use format like &eSword-COM&c, &eSword-IO&c, &eDiaSMP-Sub&c, &eBeast-Cactus&c."));
                        return;
                    }
                    PotionEffectType type = PotionEffectType.getByName((String)args[3].toUpperCase());
                    if (type == null) {
                        sender.sendMessage(ColorUtil.parse("&cUnknown potion effect: &e" + args[3]));
                        return;
                    }
                    try {
                        amp = Integer.parseInt(args[4]);
                    }
                    catch (NumberFormatException var191) {
                        sender.sendMessage(ColorUtil.parse("&cAmplifier must be a number (1-4)."));
                        return;
                    }
                    if (amp < 1 || amp > 4) {
                        sender.sendMessage(ColorUtil.parse("&cAmplifier must be between &e1 &cand &e4&c."));
                        return;
                    }
                    try {
                        duration = Integer.parseInt(args[5]);
                    }
                    catch (NumberFormatException var18) {
                        sender.sendMessage(ColorUtil.parse("&cDuration must be a number (seconds, or -1 for infinite)."));
                        return;
                    }
                    PotionManager.addPotion(key, type, amp, duration);
                    Object durStr = duration <= 0 ? "Infinite" : duration + "s";
                    sender.sendMessage(ColorUtil.parse("&aAdded &e" + type.getName() + " &f(Level &e" + amp + "&f, Duration &e" + (String)durStr + "&f) &ato &e" + key + "&a."));
                    break;
                }
                case "remove": {
                    if (args.length < 4) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea potion remove <gamemode> <potion>"));
                        return;
                    }
                    String removeKey = args[2];
                    if (!PotionManager.isValidKey(removeKey)) {
                        sender.sendMessage(ColorUtil.parse("&cInvalid gamemode key."));
                        return;
                    }
                    PotionEffectType removeType = PotionEffectType.getByName((String)args[3].toUpperCase());
                    if (removeType == null) {
                        sender.sendMessage(ColorUtil.parse("&cUnknown potion effect: &e" + args[3]));
                        return;
                    }
                    if (PotionManager.removePotion(removeKey, removeType)) {
                        String var19 = removeType.getName();
                        sender.sendMessage(ColorUtil.parse("&aRemoved &e" + var19 + " &afrom &e" + removeKey + "&a."));
                        break;
                    }
                    String var20 = removeType.getName();
                    sender.sendMessage(ColorUtil.parse("&cNo &e" + var20 + " &cfound on &e" + removeKey + "&c."));
                    break;
                }
                case "list": {
                    if (args.length < 3) {
                        sender.sendMessage(ColorUtil.parse("&cUsage: /lifea potion list <gamemode>"));
                        return;
                    }
                    String listKey = args[2];
                    List<PotionManager.GamemodePotion> list = PotionManager.getPotions(listKey);
                    sender.sendMessage(ColorUtil.parse("&8&m                    "));
                    sender.sendMessage(ColorUtil.parse("  &6Potions for &e" + listKey));
                    if (list.isEmpty()) {
                        sender.sendMessage(ColorUtil.parse("  &fNone."));
                    } else {
                        for (PotionManager.GamemodePotion gp : list) {
                            String listDurStr = gp.duration() <= 0 ? "Infinite" : gp.duration() + "s";
                            String var10001 = gp.type().getName();
                            sender.sendMessage(ColorUtil.parse("  &e" + var10001 + " &fLevel &e" + (gp.amplifier() + 1) + " &fDuration &e" + listDurStr));
                        }
                    }
                    sender.sendMessage(ColorUtil.parse("&8&m                    "));
                    break;
                }
                default: {
                    sender.sendMessage(ColorUtil.parse("&cUsage: /lifea potion <add|remove|list> <gamemode>"));
                }
            }
        }
    }

    private String formatLoc(Location loc) {
        if (loc == null) {
            return "&cNot set";
        }
        String var10000 = loc.getWorld().getName();
        return "&e" + var10000 + " &f" + (int)loc.getX() + "," + (int)loc.getY() + "," + (int)loc.getZ();
    }

    private ItemStack[] fullInventory(Player player) {
        ItemStack[] contents = player.getInventory().getStorageContents();
        ItemStack[] armor = player.getInventory().getArmorContents();
        ItemStack[] full = new ItemStack[41];
        for (int i = 0; i < 36; ++i) {
            full[i] = contents[i];
        }
        full[36] = armor[3];
        full[37] = armor[2];
        full[38] = armor[1];
        full[39] = armor[0];
        full[40] = player.getInventory().getItemInOffHand();
        return full;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("lifea.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            return this.filter(List.of("reload", "setlobby", "setqueue", "reset", "arena", "kit", "spawnitems", "potion", "auto-clone", "tpclone"), args[0]);
        }
        return switch (args[0].toLowerCase()) {
            case "reload" -> {
                if (args.length == 2) {
                    File[] files = Lifea.getInstance().getDataFolder().listFiles(fx -> fx.isFile() && fx.getName().endsWith(".yml"));
                    ArrayList<String> fileNames = new ArrayList<String>();
                    if (files != null) {
                        for (File f : files) {
                            fileNames.add(f.getName());
                        }
                    }
                    yield this.filter(fileNames, args[1]);
                }
                yield List.of();
            }
            case "setqueue" -> args.length == 2 ? this.filter(List.of("main"), args[1]) : List.of();
            case "reset" -> {
                if (args.length == 2) {
                    yield this.filter(List.of("all", "stats", "kiteditor"), args[1]);
                }
                if (args.length == 3 && args[1].equalsIgnoreCase("stats")) {
                    yield this.filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), args[2]);
                }
                yield List.of();
            }
            case "arena" -> args.length == 2 ? this.filter(List.of("create", "delete", "enable-all", "disable-all", "editor", "list", "give"), args[1]) : (args.length == 3 && (args[1].equalsIgnoreCase("delete") || args[1].equalsIgnoreCase("editor") || args[1].equalsIgnoreCase("give")) ? this.filter(ArenaManager.getAll().stream().map(Arena::getName).collect(Collectors.toList()), args[2]) : List.of());
            case "kit" -> {
                if (args.length == 2) {
                    yield this.filter(List.of("list", "create", "delete", "edit", "give", "editor", "whitelist-block"), args[1]);
                }
                if (args.length == 3 && args[1].equalsIgnoreCase("whitelist-block")) {
                    yield this.filter(List.of("add", "remove", "list"), args[2]);
                }
                if (args.length == 3 && !args[1].equalsIgnoreCase("whitelist-block") || args.length == 4 && args[1].equalsIgnoreCase("whitelist-block")) {
                    int keyArgIndex = args[1].equalsIgnoreCase("whitelist-block") ? 3 : 2;
                    ArrayList<String> keys = new ArrayList<String>();
                    Map<String, String> tierSuffix = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus", "Extra", "Extra");
                    for (Map.Entry<String, String> ts : tierSuffix.entrySet()) {
                        List gms = ConfigManager.kitEditor().getList("gamemodes." + ts.getKey());
                        if (gms == null) continue;
                        for (Object o : gms) {
                            Map m;
                            String n;
                            if (!(o instanceof Map) || (n = (String)(m = (Map)o).get("name")) == null) continue;
                            String clean = n.replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fA-FklmnorKLMNOR]", "").replaceAll("\\s*[\\(\\[\\{][^\\)\\]\\}]*\\{tier\\}[^\\)\\]\\}]*[\\)\\]\\}]\\s*", "").replace("{tier}", "").replace("{gamemode}", "").replaceAll("[()\\[\\]]", "").replaceAll("\\s+", " ").trim();
                            String var10001 = clean.replace(' ', '-');
                            keys.add(var10001 + "-" + ts.getValue());
                        }
                    }
                    yield this.filter(keys, args[keyArgIndex]);
                }
                if (args.length < 5 || !args[1].equalsIgnoreCase("whitelist-block") || !args[2].equalsIgnoreCase("add") && !args[2].equalsIgnoreCase("remove")) {
                    yield args.length == 4 && args[1].equalsIgnoreCase("give") ? Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(nx -> nx.toLowerCase().startsWith(args[3].toLowerCase())).collect(Collectors.toList()) : (args.length == 5 && args[1].equalsIgnoreCase("give") ? Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(nx -> nx.toLowerCase().startsWith(args[4].toLowerCase())).collect(Collectors.toList()) : List.of());
                }
                String partial = args[args.length - 1].toUpperCase();
                yield Arrays.stream(Material.values()).filter(mx -> mx.isBlock() && mx.name().startsWith(partial)).map(Enum::name).collect(Collectors.toList());
            }
            case "spawnitems" -> args.length == 2 ? this.filter(List.of("give"), args[1]) : (args.length == 3 ? Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(nx -> nx.toLowerCase().startsWith(args[2].toLowerCase())).collect(Collectors.toList()) : List.of());
            case "potion" -> args.length == 2 ? this.filter(List.of("add", "remove", "list"), args[1]) : (args.length == 3 ? this.filter(PotionManager.getAllPossibleKeys(), args[2]) : (args.length != 4 || !args[1].equalsIgnoreCase("add") && !args[1].equalsIgnoreCase("remove") ? (args.length == 5 && args[1].equalsIgnoreCase("add") ? this.filter(List.of("1", "2", "3", "4"), args[4]) : (args.length == 6 && args[1].equalsIgnoreCase("add") ? this.filter(List.of("-1", "30", "60", "120", "300"), args[5]) : List.of())) : Arrays.stream(PotionEffectType.values()).map(t -> t.getName().toUpperCase()).filter(nx -> nx.startsWith(args[3].toUpperCase())).collect(Collectors.toList())));
            case "auto-clone", "tpclone" -> args.length == 2 ? this.filter(ArenaManager.getAll().stream().map(Arena::getName).collect(Collectors.toList()), args[1]) : List.of();
            default -> List.of();
        };
    }

    private List<String> filter(List<String> list, String input) {
        return list.stream().filter(s -> s.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }

    private void handleAutoClone(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea auto-clone <arena> [maxClones]"));
        } else {
            int max = 20;
            if (args.length >= 3) {
                try {
                    max = Integer.parseInt(args[2]);
                }
                catch (NumberFormatException var5) {
                    sender.sendMessage(ColorUtil.parse("&cmaxClones must be a number."));
                    return;
                }
            }
            ArenaCloner.autoClone(sender, args[1], max);
        }
    }

    private void handleTpClone(CommandSender sender, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length < 2) {
                sender.sendMessage(ColorUtil.parse("&fUsage: &e/lifea tpclone <arena>"));
            } else {
                Arena arena = ArenaManager.get(args[1]);
                if (arena != null && arena.getSpawn1() != null) {
                    player.teleport(arena.getSpawn1());
                    player.sendMessage(ColorUtil.parse("&fTeleported to &e" + arena.getName() + "&f."));
                } else {
                    sender.sendMessage(ColorUtil.parse("&cArena &e" + args[1] + "&c not found or has no spawn."));
                }
            }
        } else {
            sender.sendMessage(ColorUtil.parse("&fOnly players can teleport."));
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ColorUtil.parse("&8&m                    "));
        sender.sendMessage(ColorUtil.parse("  &6Lifea Admin Commands"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea reload [file] &f- Reload configs"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea setlobby &f- Set the lobby spawn"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea setqueue &f- Set a queue sign"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea reset <all|kiteditor> &f- Reset data"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea arena <create|delete|enable-all|disable-all|editor|give> &f- Manage arenas"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea kit <create|delete|edit|give|editor> &f- Manage kits"));
        sender.sendMessage(ColorUtil.parse("    &fgive: &e/lifea kit give <kit> [target] [source]"));
        sender.sendMessage(ColorUtil.parse("    &fwhitelist-block: &e/lifea kit whitelist-block <add|remove|list> <kit> [BLOCK...]"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea auto-clone <arena> [maxClones] &f- Clone an arena into empty space"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea spawnitems give <player> &f- Give spawn items"));
        sender.sendMessage(ColorUtil.parse("  &e/lifea potion <add|remove|list> <gamemode> &f- Manage gamemode potions"));
        sender.sendMessage(ColorUtil.parse("&8&m                    "));
    }
}

