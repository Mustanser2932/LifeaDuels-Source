/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 */
package me.lifea.command;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import me.lifea.config.ConfigManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.util.ColorUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class CommandRestrictionListener
implements Listener {
    private static final Set<String> restrictedCommandsCache = new HashSet<String>();
    private static final Set<String> blockedStatesCache = new HashSet<String>();
    private static boolean isEnabled = false;
    private static String restrictionMessage = "";
    private static String bypassPermission = "";

    public CommandRestrictionListener() {
        CommandRestrictionListener.loadConfiguration();
    }

    private static void loadConfiguration() {
        FileConfiguration config = ConfigManager.config();
        isEnabled = config.getBoolean("restricted-commands.enabled", true);
        bypassPermission = config.getString("restricted-commands.ignore-permission", "lifea.commandbypass");
        restrictionMessage = config.getString("restricted-commands.message", "&cYou cannot use this command right now.");
        restrictedCommandsCache.clear();
        blockedStatesCache.clear();
        if (isEnabled) {
            for (String cmd : config.getStringList("restricted-commands.commands")) {
                restrictedCommandsCache.add(cmd.toLowerCase());
            }
            for (String state : config.getStringList("restricted-commands.blocked-states")) {
                blockedStatesCache.add(state.toUpperCase());
            }
        }
    }

    @EventHandler
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission(bypassPermission) && !player.isOp()) {
            PlayerStateManager.PlayerState state;
            String normalizedCommand;
            List<String> blacklistedWorlds = ConfigManager.blacklistedWorlds();
            if (!blacklistedWorlds.isEmpty() && blacklistedWorlds.stream().anyMatch(w -> w.equalsIgnoreCase(player.getWorld().getName()))) {
                String normalizedCommand2 = this.normalizeCommand(event.getMessage());
                if (this.isPluginCommand(normalizedCommand2)) {
                    event.setCancelled(true);
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("queue.blacklisted-world")));
                }
            } else if (isEnabled && restrictedCommandsCache.contains(normalizedCommand = this.normalizeCommand(event.getMessage())) && !this.isPluginCommand(normalizedCommand) && blockedStatesCache.contains((state = PlayerStateManager.getState(player)).name())) {
                event.setCancelled(true);
                player.sendMessage(ColorUtil.parse(restrictionMessage));
            }
        }
    }

    private String normalizeCommand(String rawCommand) {
        String cmd = rawCommand.startsWith("/") ? rawCommand.substring(1) : rawCommand;
        cmd = cmd.toLowerCase();
        String[] parts = cmd.split("\\s+");
        if ((cmd = parts[0]).contains(":")) {
            cmd = cmd.split(":")[1];
        }
        return cmd;
    }

    private boolean isPluginCommand(String command) {
        return switch (command) {
            case "duel", "1v1", "party", "queue", "kiteditor", "editor", "kitedit", "lifea", "stats", "settings", "importkit", "leave", "message", "msg", "msgtoggle", "r", "reply", "fly", "flyspeed", "spectate", "duels", "duelaccept", "dueldeny", "resetkit", "ffa-kit", "trim", "banners", "banner" -> true;
            default -> false;
        };
    }

    public static void reloadConfig() {
        CommandRestrictionListener.loadConfiguration();
    }
}

