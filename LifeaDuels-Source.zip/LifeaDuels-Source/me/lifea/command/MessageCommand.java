/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import me.lifea.config.ConfigManager;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class MessageCommand
implements CommandExecutor,
TabCompleter {
    private static final Map<UUID, UUID> replyTo = new ConcurrentHashMap<UUID, UUID>();

    public static void setReplyTarget(UUID sender, UUID target) {
        replyTo.put(sender, target);
    }

    public static void clearReplyTarget(UUID uuid) {
        replyTo.entrySet().removeIf(entry -> ((UUID)entry.getKey()).equals(uuid) || ((UUID)entry.getValue()).equals(uuid));
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("msgtoggle")) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                boolean target = PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.PRIVATE_MESSAGES);
                PlayerSettingsManager.set(player.getUniqueId(), PlayerSettingsManager.Setting.PRIVATE_MESSAGES, !target);
                player.sendMessage(ColorUtil.parse(ConfigManager.msg(!target ? "settings.messages-toggled-on" : "settings.messages-toggled-off")));
                return true;
            }
            sender.sendMessage(ColorUtil.parse("&cOnly players can use this."));
            return true;
        }
        if (!label.equalsIgnoreCase("r") && !label.equalsIgnoreCase("reply")) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                if (args.length < 2) {
                    player.sendMessage(ColorUtil.parse("&cUsage: /" + label + " <player> <message>"));
                    return true;
                }
                Player target = Bukkit.getPlayer((String)args[0]);
                if (target != null && target.isOnline()) {
                    if (target.equals((Object)player)) {
                        player.sendMessage(ColorUtil.parse("&fYou cannot message yourself."));
                        return true;
                    }
                    if (!PlayerSettingsManager.get(target.getUniqueId(), PlayerSettingsManager.Setting.PRIVATE_MESSAGES)) {
                        player.sendMessage(ColorUtil.parse(ConfigManager.msg("settings.private-messages-disabled").replace("%player%", target.getName())));
                        return true;
                    }
                    StringBuilder sb = new StringBuilder();
                    for (int i = 1; i < args.length; ++i) {
                        if (i > 1) {
                            sb.append(" ");
                        }
                        sb.append(args[i]);
                    }
                    String message = sb.toString();
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("message.outgoing").replace("%player%", target.getName()).replace("%message%", message)));
                    target.sendMessage(ColorUtil.parse(ConfigManager.msg("message.incoming").replace("%player%", player.getName()).replace("%message%", message)));
                    SoundUtil.play(target, "private-message");
                    replyTo.put(target.getUniqueId(), player.getUniqueId());
                    replyTo.put(player.getUniqueId(), target.getUniqueId());
                    return true;
                }
                player.sendMessage(ColorUtil.parse("&cPlayer &e" + args[0] + " &cnot found."));
                return true;
            }
            sender.sendMessage(ColorUtil.parse("&cOnly players can use this."));
            return true;
        }
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length < 1) {
                player.sendMessage(ColorUtil.parse("&cUsage: /" + label + " <message>"));
                return true;
            }
            UUID targetUUID = replyTo.get(player.getUniqueId());
            if (targetUUID == null) {
                player.sendMessage(ColorUtil.parse("&cYou have no one to reply to."));
                return true;
            }
            Player target = Bukkit.getPlayer((UUID)targetUUID);
            if (target != null && target.isOnline()) {
                if (!PlayerSettingsManager.get(target.getUniqueId(), PlayerSettingsManager.Setting.PRIVATE_MESSAGES)) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("settings.private-messages-disabled").replace("%player%", target.getName())));
                    return true;
                }
                String message = String.join((CharSequence)" ", args);
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("message.outgoing").replace("%player%", target.getName()).replace("%message%", message)));
                target.sendMessage(ColorUtil.parse(ConfigManager.msg("message.incoming").replace("%player%", player.getName()).replace("%message%", message)));
                SoundUtil.play(target, "private-message");
                replyTo.put(target.getUniqueId(), player.getUniqueId());
                replyTo.put(player.getUniqueId(), target.getUniqueId());
                return true;
            }
            player.sendMessage(ColorUtil.parse("&cThat player is no longer online."));
            return true;
        }
        sender.sendMessage(ColorUtil.parse("&cOnly players can use this."));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        return args.length == 1 ? Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList()) : List.of();
    }
}

