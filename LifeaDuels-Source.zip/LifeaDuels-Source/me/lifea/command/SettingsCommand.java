/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.viaversion.viaversion.api.Via
 *  com.viaversion.viaversion.api.protocol.version.ProtocolVersion
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  org.bukkit.Material
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 */
package me.lifea.command;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.lifea.command.SettingsDialogHelper;
import me.lifea.config.ConfigManager;
import me.lifea.duel.KitRulesListener;
import me.lifea.gui.GUIManager;
import me.lifea.libs.triumphgui.builder.gui.ChestGuiBuilder;
import me.lifea.libs.triumphgui.builder.item.ItemBuilder;
import me.lifea.libs.triumphgui.guis.Gui;
import me.lifea.libs.triumphgui.guis.GuiItem;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spawn.SpawnElytraManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.NametagManager;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;

public class SettingsCommand
implements CommandExecutor {
    private static final Map<UUID, Long> TOGGLE_COOLDOWNS = new HashMap<UUID, Long>();
    private static final long COOLDOWN_MS = 3000L;
    static final List<SettingEntry> SETTINGS = List.of(new SettingEntry("Duel Requests", PlayerSettingsManager.Setting.DUEL_REQUESTS, "duel-requests"), new SettingEntry("Scoreboard", PlayerSettingsManager.Setting.SCOREBOARD, "scoreboard"), new SettingEntry("Auto GG", PlayerSettingsManager.Setting.AUTO_GG, "auto-gg"), new SettingEntry("Private Messages", PlayerSettingsManager.Setting.PRIVATE_MESSAGES, "private-messages"), new SettingEntry("Chat Mentions", PlayerSettingsManager.Setting.CHAT_MENTIONS, "chat-mentions"), new SettingEntry("Party Invites", PlayerSettingsManager.Setting.PARTY_INVITES, "party-invites"), new SettingEntry("Health Indicator", PlayerSettingsManager.Setting.HEALTH_INDICATOR, "health-indicator"), new SettingEntry("Elytra", PlayerSettingsManager.Setting.ELYTRA, "elytra"), new SettingEntry("Chat Isolation", PlayerSettingsManager.Setting.CHAT_ISOLATION, "chat-isolation"), new SettingEntry("Quick Queue", null, "quick-queue"), new SettingEntry("Time of Day", null, "time-of-day"), new SettingEntry("Ping Range", null, "ping-range"), new SettingEntry("Ping Display", PlayerSettingsManager.Setting.PING_DISPLAY, "ping-display"));
    private static final int[] FILLER_SLOTS = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35};

    public static void clearCooldown(UUID uuid) {
        TOGGLE_COOLDOWNS.remove(uuid);
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 2 && args[0].equalsIgnoreCase("pingrange")) {
                PlayerSettingsManager.setPingRange(player, PlayerSettingsManager.PingRange.fromKey(args[1]));
                SettingsCommand.open(player);
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("pingrange-menu")) {
                if (SettingsCommand.supportsDialog(player)) {
                    SettingsDialogHelper.openPingRangeMenu(player);
                } else {
                    SettingsCommand.openPingRangeLegacy(player);
                }
                return true;
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("time")) {
                PlayerSettingsManager.TimeOfDay selected = PlayerSettingsManager.TimeOfDay.fromKey(args[1]);
                PlayerSettingsManager.setTimeOfDay(player, selected);
                SettingsCommand.open(player);
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("time-menu")) {
                if (SettingsCommand.supportsDialog(player)) {
                    SettingsDialogHelper.openTimeMenu(player);
                } else {
                    SettingsCommand.openTimeLegacy(player);
                }
                return true;
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("toggle")) {
                SettingsCommand.handleToggle(player, args[1]);
                SettingsCommand.open(player);
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("quickqueue")) {
                SettingsDialogHelper.close(player);
                GUIManager.openQuickQueueSettings(player);
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("close")) {
                SettingsDialogHelper.close(player);
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("noop")) {
                SettingsCommand.open(player);
                return true;
            }
            SettingsCommand.open(player);
            return true;
        }
        sender.sendMessage(ColorUtil.parse("&cOnly players can use this."));
        return true;
    }

    private static void handleToggle(Player player, String key) {
        long last;
        long now = System.currentTimeMillis();
        if (now - (last = TOGGLE_COOLDOWNS.getOrDefault(player.getUniqueId(), 0L).longValue()) < 3000L) {
            long remaining = (3000L - (now - last) + 999L) / 1000L;
            player.sendMessage(ColorUtil.parse("&cPlease wait &f" + remaining + "s &cbefore toggling again."));
            SettingsCommand.open(player);
        } else {
            TOGGLE_COOLDOWNS.put(player.getUniqueId(), now);
            for (SettingEntry entry : SETTINGS) {
                if (!entry.key().equals(key)) continue;
                boolean next = !PlayerSettingsManager.get(player.getUniqueId(), entry.setting());
                PlayerSettingsManager.set(player.getUniqueId(), entry.setting(), next);
                if (entry.setting() == PlayerSettingsManager.Setting.SCOREBOARD) {
                    if (next) {
                        ScoreboardManager.create(player);
                    } else {
                        ScoreboardManager.remove(player);
                    }
                }
                if (entry.setting() == PlayerSettingsManager.Setting.HEALTH_INDICATOR) {
                    if (next) {
                        KitRulesListener.refreshHealthIndicatorsFor(player);
                    } else {
                        KitRulesListener.removeHealthIndicator(player);
                    }
                }
                if (entry.setting() == PlayerSettingsManager.Setting.PING_DISPLAY) {
                    NametagManager.refreshAll();
                }
                return;
            }
        }
    }

    private static boolean supportsDialog(Player player) {
        if (!player.getServer().getPluginManager().isPluginEnabled("ViaVersion")) {
            return true;
        }
        ProtocolVersion clientVersion = Via.getAPI().getPlayerProtocolVersion(player.getUniqueId());
        return clientVersion.newerThanOrEqualTo(ProtocolVersion.v1_21_5);
    }

    public static void open(Player player) {
        if (!SettingsCommand.supportsDialog(player)) {
            SettingsCommand.openLegacy(player);
        } else {
            SettingsDialogHelper.open(player, SETTINGS);
        }
    }

    static void openLegacy(Player player) {
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("Settings"))).rows(4)).disableAllInteractions()).create();
        GuiItem filler = ((ItemBuilder)ItemBuilder.from(Material.GRAY_STAINED_GLASS_PANE).name((Component)Component.empty())).asGuiItem();
        for (int slot : FILLER_SLOTS) {
            gui.setItem(slot, filler);
        }
        gui.setItem(10, SettingsCommand.legacySettingItem(player, Material.BOOK, "Duel Requests", PlayerSettingsManager.Setting.DUEL_REQUESTS, "duel-requests"));
        gui.setItem(11, SettingsCommand.legacySettingItem(player, Material.CLOCK, "Scoreboard", PlayerSettingsManager.Setting.SCOREBOARD, "scoreboard"));
        gui.setItem(12, SettingsCommand.legacySettingItem(player, Material.REDSTONE, "Auto GG", PlayerSettingsManager.Setting.AUTO_GG, "auto-gg"));
        gui.setItem(13, SettingsCommand.legacySettingItem(player, Material.CAKE, "Private Messages", PlayerSettingsManager.Setting.PRIVATE_MESSAGES, "private-messages"));
        gui.setItem(14, SettingsCommand.legacySettingItem(player, Material.BELL, "Chat Mentions", PlayerSettingsManager.Setting.CHAT_MENTIONS, "chat-mentions"));
        gui.setItem(15, SettingsCommand.legacySettingItem(player, Material.PLAYER_HEAD, "Party Invites", PlayerSettingsManager.Setting.PARTY_INVITES, "party-invites"));
        gui.setItem(16, SettingsCommand.legacySettingItem(player, Material.IRON_BARS, "Chat Isolation", PlayerSettingsManager.Setting.CHAT_ISOLATION, "chat-isolation"));
        gui.setItem(20, SettingsCommand.legacySettingItem(player, Material.HEART_OF_THE_SEA, "Health Indicator", PlayerSettingsManager.Setting.HEALTH_INDICATOR, "health-indicator"));
        gui.setItem(21, SettingsCommand.elytraLegacyItem(player));
        gui.setItem(22, SettingsCommand.quickQueueItem(player));
        gui.setItem(23, SettingsCommand.timeOfDayLegacyItem(player));
        gui.setItem(24, SettingsCommand.pingRangeLegacyItem(player));
        gui.setItem(25, SettingsCommand.legacySettingItem(player, Material.LIGHTNING_ROD, "Ping Display", PlayerSettingsManager.Setting.PING_DISPLAY, "ping-display"));
        gui.open((HumanEntity)player);
    }

    private static GuiItem timeOfDayLegacyItem(Player player) {
        PlayerSettingsManager.TimeOfDay current = PlayerSettingsManager.getTimeOfDay(player.getUniqueId());
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.CLOCK).name(SettingsCommand.noItalic("&eTime of Day: &f" + current.displayName()))).lore(List.of(SettingsCommand.noItalic("&7Click to choose your personal time.")))).flags(ItemFlag.values())).asGuiItem(e -> SettingsCommand.openTimeLegacy(player));
    }

    private static void openTimeLegacy(Player player) {
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("Time of Day"))).rows(3)).disableAllInteractions()).create();
        PlayerSettingsManager.TimeOfDay current = PlayerSettingsManager.getTimeOfDay(player.getUniqueId());
        int[] slots = new int[]{10, 11, 12, 13, 14};
        PlayerSettingsManager.TimeOfDay[] options = PlayerSettingsManager.TimeOfDay.values();
        for (int i = 0; i < options.length; ++i) {
            PlayerSettingsManager.TimeOfDay option = options[i];
            String selected = option == current ? " &a\u2714" : "";
            Material material = switch (option) {
                default -> throw new MatchException(null, null);
                case PlayerSettingsManager.TimeOfDay.DEFAULT -> Material.CLOCK;
                case PlayerSettingsManager.TimeOfDay.DAYTIME -> Material.SUNFLOWER;
                case PlayerSettingsManager.TimeOfDay.DUSK -> Material.ORANGE_DYE;
                case PlayerSettingsManager.TimeOfDay.NIGHT_TIME -> Material.ENDER_EYE;
                case PlayerSettingsManager.TimeOfDay.SUNRISE -> Material.LIGHT;
            };
            gui.setItem(slots[i], ((ItemBuilder)((ItemBuilder)ItemBuilder.from(material).name(SettingsCommand.noItalic("&f" + option.displayName() + selected))).flags(ItemFlag.values())).asGuiItem(e -> {
                PlayerSettingsManager.setTimeOfDay(player, option);
                SoundUtil.playClick(player);
                SettingsCommand.openLegacy(player);
            }));
        }
        gui.setItem(22, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(SettingsCommand.noItalic("&fBack to Settings"))).flags(ItemFlag.values())).asGuiItem(e -> SettingsCommand.openLegacy(player)));
        gui.open((HumanEntity)player);
    }

    private static GuiItem pingRangeLegacyItem(Player player) {
        PlayerSettingsManager.PingRange current = PlayerSettingsManager.getPingRange(player.getUniqueId());
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.COMPASS).name(SettingsCommand.noItalic("&ePing Range: &f" + current.displayName()))).lore(List.of(SettingsCommand.noItalic("&7Choose acceptable opponent ping.")))).flags(ItemFlag.values())).asGuiItem(e -> SettingsCommand.openPingRangeLegacy(player));
    }

    private static void openPingRangeLegacy(Player player) {
        Gui gui = ((ChestGuiBuilder)((ChestGuiBuilder)((ChestGuiBuilder)Gui.gui().title(ColorUtil.parse("Ping Range"))).rows(3)).disableAllInteractions()).create();
        PlayerSettingsManager.PingRange current = PlayerSettingsManager.getPingRange(player.getUniqueId());
        PlayerSettingsManager.PingRange[] options = PlayerSettingsManager.PingRange.values();
        Material[] icons = new Material[]{Material.COPPER_INGOT, Material.IRON_INGOT, Material.GOLD_INGOT, Material.DIAMOND, Material.NETHER_STAR};
        for (int i = 0; i < options.length; ++i) {
            PlayerSettingsManager.PingRange option = options[i];
            String selected = option == current ? " &a\u2714" : "";
            gui.setItem(10 + i, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(icons[i]).name(SettingsCommand.noItalic("&f" + option.displayName() + selected))).flags(ItemFlag.values())).asGuiItem(e -> {
                PlayerSettingsManager.setPingRange(player, option);
                SoundUtil.playClick(player);
                SettingsCommand.openLegacy(player);
            }));
        }
        gui.setItem(22, ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ARROW).name(SettingsCommand.noItalic("&fBack to Settings"))).flags(ItemFlag.values())).asGuiItem(e -> SettingsCommand.openLegacy(player)));
        gui.open((HumanEntity)player);
    }

    private static GuiItem quickQueueItem(Player player) {
        ArrayList<Component> lore = new ArrayList<Component>();
        for (String line : ConfigManager.msgs("settings.descriptions.quick-queue")) {
            lore.add(SettingsCommand.noItalic(line));
        }
        lore.add((Component)Component.empty());
        lore.add(SettingsCommand.noItalic("&#FB0000Click to Open Queue Menu"));
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.CHEST).name(SettingsCommand.noItalic("&fQuick Queue"))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
            SoundUtil.playClick(player);
            GUIManager.openQuickQueueSettings(player);
        });
    }

    private static GuiItem elytraLegacyItem(Player player) {
        boolean hasPerm = player.hasPermission("lifea.cosmetics.elytra");
        if (!hasPerm) {
            return ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ELYTRA).name(SettingsCommand.noItalic("&8(&6No Permission&8) &fElytra"))).flags(ItemFlag.values())).asGuiItem();
        }
        boolean enabled = PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA);
        String displayName = enabled ? "&8(&a\u2714&8) &aElytra" : "&8(&c\u2718&8) &cElytra";
        return ((ItemBuilder)((ItemBuilder)ItemBuilder.from(Material.ELYTRA).name(SettingsCommand.noItalic(displayName))).flags(ItemFlag.values())).asGuiItem(e -> {
            SoundUtil.playClick(player);
            boolean enable = e.isLeftClick();
            PlayerSettingsManager.set(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA, enable);
            if (!enable) {
                SpawnElytraManager.removeWindCharge(player);
            } else if (SpawnManager.isMainWorld(player)) {
                SpawnElytraManager.give(player);
            }
            SettingsCommand.openLegacy(player);
        });
    }

    private static GuiItem legacySettingItem(Player player, Material mat, String name, PlayerSettingsManager.Setting setting, String descKey) {
        UUID uuid = player.getUniqueId();
        boolean enabled = PlayerSettingsManager.get(uuid, setting);
        String displayName = enabled ? "&8(&a\u2714&8) &a" + name : "&8(&c\u2718&8) &c" + name;
        List<String> descLines = ConfigManager.msgs("settings.descriptions." + descKey);
        ArrayList<Component> lore = new ArrayList<Component>();
        for (String line : descLines) {
            lore.add(SettingsCommand.noItalic(line));
        }
        lore.add((Component)Component.empty());
        lore.add(SettingsCommand.noItalic("&#FB0000LMB: &fto Enable"));
        lore.add(SettingsCommand.noItalic("&#FB0000RMB: &fto Disable"));
        return ((ItemBuilder)((ItemBuilder)((ItemBuilder)ItemBuilder.from(mat).name(SettingsCommand.noItalic(displayName))).lore(lore)).flags(ItemFlag.values())).asGuiItem(e -> {
            SoundUtil.playClick(player);
            boolean enable = e.isLeftClick();
            PlayerSettingsManager.set(uuid, setting, enable);
            if (setting == PlayerSettingsManager.Setting.SCOREBOARD) {
                if (enable) {
                    ScoreboardManager.create(player);
                } else {
                    ScoreboardManager.remove(player);
                }
            }
            if (setting == PlayerSettingsManager.Setting.PING_DISPLAY) {
                NametagManager.refreshAll();
            }
            SettingsCommand.openLegacy(player);
        });
    }

    private static Component noItalic(String text) {
        return ColorUtil.parse(text).decoration(TextDecoration.ITALIC, false);
    }

    public static void openSettings(Player player) {
        SettingsCommand.open(player);
    }

    record SettingEntry(String label, PlayerSettingsManager.Setting setting, String key) {
    }
}

