/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import me.lifea.config.ConfigManager;
import me.lifea.gui.GUIManager;
import me.lifea.match.MatchManager;
import me.lifea.party.PartyManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class DuelCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 0) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.usage")));
                return true;
            }
            switch (args[0].toLowerCase()) {
                default: 
            }
            Player target = Bukkit.getPlayer((String)args[0]);
            if (target != null && target.isOnline()) {
                if (target.equals((Object)player)) {
                    GUIManager.openMainMenu(player, player);
                    return true;
                }
                if (PartyManager.inParty(player.getUniqueId())) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.duel-in-party")));
                    return true;
                }
                if (MatchManager.inMatch(target.getUniqueId())) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.target-in-match").replace("%target%", target.getName())));
                    return true;
                }
                GUIManager.openMainMenu(player, target);
                return true;
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.player-not-found")));
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            ArrayList<String> options = new ArrayList<String>();
            options.addAll(Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals((Object)sender)).map(Player::getName).toList());
            return this.filter(options, args[0]);
        }
        return List.of();
    }

    private List<String> filter(List<String> list, String input) {
        return list.stream().filter(s -> s.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}

