/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class FlySpeedCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            int level;
            Player player = (Player)sender;
            if (args.length != 1) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("fly.speed-usage")));
                return true;
            }
            try {
                level = Integer.parseInt(args[0]);
            }
            catch (NumberFormatException var8) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("fly.speed-usage")));
                return true;
            }
            if (level >= 1 && level <= 5) {
                if (!player.hasPermission("lifea.flyspeed." + level)) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.no-permission")));
                    return true;
                }
                player.setFlySpeed((float)level * 0.2f);
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("fly.speed-set").replace("%speed%", String.valueOf(level))));
                return true;
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("fly.speed-usage")));
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        return args.length == 1 ? List.of("1", "2", "3", "4", "5") : List.of();
    }
}

