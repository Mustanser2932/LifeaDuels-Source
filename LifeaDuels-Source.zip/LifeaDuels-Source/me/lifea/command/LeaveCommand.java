/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.match.MatchManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.queue.QueueManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LeaveCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (SpectateManager.isSpectating(player.getUniqueId())) {
                SpectateManager.stopSpectating(player);
                return true;
            }
            if (QueueManager.inQueue(player)) {
                QueueManager.leaveQueue(player);
                return true;
            }
            if (DuelSession.inSession(player.getUniqueId())) {
                DuelSession session = DuelSession.getSession(player.getUniqueId());
                if (session != null) {
                    session.forfeit(player);
                }
                return true;
            }
            if (PartyDuelSession.inSession(player.getUniqueId())) {
                PartyDuelSession session = PartyDuelSession.getSession(player.getUniqueId());
                if (session != null) {
                    session.forfeit(player);
                }
                return true;
            }
            if (MatchManager.inMatch(player.getUniqueId())) {
                MatchManager.forfeit(player);
                return true;
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.not-in-queue-or-match")));
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }
}

