/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import me.lifea.kit.KitManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class ResetKitCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("lifea.admin")) {
            sender.sendMessage(ColorUtil.parse("&cYou don't have permission to use this command."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("&cUsage: /resetkit <player|all> <kit|all>"));
            sender.sendMessage(ColorUtil.parse("&f  player: a player name, or &eall &ffor every player (including offline)"));
            sender.sendMessage(ColorUtil.parse("&f  kit: a kit key like &eSword-COM&f, or &eall &ffor all kits"));
            return true;
        }
        String targetArg = args[0];
        String kitArg = args[1];
        boolean allPlayers = targetArg.equalsIgnoreCase("all");
        boolean allKits = kitArg.equalsIgnoreCase("all");
        if (allPlayers && allKits) {
            int affected = KitManager.resetAllPlayerKits();
            sender.sendMessage(ColorUtil.parse("&aReset &e" + affected + " &aplayer kit layouts across all kits."));
        } else if (allPlayers) {
            String[] parsed = KitManager.parseKitKey(kitArg);
            if (parsed == null) {
                sender.sendMessage(ColorUtil.parse("&cUnknown kit key: &e" + kitArg));
                sender.sendMessage(ColorUtil.parse("&fUse &e/resetkit " + targetArg + " all &for a valid kit key."));
                return true;
            }
            String tier = parsed[0];
            String gamemode = parsed[1];
            int affected = KitManager.resetAllPlayerKits(tier, gamemode);
            sender.sendMessage(ColorUtil.parse("&aReset &e" + affected + " &aplayer layouts for &e" + kitArg + "&a."));
        } else if (allKits) {
            OfflinePlayer target = Bukkit.getOfflinePlayer((String)targetArg);
            if (!target.hasPlayedBefore()) {
                sender.sendMessage(ColorUtil.parse("&cPlayer &e" + targetArg + " &chas never played before."));
                return true;
            }
            int affected = KitManager.resetPlayerAllKits(target.getUniqueId());
            sender.sendMessage(ColorUtil.parse("&aReset &e" + affected + " &akit layouts for &e" + target.getName() + "&a."));
        } else {
            OfflinePlayer target = Bukkit.getOfflinePlayer((String)targetArg);
            if (!target.hasPlayedBefore()) {
                sender.sendMessage(ColorUtil.parse("&cPlayer &e" + targetArg + " &chas never played before."));
                return true;
            }
            String[] parsed = KitManager.parseKitKey(kitArg);
            if (parsed == null) {
                sender.sendMessage(ColorUtil.parse("&cUnknown kit key: &e" + kitArg));
                return true;
            }
            String tier = parsed[0];
            String gamemode = parsed[1];
            KitManager.resetPlayerKit(target.getUniqueId(), tier, gamemode);
            String var10001 = target.getName();
            sender.sendMessage(ColorUtil.parse("&aReset &e" + var10001 + "&a's &e" + kitArg + " &akit layout."));
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("lifea.admin")) {
            return List.of();
        }
        if (args.length != 1) {
            if (args.length == 2) {
                ArrayList<String> suggestions = new ArrayList<String>();
                suggestions.add("all");
                suggestions.addAll(KitManager.getKitKeys());
                return this.filter(suggestions, args[1]);
            }
            return List.of();
        }
        ArrayList<String> suggestions = new ArrayList<String>();
        suggestions.add("all");
        for (Player p : Bukkit.getOnlinePlayers()) {
            suggestions.add(p.getName());
        }
        return this.filter(suggestions, args[0]);
    }

    private List<String> filter(List<String> list, String input) {
        return list.stream().filter(s -> s.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}

