/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package me.lifea.command;

import java.util.List;
import me.lifea.config.ConfigManager;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.kit.custom.CustomKitShareManager;
import me.lifea.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class ImportKitCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            int slot;
            Player player = (Player)sender;
            if (!CustomKitManager.isEnabled()) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.custom-kits-disabled")));
                return true;
            }
            if (args.length < 2) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("import-kit.usage")));
                return true;
            }
            try {
                slot = Integer.parseInt(args[0]);
            }
            catch (NumberFormatException var81) {
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("import-kit.invalid-slot")));
                return true;
            }
            if (slot >= 1 && slot <= 5) {
                CustomKitShareManager.ShareData data = CustomKitShareManager.decode(args[1]);
                if (data == null) {
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("import-kit.invalid-code")));
                    return true;
                }
                CustomKitManager.deleteKit(player.getUniqueId(), slot);
                CustomKitManager.saveKit(player.getUniqueId(), slot, data.content, data.settings, data.potions);
                player.sendMessage(ColorUtil.parse(ConfigManager.msg("import-kit.imported").replace("%slot%", String.valueOf(slot))));
                return true;
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.msg("import-kit.slot-range")));
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            return List.of("1", "2", "3", "4", "5");
        }
        return args.length == 2 ? List.of("<code>") : List.of();
    }
}

