/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.command;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.player.StatsManager;
import me.lifea.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class StatsCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            String name;
            UUID uuid;
            Player player = (Player)sender;
            if (args.length == 0) {
                uuid = player.getUniqueId();
                name = player.getName();
            } else {
                OfflinePlayer target = Bukkit.getOfflinePlayer((String)args[0]);
                uuid = target.getUniqueId();
                name = target.getName() != null ? target.getName() : args[0];
            }
            this.sendStats(player, uuid, name);
            return true;
        }
        sender.sendMessage(ColorUtil.parse(ConfigManager.msg("errors.players-only")));
        return true;
    }

    private void sendStats(Player player, UUID uuid, String name) {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
            int wins = StatsManager.getWins(uuid);
            int losses = StatsManager.getLosses(uuid);
            int matches = StatsManager.getMatches(uuid);
            int streak = StatsManager.getWinStreak(uuid);
            int best = StatsManager.getBestStreak(uuid);
            double wr = StatsManager.getWinRate(uuid);
            double kdr = StatsManager.getKDR(uuid);
            Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> {
                player.sendMessage(ColorUtil.parse("&8&m                    "));
                player.sendMessage(ColorUtil.parse("  &eYour Stats"));
                player.sendMessage(ColorUtil.parse("  &fMatches: &e" + matches));
                player.sendMessage(ColorUtil.parse("  &fWins: &a" + wins + " &f| &fLosses: &c" + losses));
                player.sendMessage(ColorUtil.parse("  &fKDR: &e" + kdr + " &f| &fWin Rate: &e" + wr + "%"));
                player.sendMessage(ColorUtil.parse("  &fWin Streak: &e" + streak + " &f|&f Best: &e" + best));
                player.sendMessage(ColorUtil.parse("&8&m                    "));
            });
        });
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        return args.length == 1 ? Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList()) : List.of();
    }
}

