/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package me.lifea;

import java.util.logging.Logger;
import me.lifea.LifeaAPI;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaBlockChangeListener;
import me.lifea.arena.ArenaGenerationListener;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.ArenaWorldListener;
import me.lifea.arena.ClipboardCache;
import me.lifea.arena.snapshot.ArenaSnapshotManager;
import me.lifea.command.BannerCommand;
import me.lifea.command.CommandRestrictionListener;
import me.lifea.command.DuelAcceptCommand;
import me.lifea.command.DuelCommand;
import me.lifea.command.DuelDenyCommand;
import me.lifea.command.DuelsCommand;
import me.lifea.command.FfaCommand;
import me.lifea.command.FlyCommand;
import me.lifea.command.FlySpeedCommand;
import me.lifea.command.ImportKitCommand;
import me.lifea.command.KitEditorCommand;
import me.lifea.command.LeaveCommand;
import me.lifea.command.LifeaCommand;
import me.lifea.command.MessageCommand;
import me.lifea.command.PartyCommand;
import me.lifea.command.QueueCommand;
import me.lifea.command.QuickQueueCommand;
import me.lifea.command.ResetKitCommand;
import me.lifea.command.RoundSelectionDialogCommand;
import me.lifea.command.SettingsCommand;
import me.lifea.command.SpectateCommand;
import me.lifea.command.StatsCommand;
import me.lifea.command.TrimCommand;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelListener;
import me.lifea.duel.DuelSession;
import me.lifea.duel.KitRulesListener;
import me.lifea.duel.LobbyRightClickDuelListener;
import me.lifea.duel.custom.CustomKitRulesListener;
import me.lifea.gui.DuelRequestGUI;
import me.lifea.gui.GUIClickListener;
import me.lifea.gui.admin.ArenaEditorGUI;
import me.lifea.gui.admin.KitSettingsGUI;
import me.lifea.gui.kit.KitEditorProtectionListener;
import me.lifea.gui.kit.ffa.FfaKitEditorListener;
import me.lifea.hotbar.HotbarListener;
import me.lifea.hotbar.HotbarManager;
import me.lifea.kit.KitManager;
import me.lifea.kit.KitRuleManager;
import me.lifea.kit.PotionManager;
import me.lifea.kit.ffa.FfaKitManager;
import me.lifea.libs.bstats.bukkit.Metrics;
import me.lifea.libs.triumphgui.TriumphGui;
import me.lifea.libs.triumphgui.guis.GuiListener;
import me.lifea.libs.triumphgui.guis.InteractionModifierListener;
import me.lifea.match.MatchCleanupService;
import me.lifea.match.MatchManager;
import me.lifea.match.RematchListener;
import me.lifea.player.ChatIsolationListener;
import me.lifea.player.ChatMentionListener;
import me.lifea.player.PlayerCache;
import me.lifea.player.PlayerCleanupListener;
import me.lifea.player.StatsManager;
import me.lifea.queue.sign.QueueSignListener;
import me.lifea.queue.sign.QueueSignManager;
import me.lifea.scoreboard.ScoreboardListener;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spectate.SpectateListener;
import me.lifea.spectate.SpectateManager;
import me.lifea.storage.AsyncQueue;
import me.lifea.storage.DatabaseManager;
import me.lifea.storage.YamlToSqlMigration;
import me.lifea.util.CountryHeadManager;
import me.lifea.util.HeadUtil;
import me.lifea.util.IpCache;
import me.lifea.util.LifeaCountriesExpansion;
import me.lifea.util.LifeaExpansion;
import me.lifea.util.LifeaRelationalExpansion;
import me.lifea.util.NametagManager;
import me.lifea.util.TabManager;
import me.lifea.visibility.MatchVisibilityManager;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class Lifea
extends JavaPlugin {
    private static Lifea instance;

    public void onEnable() {
        instance = this;
        TriumphGui.init((Plugin)this);
        ConfigManager.load();
        DatabaseManager.init();
        AsyncQueue.init();
        PlayerCache.init();
        YamlToSqlMigration.migrateArenas();
        HotbarManager.init();
        KitManager.load();
        FfaKitManager.load();
        ArenaManager.load();
        this.warnBedwarsArenasWithoutBeds();
        if (this.getServer().getPluginManager().getPlugin("FastAsyncWorldEdit") != null) {
            for (Arena a : ArenaManager.getAll()) {
                if (!a.isRegeneration() || !a.isRegionSet() || ArenaSnapshotManager.hasSchematic(a.getName())) continue;
                ArenaSnapshotManager.captureArena(a).exceptionally(ex -> {
                    Logger var10000 = this.getLogger();
                    String var10001 = a.getName();
                    var10000.warning("Could not save initial schematic for arena '" + var10001 + "': " + ex.getMessage());
                    return null;
                });
            }
        }
        QueueSignManager.load();
        PotionManager.load();
        StatsManager.load();
        DuelCommand duelCmd = new DuelCommand();
        this.getCommand("duel").setExecutor((CommandExecutor)duelCmd);
        this.getCommand("duel").setTabCompleter((TabCompleter)duelCmd);
        this.getCommand("1v1").setExecutor((CommandExecutor)duelCmd);
        this.getCommand("1v1").setTabCompleter((TabCompleter)duelCmd);
        PartyCommand partyCmd = new PartyCommand();
        this.getCommand("party").setExecutor((CommandExecutor)partyCmd);
        this.getCommand("party").setTabCompleter((TabCompleter)partyCmd);
        this.getCommand("queue").setExecutor((CommandExecutor)new QueueCommand());
        this.getCommand("quickqueue").setExecutor((CommandExecutor)new QuickQueueCommand());
        this.getCommand("kiteditor").setExecutor((CommandExecutor)new KitEditorCommand());
        LifeaCommand duelVCmd = new LifeaCommand();
        this.getCommand("lifea").setExecutor((CommandExecutor)duelVCmd);
        this.getCommand("lifea").setTabCompleter((TabCompleter)duelVCmd);
        FfaCommand ffaCmd = new FfaCommand();
        this.getCommand("ffa-kit").setExecutor((CommandExecutor)ffaCmd);
        this.getCommand("ffa-kit").setTabCompleter((TabCompleter)ffaCmd);
        StatsCommand statsCmd = new StatsCommand();
        this.getCommand("stats").setExecutor((CommandExecutor)statsCmd);
        this.getCommand("stats").setTabCompleter((TabCompleter)statsCmd);
        this.getCommand("settings").setExecutor((CommandExecutor)new SettingsCommand());
        this.getCommand("spectate").setExecutor((CommandExecutor)new SpectateCommand());
        this.getCommand("leave").setExecutor((CommandExecutor)new LeaveCommand());
        MessageCommand msgCmd = new MessageCommand();
        this.getCommand("message").setExecutor((CommandExecutor)msgCmd);
        this.getCommand("message").setTabCompleter((TabCompleter)msgCmd);
        this.getCommand("msg").setExecutor((CommandExecutor)msgCmd);
        this.getCommand("msg").setTabCompleter((TabCompleter)msgCmd);
        this.getCommand("msgtoggle").setExecutor((CommandExecutor)msgCmd);
        this.getCommand("r").setExecutor((CommandExecutor)msgCmd);
        this.getCommand("reply").setExecutor((CommandExecutor)msgCmd);
        DuelsCommand duelsCmd = new DuelsCommand();
        this.getCommand("duels").setExecutor((CommandExecutor)duelsCmd);
        this.getCommand("duels").setTabCompleter((TabCompleter)duelsCmd);
        this.getCommand("duelaccept").setExecutor((CommandExecutor)new DuelAcceptCommand());
        this.getCommand("dueldeny").setExecutor((CommandExecutor)new DuelDenyCommand());
        this.getCommand("duelround").setExecutor((CommandExecutor)new RoundSelectionDialogCommand());
        FlySpeedCommand flySpeedCmd = new FlySpeedCommand();
        this.getCommand("fly").setExecutor((CommandExecutor)new FlyCommand());
        this.getCommand("flyspeed").setExecutor((CommandExecutor)flySpeedCmd);
        this.getCommand("flyspeed").setTabCompleter((TabCompleter)flySpeedCmd);
        this.getCommand("resetkit").setExecutor((CommandExecutor)new ResetKitCommand());
        this.getCommand("resetkit").setTabCompleter((TabCompleter)new ResetKitCommand());
        ImportKitCommand importKitCmd = new ImportKitCommand();
        this.getCommand("importkit").setExecutor((CommandExecutor)importKitCmd);
        this.getCommand("importkit").setTabCompleter((TabCompleter)importKitCmd);
        this.getCommand("trim").setExecutor((CommandExecutor)new TrimCommand());
        this.getCommand("banners").setExecutor((CommandExecutor)new BannerCommand());
        this.getServer().getPluginManager().registerEvents((Listener)new GuiListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new InteractionModifierListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ScoreboardListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new HotbarListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new PlayerCleanupListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new RematchListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new KitSettingsGUI(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ArenaEditorGUI(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ChatMentionListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ChatIsolationListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new DuelListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new KitRulesListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new LobbyRightClickDuelListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new QueueSignListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CustomKitRulesListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ArenaWorldListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ArenaBlockChangeListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ArenaGenerationListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GUIClickListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new FfaKitEditorListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new DuelRequestGUI(null, null, null), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new KitEditorProtectionListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CommandRestrictionListener(), (Plugin)this);
        SpectateListener spectateListener = new SpectateListener();
        this.getServer().getPluginManager().registerEvents((Listener)spectateListener, (Plugin)this);
        spectateListener.startTasks();
        ScoreboardManager.start();
        if (this.getServer().getPluginManager().getPlugin("FastAsyncWorldEdit") != null) {
            ClipboardCache.init();
        }
        MatchCleanupService.init();
        SpectateManager.startFailsafeMonitor();
        MatchVisibilityManager.start();
        CountryHeadManager.load();
        this.getServer().getPluginManager().registerEvents((Listener)new TabManager(), (Plugin)this);
        TabManager.start();
        this.getServer().getPluginManager().registerEvents((Listener)new NametagManager(), (Plugin)this);
        NametagManager.start();
        if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new LifeaExpansion().register();
            new LifeaRelationalExpansion().register();
            new LifeaCountriesExpansion().register();
            this.getLogger().info("Registered Lifea expansion with PlaceholderAPI");
        }
        int pluginId = 32723;
        new Metrics((Plugin)this, pluginId);
        ArenaBlockChangeListener.rebuildIndexIfStale();
        this.getLogger().info("Lifea has been enabled!");
    }

    private void warnBedwarsArenasWithoutBeds() {
        block0: for (Arena arena : ArenaManager.getAll()) {
            if (!arena.isEnabled() || arena.hasBedObjectives() || arena.getAllowedKits() == null) continue;
            for (String kitKey : arena.getAllowedKits()) {
                if (kitKey == null || kitKey.isBlank() || !KitRuleManager.isBedwarsEnabled(kitKey.trim())) continue;
                this.getLogger().warning("BedPvP arena '" + arena.getName() + "' has no home beds configured, so BedPvP queue matching will skip it. Configure both beds in the Arena Editor or re-create it with /lifea autoclone.");
                continue block0;
            }
        }
    }

    public void onDisable() {
        MatchCleanupService.shutdown();
        SpectateManager.stopFailsafeMonitor();
        MatchVisibilityManager.stop();
        NametagManager.stop();
        TabManager.stop();
        PlayerCleanupListener.cleanupAllOnline();
        MatchManager.disposeAll();
        for (DuelSession session : DuelSession.getActiveSessions()) {
            try {
                if (session.countdownTask == null || session.countdownTask.isCancelled()) continue;
                session.countdownTask.cancel();
            }
            catch (Exception exception) {}
        }
        if (this.getServer().getPluginManager().getPlugin("FastAsyncWorldEdit") != null) {
            ClipboardCache.shutdown();
        }
        HotbarManager.shutdown();
        StatsManager.shutdown();
        PlayerCache.shutdown();
        AsyncQueue.shutdown();
        DatabaseManager.close();
        HeadUtil.clear();
        IpCache.clear();
        CountryHeadManager.clear();
        this.getLogger().info("Lifea has been disabled!");
    }

    public static Lifea getInstance() {
        return instance;
    }

    public LifeaAPI getAPI() {
        return LifeaAPI.get();
    }
}

