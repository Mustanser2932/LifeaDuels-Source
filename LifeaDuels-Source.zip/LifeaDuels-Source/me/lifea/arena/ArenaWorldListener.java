/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBurnEvent
 *  org.bukkit.event.block.BlockExplodeEvent
 *  org.bukkit.event.block.BlockFadeEvent
 *  org.bukkit.event.block.BlockFormEvent
 *  org.bukkit.event.block.BlockFromToEvent
 *  org.bukkit.event.block.BlockIgniteEvent
 *  org.bukkit.event.block.BlockSpreadEvent
 *  org.bukkit.event.entity.EntityChangeBlockEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 */
package me.lifea.arena;

import java.util.logging.Logger;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.config.PerformanceConfig;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;

public class ArenaWorldListener
implements Listener {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final boolean DEBUG = PerformanceConfig.isRestoreDebugLogging();

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onEntityExplode(EntityExplodeEvent event) {
        if (PerformanceConfig.isModifiedBlockTracking()) {
            for (Block block : event.blockList()) {
                Arena found = ArenaWorldListener.getArenaForBlock(block);
                if (found == null) continue;
                this.markDirty(found, block, "ENTITY_EXPLODE");
            }
        } else {
            Block foundBlock = null;
            for (Block block : event.blockList()) {
                if (ArenaWorldListener.getArenaForBlock(block) == null) continue;
                foundBlock = block;
                break;
            }
            if (foundBlock != null) {
                this.markDirty(ArenaWorldListener.getArenaForBlock(foundBlock), foundBlock, "ENTITY_EXPLODE");
            }
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (PerformanceConfig.isModifiedBlockTracking()) {
            for (Block block : event.blockList()) {
                Arena found = ArenaWorldListener.getArenaForBlock(block);
                if (found == null) continue;
                this.markDirty(found, block, "BLOCK_EXPLODE");
            }
        } else {
            Block foundBlock = null;
            for (Block block : event.blockList()) {
                if (ArenaWorldListener.getArenaForBlock(block) == null) continue;
                foundBlock = block;
                break;
            }
            if (foundBlock != null) {
                this.markDirty(ArenaWorldListener.getArenaForBlock(foundBlock), foundBlock, "BLOCK_EXPLODE");
            }
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockIgnite(BlockIgniteEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getBlock()), event.getBlock(), "BLOCK_IGNITE");
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockBurn(BlockBurnEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getBlock()), event.getBlock(), "BLOCK_BURN");
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getBlock()), event.getBlock(), "ENTITY_CHANGE_BLOCK");
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockFromTo(BlockFromToEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getToBlock()), event.getToBlock(), "BLOCK_FLOW");
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockSpread(BlockSpreadEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getBlock()), event.getBlock(), "BLOCK_SPREAD");
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockForm(BlockFormEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getBlock()), event.getBlock(), "BLOCK_FORM");
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBlockFade(BlockFadeEvent event) {
        this.markDirty(ArenaWorldListener.getArenaForBlock(event.getBlock()), event.getBlock(), "BLOCK_FADE");
    }

    private void markDirty(Arena arena, Block block, String cause) {
        if (arena != null && block != null) {
            if (PerformanceConfig.isModifiedBlockTracking()) {
                arena.getModifiedBlockTracker().recordOriginal(block.getX(), block.getY(), block.getZ(), block.getBlockData());
            }
            arena.setDirty(true);
            if (DEBUG) {
                Logger var10000 = LOG;
                String var10001 = arena.getName();
                var10000.info("[ARENA] Marked dirty: arena=" + var10001 + " cause=" + cause + " pos=" + block.getX() + "," + block.getY() + "," + block.getZ());
            }
        }
    }

    private static Arena getArenaForBlock(Block block) {
        for (Arena arena : ArenaManager.getAll()) {
            if (!arena.isInUse() || !arena.isInside(block)) continue;
            return arena;
        }
        return null;
    }
}

