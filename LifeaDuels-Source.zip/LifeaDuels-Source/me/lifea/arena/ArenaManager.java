/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package me.lifea.arena;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import me.lifea.arena.Arena;
import me.lifea.arena.snapshot.ArenaSnapshotManager;
import me.lifea.storage.DatabaseManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public class ArenaManager {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final Map<String, Arena> arenas = new ConcurrentHashMap<String, Arena>();

    public static void load() {
        try (Connection conn = DatabaseManager.connection();
             PreparedStatement st = conn.prepareStatement("SELECT * FROM arenas");
             ResultSet rs = st.executeQuery();){
            while (rs.next()) {
                int maxY;
                int minY;
                String name = rs.getString("name");
                Arena arena = new Arena(name);
                arena.setEnabled(rs.getInt("enabled") == 1);
                arena.setRegeneration(rs.getInt("regeneration") == 1);
                String worldName = rs.getString("world");
                World world = Bukkit.getWorld((String)worldName);
                arena.setWorld(worldName);
                Location spawn1 = new Location(world, rs.getDouble("spawn1_x"), rs.getDouble("spawn1_y"), rs.getDouble("spawn1_z"), rs.getFloat("spawn1_yaw"), rs.getFloat("spawn1_pitch"));
                Location spawn2 = new Location(world, rs.getDouble("spawn2_x"), rs.getDouble("spawn2_y"), rs.getDouble("spawn2_z"), rs.getFloat("spawn2_yaw"), rs.getFloat("spawn2_pitch"));
                arena.setSpawn1(spawn1);
                arena.setSpawn2(spawn2);
                if (world == null) {
                    LOG.warning("[Lifea] Arena '" + name + "' references missing world '" + worldName + "'. Arena will be unavailable until the world loads.");
                }
                try {
                    minY = rs.getInt("region_min_y");
                    maxY = rs.getInt("region_max_y");
                }
                catch (SQLException var24) {
                    LOG.warning("[Lifea] Arena '" + name + "' missing region_min_y/region_max_y columns. Using world default height. Consider re-saving this arena.");
                    minY = world != null ? world.getMinHeight() : -64;
                    maxY = world != null ? world.getMaxHeight() : 320;
                }
                arena.setRegion(rs.getInt("region_min_x"), minY, rs.getInt("region_min_z"), rs.getInt("region_max_x"), maxY, rs.getInt("region_max_z"));
                try {
                    arena.setBuildLimitY((Integer)rs.getObject("build_limit_y"));
                }
                catch (SQLException var24) {
                    // empty catch block
                }
                arena.setBedObjectives((Integer)rs.getObject("blue_bed_x"), (Integer)rs.getObject("blue_bed_y"), (Integer)rs.getObject("blue_bed_z"), (Integer)rs.getObject("red_bed_x"), (Integer)rs.getObject("red_bed_y"), (Integer)rs.getObject("red_bed_z"));
                try {
                    arena.setBlueBedFacing(rs.getString("blue_bed_facing"));
                    arena.setRedBedFacing(rs.getString("red_bed_facing"));
                }
                catch (SQLException var24) {
                    // empty catch block
                }
                try {
                    Object cx = rs.getObject("center_x");
                    Object cy = rs.getObject("center_y");
                    Object cz = rs.getObject("center_z");
                    if (cx != null && cy != null && cz != null) {
                        arena.setCenter(rs.getDouble("center_x"), rs.getDouble("center_y"), rs.getDouble("center_z"));
                    }
                }
                catch (SQLException cx) {
                    // empty catch block
                }
                try {
                    Object h1x = rs.getObject("regen_hold1_x");
                    Object h1y = rs.getObject("regen_hold1_y");
                    Object h1z = rs.getObject("regen_hold1_z");
                    if (h1x != null && h1y != null && h1z != null) {
                        arena.setRegenHold1(new Location(world, rs.getDouble("regen_hold1_x"), rs.getDouble("regen_hold1_y"), rs.getDouble("regen_hold1_z")));
                    }
                    Object h2x = rs.getObject("regen_hold2_x");
                    Object h2y = rs.getObject("regen_hold2_y");
                    Object h2z = rs.getObject("regen_hold2_z");
                    if (h2x != null && h2y != null && h2z != null) {
                        arena.setRegenHold2(new Location(world, rs.getDouble("regen_hold2_x"), rs.getDouble("regen_hold2_y"), rs.getDouble("regen_hold2_z")));
                    }
                }
                catch (SQLException h1x) {
                    // empty catch block
                }
                String kitsRaw = rs.getString("allowed_kits");
                if (kitsRaw != null && !kitsRaw.isBlank()) {
                    arena.setAllowedKits(new ArrayList<String>(Arrays.asList(kitsRaw.split(","))));
                }
                arenas.put(name.toLowerCase(), arena);
            }
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to load arenas", e);
        }
    }

    public static Arena create(String name) {
        Arena arena = new Arena(name);
        arenas.put(name.toLowerCase(), arena);
        return arena;
    }

    public static boolean rename(String oldName, String newName) {
        if (oldName != null && newName != null) {
            String oldKey = oldName.toLowerCase();
            String newKey = newName.toLowerCase();
            if (!arenas.containsKey(oldKey)) {
                return false;
            }
            if (arenas.containsKey(newKey)) {
                return false;
            }
            Arena arena = arenas.remove(oldKey);
            if (arena == null) {
                return false;
            }
            arena.setName(newName);
            arenas.put(newKey, arena);
            if (arena.getSpawn1() != null && arena.getSpawn2() != null) {
                try (Connection conn = DatabaseManager.connection();
                     PreparedStatement st = conn.prepareStatement("DELETE FROM arenas WHERE name=?");){
                    st.setString(1, oldKey);
                    st.executeUpdate();
                }
                catch (SQLException e) {
                    throw new RuntimeException("Failed to rename arena (delete old row)", e);
                }
                ArenaManager.saveArena(arena);
            }
            return true;
        }
        return false;
    }

    public static boolean delete(String name) {
        if (!arenas.containsKey(name.toLowerCase())) {
            return false;
        }
        arenas.remove(name.toLowerCase());
        try {
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement st = conn.prepareStatement("DELETE FROM arenas WHERE name=?");){
                st.setString(1, name.toLowerCase());
                st.executeUpdate();
            }
            return true;
        }
        catch (SQLException e) {
            throw new RuntimeException("Failed to delete arena", e);
        }
    }

    public static Arena get(String name) {
        return arenas.get(name.toLowerCase());
    }

    public static boolean exists(String name) {
        return arenas.containsKey(name.toLowerCase());
    }

    public static Collection<Arena> getAll() {
        return arenas.values();
    }

    public static void saveArena(Arena arena) {
        if (arena.getSpawn1() != null && arena.getSpawn2() != null) {
            String kitsRaw = String.join((CharSequence)",", arena.getAllowedKits());
            try (Connection conn = DatabaseManager.connection();
                 PreparedStatement st = conn.prepareStatement("INSERT OR REPLACE INTO arenas (name, world, spawn1_x, spawn1_y, spawn1_z, spawn1_yaw, spawn1_pitch, spawn2_x, spawn2_y, spawn2_z, spawn2_yaw, spawn2_pitch, region_min_x, region_min_z, region_max_x, region_max_z, region_min_y, region_max_y, blue_bed_x, blue_bed_y, blue_bed_z, red_bed_x, red_bed_y, red_bed_z, blue_bed_facing, red_bed_facing, enabled, regeneration, allowed_kits, center_x, center_y, center_z, regen_hold1_x, regen_hold1_y, regen_hold1_z, regen_hold2_x, regen_hold2_y, regen_hold2_z, build_limit_y) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");){
                st.setString(1, arena.getName().toLowerCase());
                st.setString(2, arena.getWorld());
                st.setDouble(3, arena.getSpawn1().getX());
                st.setDouble(4, arena.getSpawn1().getY());
                st.setDouble(5, arena.getSpawn1().getZ());
                st.setFloat(6, arena.getSpawn1().getYaw());
                st.setFloat(7, arena.getSpawn1().getPitch());
                st.setDouble(8, arena.getSpawn2().getX());
                st.setDouble(9, arena.getSpawn2().getY());
                st.setDouble(10, arena.getSpawn2().getZ());
                st.setFloat(11, arena.getSpawn2().getYaw());
                st.setFloat(12, arena.getSpawn2().getPitch());
                st.setInt(13, arena.getRegionMinX());
                st.setInt(14, arena.getRegionMinZ());
                st.setInt(15, arena.getRegionMaxX());
                st.setInt(16, arena.getRegionMaxZ());
                st.setInt(17, arena.getRegionMinY());
                st.setInt(18, arena.getRegionMaxY());
                st.setObject(19, arena.getBlueBedX());
                st.setObject(20, arena.getBlueBedY());
                st.setObject(21, arena.getBlueBedZ());
                st.setObject(22, arena.getRedBedX());
                st.setObject(23, arena.getRedBedY());
                st.setObject(24, arena.getRedBedZ());
                st.setString(25, arena.getBlueBedFacing());
                st.setString(26, arena.getRedBedFacing());
                st.setInt(27, arena.isEnabled() ? 1 : 0);
                st.setInt(28, arena.isRegeneration() ? 1 : 0);
                st.setString(29, kitsRaw);
                st.setObject(30, arena.getCenterX());
                st.setObject(31, arena.getCenterY());
                st.setObject(32, arena.getCenterZ());
                Location regenHold1 = arena.getRegenHold1();
                st.setObject(33, regenHold1 != null ? Double.valueOf(regenHold1.getX()) : null);
                st.setObject(34, regenHold1 != null ? Double.valueOf(regenHold1.getY()) : null);
                st.setObject(35, regenHold1 != null ? Double.valueOf(regenHold1.getZ()) : null);
                Location regenHold2 = arena.getRegenHold2();
                st.setObject(36, regenHold2 != null ? Double.valueOf(regenHold2.getX()) : null);
                st.setObject(37, regenHold2 != null ? Double.valueOf(regenHold2.getY()) : null);
                st.setObject(38, regenHold2 != null ? Double.valueOf(regenHold2.getZ()) : null);
                st.setObject(39, arena.getBuildLimitY());
                st.executeUpdate();
            }
            catch (SQLException e) {
                throw new RuntimeException("Failed to save arena", e);
            }
        }
    }

    public static Optional<Arena> getAvailableForKit(String kitKey) {
        return ArenaManager.getAvailableForKit(kitKey, false);
    }

    public static Optional<Arena> getAvailableForKit(String kitKey, boolean requireBedObjectives) {
        List candidates = arenas.values().stream().filter(a -> !(!a.isEnabled() || !a.isRegionSet() || a.getSpawn1() == null || a.getSpawn2() == null || a.isInUse() || a.isRegeneration() && !ArenaSnapshotManager.hasSchematic(a.getName()) || requireBedObjectives && !a.hasBedObjectives())).collect(Collectors.toList());
        if (kitKey != null && !kitKey.isBlank()) {
            String keyLower = kitKey.toLowerCase();
            Arena bestBound = null;
            Arena bestUnbound = null;
            block0: for (Arena arena : candidates) {
                List<String> allowed = arena.getAllowedKits();
                if (allowed != null && !allowed.isEmpty()) {
                    for (String k : allowed) {
                        if (k == null || !k.trim().equalsIgnoreCase(keyLower)) continue;
                        if (bestBound != null && arena.getTimesUsed() >= bestBound.getTimesUsed()) continue block0;
                        bestBound = arena;
                        continue block0;
                    }
                    continue;
                }
                if (bestUnbound != null && arena.getTimesUsed() >= bestUnbound.getTimesUsed()) continue;
                bestUnbound = arena;
            }
            Arena result = bestBound != null ? bestBound : bestUnbound;
            return Optional.ofNullable(result);
        }
        return candidates.stream().min(Comparator.comparingLong(Arena::getTimesUsed));
    }

    public static Optional<Arena> getAvailableForBase(String baseName) {
        return ArenaManager.getAvailableForBase(baseName, false);
    }

    public static Optional<Arena> getAvailableForBase(String baseName, boolean requireBedObjectives) {
        String prefix = baseName.toLowerCase() + "-";
        return arenas.values().stream().filter(a -> !(!a.isEnabled() || !a.isRegionSet() || a.getSpawn1() == null || a.getSpawn2() == null || a.isInUse() || a.isRegeneration() && !ArenaSnapshotManager.hasSchematic(a.getName()) || requireBedObjectives && !a.hasBedObjectives())).filter(a -> a.getName().equalsIgnoreCase(baseName) || a.getName().toLowerCase().startsWith(prefix)).min(Comparator.comparingLong(Arena::getTimesUsed));
    }
}

