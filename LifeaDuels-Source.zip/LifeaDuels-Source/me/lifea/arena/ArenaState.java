/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.arena;

public final class ArenaState
extends Enum<ArenaState> {
    public static final /* enum */ ArenaState AVAILABLE = new ArenaState();
    public static final /* enum */ ArenaState IN_USE = new ArenaState();
    public static final /* enum */ ArenaState REGENERATING = new ArenaState();
    public static final /* enum */ ArenaState DISABLED = new ArenaState();
    private static final /* synthetic */ ArenaState[] $VALUES;

    public static ArenaState[] values() {
        return (ArenaState[])$VALUES.clone();
    }

    public static ArenaState valueOf(String name) {
        return Enum.valueOf(ArenaState.class, name);
    }

    private static ArenaState[] $values() {
        return new ArenaState[]{AVAILABLE, IN_USE, REGENERATING, DISABLED};
    }

    private static ArenaState[] $values$() {
        return new ArenaState[]{AVAILABLE, IN_USE, REGENERATING, DISABLED};
    }

    private static /* synthetic */ ArenaState[] $values$$() {
        return new ArenaState[]{AVAILABLE, IN_USE, REGENERATING, DISABLED};
    }

    static {
        $VALUES = ArenaState.$values$$();
    }
}

