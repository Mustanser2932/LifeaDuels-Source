/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockExplodeEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.player.PlayerBucketEmptyEvent
 *  org.bukkit.event.player.PlayerBucketFillEvent
 */
package me.lifea.arena;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.ArenaState;
import me.lifea.arena.ModifiedBlockTracker;
import me.lifea.config.PerformanceConfig;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;

public class ArenaBlockChangeListener
implements Listener {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final boolean DEBUG = PerformanceConfig.isRestoreDebugLogging();
    private static final boolean MODIFIED_BLOCK_TRACKING = PerformanceConfig.isModifiedBlockTracking();
    private static final Map<String, List<Arena>> arenasByWorld = new ConcurrentHashMap<String, List<Arena>>();
    private static long lastIndexRebuild = 0L;
    private static final long INDEX_REBUILD_INTERVAL = 5000L;

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent event) {
        Block replaced;
        Arena arena;
        Player player = event.getPlayer();
        if (player != null && (arena = ArenaBlockChangeListener.getArenaForBlock(replaced = event.getBlockReplacedState().getBlock())) != null) {
            if (MODIFIED_BLOCK_TRACKING) {
                arena.getModifiedBlockTracker().recordOriginal(replaced.getX(), replaced.getY(), replaced.getZ(), event.getBlockReplacedState().getBlockData());
            }
            Block placed = event.getBlockPlaced();
            arena.getModifiedBlockTracker().markPersonalPlaced(placed.getX(), placed.getY(), placed.getZ());
            arena.setDirty(true);
            if (DEBUG) {
                Logger var10000 = LOG;
                String var10001 = arena.getName();
                var10000.info("[ARENA] Marked dirty: arena=" + var10001 + " cause=BLOCK_PLACE pos=" + replaced.getX() + "," + replaced.getY() + "," + replaced.getZ());
            }
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        Arena arena = ArenaBlockChangeListener.getArenaForBlock(block);
        if (arena != null) {
            if (MODIFIED_BLOCK_TRACKING) {
                arena.getModifiedBlockTracker().recordOriginal(block.getX(), block.getY(), block.getZ(), block.getBlockData());
            }
            arena.setDirty(true);
            if (DEBUG) {
                Logger var10000 = LOG;
                String var10001 = arena.getName();
                var10000.info("[ARENA] Marked dirty: arena=" + var10001 + " cause=BLOCK_BREAK pos=" + block.getX() + "," + block.getY() + "," + block.getZ());
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Block block = event.getBlock();
        Arena arena = ArenaBlockChangeListener.getArenaForBlock(block);
        if (arena != null) {
            if (MODIFIED_BLOCK_TRACKING) {
                arena.getModifiedBlockTracker().recordOriginal(block.getX(), block.getY(), block.getZ(), block.getBlockData());
            }
            arena.setDirty(true);
            if (DEBUG) {
                Logger var10000 = LOG;
                String var10001 = arena.getName();
                var10000.info("[ARENA] Marked dirty: arena=" + var10001 + " cause=BUCKET_EMPTY pos=" + block.getX() + "," + block.getY() + "," + block.getZ());
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        Block block = event.getBlock();
        Arena arena = ArenaBlockChangeListener.getArenaForBlock(block);
        if (arena != null) {
            if (MODIFIED_BLOCK_TRACKING) {
                arena.getModifiedBlockTracker().recordOriginal(block.getX(), block.getY(), block.getZ(), block.getBlockData());
            }
            arena.setDirty(true);
            if (DEBUG) {
                Logger var10000 = LOG;
                String var10001 = arena.getName();
                var10000.info("[ARENA] Marked dirty: arena=" + var10001 + " cause=BUCKET_FILL pos=" + block.getX() + "," + block.getY() + "," + block.getZ());
            }
        }
    }

    @EventHandler(priority=EventPriority.NORMAL, ignoreCancelled=true)
    public void onEntityExplode(EntityExplodeEvent event) {
        Arena arena;
        List blocks = event.blockList();
        if (!blocks.isEmpty() && (arena = ArenaBlockChangeListener.getArenaForBlock((Block)blocks.get(0))) != null) {
            if (MODIFIED_BLOCK_TRACKING) {
                ModifiedBlockTracker tracker = arena.getModifiedBlockTracker();
                for (Block block : blocks) {
                    if (!arena.isInside(block)) continue;
                    tracker.recordOriginal(block.getX(), block.getY(), block.getZ(), block.getBlockData());
                }
            }
            arena.setDirty(true);
        }
    }

    @EventHandler(priority=EventPriority.NORMAL, ignoreCancelled=true)
    public void onBlockExplode(BlockExplodeEvent event) {
        Arena arena;
        List blocks = event.blockList();
        if (!blocks.isEmpty() && (arena = ArenaBlockChangeListener.getArenaForBlock((Block)blocks.get(0))) != null) {
            if (MODIFIED_BLOCK_TRACKING) {
                ModifiedBlockTracker tracker = arena.getModifiedBlockTracker();
                for (Block block : blocks) {
                    if (!arena.isInside(block)) continue;
                    tracker.recordOriginal(block.getX(), block.getY(), block.getZ(), block.getBlockData());
                }
            }
            arena.setDirty(true);
        }
    }

    private static Arena getArenaForBlock(Block block) {
        ArenaBlockChangeListener.rebuildIndexIfStale();
        String worldName = block.getWorld().getName();
        List<Arena> candidates = arenasByWorld.get(worldName);
        if (candidates == null) {
            return null;
        }
        for (Arena arena : candidates) {
            if (!arena.isInUse() || arena.getState() != ArenaState.IN_USE || !arena.isInside(block)) continue;
            return arena;
        }
        return null;
    }

    public static void rebuildIndexIfStale() {
        long now = System.currentTimeMillis();
        if (now - lastIndexRebuild > 5000L) {
            lastIndexRebuild = now;
            ArenaBlockChangeListener.doRebuildIndex();
        }
    }

    private static void doRebuildIndex() {
        arenasByWorld.clear();
        for (Arena arena : ArenaManager.getAll()) {
            if (arena.getWorld() == null) continue;
            arenasByWorld.computeIfAbsent(arena.getWorld(), k -> new ArrayList()).add(arena);
        }
    }
}

