/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fastasyncworldedit.core.FaweAPI
 *  com.fastasyncworldedit.core.extent.clipboard.CPUOptimizedClipboard
 *  com.fastasyncworldedit.core.extent.clipboard.SimpleClipboard
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.function.operation.ForwardExtentCopy
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.regions.CuboidRegion
 *  com.sk89q.worldedit.regions.Region
 *  com.sk89q.worldedit.world.World
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.arena;

import com.fastasyncworldedit.core.FaweAPI;
import com.fastasyncworldedit.core.extent.clipboard.CPUOptimizedClipboard;
import com.fastasyncworldedit.core.extent.clipboard.SimpleClipboard;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.world.World;
import java.util.ArrayList;
import java.util.List;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.ClipboardCache;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public final class ArenaCloner {
    private static final int GAP = 100;

    private ArenaCloner() {
    }

    public static void autoClone(CommandSender sender, String arenaName, int maxClones) {
        Arena source = ArenaManager.get(arenaName);
        if (source == null) {
            sender.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + "&c not found."));
        } else if (!source.isRegionSet()) {
            sender.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + "&c has no region set."));
        } else if (source.getWorld() != null && FaweAPI.getWorld((String)source.getWorld()) != null) {
            int clones = Math.max(1, Math.min(20, maxClones));
            String world = source.getWorld();
            int minX = source.getRegionMinX();
            int minY = source.getRegionMinY();
            int minZ = source.getRegionMinZ();
            int maxX = source.getRegionMaxX();
            int maxY = source.getRegionMaxY();
            int maxZ = source.getRegionMaxZ();
            int width = maxX - minX + 1;
            int step = width + 100;
            String var10001 = source.getName();
            sender.sendMessage(ColorUtil.parse("&fCloning &e" + var10001 + "&f (up to &e" + clones + "&f)... this runs in the background."));
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
                Clipboard clip = ArenaCloner.captureRegion(source);
                try {
                    ArrayList<String[]> made = new ArrayList<String[]>();
                    int placed = 0;
                    int k = 0;
                    int cap = clones * 5;
                    while (placed < clones && k < cap) {
                        int cMinX;
                        int dx;
                        int cMaxX = maxX + dx;
                        if (ArenaCloner.anyArenaOverlaps(world, cMinX = minX + (dx = ++k * step), cMaxX, minZ, maxZ) || !ArenaCloner.isRegionAir(world, cMinX, minY, minZ, cMaxX, maxY, maxZ)) continue;
                        try {
                            ClipboardCache.pasteClipboard(clip, world, cMinX, minY, minZ).join();
                        }
                        catch (Exception var30) {
                            continue;
                        }
                        Arena clone = ArenaCloner.registerClone(source, dx);
                        int cx = (clone.getRegionMinX() + clone.getRegionMaxX()) / 2;
                        int cy = (clone.getRegionMinY() + clone.getRegionMaxY()) / 2;
                        int cz = (clone.getRegionMinZ() + clone.getRegionMaxZ()) / 2;
                        made.add(new String[]{clone.getName(), String.valueOf(cx), String.valueOf(cy), String.valueOf(cz)});
                        ++placed;
                    }
                    int placedCount = placed;
                    Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), () -> ArenaCloner.report(sender, source.getName(), placedCount, clones, made));
                }
                finally {
                    try {
                        clip.close();
                    }
                    catch (Exception exception) {}
                }
            });
        } else {
            sender.sendMessage(ColorUtil.parse("&cArena &e" + arenaName + "&c's world is not loaded."));
        }
    }

    static Clipboard captureRegion(Arena source) {
        World weWorld = FaweAPI.getWorld((String)source.getWorld());
        BlockVector3 min = BlockVector3.at((int)source.getBorderMinX(), (int)source.getBorderMinY(), (int)source.getBorderMinZ());
        BlockVector3 max = BlockVector3.at((int)source.getBorderMaxX(), (int)source.getBorderMaxY(), (int)source.getBorderMaxZ());
        CuboidRegion region = new CuboidRegion(weWorld, min, max);
        BlockArrayClipboard clipboard = new BlockArrayClipboard((Region)region, (SimpleClipboard)new CPUOptimizedClipboard((Region)region));
        EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder().world(weWorld).fastMode(Boolean.valueOf(true)).changeSetNull().limitUnlimited().build();
        try {
            ForwardExtentCopy copy = new ForwardExtentCopy((Extent)editSession, (Region)region, (Extent)clipboard, region.getMinimumPoint());
            Operations.complete((Operation)copy);
        }
        catch (Throwable var11) {
            if (editSession != null) {
                try {
                    editSession.close();
                }
                catch (Throwable var9) {
                    var11.addSuppressed(var9);
                }
            }
            try {
                clipboard.close();
            }
            catch (Exception exception) {
                // empty catch block
            }
            throw var11;
        }
        if (editSession != null) {
            editSession.close();
        }
        clipboard.setOrigin(clipboard.getMinimumPoint());
        return clipboard;
    }

    static boolean anyArenaOverlaps(String world, int minX, int maxX, int minZ, int maxZ) {
        for (Arena a : ArenaManager.getAll()) {
            if (a.getWorld() == null || !a.getWorld().equalsIgnoreCase(world) || !ArenaCloner.regionsOverlapXZ(minX, maxX, minZ, maxZ, a)) continue;
            return true;
        }
        return false;
    }

    static boolean regionsOverlapXZ(int aMinX, int aMaxX, int aMinZ, int aMaxZ, Arena b) {
        if (!b.isRegionSet()) {
            return false;
        }
        boolean xOverlap = aMinX <= b.getRegionMaxX() && aMaxX >= b.getRegionMinX();
        boolean zOverlap = aMinZ <= b.getRegionMaxZ() && aMaxZ >= b.getRegionMinZ();
        return xOverlap && zOverlap;
    }

    static boolean isRegionAir(String world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        boolean var12;
        block9: {
            World weWorld = FaweAPI.getWorld((String)world);
            try (EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder().world(weWorld).fastMode(Boolean.valueOf(true)).changeSetNull().limitUnlimited().build();){
                for (int x = minX; x <= maxX; ++x) {
                    for (int y = minY; y <= maxY; ++y) {
                        for (int z = minZ; z <= maxZ; ++z) {
                            if (editSession.getBlock(BlockVector3.at((int)x, (int)y, (int)z)).getBlockType().getMaterial().isAir()) continue;
                            var12 = false;
                            break block9;
                        }
                    }
                }
            }
            return true;
        }
        return var12;
    }

    static Arena registerClone(Arena source, int dx) {
        String name = ArenaCloner.nextCloneName(source.getName());
        Arena clone = ArenaManager.create(name);
        clone.setWorld(source.getWorld());
        clone.setRegion(source.getRegionMinX() + dx, source.getRegionMinY(), source.getRegionMinZ(), source.getRegionMaxX() + dx, source.getRegionMaxY(), source.getRegionMaxZ());
        clone.setSpawn1(ArenaCloner.shift(source.getSpawn1(), dx));
        clone.setSpawn2(ArenaCloner.shift(source.getSpawn2(), dx));
        if (source.hasBedObjectives()) {
            clone.setBedObjectives(source.getBlueBedX() + dx, source.getBlueBedY(), source.getBlueBedZ(), source.getRedBedX() + dx, source.getRedBedY(), source.getRedBedZ());
            clone.setBlueBedFacing(source.getBlueBedFacing());
            clone.setRedBedFacing(source.getRedBedFacing());
        }
        if (source.hasCenter()) {
            clone.setCenter(source.getCenterX() + (double)dx, source.getCenterY(), source.getCenterZ());
        }
        clone.setAllowedKits(new ArrayList<String>(source.getAllowedKits()));
        clone.setRegeneration(source.isRegeneration());
        clone.setBuildLimitY(source.getBuildLimitY());
        clone.setEnabled(source.isEnabled());
        ArenaManager.saveArena(clone);
        return clone;
    }

    static String nextCloneName(String source) {
        int n = 1;
        String candidate;
        while (ArenaManager.exists(candidate = source + "_clone" + n)) {
            ++n;
        }
        return candidate;
    }

    private static Location shift(Location loc, int dx) {
        if (loc == null) {
            return null;
        }
        Location c = loc.clone();
        c.setX(c.getX() + (double)dx);
        return c;
    }

    private static void report(CommandSender sender, String source, int placed, int requested, List<String[]> made) {
        if (placed == 0) {
            sender.sendMessage(ColorUtil.parse("&cNo empty space found to place clones of &e" + source + "&c."));
        } else {
            sender.sendMessage(ColorUtil.parse("&aPlaced &e" + placed + "&a/&e" + requested + "&a clones of &e" + source + "&a:"));
            for (String[] c : made) {
                String name = c[0];
                String x = c[1];
                String y = c[2];
                String z = c[3];
                Component line = ColorUtil.parse("&f \u2022 &e" + name + " &f(" + x + ", " + y + ", " + z + ") ").append(ColorUtil.parse("&a[Teleport]").clickEvent(ClickEvent.runCommand((String)("/lifea tpclone " + name))).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse("&fTeleport to &e" + name))));
                sender.sendMessage(line);
            }
            if (placed < requested) {
                sender.sendMessage(ColorUtil.parse("&fStopped early: no more empty space found along +X."));
            }
        }
    }
}

