/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.block.data.type.Bed
 *  org.bukkit.block.data.type.Bed$Part
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.BoundingBox
 */
package me.lifea.arena;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ModifiedBlockTracker;
import me.lifea.arena.snapshot.ArenaSnapshotManager;
import me.lifea.config.PerformanceConfig;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Bed;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;

public final class ArenaRestore {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final boolean DEBUG = PerformanceConfig.isRestoreDebugLogging();

    private ArenaRestore() {
    }

    public static void revertModified(Arena arena) {
        World world;
        if (arena != null && (world = Bukkit.getWorld((String)arena.getWorld())) != null) {
            arena.getModifiedBlockTracker().revert(world);
            ArenaRestore.clearItems(arena);
            ArenaRestore.restoreBedObjectives(arena);
        }
    }

    public static void restoreAsync(Arena arena, Runnable onComplete) {
        if (arena != null && arena.isRegionSet()) {
            ArenaRestore.clearItems(arena);
            if (!arena.isRegeneration()) {
                ArenaRestore.restoreTrackedAsync(arena, () -> {
                    ArenaRestore.restoreBedObjectives(arena);
                    ArenaRestore.run(onComplete);
                });
            } else {
                boolean largeChange;
                ModifiedBlockTracker tracker = arena.getModifiedBlockTracker();
                int changed = tracker.size();
                boolean bl = largeChange = !PerformanceConfig.isModifiedBlockTracking() || changed >= PerformanceConfig.getSchematicRestoreThreshold();
                if (largeChange) {
                    tracker.clear();
                    if (DEBUG) {
                        Logger var10000 = LOG;
                        String var10001 = arena.getName();
                        var10000.info("[ArenaRestore] LARGE restore: arena=" + var10001 + " changed=" + changed + " -> FAWE schematic paste");
                    }
                    ArenaSnapshotManager.restoreArena(arena).whenComplete((v, ex) -> {
                        if (ex != null) {
                            Logger var10000 = LOG;
                            String var10001 = arena.getName();
                            var10000.severe("[ArenaRestore] Schematic restore failed for " + var10001 + ": " + ex.getMessage());
                        }
                        ArenaRestore.restoreBedObjectives(arena);
                        ArenaRestore.run(onComplete);
                    });
                } else {
                    if (DEBUG) {
                        Logger var5 = LOG;
                        String var6 = arena.getName();
                        var5.info("[ArenaRestore] SMALL restore: arena=" + var6 + " changed=" + changed + " -> block-level revert");
                    }
                    ArenaRestore.restoreTrackedAsync(arena, () -> {
                        ArenaRestore.restoreBedObjectives(arena);
                        ArenaRestore.run(onComplete);
                    });
                }
            }
        } else {
            ArenaRestore.run(onComplete);
        }
    }

    private static void restoreTrackedAsync(Arena arena, Runnable onComplete) {
        ModifiedBlockTracker tracker = arena.getModifiedBlockTracker();
        World world = Bukkit.getWorld((String)arena.getWorld());
        ArrayList<Map.Entry<ModifiedBlockTracker.BlockPos, ModifiedBlockTracker.OriginalBlockData>> entries = world == null ? List.of() : new ArrayList<Map.Entry<ModifiedBlockTracker.BlockPos, ModifiedBlockTracker.OriginalBlockData>>(tracker.getEntries());
        tracker.clear();
        if (!entries.isEmpty() && world != null) {
            int perTick = Math.max(1, PerformanceConfig.getRestoreBlocksPerTick());
            AtomicInteger index = new AtomicInteger();
            AtomicReference<BukkitTask> taskRef = new AtomicReference<BukkitTask>();
            taskRef.set(Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), () -> {
                int from = index.get();
                int to = Math.min(entries.size(), from + perTick);
                for (int i = from; i < to; ++i) {
                    Map.Entry entry = (Map.Entry)entries.get(i);
                    ModifiedBlockTracker.BlockPos pos = (ModifiedBlockTracker.BlockPos)entry.getKey();
                    BlockData data = Bukkit.createBlockData((String)((ModifiedBlockTracker.OriginalBlockData)entry.getValue()).blockData());
                    world.getBlockAt(pos.x(), pos.y(), pos.z()).setBlockData(data);
                }
                if (to >= entries.size()) {
                    ((BukkitTask)taskRef.get()).cancel();
                    ArenaRestore.run(onComplete);
                } else {
                    index.set(to);
                }
            }, 0L, 1L));
        } else {
            ArenaRestore.run(onComplete);
        }
    }

    public static void clearItems(Arena arena) {
        World world;
        if (arena != null && arena.getWorld() != null && (world = Bukkit.getWorld((String)arena.getWorld())) != null) {
            int minX = arena.getRegionMinX() - 5;
            int maxX = arena.getRegionMaxX() + 5;
            int minY = arena.getRegionMinY() - 5;
            int maxY = arena.getRegionMaxY() + 5;
            int minZ = arena.getRegionMinZ() - 5;
            int maxZ = arena.getRegionMaxZ() + 5;
            BoundingBox bounds = new BoundingBox((double)minX, (double)minY, (double)minZ, (double)maxX, (double)maxY, (double)maxZ);
            for (Entity entity : world.getNearbyEntities(bounds)) {
                Location loc;
                if (entity instanceof Player || !arena.isInside(loc = entity.getLocation())) continue;
                entity.remove();
            }
        }
    }

    public static void restoreBedObjectives(Arena arena) {
        World world;
        if (arena != null && arena.hasBedObjectives() && (world = Bukkit.getWorld((String)arena.getWorld())) != null) {
            Runnable apply = () -> {
                ArenaRestore.restoreBed(world, arena.getBlueBedX(), arena.getBlueBedY(), arena.getBlueBedZ(), arena.getBlueBedFacing(), true);
                ArenaRestore.restoreBed(world, arena.getRedBedX(), arena.getRedBedY(), arena.getRedBedZ(), arena.getRedBedFacing(), false);
            };
            if (Bukkit.isPrimaryThread()) {
                apply.run();
            } else {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), apply);
            }
        }
    }

    private static void restoreBed(World world, Integer x, Integer y, Integer z, String facingName, boolean blue) {
        Block bedBlock;
        if (x != null && y != null && z != null && !ArenaRestore.isCompleteBed(bedBlock = world.getBlockAt(x.intValue(), y.intValue(), z.intValue()))) {
            BlockFace facing;
            try {
                facing = facingName != null ? BlockFace.valueOf((String)facingName) : BlockFace.NORTH;
            }
            catch (IllegalArgumentException var11) {
                facing = BlockFace.NORTH;
            }
            Material bedMaterial = blue ? Material.BLUE_BED : Material.RED_BED;
            Bed footData = (Bed)Bukkit.createBlockData((Material)bedMaterial);
            footData.setFacing(facing);
            footData.setPart(Bed.Part.FOOT);
            bedBlock.setBlockData((BlockData)footData);
            Bed headData = (Bed)Bukkit.createBlockData((Material)bedMaterial);
            headData.setFacing(facing);
            headData.setPart(Bed.Part.HEAD);
            bedBlock.getRelative(facing).setBlockData((BlockData)headData);
        }
    }

    private static boolean isCompleteBed(Block block) {
        BlockData data = block.getBlockData();
        if (data instanceof Bed) {
            Bed otherBed;
            Bed bed = (Bed)data;
            Block other = bed.getPart() == Bed.Part.HEAD ? block.getRelative(bed.getFacing().getOppositeFace()) : block.getRelative(bed.getFacing());
            BlockData otherData = other.getBlockData();
            if (otherData instanceof Bed && (otherBed = (Bed)otherData).getPart() != bed.getPart()) {
                boolean var10000 = true;
                return var10000;
            }
            boolean var10000 = false;
            return var10000;
        }
        return false;
    }

    private static void run(Runnable callback) {
        if (callback != null) {
            callback.run();
        }
    }
}

