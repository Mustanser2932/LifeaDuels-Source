/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.Listener
 */
package me.lifea.arena;

import org.bukkit.event.Listener;

public final class ArenaGenerationListener
implements Listener {
}

