/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.data.type.Bed
 */
package me.lifea.arena;

import java.util.ArrayList;
import java.util.List;
import me.lifea.arena.ArenaState;
import me.lifea.arena.ModifiedBlockTracker;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Bed;

public class Arena {
    private String name;
    private Location spawn1;
    private Location spawn2;
    private Location regenHold1;
    private Location regenHold2;
    private String world;
    private int regionMinX;
    private int regionMinY;
    private int regionMinZ;
    private int regionMaxX;
    private int regionMaxY;
    private int regionMaxZ;
    private Integer buildLimitY;
    private Integer blueBedX;
    private Integer blueBedY;
    private Integer blueBedZ;
    private Integer redBedX;
    private Integer redBedY;
    private Integer redBedZ;
    private String blueBedFacing;
    private String redBedFacing;
    private Double centerX;
    private Double centerY;
    private Double centerZ;
    private boolean enabled;
    private boolean regeneration = true;
    private boolean inUse = false;
    private boolean dirty = false;
    private boolean regionSet = false;
    private long lastModifiedAtMs = 0L;
    private Integer borderMinX;
    private Integer borderMinY;
    private Integer borderMinZ;
    private Integer borderMaxX;
    private Integer borderMaxY;
    private Integer borderMaxZ;
    private List<String> allowedKits = new ArrayList<String>();
    private ArenaState state = ArenaState.DISABLED;
    private final ModifiedBlockTracker modifiedBlockTracker = new ModifiedBlockTracker();
    private long timesUsed = 0L;
    private long lastUsedAtMs = 0L;

    public Arena(String name) {
        this.name = name;
        this.enabled = false;
        this.state = ArenaState.DISABLED;
    }

    public String getName() {
        return this.name;
    }

    public Location getSpawn1() {
        World bukkitWorld;
        if (this.spawn1 != null && this.spawn1.getWorld() == null && this.world != null && (bukkitWorld = Bukkit.getWorld((String)this.world)) != null) {
            this.spawn1 = new Location(bukkitWorld, this.spawn1.getX(), this.spawn1.getY(), this.spawn1.getZ(), this.spawn1.getYaw(), this.spawn1.getPitch());
        }
        return this.spawn1;
    }

    public Location getSpawn2() {
        World bukkitWorld;
        if (this.spawn2 != null && this.spawn2.getWorld() == null && this.world != null && (bukkitWorld = Bukkit.getWorld((String)this.world)) != null) {
            this.spawn2 = new Location(bukkitWorld, this.spawn2.getX(), this.spawn2.getY(), this.spawn2.getZ(), this.spawn2.getYaw(), this.spawn2.getPitch());
        }
        return this.spawn2;
    }

    public String getWorld() {
        return this.world;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public boolean isInUse() {
        return this.inUse;
    }

    public ArenaState getState() {
        return this.state;
    }

    public ModifiedBlockTracker getModifiedBlockTracker() {
        return this.modifiedBlockTracker;
    }

    public long getTimesUsed() {
        return this.timesUsed;
    }

    public long getLastUsedAtMs() {
        return this.lastUsedAtMs;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpawn1(Location loc) {
        this.spawn1 = loc;
        if (loc != null && loc.getWorld() != null) {
            this.world = loc.getWorld().getName();
        }
        this.syncState();
    }

    public void setSpawn2(Location loc) {
        this.spawn2 = loc;
        if (loc != null && loc.getWorld() != null && this.world == null) {
            this.world = loc.getWorld().getName();
        }
        this.syncState();
    }

    public Location getRegenHold1() {
        World bukkitWorld;
        if (this.regenHold1 != null && this.regenHold1.getWorld() == null && this.world != null && (bukkitWorld = Bukkit.getWorld((String)this.world)) != null) {
            this.regenHold1 = new Location(bukkitWorld, this.regenHold1.getX(), this.regenHold1.getY(), this.regenHold1.getZ(), this.regenHold1.getYaw(), this.regenHold1.getPitch());
        }
        return this.regenHold1;
    }

    public Location getRegenHold2() {
        World bukkitWorld;
        if (this.regenHold2 != null && this.regenHold2.getWorld() == null && this.world != null && (bukkitWorld = Bukkit.getWorld((String)this.world)) != null) {
            this.regenHold2 = new Location(bukkitWorld, this.regenHold2.getX(), this.regenHold2.getY(), this.regenHold2.getZ(), this.regenHold2.getYaw(), this.regenHold2.getPitch());
        }
        return this.regenHold2;
    }

    public void setRegenHold1(Location loc) {
        this.regenHold1 = loc;
        if (loc != null && loc.getWorld() != null && this.world == null) {
            this.world = loc.getWorld().getName();
        }
    }

    public void setRegenHold2(Location loc) {
        this.regenHold2 = loc;
        if (loc != null && loc.getWorld() != null && this.world == null) {
            this.world = loc.getWorld().getName();
        }
    }

    public void setWorld(String world) {
        this.world = world;
    }

    public void setEnabled(boolean val) {
        this.enabled = val;
        this.syncState();
    }

    public void setInUse(boolean val) {
        boolean wasInUse = this.inUse;
        this.inUse = val;
        if (!wasInUse && val) {
            ++this.timesUsed;
            this.lastUsedAtMs = System.currentTimeMillis();
        }
        this.syncState();
    }

    public Integer getBuildLimitY() {
        return this.buildLimitY;
    }

    public void setBuildLimitY(Integer buildLimitY) {
        this.buildLimitY = buildLimitY;
    }

    public boolean isRegeneration() {
        return this.regeneration;
    }

    public void setRegeneration(boolean val) {
        this.regeneration = val;
    }

    public boolean isDirty() {
        return this.dirty;
    }

    public long getLastModifiedAtMs() {
        return this.lastModifiedAtMs;
    }

    public void setDirty(boolean val) {
        this.dirty = val;
        if (val) {
            this.lastModifiedAtMs = System.currentTimeMillis();
        }
    }

    public List<String> getAllowedKits() {
        return this.allowedKits;
    }

    public void setAllowedKits(List<String> kits) {
        this.allowedKits = kits;
    }

    public void setState(ArenaState state) {
        this.state = state;
    }

    public void setRegion(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        this.regionMinX = Math.min(minX, maxX);
        this.regionMinY = Math.min(minY, maxY);
        this.regionMinZ = Math.min(minZ, maxZ);
        this.regionMaxX = Math.max(minX, maxX);
        this.regionMaxY = Math.max(minY, maxY);
        this.regionMaxZ = Math.max(minZ, maxZ);
        this.regionSet = true;
        this.syncState();
    }

    public int getRegionMinX() {
        return this.regionMinX;
    }

    public int getRegionMinY() {
        return this.regionMinY;
    }

    public int getRegionMinZ() {
        return this.regionMinZ;
    }

    public int getRegionMaxX() {
        return this.regionMaxX;
    }

    public int getRegionMaxY() {
        return this.regionMaxY;
    }

    public int getRegionMaxZ() {
        return this.regionMaxZ;
    }

    public boolean isRegionSet() {
        return this.regionSet;
    }

    public void setBlueBed(Block bed) {
        this.blueBedX = bed.getX();
        this.blueBedY = bed.getY();
        this.blueBedZ = bed.getZ();
        this.blueBedFacing = Arena.bedFacingOf(bed);
    }

    public void setRedBed(Block bed) {
        this.redBedX = bed.getX();
        this.redBedY = bed.getY();
        this.redBedZ = bed.getZ();
        this.redBedFacing = Arena.bedFacingOf(bed);
    }

    private static String bedFacingOf(Block bed) {
        return bed.getBlockData() instanceof Bed ? ((Bed)bed.getBlockData()).getFacing().name() : null;
    }

    public Block getBlueBed() {
        World world = this.getSpawn1() != null ? this.getSpawn1().getWorld() : (this.world != null ? Bukkit.getWorld((String)this.world) : null);
        return world != null && this.blueBedX != null ? world.getBlockAt(this.blueBedX.intValue(), this.blueBedY.intValue(), this.blueBedZ.intValue()) : null;
    }

    public Block getRedBed() {
        World world = this.getSpawn2() != null ? this.getSpawn2().getWorld() : (this.world != null ? Bukkit.getWorld((String)this.world) : null);
        return world != null && this.redBedX != null ? world.getBlockAt(this.redBedX.intValue(), this.redBedY.intValue(), this.redBedZ.intValue()) : null;
    }

    public boolean hasBedObjectives() {
        return this.blueBedX != null && this.redBedX != null;
    }

    public Integer getBlueBedX() {
        return this.blueBedX;
    }

    public Integer getBlueBedY() {
        return this.blueBedY;
    }

    public Integer getBlueBedZ() {
        return this.blueBedZ;
    }

    public Integer getRedBedX() {
        return this.redBedX;
    }

    public Integer getRedBedY() {
        return this.redBedY;
    }

    public Integer getRedBedZ() {
        return this.redBedZ;
    }

    public String getBlueBedFacing() {
        return this.blueBedFacing;
    }

    public String getRedBedFacing() {
        return this.redBedFacing;
    }

    public void setBlueBedFacing(String facing) {
        this.blueBedFacing = facing;
    }

    public void setRedBedFacing(String facing) {
        this.redBedFacing = facing;
    }

    public void setBedObjectives(Integer blueBedX, Integer blueBedY, Integer blueBedZ, Integer redBedX, Integer redBedY, Integer redBedZ) {
        this.blueBedX = blueBedX;
        this.blueBedY = blueBedY;
        this.blueBedZ = blueBedZ;
        this.redBedX = redBedX;
        this.redBedY = redBedY;
        this.redBedZ = redBedZ;
    }

    public void setBorderPos1(int x, int y, int z) {
        this.borderMinX = x;
        this.borderMinY = y;
        this.borderMinZ = z;
    }

    public void setBorderPos2(int x, int y, int z) {
        this.borderMaxX = x;
        this.borderMaxY = y;
        this.borderMaxZ = z;
    }

    public void clearBorder() {
        this.borderMaxZ = null;
        this.borderMaxY = null;
        this.borderMaxX = null;
        this.borderMinZ = null;
        this.borderMinY = null;
        this.borderMinX = null;
    }

    public boolean isBorderSet() {
        return this.borderMinX != null && this.borderMaxX != null;
    }

    public int getBorderMinX() {
        return this.borderMinX != null ? Math.min(this.borderMinX, this.borderMaxX) : Math.min(this.regionMinX, this.regionMaxX);
    }

    public int getBorderMinY() {
        return this.borderMinY != null ? Math.min(this.borderMinY, this.borderMaxY) : Math.min(this.regionMinY, this.regionMaxY);
    }

    public int getBorderMinZ() {
        return this.borderMinZ != null ? Math.min(this.borderMinZ, this.borderMaxZ) : Math.min(this.regionMinZ, this.regionMaxZ);
    }

    public int getBorderMaxX() {
        return this.borderMaxX != null ? Math.max(this.borderMinX, this.borderMaxX) : Math.max(this.regionMinX, this.regionMaxX);
    }

    public int getBorderMaxY() {
        return this.borderMaxY != null ? Math.max(this.borderMinY, this.borderMaxY) : Math.max(this.regionMinY, this.regionMaxY);
    }

    public int getBorderMaxZ() {
        return this.borderMaxZ != null ? Math.max(this.borderMinZ, this.borderMaxZ) : Math.max(this.regionMinZ, this.regionMaxZ);
    }

    public boolean hasCenter() {
        return this.centerX != null && this.centerY != null && this.centerZ != null;
    }

    public void setCenter(Location loc) {
        if (loc == null) {
            this.centerX = null;
            this.centerY = null;
            this.centerZ = null;
        } else {
            this.centerX = loc.getX();
            this.centerY = loc.getY();
            this.centerZ = loc.getZ();
        }
    }

    public void setCenter(double x, double y, double z) {
        this.centerX = x;
        this.centerY = y;
        this.centerZ = z;
    }

    public Double getCenterX() {
        return this.centerX;
    }

    public Double getCenterY() {
        return this.centerY;
    }

    public Double getCenterZ() {
        return this.centerZ;
    }

    public Location getRegionCenter() {
        if (!this.regionSet) {
            return null;
        }
        World w = this.spawn1 != null ? this.spawn1.getWorld() : (this.world != null ? Bukkit.getWorld((String)this.world) : null);
        return w == null ? null : new Location(w, (double)(this.getRegionMinX() + this.getRegionMaxX()) / 2.0, (double)(this.getRegionMinY() + this.getRegionMaxY()) / 2.0, (double)(this.getRegionMinZ() + this.getRegionMaxZ()) / 2.0);
    }

    public Location getCenter() {
        if (this.hasCenter()) {
            World w = this.spawn1 != null ? this.spawn1.getWorld() : (this.world != null ? Bukkit.getWorld((String)this.world) : null);
            return new Location(w, this.centerX.doubleValue(), this.centerY.doubleValue(), this.centerZ.doubleValue());
        }
        if (this.spawn1 != null && this.spawn2 != null) {
            World w = this.spawn1.getWorld();
            if (w == null && this.world != null) {
                w = Bukkit.getWorld((String)this.world);
            }
            return new Location(w, (this.spawn1.getX() + this.spawn2.getX()) / 2.0, (this.spawn1.getY() + this.spawn2.getY()) / 2.0, (this.spawn1.getZ() + this.spawn2.getZ()) / 2.0);
        }
        return this.spawn1 != null ? this.spawn1 : this.spawn2;
    }

    public boolean isInside(Location loc) {
        if (!this.regionSet) {
            return false;
        }
        if (!loc.getWorld().getName().equals(this.world)) {
            return false;
        }
        double x = loc.getX();
        double y = loc.getY();
        double z = loc.getZ();
        return x >= (double)this.regionMinX && x < (double)(this.regionMaxX + 1) && y >= (double)this.regionMinY && y < (double)(this.regionMaxY + 1) && z >= (double)this.regionMinZ && z < (double)(this.regionMaxZ + 1);
    }

    public boolean isInsideForBorder(Location loc, double padding) {
        if (!this.regionSet) {
            return false;
        }
        if (!loc.getWorld().getName().equals(this.world)) {
            return false;
        }
        double x = loc.getX();
        double z = loc.getZ();
        return x >= (double)this.regionMinX - padding && x < (double)(this.regionMaxX + 1) + padding && z >= (double)this.regionMinZ - padding && z < (double)(this.regionMaxZ + 1) + padding;
    }

    public boolean isInsideForBorder3D(Location loc, double padding) {
        if (!this.regionSet) {
            return false;
        }
        if (!loc.getWorld().getName().equals(this.world)) {
            return false;
        }
        double x = loc.getX();
        double y = loc.getY();
        double z = loc.getZ();
        return x >= (double)this.regionMinX - padding && x < (double)(this.regionMaxX + 1) + padding && y >= (double)this.regionMinY - padding && y < (double)(this.regionMaxY + 1) + padding && z >= (double)this.regionMinZ - padding && z < (double)(this.regionMaxZ + 1) + padding;
    }

    public double[] clampToBorder(double x, double z, double padding) {
        double clampedX = Math.max((double)this.regionMinX - padding + 0.5, Math.min(x, (double)this.regionMaxX + padding + 0.5));
        double clampedZ = Math.max((double)this.regionMinZ - padding + 0.5, Math.min(z, (double)this.regionMaxZ + padding + 0.5));
        return new double[]{clampedX, clampedZ};
    }

    public boolean isInside(Block block) {
        if (!this.regionSet) {
            return false;
        }
        if (!block.getWorld().getName().equals(this.world)) {
            return false;
        }
        int x = block.getX();
        int y = block.getY();
        int z = block.getZ();
        return x >= this.regionMinX && x <= this.regionMaxX && y >= this.regionMinY && y <= this.regionMaxY && z >= this.regionMinZ && z <= this.regionMaxZ;
    }

    private void syncState() {
        if (!this.enabled) {
            this.state = ArenaState.DISABLED;
        } else if (this.inUse) {
            this.state = ArenaState.IN_USE;
        } else if (this.state != ArenaState.REGENERATING) {
            this.state = ArenaState.AVAILABLE;
        }
    }
}

