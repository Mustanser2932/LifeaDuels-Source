/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fastasyncworldedit.core.FaweAPI
 *  com.fastasyncworldedit.core.extent.clipboard.CPUOptimizedClipboard
 *  com.fastasyncworldedit.core.extent.clipboard.SimpleClipboard
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardReader
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter
 *  com.sk89q.worldedit.function.operation.ForwardExtentCopy
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.regions.CuboidRegion
 *  com.sk89q.worldedit.regions.Region
 *  com.sk89q.worldedit.world.World
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.arena.snapshot;

import com.fastasyncworldedit.core.FaweAPI;
import com.fastasyncworldedit.core.extent.clipboard.CPUOptimizedClipboard;
import com.fastasyncworldedit.core.extent.clipboard.SimpleClipboard;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.world.World;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.ClipboardCache;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

public final class ArenaSnapshotManager {
    private static final Logger LOG = Logger.getLogger("Lifea");

    private ArenaSnapshotManager() {
    }

    public static CompletableFuture<Void> captureArena(Arena arena) {
        if (arena == null) {
            return ArenaSnapshotManager.failed(new IllegalArgumentException("Arena is null"));
        }
        if (!arena.isRegionSet()) {
            return ArenaSnapshotManager.failed(new IllegalStateException("Arena region not set"));
        }
        String worldName = arena.getWorld();
        String schematicName = arena.getName();
        BlockVector3 min = BlockVector3.at((int)arena.getRegionMinX(), (int)arena.getRegionMinY(), (int)arena.getRegionMinZ());
        BlockVector3 max = BlockVector3.at((int)arena.getRegionMaxX(), (int)arena.getRegionMaxY(), (int)arena.getRegionMaxZ());
        return ArenaSnapshotManager.runAsync(() -> {
            World weWorld = ArenaSnapshotManager.requireWorld(worldName);
            CuboidRegion region = new CuboidRegion(min, max);
            BlockArrayClipboard clipboard = new BlockArrayClipboard((Region)region, (SimpleClipboard)new CPUOptimizedClipboard((Region)region));
            EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder().world(weWorld).fastMode(Boolean.valueOf(true)).changeSetNull().limitUnlimited().build();
            try {
                ForwardExtentCopy copy = new ForwardExtentCopy((Extent)editSession, (Region)region, (Extent)clipboard, region.getMinimumPoint());
                Operations.complete((Operation)copy);
                editSession.close();
            }
            catch (Throwable var14) {
                try {
                    editSession.close();
                }
                catch (Throwable s) {
                    var14.addSuppressed(s);
                }
                ClipboardCache.closeQuietly((Clipboard)clipboard);
                throw var14;
            }
            clipboard.setOrigin(clipboard.getMinimumPoint());
            ClipboardCache.store(schematicName, (Clipboard)clipboard);
            File file = ArenaSnapshotManager.schematicFile(schematicName);
            file.getParentFile().mkdirs();
            try (ClipboardWriter writer = BuiltInClipboardFormat.SPONGE_SCHEMATIC.getWriter((OutputStream)new FileOutputStream(file));){
                writer.write((Clipboard)clipboard);
            }
        });
    }

    public static CompletableFuture<Void> pasteArena(String schematicName, Location location) {
        if (location != null && location.getWorld() != null) {
            File file = ArenaSnapshotManager.schematicFile(schematicName);
            String worldName = location.getWorld().getName();
            int x = location.getBlockX();
            int y = location.getBlockY();
            int z = location.getBlockZ();
            return ClipboardCache.pasteSchematic(file, worldName, x, y, z);
        }
        return ArenaSnapshotManager.failed(new IllegalArgumentException("Location or world is null"));
    }

    public static CompletableFuture<Optional<SnapshotInfo>> loadSchematicInfo(String schematicName) {
        if (schematicName != null && !schematicName.isBlank()) {
            File file = ArenaSnapshotManager.schematicFile(schematicName);
            int[] origin = ArenaSnapshotManager.resolveOriginOnMain(schematicName);
            return ArenaSnapshotManager.runAsync(() -> {
                Optional<SnapshotInfo> var7;
                if (!file.isFile()) {
                    return Optional.empty();
                }
                ClipboardFormat format = ClipboardFormats.findByFile((File)file);
                if (format == null) {
                    throw new IllegalStateException("Unsupported schematic format: " + file.getName());
                }
                try (ClipboardReader reader = format.getReader((InputStream)new FileInputStream(file));){
                    Clipboard clipboard = reader.read();
                    BlockVector3 size = clipboard.getDimensions();
                    var7 = Optional.of(new SnapshotInfo(file, schematicName, size.x(), size.y(), size.z(), origin[0], origin[1], origin[2]));
                    try {
                        clipboard.close();
                    }
                    catch (Exception exception) {}
                }
                return var7;
            });
        }
        return CompletableFuture.completedFuture(Optional.empty());
    }

    public static CompletableFuture<Void> restoreArena(Arena arena) {
        if (arena != null && arena.isRegionSet()) {
            String name = arena.getName();
            String worldName = arena.getWorld();
            int x = arena.getRegionMinX();
            int y = arena.getRegionMinY();
            int z = arena.getRegionMinZ();
            return ClipboardCache.get(name) == null && !ArenaSnapshotManager.hasSchematic(name) ? ArenaSnapshotManager.failed(new IllegalStateException("No saved arena schematic: " + name)) : ClipboardCache.pasteFromCache(name, worldName, x, y, z);
        }
        return arena == null ? CompletableFuture.completedFuture(null) : ArenaSnapshotManager.failed(new IllegalStateException("Arena region not set: " + arena.getName()));
    }

    public static void restore(Arena arena, Runnable onComplete) {
        ArenaSnapshotManager.restoreArena(arena).whenComplete((v, ex) -> ArenaSnapshotManager.runOnMain(() -> {
            if (ex != null) {
                LOG.log(Level.SEVERE, "[ArenaSnapshot] Restore failed: " + arena.getName(), (Throwable)ex);
            }
            if (onComplete != null) {
                onComplete.run();
            }
        }));
    }

    public static CompletableFuture<Location> pasteCenteredAtPlayer(String schematicName, Location playerLoc) {
        return playerLoc != null && playerLoc.getWorld() != null ? ArenaSnapshotManager.loadSchematicInfo(schematicName).thenCompose(infoOpt -> {
            if (infoOpt.isEmpty()) {
                return ArenaSnapshotManager.failed(new IllegalStateException("Schematic not found: " + schematicName));
            }
            SnapshotInfo snap = (SnapshotInfo)infoOpt.get();
            int pasteX = playerLoc.getBlockX() - snap.sizeX() / 2;
            int pasteY = playerLoc.getBlockY();
            int pasteZ = playerLoc.getBlockZ() - snap.sizeZ() / 2;
            Location pasteLoc = new Location(playerLoc.getWorld(), (double)pasteX, (double)pasteY, (double)pasteZ);
            return ArenaSnapshotManager.pasteArena(schematicName, pasteLoc).thenApply(v -> pasteLoc);
        }) : ArenaSnapshotManager.failed(new IllegalArgumentException("Player location is invalid"));
    }

    public static CompletableFuture<Void> cloneSchematic(String sourceName, String targetName) {
        File source = ArenaSnapshotManager.schematicFile(sourceName);
        File target = ArenaSnapshotManager.schematicFile(targetName);
        return ArenaSnapshotManager.runAsync(() -> {
            if (!source.isFile()) {
                throw new IllegalStateException("Source schematic not found: " + sourceName);
            }
            target.getParentFile().mkdirs();
            Files.copy(source.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        });
    }

    public static boolean hasSchematic(String schematicName) {
        return ArenaSnapshotManager.schematicFile(schematicName).isFile();
    }

    private static File schematicFolder() {
        Plugin fawe = Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit");
        if (fawe == null) {
            fawe = Bukkit.getPluginManager().getPlugin("WorldEdit");
        }
        return fawe == null ? new File(Lifea.getInstance().getDataFolder(), "schematics") : new File(fawe.getDataFolder(), "schematics");
    }

    static File schematicFile(String schematicName) {
        return new File(ArenaSnapshotManager.schematicFolder(), schematicName.toLowerCase() + ".schem");
    }

    private static World requireWorld(String worldName) {
        World world = FaweAPI.getWorld((String)worldName);
        if (world == null) {
            throw new IllegalStateException("World not loaded: " + worldName);
        }
        return world;
    }

    private static int[] resolveOriginOnMain(String schematicName) {
        if (Bukkit.isPrimaryThread()) {
            return ArenaSnapshotManager.originFromArena(schematicName);
        }
        try {
            return (int[])Bukkit.getScheduler().callSyncMethod((Plugin)Lifea.getInstance(), () -> ArenaSnapshotManager.originFromArena(schematicName)).get();
        }
        catch (Exception e) {
            LOG.log(Level.WARNING, "[ArenaSnapshot] Could not resolve origin on main thread", e);
            return new int[]{0, 0, 0};
        }
    }

    private static int[] originFromArena(String schematicName) {
        int[] nArray;
        Arena arena = ArenaManager.get(schematicName);
        if (arena != null && arena.isRegionSet()) {
            int[] nArray2 = new int[3];
            nArray2[0] = arena.getRegionMinX();
            nArray2[1] = arena.getRegionMinY();
            nArray = nArray2;
            nArray2[2] = arena.getRegionMinZ();
        } else {
            int[] nArray3 = new int[3];
            nArray3[0] = 0;
            nArray3[1] = 0;
            nArray = nArray3;
            nArray3[2] = 0;
        }
        return nArray;
    }

    private static CompletableFuture<Void> runAsync(AsyncTask task) {
        CompletableFuture<Void> future = new CompletableFuture<Void>();
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
            try {
                task.run();
                future.complete(null);
            }
            catch (Throwable error) {
                future.completeExceptionally(error);
            }
        });
        return future;
    }

    private static <T> CompletableFuture<T> runAsync(SupplyingAsyncTask<T> task) {
        CompletableFuture future = new CompletableFuture();
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
            try {
                future.complete(task.run());
            }
            catch (Throwable error) {
                future.completeExceptionally(error);
            }
        });
        return future;
    }

    private static <T> CompletableFuture<T> failed(Throwable error) {
        CompletableFuture future = new CompletableFuture();
        future.completeExceptionally(error);
        return future;
    }

    static void runOnMain(Runnable runnable) {
        if (runnable != null) {
            if (Bukkit.isPrimaryThread()) {
                runnable.run();
            } else {
                Bukkit.getScheduler().runTask((Plugin)Lifea.getInstance(), runnable);
            }
        }
    }

    @FunctionalInterface
    private static interface AsyncTask {
        public void run() throws Exception;
    }

    @FunctionalInterface
    private static interface SupplyingAsyncTask<T> {
        public T run() throws Exception;
    }

    public record SnapshotInfo(File file, String schematicName, int sizeX, int sizeY, int sizeZ, int originMinX, int originMinY, int originMinZ) {
    }
}

