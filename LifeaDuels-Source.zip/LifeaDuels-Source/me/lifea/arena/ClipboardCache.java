/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fastasyncworldedit.core.Fawe
 *  com.fastasyncworldedit.core.FaweAPI
 *  com.fastasyncworldedit.core.configuration.Settings
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardReader
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.session.ClipboardHolder
 *  com.sk89q.worldedit.world.World
 *  org.bukkit.Bukkit
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.arena;

import com.fastasyncworldedit.core.Fawe;
import com.fastasyncworldedit.core.FaweAPI;
import com.fastasyncworldedit.core.configuration.Settings;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.world.World;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.function.Supplier;
import java.util.logging.Logger;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.config.PerformanceConfig;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class ClipboardCache {
    private static final Logger LOG = Logger.getLogger("Lifea");
    private static final int MAX_CONCURRENT = Math.max(1, PerformanceConfig.getMaxConcurrentRestores());
    private static final Semaphore SEMAPHORE;
    private static final Queue<PendingPaste> QUEUE;
    private static final Map<String, Clipboard> RAM_CACHE;

    private ClipboardCache() {
    }

    public static void init() {
        SEMAPHORE.drainPermits();
        SEMAPHORE.release(MAX_CONCURRENT);
    }

    public static void shutdown() {
        PendingPaste pending;
        SEMAPHORE.drainPermits();
        SEMAPHORE.release(MAX_CONCURRENT);
        for (Map.Entry<String, Clipboard> entry : RAM_CACHE.entrySet()) {
            ClipboardCache.closeQuietly(entry.getValue());
        }
        RAM_CACHE.clear();
        while ((pending = QUEUE.poll()) != null) {
            pending.future().completeExceptionally(new CancellationException("Lifea is disabling"));
        }
    }

    public static void store(String arenaName, Clipboard clipboard) {
        Clipboard old;
        if (arenaName != null && clipboard != null && (old = RAM_CACHE.put(arenaName.toLowerCase(), clipboard)) != null && old != clipboard) {
            ClipboardCache.closeQuietly(old);
        }
    }

    public static Clipboard get(String arenaName) {
        return arenaName == null ? null : RAM_CACHE.get(arenaName.toLowerCase());
    }

    public static CompletableFuture<Void> pasteFromCache(String arenaName, String worldName, int x, int y, int z) {
        Clipboard cached = ClipboardCache.get(arenaName);
        if (cached != null) {
            String info = "ram:" + arenaName + " -> " + worldName + " @ " + x + "," + y + "," + z;
            Supplier<CompletableFuture<Void>> supplier = () -> ClipboardCache.doPasteClipboard(cached, worldName, x, y, z);
            return ClipboardCache.enqueue(supplier, info);
        }
        File file = ClipboardCache.schematicFile(arenaName);
        return ClipboardCache.pasteSchematic(file, worldName, x, y, z);
    }

    public static CompletableFuture<Void> pasteSchematic(File file, String worldName, int x, int y, int z) {
        String info = file.getName() + " -> " + worldName + " @ " + x + "," + y + "," + z;
        Supplier<CompletableFuture<Void>> supplier = () -> ClipboardCache.doPasteSchematic(file, worldName, x, y, z);
        return ClipboardCache.enqueue(supplier, info);
    }

    private static CompletableFuture<Void> doPasteSchematic(File file, String worldName, int x, int y, int z) {
        return ClipboardCache.runAsync(() -> {
            if (!file.isFile()) {
                throw new IllegalStateException("Schematic file missing: " + file.getName());
            }
            World weWorld = ClipboardCache.requireWorld(worldName);
            ClipboardFormat format = ClipboardFormats.findByFile((File)file);
            if (format == null) {
                throw new IllegalStateException("Bad schematic format: " + file.getName());
            }
            try (ClipboardReader reader = format.getReader((InputStream)new FileInputStream(file));){
                Clipboard clipboard = reader.read();
                try {
                    ClipboardCache.pasteAndClose(clipboard, weWorld, x, y, z);
                }
                catch (Throwable t) {
                    ClipboardCache.closeQuietly(clipboard);
                    throw t;
                }
            }
            catch (IOException e) {
                throw new RuntimeException("Failed to paste schematic: " + file.getName(), e);
            }
        });
    }

    public static CompletableFuture<Void> pasteClipboard(Clipboard clipboard, String worldName, int x, int y, int z) {
        String info = "clipboard -> " + worldName + " @ " + x + "," + y + "," + z;
        Supplier<CompletableFuture<Void>> supplier = () -> ClipboardCache.doPasteClipboard(clipboard, worldName, x, y, z);
        return ClipboardCache.enqueue(supplier, info);
    }

    private static CompletableFuture<Void> doPasteClipboard(Clipboard clipboard, String worldName, int x, int y, int z) {
        return ClipboardCache.runAsync(() -> {
            World weWorld = ClipboardCache.requireWorld(worldName);
            ClipboardCache.pasteAndClose(clipboard, weWorld, x, y, z);
        });
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void pasteAndClose(Clipboard clipboard, World weWorld, int x, int y, int z) throws Exception {
        try (EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder().world(weWorld).fastMode(Boolean.valueOf(true)).changeSetNull().limitUnlimited().build();){
            clipboard.setOrigin(clipboard.getMinimumPoint());
            Operation operation = new ClipboardHolder(clipboard).createPaste((Extent)editSession).to(BlockVector3.at((int)x, (int)y, (int)z)).ignoreAirBlocks(false).copyEntities(false).copyBiomes(false).build();
            Operations.complete((Operation)operation);
        }
    }

    public static boolean hasQueuedPastes() {
        return SEMAPHORE.availablePermits() < MAX_CONCURRENT || !QUEUE.isEmpty();
    }

    public static void release(Arena arena) {
        String key;
        Clipboard old;
        if (arena != null && (old = RAM_CACHE.remove(key = arena.getName().toLowerCase())) != null) {
            ClipboardCache.closeQuietly(old);
        }
    }

    public static void releaseForMatch(Arena arena) {
    }

    public static void releaseAndDeleteSchematic(Arena arena) {
        if (arena != null) {
            ClipboardCache.release(arena);
            File file = ClipboardCache.schematicFile(arena.getName());
            if (file.exists()) {
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
                    if (!file.delete()) {
                        LOG.warning("[ClipboardCache] Could not delete schematic: " + file.getName());
                    }
                });
            }
        }
    }

    private static CompletableFuture<Void> enqueue(Supplier<CompletableFuture<Void>> supplier, String info) {
        CompletableFuture<Void> future = new CompletableFuture<Void>();
        if (ClipboardCache.tryAcquireAndRun(supplier, future, info)) {
            return future;
        }
        QUEUE.add(new PendingPaste(supplier, future));
        return future;
    }

    private static boolean tryAcquireAndRun(Supplier<CompletableFuture<Void>> supplier, CompletableFuture<Void> future, String info) {
        if (!SEMAPHORE.tryAcquire()) {
            return false;
        }
        ClipboardCache.runWithPermit(supplier, future, info);
        return true;
    }

    private static void runWithPermit(Supplier<CompletableFuture<Void>> supplier, CompletableFuture<Void> future, String info) {
        CompletableFuture<Void> paste;
        try {
            paste = supplier.get();
        }
        catch (Throwable error) {
            future.completeExceptionally(error);
            LOG.severe("[ClipboardCache] Paste could not start: " + info + " - " + error.getMessage());
            ClipboardCache.handOffPermit();
            return;
        }
        paste.whenComplete((v, ex) -> {
            if (ex != null) {
                future.completeExceptionally((Throwable)ex);
                LOG.severe("[ClipboardCache] Paste failed: " + info + " - " + ex.getMessage());
            } else {
                future.complete((Void)v);
            }
            ClipboardCache.deleteStaleClipboards();
            ClipboardCache.handOffPermit();
        });
    }

    private static void handOffPermit() {
        PendingPaste next = QUEUE.poll();
        if (next != null) {
            ClipboardCache.runWithPermit(next.supplier(), next.future(), "(queued)");
        } else {
            SEMAPHORE.release();
        }
    }

    static File schematicFile(String schematicName) {
        Plugin fawe = Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit");
        if (fawe == null) {
            fawe = Bukkit.getPluginManager().getPlugin("WorldEdit");
        }
        File folder = fawe == null ? new File(Lifea.getInstance().getDataFolder(), "schematics") : new File(fawe.getDataFolder(), "schematics");
        return new File(folder, schematicName.toLowerCase() + ".schem");
    }

    private static World requireWorld(String worldName) {
        World world = FaweAPI.getWorld((String)worldName);
        if (world == null) {
            throw new IllegalStateException("World not loaded: " + worldName);
        }
        return world;
    }

    private static CompletableFuture<Void> runAsync(AsyncTask task) {
        CompletableFuture<Void> future = new CompletableFuture<Void>();
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
            try {
                task.run();
                future.complete(null);
            }
            catch (Throwable error) {
                future.completeExceptionally(error);
            }
        });
        return future;
    }

    public static void deleteStaleClipboards() {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)Lifea.getInstance(), () -> {
            try {
                Fawe fawe = Fawe.instance();
                if (fawe == null) {
                    return;
                }
                File faweDir = Fawe.platform().getDirectory();
                if (faweDir == null) {
                    return;
                }
                String clipboardPath = Settings.settings().PATHS.CLIPBOARD;
                File clipboardDir = new File(faweDir, clipboardPath);
                if (!clipboardDir.isDirectory()) {
                    return;
                }
                File[] files = clipboardDir.listFiles();
                if (files == null) {
                    return;
                }
                for (File file : files) {
                    String name = file.getName();
                    String base = name.contains(".") ? name.substring(0, name.lastIndexOf(46)) : name;
                    try {
                        UUID.fromString(base);
                        if (file.delete()) continue;
                        LOG.warning("[ClipboardCache] Could not delete stale clipboard: " + name);
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        // empty catch block
                    }
                }
            }
            catch (Exception e) {
                LOG.warning("[ClipboardCache] Failed to clean stale clipboards: " + e.getMessage());
            }
        });
    }

    public static void closeQuietly(Clipboard clipboard) {
        if (clipboard != null) {
            try {
                clipboard.close();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    static {
        QUEUE = new ConcurrentLinkedQueue<PendingPaste>();
        RAM_CACHE = new ConcurrentHashMap<String, Clipboard>();
        SEMAPHORE = new Semaphore(MAX_CONCURRENT);
    }

    private record PendingPaste(Supplier<CompletableFuture<Void>> supplier, CompletableFuture<Void> future) {
    }

    @FunctionalInterface
    private static interface AsyncTask {
        public void run() throws Exception;
    }
}

