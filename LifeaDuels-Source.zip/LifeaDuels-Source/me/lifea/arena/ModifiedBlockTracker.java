/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.block.data.BlockData
 */
package me.lifea.arena;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;

public class ModifiedBlockTracker {
    private final Map<BlockPos, OriginalBlockData> modifiedBlocks = new ConcurrentHashMap<BlockPos, OriginalBlockData>();
    private final Set<BlockPos> personalPlaced = ConcurrentHashMap.newKeySet();

    public void markPersonalPlaced(int x, int y, int z) {
        this.personalPlaced.add(new BlockPos(x, y, z));
    }

    public void unmarkPersonalPlaced(int x, int y, int z) {
        this.personalPlaced.remove(new BlockPos(x, y, z));
    }

    public boolean isPersonalPlaced(int x, int y, int z) {
        return this.personalPlaced.contains(new BlockPos(x, y, z));
    }

    public void recordOriginal(int x, int y, int z, BlockData original) {
        BlockPos pos = new BlockPos(x, y, z);
        if (!this.modifiedBlocks.containsKey(pos)) {
            this.modifiedBlocks.put(pos, new OriginalBlockData(original.getAsString()));
        }
    }

    public boolean hasChanges() {
        return !this.modifiedBlocks.isEmpty();
    }

    public Collection<Map.Entry<BlockPos, OriginalBlockData>> getEntries() {
        return this.modifiedBlocks.entrySet();
    }

    public void clear() {
        this.modifiedBlocks.clear();
        this.personalPlaced.clear();
    }

    public int size() {
        return this.modifiedBlocks.size();
    }

    public void revert(World world) {
        if (world != null) {
            for (Map.Entry<BlockPos, OriginalBlockData> entry : this.modifiedBlocks.entrySet()) {
                BlockPos pos = entry.getKey();
                BlockData data = Bukkit.createBlockData((String)entry.getValue().blockData());
                world.getBlockAt(pos.x(), pos.y(), pos.z()).setBlockData(data);
            }
            this.modifiedBlocks.clear();
            this.personalPlaced.clear();
        }
    }

    public record BlockPos(int x, int y, int z) {
    }

    public record OriginalBlockData(String blockData) {
    }
}

