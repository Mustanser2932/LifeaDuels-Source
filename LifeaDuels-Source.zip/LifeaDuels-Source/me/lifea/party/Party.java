/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.party;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Party {
    private UUID leader;
    private final List<UUID> members = new ArrayList<UUID>();
    private boolean isPublic = false;

    public Party(UUID leader) {
        this.leader = leader;
        this.members.add(leader);
    }

    public UUID getLeader() {
        return this.leader;
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }

    public List<UUID> getMembers() {
        return this.members;
    }

    public boolean isMember(UUID uuid) {
        return this.members.contains(uuid);
    }

    public boolean isLeader(UUID uuid) {
        return this.leader.equals(uuid);
    }

    public void addMember(UUID uuid) {
        this.members.add(uuid);
    }

    public void removeMember(UUID uuid) {
        this.members.remove(uuid);
    }

    public boolean isPublic() {
        return this.isPublic;
    }

    public void setPublic(boolean isPublic) {
        this.isPublic = isPublic;
    }

    public int size() {
        return this.members.size();
    }
}

