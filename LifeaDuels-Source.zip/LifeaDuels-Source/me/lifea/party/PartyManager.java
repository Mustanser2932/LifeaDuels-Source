/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.permissions.PermissionAttachmentInfo
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.party;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.hotbar.HotbarManager;
import me.lifea.party.Party;
import me.lifea.party.match.PartyDuelRequestManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.PlayerCacheEvictor;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.plugin.Plugin;

public class PartyManager {
    private static final Map<UUID, Party> parties = new ConcurrentHashMap<UUID, Party>();
    private static final Map<UUID, UUID> pendingInvites = new ConcurrentHashMap<UUID, UUID>();

    public static Party getParty(UUID uuid) {
        return parties.get(uuid);
    }

    public static boolean inParty(UUID uuid) {
        return parties.containsKey(uuid);
    }

    public static Set<Party> getParties() {
        return new HashSet<Party>(parties.values());
    }

    public static void createParty(Player leader) {
        if (PartyManager.inParty(leader.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("already-in-party")));
        } else {
            Party party = new Party(leader.getUniqueId());
            parties.put(leader.getUniqueId(), party);
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("created")));
            ScoreboardManager.updatePlayer(leader);
            if (HotbarManager.shouldHaveLobbyItems(leader)) {
                HotbarManager.give(leader, HotbarManager.HotbarType.PARTY_LEADER);
            }
        }
    }

    public static void disbandParty(Player leader) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (!party.isLeader(leader.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        } else {
            PartyDuelRequestManager.cancelForParty(party);
            boolean inMatch = PartyDuelSession.isPartyInSession(party);
            for (UUID uuid : party.getMembers()) {
                parties.remove(uuid);
                PlayerCacheEvictor.evict(uuid);
                Player member = Bukkit.getPlayer((UUID)uuid);
                if (member == null || member.equals((Object)leader)) continue;
                member.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("disbanded-member").replace("%leader%", leader.getName())));
                SoundUtil.play(member, "party-disband");
                if (!PlayerStateManager.shouldHaveLobbyItems(member)) continue;
                PlayerStateManager.resetToLobby(member, inMatch);
            }
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("disbanded")));
            SoundUtil.play(leader, "party-disband");
            if (PlayerStateManager.shouldHaveLobbyItems(leader)) {
                PlayerStateManager.resetToLobby(leader, inMatch);
            }
        }
    }

    public static int getPartyLimit(Player leader) {
        if (leader.isOp()) {
            return Integer.MAX_VALUE;
        }
        int highest = -1;
        for (PermissionAttachmentInfo pai : leader.getEffectivePermissions()) {
            String perm = pai.getPermission();
            if (!pai.getValue() || !perm.startsWith("lifea.party.limit.")) continue;
            try {
                int val = Integer.parseInt(perm.substring("lifea.party.limit.".length()));
                if (val <= highest) continue;
                highest = val;
            }
            catch (NumberFormatException numberFormatException) {}
        }
        return highest > 0 ? highest : ConfigManager.config().getInt("party.max-size", 8);
    }

    public static void invitePlayer(Player leader, Player target) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (!party.isLeader(leader.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        } else if (PartyManager.inParty(target.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("target-in-party").replace("%target%", target.getName())));
        } else if (pendingInvites.containsKey(target.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("already-invited").replace("%target%", target.getName())));
        } else if (party.size() >= PartyManager.getPartyLimit(leader)) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("party-full")));
        } else if (!PlayerSettingsManager.get(target.getUniqueId(), PlayerSettingsManager.Setting.PARTY_INVITES)) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.msg("settings.party-invites-disabled").replace("%player%", target.getName())));
        } else {
            pendingInvites.put(target.getUniqueId(), leader.getUniqueId());
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("invite-sent").replace("%target%", target.getName())));
            for (String _line : ConfigManager.partyMsgs("invite-lines")) {
                String _parsed = _line.replace("%leader%", leader.getName()).replace("%size%", String.valueOf(party.size()));
                if (_parsed.contains("Click Here")) {
                    int idx = _parsed.indexOf("Click Here");
                    String before = _parsed.substring(0, idx);
                    String after = _parsed.substring(idx + "Click Here".length());
                    String clickColor = "";
                    String trimmedBefore = before;
                    Matcher m = Pattern.compile("((?:&[0-9a-fk-orA-FK-OR]|&#[0-9a-fA-F]{6})+)$").matcher(before);
                    if (m.find()) {
                        clickColor = m.group(1);
                        trimmedBefore = before.substring(0, m.start());
                    }
                    target.sendMessage(ColorUtil.parse(trimmedBefore).append(ColorUtil.parse(clickColor + "Click Here").clickEvent(ClickEvent.runCommand((String)("/party join " + leader.getName()))).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse(ConfigManager.partyMsg("invite-click-hover").replace("%leader%", leader.getName()))))).append(ColorUtil.parse(after)));
                    continue;
                }
                target.sendMessage(ColorUtil.parse(_parsed));
            }
            Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                if (pendingInvites.remove(target.getUniqueId(), leader.getUniqueId())) {
                    leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("invite-expired").replace("%target%", target.getName())));
                    target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("invite-expired-target").replace("%leader%", leader.getName())));
                }
            }, 600L);
        }
    }

    public static void togglePublic(Player leader) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (!party.isLeader(leader.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        } else {
            party.setPublic(!party.isPublic());
            leader.sendMessage(ColorUtil.parse(party.isPublic() ? ConfigManager.partyMsg("set-public") : ConfigManager.partyMsg("set-private")));
        }
    }

    public static void joinParty(Player target, Player leader) {
        if (PartyManager.inParty(target.getUniqueId())) {
            target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("already-in-party")));
        } else {
            Party party = PartyManager.getParty(leader.getUniqueId());
            if (party == null) {
                target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
            } else if (party.isPublic()) {
                int maxSize;
                Player leaderPlayer = Bukkit.getPlayer((UUID)leader.getUniqueId());
                int n = maxSize = leaderPlayer != null ? PartyManager.getPartyLimit(leaderPlayer) : ConfigManager.config().getInt("party.max-size", 8);
                if (party.size() >= maxSize) {
                    target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("party-full")));
                } else {
                    PartyManager.addToParty(target, party);
                }
            } else {
                UUID leaderUUID = pendingInvites.get(target.getUniqueId());
                if (leaderUUID != null && leaderUUID.equals(leader.getUniqueId())) {
                    pendingInvites.remove(target.getUniqueId());
                    PartyManager.addToParty(target, party);
                } else {
                    target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-invite")));
                }
            }
        }
    }

    private static void addToParty(Player target, Party party) {
        if (PartyManager.inParty(target.getUniqueId())) {
            target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("already-in-party")));
        } else {
            party.addMember(target.getUniqueId());
            parties.put(target.getUniqueId(), party);
            PartyManager.broadcastParty(party, ColorUtil.parse(ConfigManager.partyMsg("member-joined").replace("%player%", target.getName())));
            ScoreboardManager.setType(target, ScoreboardManager.Type.PARTY, null);
            if (HotbarManager.shouldHaveLobbyItems(target)) {
                HotbarManager.give(target, HotbarManager.HotbarType.PARTY_MEMBER);
            }
        }
    }

    public static void acceptInvite(Player target) {
        UUID leaderUUID = pendingInvites.remove(target.getUniqueId());
        if (leaderUUID == null) {
            target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-invite")));
        } else {
            Player leader = Bukkit.getPlayer((UUID)leaderUUID);
            if (leader != null && leader.isOnline()) {
                Party party = PartyManager.getParty(leaderUUID);
                if (party == null) {
                    target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-invite")));
                } else {
                    PartyManager.addToParty(target, party);
                }
            } else {
                target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("invite-leader-offline")));
            }
        }
    }

    public static void denyInvite(Player target) {
        UUID leaderUUID = pendingInvites.remove(target.getUniqueId());
        if (leaderUUID == null) {
            target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("no-invite")));
        } else {
            Player leader = Bukkit.getPlayer((UUID)leaderUUID);
            target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("invite-denied")));
            if (leader != null && leader.isOnline()) {
                leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("invite-denied-leader").replace("%target%", target.getName())));
            }
        }
    }

    public static void clearInvites(UUID uuid) {
        pendingInvites.remove(uuid);
        pendingInvites.entrySet().removeIf(entry -> ((UUID)entry.getValue()).equals(uuid));
    }

    public static void kickMember(Player leader, Player target) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (!party.isLeader(leader.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        } else if (!party.isMember(target.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-member").replace("%target%", target.getName())));
        } else if (target.equals((Object)leader)) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("cannot-kick-self")));
        } else {
            party.removeMember(target.getUniqueId());
            parties.remove(target.getUniqueId());
            PlayerCacheEvictor.evict(target.getUniqueId());
            target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("kicked").replace("%leader%", leader.getName())));
            PartyManager.broadcastParty(party, ColorUtil.parse(ConfigManager.partyMsg("member-kicked").replace("%player%", target.getName())));
            if (PlayerStateManager.shouldHaveLobbyItems(target)) {
                PlayerStateManager.resetToLobby(target);
            }
        }
    }

    public static void leaveParty(Player player) {
        Party party = PartyManager.getParty(player.getUniqueId());
        if (party == null) {
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (party.isLeader(player.getUniqueId())) {
            PartyManager.disbandParty(player);
        } else {
            PartyDuelRequestManager.cancelForParty(party);
            party.removeMember(player.getUniqueId());
            parties.remove(player.getUniqueId());
            PlayerCacheEvictor.evict(player.getUniqueId());
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("left")));
            PartyManager.broadcastParty(party, ColorUtil.parse(ConfigManager.partyMsg("member-left").replace("%player%", player.getName())));
            if (PlayerStateManager.shouldHaveLobbyItems(player)) {
                PlayerStateManager.resetToLobby(player);
            }
        }
    }

    public static void transferLeader(Player leader, Player target) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party == null) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else if (!party.isLeader(leader.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        } else if (!party.isMember(target.getUniqueId())) {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-member").replace("%target%", target.getName())));
        } else {
            party.setLeader(target.getUniqueId());
            ScoreboardManager.updatePlayer(leader);
            ScoreboardManager.updatePlayer(target);
            if (HotbarManager.shouldHaveLobbyItems(leader)) {
                HotbarManager.give(leader, HotbarManager.HotbarType.PARTY_MEMBER);
            }
            if (HotbarManager.shouldHaveLobbyItems(target)) {
                HotbarManager.give(target, HotbarManager.HotbarType.PARTY_LEADER);
            }
            PartyManager.broadcastParty(party, ColorUtil.parse(ConfigManager.partyMsg("leader-transferred").replace("%old%", leader.getName()).replace("%new%", target.getName())));
        }
    }

    public static void listParty(Player player) {
        Party party = PartyManager.getParty(player.getUniqueId());
        if (party == null) {
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-in-party")));
        } else {
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("info-header")));
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("info-title").replace("%size%", String.valueOf(party.size()))));
            player.sendMessage(ColorUtil.parse(party.isPublic() ? ConfigManager.partyMsg("info-public") : ConfigManager.partyMsg("info-private")));
            for (UUID uuid : party.getMembers()) {
                String name;
                Player member = Bukkit.getPlayer((UUID)uuid);
                String string = name = member != null ? member.getName() : Bukkit.getOfflinePlayer((UUID)uuid).getName();
                if (!party.isLeader(uuid)) continue;
                player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("info-entry-leader").replace("%player%", name)));
            }
            long memberCount = party.getMembers().stream().filter(uuidx -> !party.isLeader((UUID)uuidx)).count();
            if (memberCount > 0L) {
                player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("info-entry-member").replace("%size%", String.valueOf(memberCount))));
            }
            player.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("info-footer")));
        }
    }

    public static void removePlayer(UUID uuid) {
        Party party = parties.get(uuid);
        if (party != null) {
            party.removeMember(uuid);
            parties.remove(uuid);
        }
        PlayerCacheEvictor.evict(uuid);
    }

    public static void broadcastParty(Party party, Component message) {
        for (UUID uuid : party.getMembers()) {
            Player member = Bukkit.getPlayer((UUID)uuid);
            if (member == null) continue;
            member.sendMessage(message);
        }
    }
}

