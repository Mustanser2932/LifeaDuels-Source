/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.lifea.party.match;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.gui.party.PartyTierGUI;
import me.lifea.match.MatchManager;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.party.match.PartyMatchContext;
import me.lifea.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class PartyDuelRequestManager {
    private static final Map<UUID, PartyDuelRequest> pendingByTarget = new ConcurrentHashMap<UUID, PartyDuelRequest>();

    private PartyDuelRequestManager() {
    }

    public static void sendRequest(Player senderLeader, Player targetLeader) {
        Party senderParty = PartyManager.getParty(senderLeader.getUniqueId());
        Party targetParty = PartyManager.getParty(targetLeader.getUniqueId());
        if (senderParty != null && targetParty != null) {
            if (senderParty.isLeader(senderLeader.getUniqueId()) && targetParty.isLeader(targetLeader.getUniqueId())) {
                if (senderParty == targetParty) {
                    senderLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-self")));
                } else if (!PartyDuelSession.isPartyInSession(senderParty) && !PartyDuelSession.isPartyInSession(targetParty)) {
                    if (!PartyDuelRequestManager.hasAnyPlayerInMatch(senderParty) && !PartyDuelRequestManager.hasAnyPlayerInMatch(targetParty)) {
                        PartyDuelRequest request = new PartyDuelRequest(senderLeader.getUniqueId(), targetLeader.getUniqueId(), System.currentTimeMillis());
                        pendingByTarget.put(targetLeader.getUniqueId(), request);
                        senderLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-sent").replace("%target%", targetLeader.getName())));
                        for (String line : ConfigManager.partyMsgs("duel-request-lines")) {
                            int var10002;
                            String var10000 = line.replace("%sender%", senderLeader.getName());
                            String parsed = var10000.replace("%size%", (var10002 = senderParty.size()) + "v" + targetParty.size());
                            if (!parsed.contains("\u1d00\u1d04\u1d04\u1d07\u1d18\u1d1b") && !parsed.contains("Accept")) {
                                targetLeader.sendMessage(ColorUtil.parse(parsed));
                                continue;
                            }
                            targetLeader.sendMessage(ColorUtil.parse("&f[&#FB0000\u1d00\u1d04\u1d04\u1d07\u1d18\u1d1b&f]").clickEvent(ClickEvent.runCommand((String)"/party duelaccept")).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse(ConfigManager.partyMsg("duel-request-hover-accept")))).append(ColorUtil.parse(" &f[&#FB0000\u1d05\u1d07\u0274\u028f&f]").clickEvent(ClickEvent.runCommand((String)"/party dueldeny")).hoverEvent((HoverEventSource)HoverEvent.showText((Component)ColorUtil.parse(ConfigManager.partyMsg("duel-request-hover-deny"))))));
                        }
                        long ticks = 600L;
                        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                            if (pendingByTarget.remove(targetLeader.getUniqueId(), request)) {
                                Player sender = Bukkit.getPlayer((UUID)request.senderLeader());
                                Player target = Bukkit.getPlayer((UUID)request.targetLeader());
                                if (sender != null) {
                                    sender.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-expired-sender")));
                                }
                                if (target != null) {
                                    target.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-expired-target")));
                                }
                            }
                        }, ticks);
                    } else {
                        senderLeader.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
                    }
                } else {
                    senderLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-already-in-match")));
                }
            } else {
                senderLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-leader-only")));
            }
        } else {
            senderLeader.sendMessage(ColorUtil.parse(ConfigManager.msg("party-match.both-leaders-in-parties")));
        }
    }

    public static void acceptRequest(Player targetLeader) {
        PartyDuelRequest request = pendingByTarget.remove(targetLeader.getUniqueId());
        if (request == null) {
            targetLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-no-pending")));
        } else {
            Player senderLeader = Bukkit.getPlayer((UUID)request.senderLeader());
            if (senderLeader != null && senderLeader.isOnline()) {
                Party senderParty = PartyManager.getParty(senderLeader.getUniqueId());
                Party targetParty = PartyManager.getParty(targetLeader.getUniqueId());
                if (senderParty != null && targetParty != null) {
                    if (senderParty.isLeader(senderLeader.getUniqueId()) && targetParty.isLeader(targetLeader.getUniqueId())) {
                        if (!(PartyDuelSession.isPartyInSession(senderParty) || PartyDuelSession.isPartyInSession(targetParty) || PartyDuelRequestManager.hasAnyPlayerInMatch(senderParty) || PartyDuelRequestManager.hasAnyPlayerInMatch(targetParty))) {
                            senderLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-accepted-sender")));
                            targetLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-accepted-target").replace("%sender%", senderLeader.getName())));
                            PartyMatchContext.setDuel(senderLeader.getUniqueId(), targetLeader.getUniqueId());
                            new PartyTierGUI().open(senderLeader);
                        } else {
                            senderLeader.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
                            targetLeader.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
                        }
                    } else {
                        targetLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-leadership-changed")));
                    }
                } else {
                    targetLeader.sendMessage(ColorUtil.parse(ConfigManager.msg("party-match.parties-no-longer-exist")));
                }
            } else {
                targetLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-leader-offline")));
            }
        }
    }

    public static void denyRequest(Player targetLeader) {
        PartyDuelRequest request = pendingByTarget.remove(targetLeader.getUniqueId());
        if (request == null) {
            targetLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-no-pending")));
        } else {
            Player senderLeader = Bukkit.getPlayer((UUID)request.senderLeader());
            targetLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-denied-target")));
            if (senderLeader != null) {
                senderLeader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("duel-request-denied-sender")));
            }
        }
    }

    public static void cancelForParty(Party party) {
        if (party != null) {
            pendingByTarget.entrySet().removeIf(entry -> party.isMember((UUID)entry.getKey()) || party.isMember(((PartyDuelRequest)entry.getValue()).senderLeader()));
        }
    }

    public static void clearFor(UUID uuid) {
        pendingByTarget.remove(uuid);
        pendingByTarget.entrySet().removeIf(entry -> ((PartyDuelRequest)entry.getValue()).senderLeader().equals(uuid));
    }

    private static boolean hasAnyPlayerInMatch(Party party) {
        for (UUID uuid : party.getMembers()) {
            if (!MatchManager.inMatch(uuid) && !PartyDuelSession.inSession(uuid)) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player != null && player.isOnline()) continue;
                return true;
            }
            return true;
        }
        return false;
    }

    public record PartyDuelRequest(UUID senderLeader, UUID targetLeader, long createdAt) {
    }
}

