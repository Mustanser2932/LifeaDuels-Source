/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitTask
 */
package me.lifea.party.match;

import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.arena.Arena;
import me.lifea.arena.ArenaManager;
import me.lifea.arena.ArenaRestore;
import me.lifea.arena.ClipboardCache;
import me.lifea.config.ConfigManager;
import me.lifea.cosmetic.BannerManager;
import me.lifea.cosmetic.TrimManager;
import me.lifea.duel.KitRulesListener;
import me.lifea.gui.GUIManager;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.kit.GamemodeRegistry;
import me.lifea.kit.KitManager;
import me.lifea.kit.KitRuleManager;
import me.lifea.kit.PotionManager;
import me.lifea.kit.custom.CustomKit;
import me.lifea.kit.custom.CustomKitManager;
import me.lifea.match.Match;
import me.lifea.match.MatchManager;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyMatchType;
import me.lifea.player.PlayerDataCache;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import me.lifea.scoreboard.ScoreboardManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.ScoreboardUtil;
import me.lifea.util.SoundUtil;
import me.lifea.util.TitleUtil;
import me.lifea.util.WorldBorderUtil;
import me.lifea.visibility.MatchVisibilityManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

public class PartyDuelSession {
    private static final Map<UUID, PartyDuelSession> sessions = new ConcurrentHashMap<UUID, PartyDuelSession>();
    private final Match match;
    private final Arena arena;
    private final String tier;
    private final String gamemode;
    private final String othersTier;
    private final String othersGamemode;
    private final PartyMatchType type;
    private final List<List<UUID>> teams;
    private final Set<UUID> participants;
    private final Map<UUID, Integer> teamByPlayer = new HashMap<UUID, Integer>();
    private final Map<Integer, Integer> winsByTeam = new HashMap<Integer, Integer>();
    private final Set<UUID> alive = new HashSet<UUID>();
    private final Set<UUID> forfeited = new HashSet<UUID>();
    private final Map<UUID, Integer> partyKillStreak = new HashMap<UUID, Integer>();
    private int currentRound = 1;
    private final UUID customKitOwner;
    private final int customKitSlot;
    private boolean fighting = false;
    private boolean frozen = false;
    private boolean ended = false;
    private long fightStartMillis = -1L;
    private BukkitTask countdownTask;
    final Set<UUID> gappleBoostUsed = new HashSet<UUID>();

    private PartyDuelSession(List<List<UUID>> teams, Arena arena, String tier, String gamemode, String othersTier, String othersGamemode, int rounds, PartyMatchType type, UUID customKitOwner, int customKitSlot) {
        this.teams = teams.stream().map(team -> List.copyOf(team)).toList();
        this.arena = arena;
        this.tier = tier;
        this.gamemode = gamemode;
        this.othersTier = othersTier;
        this.othersGamemode = othersGamemode;
        this.type = type;
        this.customKitOwner = customKitOwner;
        this.customKitSlot = customKitSlot;
        this.participants = new HashSet<UUID>();
        for (int i = 0; i < this.teams.size(); ++i) {
            this.winsByTeam.put(i, 0);
            for (UUID uuid : this.teams.get(i)) {
                this.participants.add(uuid);
                this.teamByPlayer.put(uuid, i);
            }
        }
        arena.setInUse(true);
        Player p1 = PartyDuelSession.firstOnline(this.teams.get(0));
        Player p2 = PartyDuelSession.firstOnline(this.teams.size() > 1 ? this.teams.get(1) : this.teams.get(0));
        this.match = MatchManager.createMatch(p1, p2, tier, gamemode, rounds, Match.MatchType.PARTY, arena.getName(), false);
        MatchManager.registerMatchParticipants(this.participants, this.match);
        for (UUID uuid : this.participants) {
            sessions.put(uuid, this);
        }
    }

    public static PartyDuelSession getSession(UUID uuid) {
        return sessions.get(uuid);
    }

    public static boolean inSession(UUID uuid) {
        return sessions.containsKey(uuid);
    }

    public static Collection<PartyDuelSession> getActiveSessions() {
        return Collections.unmodifiableCollection(sessions.values());
    }

    public Set<UUID> getParticipants() {
        return this.participants;
    }

    public static boolean isPartyInSession(Party party) {
        if (party == null) {
            return false;
        }
        for (UUID uuid : party.getMembers()) {
            if (!PartyDuelSession.inSession(uuid)) continue;
            return true;
        }
        return false;
    }

    public static PartyDuelSession getSessionForParty(Party party) {
        if (party == null) {
            return null;
        }
        for (UUID uuid : party.getMembers()) {
            PartyDuelSession session = sessions.get(uuid);
            if (session == null) continue;
            return session;
        }
        return null;
    }

    public static PartyDuelSession start(List<List<UUID>> teams, String tier, String gamemode, int rounds, PartyMatchType type) {
        return PartyDuelSession.start(teams, tier, gamemode, rounds, type, null);
    }

    public static PartyDuelSession start(List<List<UUID>> teams, String tier, String gamemode, int rounds, PartyMatchType type, String arenaBaseName) {
        boolean explicitArena;
        List<List<UUID>> cleanTeams = teams.stream().filter(teamx -> teamx != null && !teamx.isEmpty()).map(teamx -> {
            ArrayList copy = new ArrayList(teamx);
            return copy;
        }).toList();
        if (cleanTeams.size() < 2) {
            PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.partyMsg("needs-two-teams"));
            return null;
        }
        String bedwarsKitKey = PartyDuelSession.buildKitKey(tier, gamemode);
        if (bedwarsKitKey != null && KitRuleManager.isBedwarsEnabled(bedwarsKitKey)) {
            PartyDuelSession.sendToTeams(cleanTeams, PartyDuelSession.bedwarsPartyDisabledMessage());
            return null;
        }
        for (List<UUID> team : cleanTeams) {
            for (UUID uUID : team) {
                Player player = Bukkit.getPlayer((UUID)uUID);
                if (player != null && player.isOnline()) {
                    if (!MatchManager.inMatch(uUID) && !PartyDuelSession.inSession(uUID)) continue;
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
                    return null;
                }
                PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.partyMsg("members-must-be-online"));
                return null;
            }
        }
        Arena arena = null;
        boolean bl = explicitArena = arenaBaseName != null && !arenaBaseName.isBlank();
        if (explicitArena) {
            arena = ArenaManager.getAvailableForBase(arenaBaseName).orElse(null);
        }
        if (arena == null && !explicitArena) {
            String kitKey = PartyDuelSession.buildKitKey(tier, gamemode);
            arena = ArenaManager.getAvailableForKit(kitKey).orElse(null);
        }
        if (arena == null) {
            PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.msg("duel.no-arena"));
            return null;
        }
        for (List list : cleanTeams) {
            for (UUID uuid : list) {
                Player player2 = Bukkit.getPlayer((UUID)uuid);
                if (player2 == null) continue;
                QueueManager.removePlayerFromQueues(player2);
            }
        }
        ArrayList<Player> onlineParticipants = new ArrayList<Player>();
        for (List<UUID> list : cleanTeams) {
            for (UUID uuid : list) {
                Player player3 = Bukkit.getPlayer((UUID)uuid);
                if (player3 == null) continue;
                onlineParticipants.add(player3);
            }
        }
        GUIManager.closeMenus(onlineParticipants.toArray(new Player[0]));
        for (Player player : onlineParticipants) {
            GUIManager.clearSelectedArena(player.getUniqueId());
        }
        QueueManager.invalidateDuelCountCache();
        PartyDuelSession partyDuelSession = new PartyDuelSession(cleanTeams, arena, tier, gamemode, null, null, rounds, type, null, -1);
        partyDuelSession.beginDuel();
        return partyDuelSession;
    }

    public static PartyDuelSession startCustomKit(List<List<UUID>> teams, String tier, String gamemode, int rounds, PartyMatchType type, UUID customKitOwner, int customKitSlot) {
        return PartyDuelSession.startCustomKit(teams, tier, gamemode, rounds, type, customKitOwner, customKitSlot, null);
    }

    public static PartyDuelSession startCustomKit(List<List<UUID>> teams, String tier, String gamemode, int rounds, PartyMatchType type, UUID customKitOwner, int customKitSlot, String arenaBaseName) {
        boolean bl;
        List<List<UUID>> cleanTeams = teams.stream().filter(teamx -> teamx != null && !teamx.isEmpty()).map(teamx -> {
            ArrayList copy = new ArrayList(teamx);
            return copy;
        }).toList();
        if (cleanTeams.size() < 2) {
            PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.partyMsg("needs-two-teams"));
            return null;
        }
        for (List list : cleanTeams) {
            for (UUID uUID : list) {
                Player player = Bukkit.getPlayer((UUID)uUID);
                if (player != null && player.isOnline()) {
                    if (!MatchManager.inMatch(uUID) && !PartyDuelSession.inSession(uUID)) continue;
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
                    return null;
                }
                PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.partyMsg("members-must-be-online"));
                return null;
            }
        }
        Arena arena = null;
        boolean bl2 = bl = arenaBaseName != null && !arenaBaseName.isBlank();
        if (bl) {
            arena = ArenaManager.getAvailableForBase(arenaBaseName).orElse(null);
        }
        if (arena == null && !bl) {
            arena = ArenaManager.getAvailableForKit("CUSTOM_KITS").orElse(null);
        }
        if (arena == null) {
            String kitKey = PartyDuelSession.buildKitKey(tier, gamemode);
            arena = ArenaManager.getAvailableForKit(kitKey).orElse(null);
        }
        if (arena == null) {
            PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.msg("duel.no-arena"));
            return null;
        }
        for (List list : cleanTeams) {
            for (UUID uuid : list) {
                Player player2 = Bukkit.getPlayer((UUID)uuid);
                if (player2 == null) continue;
                QueueManager.removePlayerFromQueues(player2);
            }
        }
        ArrayList<Player> onlineParticipants = new ArrayList<Player>();
        for (List<UUID> list : cleanTeams) {
            for (UUID uuid : list) {
                Player player3 = Bukkit.getPlayer((UUID)uuid);
                if (player3 == null) continue;
                onlineParticipants.add(player3);
            }
        }
        GUIManager.closeMenus(onlineParticipants.toArray(new Player[0]));
        for (Player player : onlineParticipants) {
            GUIManager.clearSelectedArena(player.getUniqueId());
        }
        QueueManager.invalidateDuelCountCache();
        PartyDuelSession partyDuelSession = new PartyDuelSession(cleanTeams, arena, tier, gamemode, null, null, rounds, type, customKitOwner, customKitSlot);
        partyDuelSession.beginDuel();
        return partyDuelSession;
    }

    public static PartyDuelSession startJuggernaut(List<List<UUID>> teams, String jugTier, String jugGamemode, String othersTier, String othersGamemode, int rounds, String arenaBaseName) {
        boolean bl;
        List<List<UUID>> cleanTeams = teams.stream().filter(t -> t != null && !t.isEmpty()).map(t -> new ArrayList(t)).toList();
        if (cleanTeams.size() < 2) {
            PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.partyMsg("needs-two-teams"));
            return null;
        }
        for (List list : cleanTeams) {
            for (Object uuid : list) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player != null && player.isOnline()) {
                    if (!MatchManager.inMatch((UUID)uuid) && !PartyDuelSession.inSession((UUID)uuid)) continue;
                    player.sendMessage(ColorUtil.parse(ConfigManager.msg("duel.already-in-match")));
                    return null;
                }
                PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.partyMsg("members-must-be-online"));
                return null;
            }
        }
        Arena arena = null;
        boolean bl2 = bl = arenaBaseName != null && !arenaBaseName.isBlank();
        if (bl) {
            arena = ArenaManager.getAvailableForBase(arenaBaseName).orElse(null);
        }
        if (arena == null && !bl) {
            arena = ArenaManager.getAvailableForKit(PartyDuelSession.buildKitKey(jugTier, jugGamemode)).orElse(null);
        }
        if (arena == null) {
            PartyDuelSession.sendToTeams(cleanTeams, ConfigManager.msg("duel.no-arena"));
            return null;
        }
        ArrayList<Player> online = new ArrayList<Player>();
        for (List list : cleanTeams) {
            for (UUID uuid : list) {
                Player p = Bukkit.getPlayer((UUID)uuid);
                if (p == null) continue;
                QueueManager.removePlayerFromQueues(p);
                online.add(p);
            }
        }
        GUIManager.closeMenus(online.toArray(new Player[0]));
        for (Player player : online) {
            GUIManager.clearSelectedArena(player.getUniqueId());
        }
        QueueManager.invalidateDuelCountCache();
        PartyDuelSession session = new PartyDuelSession(cleanTeams, arena, jugTier, jugGamemode, othersTier, othersGamemode, rounds, PartyMatchType.JUGGERNAUT, null, -1);
        session.beginDuel();
        return session;
    }

    public Match getMatch() {
        return this.match;
    }

    public Arena getArena() {
        return this.arena;
    }

    public boolean isFighting() {
        return this.fighting;
    }

    public long getFightingTicksElapsed() {
        return this.fighting && this.fightStartMillis >= 0L ? (System.currentTimeMillis() - this.fightStartMillis) / 50L : 0L;
    }

    public boolean isFrozen() {
        return this.frozen;
    }

    public boolean isEnded() {
        return this.ended;
    }

    public boolean isInCountdown() {
        return this.countdownTask != null && !this.countdownTask.isCancelled() && this.frozen && !this.fighting && !this.ended;
    }

    public boolean useGappleBoost(UUID uuid) {
        return this.gappleBoostUsed.add(uuid);
    }

    public String getTier() {
        return this.tier;
    }

    public String getGamemode() {
        return this.gamemode;
    }

    public String getOthersTier() {
        return this.othersTier;
    }

    public String getOthersGamemode() {
        return this.othersGamemode;
    }

    public boolean isCustomKit() {
        return this.customKitOwner != null;
    }

    public boolean isSameTeam(Player a, Player b) {
        return this.type == PartyMatchType.FFA ? false : this.teamByPlayer.get(a.getUniqueId()).equals(this.teamByPlayer.get(b.getUniqueId()));
    }

    public Location getRespawnLocation(Player player) {
        return this.spawnFor(player.getUniqueId(), 0);
    }

    private void beginDuel() {
        Player p;
        this.arena.getModifiedBlockTracker().clear();
        HashMap<UUID, Set<UUID>> recentOpponents = new HashMap<UUID, Set<UUID>>();
        for (UUID playerId : this.participants) {
            HashSet<UUID> opponents = new HashSet<UUID>();
            for (UUID otherId : this.participants) {
                if (playerId.equals(otherId) || this.type != PartyMatchType.FFA && this.teamByPlayer.get(playerId).equals(this.teamByPlayer.get(otherId))) continue;
                opponents.add(otherId);
            }
            recentOpponents.put(playerId, opponents);
        }
        MatchVisibilityManager.rememberDuelOpponents(recentOpponents);
        for (UUID uuid : this.participants) {
            p = Bukkit.getPlayer((UUID)uuid);
            if (p == null) continue;
            KitEditorGUI.removeIfEditing(p);
            p.closeInventory();
        }
        this.broadcast(ConfigManager.partyMsg("match-starting").replace("%tier%", this.tier).replace("%gamemode%", GamemodeRegistry.getDisplayName(this.tier, this.gamemode)).replace("%rounds%", String.valueOf(this.match.getTotalRounds())));
        this.resetRoundState();
        this.prepareAllPlayers();
        this.updateScoreboards();
        for (UUID uuid : this.participants) {
            p = Bukkit.getPlayer((UUID)uuid);
            if (p == null || !p.isOnline()) continue;
            ScoreboardUtil.createDuelBoard(p);
        }
        this.scheduleHealthIndicatorRefresh();
        this.frozen = true;
        this.fighting = false;
        this.startCountdown();
        MatchVisibilityManager.updateAll();
    }

    private void resetRoundState() {
        this.alive.clear();
        for (UUID uuid : this.participants) {
            Player player;
            if (this.forfeited.contains(uuid) || (player = Bukkit.getPlayer((UUID)uuid)) == null || !player.isOnline()) continue;
            this.alive.add(uuid);
        }
    }

    private boolean canPlayAnotherRound() {
        if (this.ended) {
            return false;
        }
        if (this.type == PartyMatchType.FFA) {
            return this.alive.size() >= 2;
        }
        HashSet<Integer> aliveTeams = new HashSet<Integer>();
        for (UUID uuid : this.alive) {
            Integer team = this.teamByPlayer.get(uuid);
            if (team == null) continue;
            aliveTeams.add(team);
        }
        return aliveTeams.size() >= 2;
    }

    private boolean hasEnoughParticipantsForAnotherRound() {
        if (this.ended) {
            return false;
        }
        if (this.type == PartyMatchType.FFA) {
            int online = 0;
            for (UUID uuid : this.participants) {
                Player player;
                if (this.forfeited.contains(uuid) || (player = Bukkit.getPlayer((UUID)uuid)) == null || !player.isOnline()) continue;
                ++online;
            }
            return online >= 2;
        }
        HashSet<Integer> teamsWithOnline = new HashSet<Integer>();
        for (UUID uuid : this.participants) {
            Integer team;
            Player player;
            if (this.forfeited.contains(uuid) || (player = Bukkit.getPlayer((UUID)uuid)) == null || !player.isOnline() || (team = this.teamByPlayer.get(uuid)) == null) continue;
            teamsWithOnline.add(team);
        }
        return teamsWithOnline.size() >= 2;
    }

    private Integer resolveRoundWinner() {
        if (this.type == PartyMatchType.FFA) {
            return this.alive.size() != 1 ? null : this.teamByPlayer.get(this.alive.iterator().next());
        }
        Integer onlyTeam = this.getOnlyAliveTeam();
        return onlyTeam != null && onlyTeam >= 0 ? onlyTeam : null;
    }

    private Integer determineMatchWinnerOnAbort() {
        Integer survivorTeam = this.getOnlyAliveTeam();
        if (survivorTeam != null && survivorTeam >= 0) {
            return survivorTeam;
        }
        int bestTeam = -1;
        int bestWins = -1;
        for (Map.Entry<Integer, Integer> entry : this.winsByTeam.entrySet()) {
            if (entry.getValue() <= bestWins) continue;
            bestWins = entry.getValue();
            bestTeam = entry.getKey();
        }
        return bestTeam >= 0 ? Integer.valueOf(bestTeam) : null;
    }

    private void handleElimination() {
        if (!this.ended) {
            if (!this.fighting) {
                if (!this.canPlayAnotherRound()) {
                    Integer matchWinner = this.determineMatchWinnerOnAbort();
                    if (matchWinner != null) {
                        this.onMatchEnd(matchWinner);
                    } else {
                        this.endMatch();
                    }
                }
            } else {
                Integer roundWinner = this.resolveRoundWinner();
                if (roundWinner != null) {
                    this.completeRound(roundWinner);
                } else if (!this.canPlayAnotherRound()) {
                    this.fighting = false;
                    Integer matchWinner = this.determineMatchWinnerOnAbort();
                    if (matchWinner != null) {
                        this.onMatchEnd(matchWinner);
                    } else {
                        this.endMatch();
                    }
                }
            }
        }
    }

    private void completeRound(int winningTeam) {
        this.fighting = false;
        this.winsByTeam.put(winningTeam, this.winsByTeam.getOrDefault(winningTeam, 0) + 1);
        ++this.currentRound;
        if (this.winsByTeam.get(winningTeam) >= this.match.getTotalRounds()) {
            this.onMatchEnd(winningTeam);
        } else {
            this.onRoundEnd(winningTeam);
        }
    }

    private void prepareAllPlayers() {
        this.gappleBoostUsed.clear();
        int[] teamOffsets = new int[this.teams.size()];
        int[] globalOffset = new int[]{0};
        for (int teamIndex = 0; teamIndex < this.teams.size(); ++teamIndex) {
            for (UUID uuid : this.teams.get(teamIndex)) {
                int var10000;
                Player player;
                if (this.forfeited.contains(uuid) || (player = Bukkit.getPlayer((UUID)uuid)) == null || !player.isOnline()) continue;
                if (this.type == PartyMatchType.FFA) {
                    int var10003 = globalOffset[0];
                    var10000 = globalOffset[0];
                    globalOffset[0] = var10003 + 1;
                } else {
                    int var8 = teamOffsets[teamIndex];
                    var10000 = teamOffsets[teamIndex];
                    teamOffsets[teamIndex] = var8 + 1;
                }
                player.setInvulnerable(false);
                player.teleport(this.spawnFor(uuid, var10000));
                player.getInventory().clear();
                player.getInventory().setArmorContents((ItemStack[])null);
                player.getInventory().setItemInOffHand((ItemStack)null);
                player.setGameMode(GameMode.SURVIVAL);
                this.healPlayer(player);
                if (this.isCustomKit()) {
                    CustomKitManager.applyCustomKit(player, this.customKitOwner, this.customKitSlot);
                    this.applyCustomKitEffects(player);
                } else if (this.type == PartyMatchType.JUGGERNAUT && teamIndex == 1 && this.othersTier != null) {
                    KitManager.applyKit(player, this.othersTier, this.othersGamemode);
                } else {
                    KitManager.applyKit(player, this.tier, this.gamemode);
                }
                TrimManager.applyTrims(player);
                BannerManager.applyBanner(player);
                WorldBorderUtil.set(player, this.arena);
            }
        }
    }

    private void applyCustomKitEffects(Player player) {
        CustomKit kit;
        if (this.isCustomKit() && player != null && (kit = CustomKitManager.getKit(this.customKitOwner, this.customKitSlot)) != null) {
            if (kit.isSettingEnabled("adventure-mode")) {
                player.setGameMode(GameMode.ADVENTURE);
            }
            for (Map.Entry<String, String> entry : kit.getPotions().entrySet()) {
                String effectName = entry.getKey();
                String[] parts = entry.getValue().split(":");
                try {
                    int durationSec;
                    int amplifier = Integer.parseInt(parts[0]);
                    int n = durationSec = parts.length > 1 ? Integer.parseInt(parts[1]) : -1;
                    PotionEffectType type = PotionEffectType.getByName((String)effectName);
                    if (type == null) continue;
                    int ticks = durationSec <= 0 ? Integer.MAX_VALUE : durationSec * 20;
                    player.addPotionEffect(new PotionEffect(type, ticks, amplifier, false, false, true));
                }
                catch (NumberFormatException numberFormatException) {}
            }
        }
    }

    private void startCountdown() {
        final int countdownSeconds = ConfigManager.config().getInt("duel.countdown-seconds", 5);
        this.countdownTask = Bukkit.getScheduler().runTaskTimer((Plugin)Lifea.getInstance(), new Runnable(){
            int seconds;
            final /* synthetic */ PartyDuelSession this$0;
            {
                this.this$0 = this$0;
                this.seconds = countdownSeconds;
            }

            @Override
            public void run() {
                if (this.this$0.ended) {
                    this.this$0.countdownTask.cancel();
                } else if (this.seconds > 0) {
                    this.this$0.forEachOnline(player -> {
                        TitleUtil.send(player, this.this$0.getTitleKey("countdown"), new String[][]{{"%seconds%", String.valueOf(this.seconds)}});
                        SoundUtil.play(player, this.this$0.getSoundKey("countdown"));
                    });
                    --this.seconds;
                } else {
                    this.this$0.countdownTask.cancel();
                    this.this$0.onCountdownEnd();
                }
            }
        }, 0L, 20L);
    }

    private void onCountdownEnd() {
        if (!this.ended) {
            boolean isMatchPoint = false;
            Integer matchPointTeam = null;
            if (this.match.getTotalRounds() > 1) {
                for (int teamIndex = 0; teamIndex < this.teams.size(); ++teamIndex) {
                    int currentWins = this.winsByTeam.getOrDefault(teamIndex, 0);
                    if (currentWins + 1 < this.match.getTotalRounds()) continue;
                    isMatchPoint = true;
                    matchPointTeam = teamIndex;
                    break;
                }
            }
            String titleKey = this.getTitleKey("go");
            String soundKey = isMatchPoint ? this.getSoundKey("matchpoint") : this.getSoundKey("go");
            String[][] placeholders = this.getGoPlaceholders();
            this.forEachOnline(player -> {
                TitleUtil.send(player, titleKey, placeholders);
                SoundUtil.play(player, soundKey);
            });
            this.frozen = false;
            this.fighting = true;
            this.fightStartMillis = System.currentTimeMillis();
            String potionKey = this.buildPotionKey();
            if (potionKey != null) {
                Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                    if (!this.ended) {
                        this.forEachOnline(p -> PotionManager.applyPotions(p, potionKey));
                    }
                }, 20L);
            }
        }
    }

    public void onPlayerDeath(Player dead, Location deathLocation, Player killer) {
        if (!this.ended && this.fighting && this.alive.remove(dead.getUniqueId())) {
            String killerName;
            dead.setGameMode(GameMode.SPECTATOR);
            dead.setInvulnerable(true);
            MatchVisibilityManager.reset(dead);
            this.partyKillStreak.put(dead.getUniqueId(), 0);
            String string = killerName = killer != null ? killer.getName() : "Something Unknown";
            if (killer != null && !killer.getUniqueId().equals(dead.getUniqueId())) {
                this.partyKillStreak.merge(killer.getUniqueId(), 1, Integer::sum);
            }
            this.broadcast(ConfigManager.partyMsg("kill-message").replace("%killer%", killerName).replace("%victim%", dead.getName()));
            this.handleElimination();
        }
    }

    private void onRoundEnd(int winningTeam) {
        int roundWon = this.currentRound - 1;
        int losingTeam = 1 - winningTeam;
        String winnerDisplay = (winningTeam == 0 ? "&c" : "&9") + this.teamDisplayName(winningTeam);
        String loserDisplay = (losingTeam == 0 ? "&c" : "&9") + this.teamDisplayName(losingTeam);
        int redScore = this.winsByTeam.getOrDefault(0, 0);
        int blueScore = this.winsByTeam.getOrDefault(1, 0);
        List<String> roundMsgs = ConfigManager.msgs("duel.round-win-msg");
        for (UUID uuid : this.participants) {
            Player player = Bukkit.getPlayer((UUID)uuid);
            if (player == null) continue;
            int playerTeam = this.teamByPlayer.get(uuid);
            int playerScore = this.winsByTeam.getOrDefault(playerTeam, 0);
            int opponentScore = this.type == PartyMatchType.FFA ? 0 : this.winsByTeam.getOrDefault(1 - playerTeam, 0);
            String[][] placeholders = new String[][]{{"%score%", String.valueOf(playerScore)}, {"%opponent_score%", String.valueOf(opponentScore)}};
            if (this.teamByPlayer.get(uuid) == winningTeam) {
                TitleUtil.send(player, this.getTitleKey("round-win"), placeholders);
                SoundUtil.play(player, this.getSoundKey("round-win"));
            } else {
                TitleUtil.send(player, this.getTitleKey("round-lose"), placeholders);
                SoundUtil.play(player, this.getSoundKey("round-lose"));
            }
            for (String line : roundMsgs) {
                player.sendMessage(ColorUtil.parse(line.replace("%round%", String.valueOf(roundWon)).replace("%winner%", winnerDisplay).replace("%looser%", loserDisplay).replace("%red_score%", String.valueOf(redScore)).replace("%blue_score%", String.valueOf(blueScore))));
            }
        }
        this.updateScoreboards();
        MatchVisibilityManager.updateAll();
        int freezeSeconds = ConfigManager.config().getInt("duel.round-freeze-seconds", 3);
        ArenaRestore.restoreAsync(this.arena, () -> Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (!this.ended) {
                if (!this.hasEnoughParticipantsForAnotherRound()) {
                    Integer finalWinner = this.determineMatchWinnerOnAbort();
                    if (finalWinner != null) {
                        this.onMatchEnd(finalWinner);
                    } else {
                        this.endMatch();
                    }
                } else {
                    this.proceedToNextRoundParty();
                }
            }
        }, (long)freezeSeconds * 20L));
    }

    private void proceedToNextRoundParty() {
        ArenaRestore.clearItems(this.arena);
        this.arena.getModifiedBlockTracker().clear();
        this.resetRoundState();
        this.prepareAllPlayers();
        this.updateScoreboards();
        ArrayList<Player> roundPlayers = new ArrayList<Player>();
        for (UUID uuid : this.participants) {
            Player p = Bukkit.getPlayer((UUID)uuid);
            if (p == null || !p.isOnline()) continue;
            roundPlayers.add(p);
        }
        this.scheduleHealthIndicatorRefresh();
        this.frozen = true;
        this.fighting = false;
        this.startCountdown();
    }

    private void scheduleHealthIndicatorRefresh() {
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (!this.ended) {
                ArrayList<Player> players = new ArrayList<Player>();
                for (UUID uuid : this.participants) {
                    Player player = Bukkit.getPlayer((UUID)uuid);
                    if (player == null || !player.isOnline()) continue;
                    players.add(player);
                }
                KitRulesListener.refreshHealthIndicators(players);
            }
        }, 1L);
    }

    private void onMatchEnd(int winningTeam) {
        int playerScore;
        int playerTeam;
        Player player;
        int loserScore;
        int winnerScore;
        String loserName;
        String winnerName;
        this.ended = true;
        this.fighting = false;
        this.frozen = false;
        if (this.countdownTask != null) {
            this.countdownTask.cancel();
        }
        List<String> resultMsgs = ConfigManager.msgs("duel." + (switch (this.type) {
            case PartyMatchType.DUEL -> "party-duel-result";
            case PartyMatchType.FFA -> "party-ffa-result";
            case PartyMatchType.SPLIT, PartyMatchType.JUGGERNAUT -> "party-split-result";
            default -> throw new MatchException(null, null);
        }));
        if (this.type == PartyMatchType.FFA) {
            Player ffaWinner = PartyDuelSession.firstOnline(this.teams.get(winningTeam));
            winnerName = ffaWinner != null ? ffaWinner.getName() : "Winner";
            loserName = "";
            winnerScore = this.winsByTeam.getOrDefault(winningTeam, 0);
            loserScore = 0;
        } else {
            winnerName = winningTeam == 0 ? "Team A" : "Team B";
            loserName = winningTeam == 0 ? "Team B" : "Team A";
            winnerScore = this.winsByTeam.getOrDefault(winningTeam, 0);
            loserScore = this.winsByTeam.getOrDefault(1 - winningTeam, 0);
        }
        for (UUID uuid : this.participants) {
            player = Bukkit.getPlayer((UUID)uuid);
            if (player == null) continue;
            playerTeam = this.teamByPlayer.get(uuid);
            playerScore = this.winsByTeam.getOrDefault(playerTeam, 0);
            int opponentScore = this.type == PartyMatchType.FFA ? 0 : this.winsByTeam.getOrDefault(1 - playerTeam, 0);
            String[][] placeholders = new String[][]{{"%score%", String.valueOf(playerScore)}, {"%opponent_score%", String.valueOf(opponentScore)}};
            if (this.teamByPlayer.get(uuid) == winningTeam) {
                TitleUtil.send(player, this.getTitleKey("win"), placeholders);
                SoundUtil.play(player, this.getSoundKey("win"));
                StatsManager.addWin(uuid);
                for (String line : resultMsgs) {
                    player.sendMessage(ColorUtil.parse(line.replace("%score%", this.getScoreString()).replace("%winner%", winnerName).replace("%looser%", loserName).replace("%winner_score%", String.valueOf(winnerScore)).replace("%winnerScore%", String.valueOf(winnerScore)).replace("%loser_score%", String.valueOf(loserScore)).replace("%loserScore%", String.valueOf(loserScore)).replace("%rounds%", String.valueOf(this.match.getTotalRounds())).replace("%kit%", GamemodeRegistry.getDisplayName(this.tier, this.gamemode)).replace("%team_a_color%", "&9").replace("%team_b_color%", "&c")));
                }
                continue;
            }
            TitleUtil.send(player, this.getTitleKey("lose"), placeholders);
            SoundUtil.play(player, this.getSoundKey("lose"));
            StatsManager.addLoss(uuid);
            for (String line : resultMsgs) {
                player.sendMessage(ColorUtil.parse(line.replace("%score%", this.getScoreString()).replace("%winner%", winnerName).replace("%looser%", loserName).replace("%winner_score%", String.valueOf(winnerScore)).replace("%winnerScore%", String.valueOf(winnerScore)).replace("%loser_score%", String.valueOf(loserScore)).replace("%loserScore%", String.valueOf(loserScore)).replace("%rounds%", String.valueOf(this.match.getTotalRounds())).replace("%kit%", GamemodeRegistry.getDisplayName(this.tier, this.gamemode)).replace("%team_a_color%", "&9").replace("%team_b_color%", "&c")));
            }
        }
        for (UUID uuid : this.forfeited) {
            player = Bukkit.getPlayer((UUID)uuid);
            if (player == null || !player.isOnline()) continue;
            playerTeam = this.teamByPlayer.getOrDefault(uuid, -1);
            playerScore = this.winsByTeam.getOrDefault(playerTeam, 0);
            for (String line : resultMsgs) {
                player.sendMessage(ColorUtil.parse(line.replace("%score%", this.getScoreString()).replace("%winner%", winnerName).replace("%looser%", loserName).replace("%winner_score%", String.valueOf(winnerScore)).replace("%winnerScore%", String.valueOf(winnerScore)).replace("%loser_score%", String.valueOf(loserScore)).replace("%loserScore%", String.valueOf(loserScore)).replace("%rounds%", String.valueOf(this.match.getTotalRounds())).replace("%kit%", GamemodeRegistry.getDisplayName(this.tier, this.gamemode)).replace("%team_a_color%", "&9").replace("%team_b_color%", "&c")));
            }
        }
        this.forEachOnline(p -> p.setGameMode(GameMode.SPECTATOR));
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), this::cleanupAll, 40L);
    }

    public void onPlayerQuit(Player quitter) {
        if (!this.ended) {
            UUID quitterUuid = quitter.getUniqueId();
            this.alive.remove(quitterUuid);
            this.forfeited.add(quitterUuid);
            sessions.remove(quitterUuid);
            this.participants.remove(quitterUuid);
            PlayerStateManager.resetToLobby(quitter, true);
            Party party = PartyManager.getParty(quitterUuid);
            if (party != null) {
                party.removeMember(quitterUuid);
            }
            this.broadcast(ConfigManager.partyMsg("match-left").replace("%player%", quitter.getName()));
            this.handleElimination();
        }
    }

    public void forfeit(Player forfeiter) {
        if (!this.ended) {
            UUID forfeiterUuid = forfeiter.getUniqueId();
            this.forfeited.add(forfeiterUuid);
            this.alive.remove(forfeiterUuid);
            sessions.remove(forfeiterUuid);
            this.participants.remove(forfeiterUuid);
            MatchManager.removeMatch(forfeiterUuid);
            forfeiter.sendMessage(ColorUtil.parse(ConfigManager.msg("leave.forfeit")));
            this.broadcast(ConfigManager.partyMsg("match-forfeited").replace("%player%", forfeiter.getName()));
            this.handleElimination();
            PlayerStateManager.resetToLobby(forfeiter, true);
        }
    }

    public void endMatch() {
        if (!this.ended) {
            this.ended = true;
            this.fighting = false;
            this.frozen = false;
            if (this.countdownTask != null) {
                this.countdownTask.cancel();
            }
            this.cleanupAll();
        }
    }

    public static void forceEnd(Player leader) {
        Party party = PartyManager.getParty(leader.getUniqueId());
        if (party != null && party.isLeader(leader.getUniqueId())) {
            PartyDuelSession session = PartyDuelSession.getSessionForParty(party);
            if (session == null) {
                leader.sendMessage(ColorUtil.parse(ConfigManager.msg("party-match.not-in-match")));
            } else {
                session.broadcast("&cParty match force-ended by &f" + leader.getName() + "&c.");
                session.endMatch();
            }
        } else {
            leader.sendMessage(ColorUtil.parse(ConfigManager.partyMsg("not-leader")));
        }
    }

    private Integer getOnlyAliveTeam() {
        HashSet<Integer> aliveTeams = new HashSet<Integer>();
        for (UUID uuid : this.alive) {
            Integer team = this.teamByPlayer.get(uuid);
            if (team == null) continue;
            aliveTeams.add(team);
        }
        if (aliveTeams.isEmpty()) {
            return null;
        }
        if (aliveTeams.size() == 1) {
            return (Integer)aliveTeams.iterator().next();
        }
        return -1;
    }

    private String getScoreString() {
        if (this.type != PartyMatchType.FFA) {
            String var10000 = String.valueOf(this.winsByTeam.getOrDefault(0, 0));
            return var10000 + " - " + String.valueOf(this.winsByTeam.getOrDefault(1, 0));
        }
        ArrayList<CallSite> parts = new ArrayList<CallSite>();
        for (int i = 0; i < this.teams.size(); ++i) {
            String var10001 = this.teamDisplayName(i);
            parts.add((CallSite)((Object)(var10001 + ": " + String.valueOf(this.winsByTeam.getOrDefault(i, 0)))));
        }
        return String.join((CharSequence)" | ", parts);
    }

    private String getMatchPointTargetName(int teamIndex) {
        if (this.type == PartyMatchType.FFA) {
            Player player = PartyDuelSession.firstOnline(this.teams.get(teamIndex));
            return player != null ? player.getName() : "Player";
        }
        return teamIndex == 0 ? "Team A" : "Team B";
    }

    private String[][] getGoPlaceholders() {
        String[][] stringArray;
        if (this.type == PartyMatchType.FFA) {
            String[][] stringArray2 = new String[1][];
            stringArray = stringArray2;
            stringArray2[0] = new String[]{"%total%", String.valueOf(this.participants.size())};
        } else {
            String[][] stringArrayArray = new String[2][];
            stringArrayArray[0] = new String[]{"%team_A_color%", "&9"};
            stringArray = stringArrayArray;
            stringArrayArray[1] = new String[]{"%team_B_color%", "&c"};
        }
        return stringArray;
    }

    private String getTitleKey(String suffix) {
        return (switch (this.type) {
            case PartyMatchType.DUEL -> "party-duel-";
            case PartyMatchType.FFA -> "party-ffa-";
            case PartyMatchType.SPLIT, PartyMatchType.JUGGERNAUT -> "party-split-";
            default -> throw new MatchException(null, null);
        }) + suffix;
    }

    private String getSoundKey(String suffix) {
        return (switch (this.type) {
            case PartyMatchType.DUEL -> "party-duel-";
            case PartyMatchType.FFA -> "party-ffa-";
            case PartyMatchType.SPLIT, PartyMatchType.JUGGERNAUT -> "party-split-";
            default -> throw new MatchException(null, null);
        }) + suffix;
    }

    private String teamDisplayName(int teamIndex) {
        if (this.type == PartyMatchType.FFA) {
            Player player = PartyDuelSession.firstOnline(this.teams.get(teamIndex));
            return player != null ? player.getName() : "Player " + (teamIndex + 1);
        }
        return teamIndex == 0 ? "Team A" : "Team B";
    }

    private Location spawnFor(UUID uuid, int offset) {
        Location base;
        int team = this.teamByPlayer.getOrDefault(uuid, 0);
        if (this.type == PartyMatchType.FFA) {
            Location s1 = this.arena.getSpawn1();
            Location s2 = this.arena.getSpawn2();
            base = new Location(s1.getWorld(), (s1.getX() + s2.getX()) / 2.0, (s1.getY() + s2.getY()) / 2.0, (s1.getZ() + s2.getZ()) / 2.0, s1.getYaw(), s1.getPitch());
        } else {
            base = team == 0 ? this.arena.getSpawn1() : this.arena.getSpawn2();
        }
        Location loc = base.clone();
        int radius = Math.max(0, offset);
        loc.add((double)(radius % 3 - 1), 0.0, (double)(radius / 3));
        return loc;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void cleanupAll() {
        if (this.countdownTask != null) {
            this.countdownTask.cancel();
            this.countdownTask = null;
        }
        ArrayList<Player> online = new ArrayList<Player>();
        try {
            for (UUID uuid : this.participants) {
                sessions.remove(uuid);
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player == null) continue;
                online.add(player);
            }
            for (UUID uuid : this.participants) {
                KitRulesListener.clearBoxingHitsForPlayers(uuid, null);
                KitRulesListener.clearSumoWaterDeath(uuid);
            }
            ArenaRestore.clearItems(this.arena);
            ArenaRestore.restoreAsync(this.arena, () -> {
                this.arena.setInUse(false);
                ClipboardCache.releaseForMatch(this.arena);
            });
            SpectateManager.removeSpectatorsForArena(this.arena.getName());
            for (Player player : online) {
                KitRulesListener.removeHealthIndicator(player);
                if (this.forfeited.contains(player.getUniqueId())) continue;
                Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> PlayerStateManager.resetToLobby(player), 3L);
            }
            MatchVisibilityManager.updateAll();
        }
        finally {
            MatchManager.disposeMatch(this.match);
            for (UUID uuid : this.participants) {
                StatsManager.evictCache(uuid);
                PlayerSettingsManager.evict(uuid);
                PlayerDataCache.evict(uuid);
                KitRulesListener.clearPlayerKitCache(uuid);
            }
            this.alive.clear();
            this.forfeited.clear();
            this.partyKillStreak.clear();
            this.winsByTeam.clear();
            this.teamByPlayer.clear();
            this.participants.clear();
            this.gappleBoostUsed.clear();
        }
    }

    private void updateScoreboards() {
        ScoreboardManager.Type sbType = switch (this.type) {
            case PartyMatchType.DUEL -> ScoreboardManager.Type.PARTY_DUEL;
            case PartyMatchType.FFA -> ScoreboardManager.Type.PARTY_FFA;
            case PartyMatchType.SPLIT, PartyMatchType.JUGGERNAUT -> ScoreboardManager.Type.PARTY_SPLIT;
            default -> throw new MatchException(null, null);
        };
        for (UUID uuid : this.participants) {
            Player player;
            if (this.forfeited.contains(uuid) || (player = Bukkit.getPlayer((UUID)uuid)) == null) continue;
            int team = this.teamByPlayer.getOrDefault(uuid, 0);
            HashMap<String, String> ph = new HashMap<String, String>();
            ph.put("%opponent%", this.type == PartyMatchType.FFA ? "FFA" : (team == 0 ? "Team B" : "Team A"));
            ph.put("%tier%", this.tier);
            ph.put("%gamemode%", this.gamemode);
            int var10002 = this.match.getTotalRounds();
            ph.put("%rounds%", "FT" + var10002);
            int wins = this.winsByTeam.getOrDefault(team, 0);
            ph.put("%wins%", String.valueOf(wins));
            ph.put("%losses%", String.valueOf(Math.max(0, this.currentRound - 1 - wins)));
            ph.put("%team_prefix%", team == 0 ? "&8[&#007BFB&lB&8] " : "&8[&#FB0000&lR&8] ");
            ph.put("%team_color%", team == 0 ? "&#007BFB" : "&#FB0000");
            ScoreboardManager.setType(player, sbType, ph);
        }
    }

    private void forEachOnline(PlayerConsumer consumer) {
        for (UUID uuid : this.participants) {
            Player player;
            if (this.forfeited.contains(uuid) || (player = Bukkit.getPlayer((UUID)uuid)) == null || !player.isOnline()) continue;
            consumer.accept(player);
        }
    }

    private static Player firstOnline(List<UUID> players) {
        for (UUID uuid : players) {
            Player player = Bukkit.getPlayer((UUID)uuid);
            if (player == null || !player.isOnline()) continue;
            return player;
        }
        return null;
    }

    private static String bedwarsPartyDisabledMessage() {
        String message = ConfigManager.partyMsg("bedwars-party-disabled");
        return message != null && !message.startsWith("&cMissing party message:") ? message : "&f\u2139 &#FB0000BedWars &fis a &#FB00001v1-only &fmode and cannot be used in &#FB0000party matches&f.";
    }

    private static void sendToTeams(List<List<UUID>> teams, String message) {
        for (List<UUID> team : teams) {
            for (UUID uuid : team) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player == null) continue;
                player.sendMessage(ColorUtil.parse(message));
            }
        }
    }

    private void broadcast(String message) {
        this.forEachOnline(player -> player.sendMessage(ColorUtil.parse(message)));
    }

    private void healPlayer(Player player) {
        if (player.getAttribute(Attribute.MAX_HEALTH) != null) {
            player.setHealth(player.getAttribute(Attribute.MAX_HEALTH).getValue());
        }
        player.setFoodLevel(20);
        player.setSaturation(5.0f);
        player.setFireTicks(0);
        this.clearPotions(player);
    }

    private void clearPotions(Player player) {
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
    }

    private String buildPotionKey() {
        return PotionManager.buildKey(this.tier, this.gamemode);
    }

    private static String buildKitKey(String tier, String gamemode) {
        if (tier != null && gamemode != null) {
            Map<String, String> tierToSuffix = Map.of("MCTiers", "COM", "PvPTiers", "IO", "SubTiers", "Sub", "CactusTiers", "Cactus", "Extra", "Extra");
            String suffix = tierToSuffix.get(tier);
            return suffix != null ? gamemode + "-" + suffix : gamemode;
        }
        return null;
    }

    public int getTotalPlayers() {
        return this.participants.size();
    }

    public int getAlivePlayers() {
        return this.alive.size();
    }

    public int getTeamTotal(int teamIndex) {
        return teamIndex >= 0 && teamIndex < this.teams.size() ? this.teams.get(teamIndex).size() : 0;
    }

    public int getTeamAlive(int teamIndex) {
        int count = 0;
        for (UUID uuid : this.alive) {
            if (this.teamByPlayer.getOrDefault(uuid, -1) != teamIndex) continue;
            ++count;
        }
        return count;
    }

    public int getTeamScore(int teamIndex) {
        return this.winsByTeam.getOrDefault(teamIndex, 0);
    }

    public int getPartyKillStreak(UUID uuid) {
        return this.partyKillStreak.getOrDefault(uuid, 0);
    }

    public int getPlayerTeamIndex(UUID uuid) {
        return this.teamByPlayer.getOrDefault(uuid, 0);
    }

    public boolean isAlive(UUID uuid) {
        return this.alive.contains(uuid);
    }

    public boolean isParticipant(UUID uuid) {
        return this.participants.contains(uuid);
    }

    public UUID getAnyParticipantId() {
        return this.participants.isEmpty() ? null : this.participants.iterator().next();
    }

    public PartyMatchType getMatchType() {
        return this.type;
    }

    private static interface PlayerConsumer {
        public void accept(Player var1);
    }
}

