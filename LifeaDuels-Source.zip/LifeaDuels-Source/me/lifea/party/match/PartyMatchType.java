/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.party.match;

public final class PartyMatchType
extends Enum<PartyMatchType> {
    public static final /* enum */ PartyMatchType DUEL = new PartyMatchType();
    public static final /* enum */ PartyMatchType SPLIT = new PartyMatchType();
    public static final /* enum */ PartyMatchType FFA = new PartyMatchType();
    public static final /* enum */ PartyMatchType JUGGERNAUT = new PartyMatchType();
    private static final /* synthetic */ PartyMatchType[] $VALUES;

    public static PartyMatchType[] values() {
        return (PartyMatchType[])$VALUES.clone();
    }

    public static PartyMatchType valueOf(String name) {
        return Enum.valueOf(PartyMatchType.class, name);
    }

    private static PartyMatchType[] $values() {
        return new PartyMatchType[]{DUEL, SPLIT, FFA};
    }

    private static PartyMatchType[] $values$() {
        return new PartyMatchType[]{DUEL, SPLIT, FFA, JUGGERNAUT};
    }

    private static /* synthetic */ PartyMatchType[] $values$$() {
        return new PartyMatchType[]{DUEL, SPLIT, FFA, JUGGERNAUT};
    }

    static {
        $VALUES = PartyMatchType.$values$$();
    }
}

