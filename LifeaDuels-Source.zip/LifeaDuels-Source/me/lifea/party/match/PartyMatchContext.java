/*
 * Decompiled with CFR 0.152.
 */
package me.lifea.party.match;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.party.match.PartyMatchType;

public final class PartyMatchContext {
    private static final Map<UUID, Context> contexts = new ConcurrentHashMap<UUID, Context>();
    private static final Map<UUID, UUID> customKitOwners = new ConcurrentHashMap<UUID, UUID>();
    private static final Map<UUID, Integer> customKitSlots = new ConcurrentHashMap<UUID, Integer>();
    private static final Map<UUID, String[]> jugOthersKit = new ConcurrentHashMap<UUID, String[]>();

    private PartyMatchContext() {
    }

    public static void setCustomKit(UUID leader, UUID owner, int slot) {
        customKitOwners.put(leader, owner);
        customKitSlots.put(leader, slot);
    }

    public static UUID getCustomKitOwner(UUID leader) {
        return customKitOwners.get(leader);
    }

    public static int getCustomKitSlot(UUID leader) {
        return customKitSlots.getOrDefault(leader, -1);
    }

    public static boolean hasCustomKit(UUID leader) {
        return customKitOwners.containsKey(leader) && customKitSlots.containsKey(leader);
    }

    public static void clearCustomKit(UUID leader) {
        customKitOwners.remove(leader);
        customKitSlots.remove(leader);
    }

    public static void setJuggernaut(UUID leader, List<UUID> juggernauts, List<UUID> others) {
        contexts.put(leader, new Context(PartyMatchType.JUGGERNAUT, null, List.copyOf(juggernauts), List.copyOf(others)));
    }

    public static void setJuggernautOthersKit(UUID leader, String tier, String gamemode) {
        jugOthersKit.put(leader, new String[]{tier, gamemode});
    }

    public static String[] getJugOthersKit(UUID leader) {
        return jugOthersKit.get(leader);
    }

    public static boolean hasJugOthersKit(UUID leader) {
        return jugOthersKit.containsKey(leader);
    }

    public static void setDuel(UUID leader, UUID opponentLeader) {
        contexts.put(leader, new Context(PartyMatchType.DUEL, opponentLeader, List.of(), List.of()));
    }

    public static void setSplit(UUID leader, List<UUID> teamA, List<UUID> teamB) {
        contexts.put(leader, new Context(PartyMatchType.SPLIT, null, List.copyOf(teamA), List.copyOf(teamB)));
    }

    public static void setFfa(UUID leader) {
        contexts.put(leader, new Context(PartyMatchType.FFA, null, List.of(), List.of()));
    }

    public static Context get(UUID leader) {
        return contexts.get(leader);
    }

    public static Context remove(UUID leader) {
        return contexts.remove(leader);
    }

    public static void clearFor(UUID uuid) {
        contexts.remove(uuid);
        customKitOwners.remove(uuid);
        customKitSlots.remove(uuid);
        jugOthersKit.remove(uuid);
        contexts.entrySet().removeIf(entry -> {
            Context context = (Context)entry.getValue();
            return uuid.equals(context.opponentLeader()) || context.teamA().contains(uuid) || context.teamB().contains(uuid);
        });
    }

    public static List<List<UUID>> singletonTeams(List<UUID> players) {
        ArrayList<List<UUID>> teams = new ArrayList<List<UUID>>();
        for (UUID player : players) {
            teams.add(List.of(player));
        }
        return teams;
    }

    public record Context(PartyMatchType type, UUID opponentLeader, List<UUID> teamA, List<UUID> teamB) {
    }
}

