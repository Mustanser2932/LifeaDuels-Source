/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.datacomponent.DataComponentTypes
 *  io.papermc.paper.datacomponent.item.UseCooldown
 *  net.kyori.adventure.key.Key
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeModifier
 *  org.bukkit.attribute.AttributeModifier$Operation
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.EquipmentSlotGroup
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package me.lifea.hotbar;

import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.UseCooldown;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.lifea.Lifea;
import me.lifea.command.SettingsCommand;
import me.lifea.config.ConfigManager;
import me.lifea.gui.DuelMenuGUI;
import me.lifea.gui.GUIManager;
import me.lifea.gui.party.PartyManagementGUI;
import me.lifea.gui.party.PartyMatchGUI;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.PlayerStateManager;
import me.lifea.queue.QueueManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.ColorUtil;
import me.lifea.util.HeadUtil;
import me.lifea.util.LoreUtil;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class HotbarManager {
    private static final Map<UUID, Map<Integer, String>> slotActionCache = new ConcurrentHashMap<UUID, Map<Integer, String>>();
    private static final Map<UUID, HotbarType> currentType = new ConcurrentHashMap<UUID, HotbarType>();
    private static final Map<HotbarType, Map<Integer, CachedSlot>> ITEM_CACHE = new ConcurrentHashMap<HotbarType, Map<Integer, CachedSlot>>();
    private static final Map<HotbarType, Map<Integer, String>> SLOT_CACHE = new ConcurrentHashMap<HotbarType, Map<Integer, String>>();
    private static boolean restrictionsEnabled = true;
    static final Key HOTBAR_COOLDOWN_GROUP = Key.key((String)"lifea", (String)"hotbar");

    public static boolean restrictionsEnabled() {
        return restrictionsEnabled;
    }

    public static void setRestrictionsEnabled(boolean enabled) {
        restrictionsEnabled = enabled;
        ConfigManager.config().set("spawn-items-restrictions", (Object)enabled);
        Lifea.getInstance().saveConfig();
    }

    public static void init() {
        restrictionsEnabled = ConfigManager.config().getBoolean("spawn-items-restrictions", true);
        for (HotbarType type : HotbarType.values()) {
            HashMap<Integer, CachedSlot> items = new HashMap<Integer, CachedSlot>();
            HashMap<Integer, String> slots = new HashMap<Integer, String>();
            for (String path : HotbarManager.sectionsForType(type)) {
                ConfigurationSection section = ConfigManager.config().getConfigurationSection(path);
                if (section == null) continue;
                for (String key : section.getKeys(false)) {
                    int slot;
                    ConfigurationSection itemSec = section.getConfigurationSection(key);
                    if (itemSec == null || (slot = itemSec.getInt("slot", -1) - 1) < 0 || slot > 8) continue;
                    slots.put(slot, key.toLowerCase());
                    items.put(slot, new CachedSlot(key.toLowerCase(), HotbarManager.buildItem(itemSec)));
                }
            }
            ITEM_CACHE.put(type, items);
            SLOT_CACHE.put(type, slots);
        }
    }

    public static void reload() {
        ITEM_CACHE.clear();
        SLOT_CACHE.clear();
        HotbarManager.init();
    }

    public static void shutdown() {
        ITEM_CACHE.clear();
        SLOT_CACHE.clear();
        slotActionCache.clear();
        currentType.clear();
    }

    private static ItemStack buildItem(ConfigurationSection itemSec) {
        Material mat = Material.matchMaterial((String)itemSec.getString("material", "STONE"));
        if (mat == null) {
            mat = Material.STONE;
        }
        String name = itemSec.getString("name", "");
        List<Component> lore = LoreUtil.read(itemSec, "lore");
        ItemStack item = new ItemStack(mat);
        HeadUtil.applyTexture(item, itemSec);
        item.editMeta(meta -> {
            meta.displayName(ColorUtil.parse(name));
            if (!lore.isEmpty()) {
                meta.lore(lore);
            }
            meta.addItemFlags(ItemFlag.values());
            meta.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(NamespacedKey.fromString((String)"lifea:no_cooldown"), 1024.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        });
        item.setData(DataComponentTypes.USE_COOLDOWN, (Object)((UseCooldown)UseCooldown.useCooldown((float)1.1f).build()));
        return item;
    }

    public static void give(Player player, HotbarType type) {
        if (HotbarManager.shouldHaveLobbyItems(player)) {
            Map<Integer, CachedSlot> pmItems;
            UUID uuid = player.getUniqueId();
            HotbarType previous = currentType.get(uuid);
            HashMap<Integer, String> slotActions = new HashMap<Integer, String>();
            boolean partyInMatch = false;
            if (type == HotbarType.PARTY_MEMBER) {
                Party p = PartyManager.getParty(player.getUniqueId());
                partyInMatch = p != null && PartyDuelSession.isPartyInSession(p);
            }
            Map prevSlots = previous != null ? SLOT_CACHE.getOrDefault((Object)previous, Collections.emptyMap()) : Collections.emptyMap();
            Map newSlots = SLOT_CACHE.getOrDefault((Object)type, Collections.emptyMap());
            Map items = ITEM_CACHE.getOrDefault((Object)type, Collections.emptyMap());
            Iterator<Object> iterator = prevSlots.keySet().iterator();
            while (iterator.hasNext()) {
                int n = (Integer)iterator.next();
                if (newSlots.containsKey(n)) continue;
                player.getInventory().setItem(n, (ItemStack)null);
            }
            for (Map.Entry entry : items.entrySet()) {
                ItemStack existing;
                int slot = (Integer)entry.getKey();
                CachedSlot cached = (CachedSlot)entry.getValue();
                if ("spectate".equalsIgnoreCase(cached.action) && !partyInMatch) {
                    player.getInventory().setItem(slot, (ItemStack)null);
                    continue;
                }
                if (previous == type && prevSlots.containsKey(slot) && (existing = player.getInventory().getItem(slot)) != null && existing.getType() != Material.AIR) {
                    slotActions.put(slot, cached.action);
                    continue;
                }
                player.getInventory().setItem(slot, cached.item.clone());
                slotActions.put(slot, cached.action);
            }
            if (type == HotbarType.PARTY_MEMBER && !partyInMatch && (pmItems = ITEM_CACHE.get((Object)HotbarType.PARTY_MEMBER)) != null) {
                for (Map.Entry<Integer, CachedSlot> entry : pmItems.entrySet()) {
                    if (!"spectate".equalsIgnoreCase(entry.getValue().action)) continue;
                    player.getInventory().setItem(entry.getKey().intValue(), (ItemStack)null);
                    break;
                }
            }
            currentType.put(uuid, type);
            slotActionCache.put(uuid, slotActions);
        }
    }

    private static String[] sectionsForType(HotbarType type) {
        return switch (type.ordinal()) {
            case 0 -> new String[]{"hotbar.spawn"};
            case 1 -> new String[]{"hotbar.spawn", "hotbar.queue"};
            case 2 -> new String[]{"hotbar.party", "hotbar.party-leader"};
            case 3 -> new String[]{"hotbar.party", "hotbar.party-member"};
            default -> throw new MatchException(null, null);
        };
    }

    public static boolean shouldHaveLobbyItems(Player player) {
        return PlayerStateManager.shouldHaveLobbyItems(player);
    }

    public static void clearCache(Player player) {
        HotbarManager.clearCache(player.getUniqueId());
    }

    public static void clearCache(UUID uuid) {
        slotActionCache.remove(uuid);
        currentType.remove(uuid);
    }

    public static boolean isHotbarSlot(Player player, int slot) {
        Map<Integer, String> actions = slotActionCache.get(player.getUniqueId());
        return actions != null && actions.containsKey(slot);
    }

    public static void handleClick(Player player, int slot, HotbarType type) {
        String action;
        Map<Integer, String> slotActions;
        if (SpawnManager.isMainWorld(player) && (slotActions = slotActionCache.get(player.getUniqueId())) != null && (action = slotActions.get(slot)) != null) {
            switch (type.ordinal()) {
                case 0: 
                case 1: {
                    HotbarManager.handleSpawnAction(player, action, type);
                    break;
                }
                case 2: 
                case 3: {
                    HotbarManager.handlePartyAction(player, action);
                }
            }
        }
    }

    private static void handleSpawnAction(Player player, String action, HotbarType type) {
        switch (action) {
            case "queue": {
                GUIManager.openQueueMainMenu(player);
                break;
            }
            case "kiteditor": {
                new DuelMenuGUI("Duel-menu", null, DuelMenuGUI.Mode.KIT_EDITOR).open(player);
                break;
            }
            case "party": {
                if (PartyManager.inParty(player.getUniqueId())) {
                    PartyManager.listParty(player);
                    break;
                }
                PartyManager.createParty(player);
                break;
            }
            case "settings": {
                SettingsCommand.openSettings(player);
                break;
            }
            case "quickqueue": {
                QueueManager.quickQueue(player);
                break;
            }
            case "leavequeue": {
                if (type != HotbarType.QUEUE) break;
                QueueManager.leaveQueue(player);
            }
        }
    }

    private static void handlePartyAction(Player player, String action) {
        switch (action) {
            case "partyinfo": {
                PartyManager.listParty(player);
                break;
            }
            case "partymanagement": {
                Party party = PartyManager.getParty(player.getUniqueId());
                if (party == null || !party.isLeader(player.getUniqueId())) break;
                new PartyManagementGUI(player, party, 0).open();
                break;
            }
            case "match": {
                new PartyMatchGUI().open(player);
                break;
            }
            case "spectate": {
                Party spectateParty = PartyManager.getParty(player.getUniqueId());
                if (spectateParty == null) {
                    return;
                }
                if (!PartyDuelSession.isPartyInSession(spectateParty)) {
                    player.sendMessage(ColorUtil.parse("&cYour party is not currently in a match."));
                    return;
                }
                PartyDuelSession partySession = PartyDuelSession.getSessionForParty(spectateParty);
                if (partySession == null) {
                    return;
                }
                Player targetPlayer = Bukkit.getPlayer((UUID)partySession.getMatch().getPlayer1());
                if (targetPlayer == null || !targetPlayer.isOnline()) {
                    player.sendMessage(ColorUtil.parse("&cNo active participants found in the party match."));
                    return;
                }
                SpectateManager.startSpectating(player, targetPlayer);
                break;
            }
            case "leaveparty": {
                PartyManager.leaveParty(player);
                break;
            }
            case "disbandparty": {
                PartyManager.disbandParty(player);
            }
        }
    }

    public static final class HotbarType
    extends Enum<HotbarType> {
        public static final /* enum */ HotbarType SPAWN = new HotbarType();
        public static final /* enum */ HotbarType QUEUE = new HotbarType();
        public static final /* enum */ HotbarType PARTY_LEADER = new HotbarType();
        public static final /* enum */ HotbarType PARTY_MEMBER = new HotbarType();
        private static final /* synthetic */ HotbarType[] $VALUES;

        public static HotbarType[] values() {
            return (HotbarType[])$VALUES.clone();
        }

        public static HotbarType valueOf(String name) {
            return Enum.valueOf(HotbarType.class, name);
        }

        private static HotbarType[] $values() {
            return new HotbarType[]{SPAWN, QUEUE, PARTY_LEADER, PARTY_MEMBER};
        }

        private static HotbarType[] $values$() {
            return new HotbarType[]{SPAWN, QUEUE, PARTY_LEADER, PARTY_MEMBER};
        }

        private static /* synthetic */ HotbarType[] $values$$() {
            return new HotbarType[]{SPAWN, QUEUE, PARTY_LEADER, PARTY_MEMBER};
        }

        static {
            $VALUES = HotbarType.$values$$();
        }
    }

    private record CachedSlot(String action, ItemStack item) {
    }
}

