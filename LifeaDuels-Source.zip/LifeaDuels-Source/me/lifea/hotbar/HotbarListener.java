/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.entity.ProjectileLaunchEvent
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryAction
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.event.inventory.InventoryType$SlotType
 *  org.bukkit.event.player.PlayerChangedWorldEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemHeldEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.projectiles.ProjectileSource
 */
package me.lifea.hotbar;

import java.util.Iterator;
import java.util.UUID;
import me.lifea.Lifea;
import me.lifea.config.ConfigManager;
import me.lifea.duel.DuelSession;
import me.lifea.gui.kit.KitEditorGUI;
import me.lifea.gui.kit.custom.CustomKitEditorGUI;
import me.lifea.hotbar.HotbarManager;
import me.lifea.match.MatchManager;
import me.lifea.party.Party;
import me.lifea.party.PartyManager;
import me.lifea.party.match.PartyDuelSession;
import me.lifea.player.PlayerCache;
import me.lifea.player.PlayerSettingsManager;
import me.lifea.player.PlayerStateManager;
import me.lifea.player.StatsManager;
import me.lifea.queue.QueueManager;
import me.lifea.spawn.SpawnElytraManager;
import me.lifea.spawn.SpawnManager;
import me.lifea.spectate.SpectateManager;
import me.lifea.util.IpCache;
import me.lifea.util.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;

public class HotbarListener
implements Listener {
    private static boolean isKitEditing(Player player) {
        return KitEditorGUI.isEditing(player) || CustomKitEditorGUI.isEditing(player);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        IpCache.store(player);
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
            if (player.isOnline()) {
                IpCache.store(player);
            }
        }, 20L);
        PlayerCache.loadOnJoin(player);
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> HotbarListener.applyLobbyOnReconnect(player, true), 10L);
    }

    private static void applyLobbyOnReconnect(Player player, boolean cosmeticsAlreadyDelayed) {
        PlayerStateManager.PlayerState state;
        if (player != null && player.isOnline() && (state = PlayerStateManager.getState(player)) != PlayerStateManager.PlayerState.MATCH && state != PlayerStateManager.PlayerState.SPECTATOR) {
            if (cosmeticsAlreadyDelayed) {
                PlayerStateManager.resetToLobby(player, true, false);
                PlayerStateManager.refreshLobbyCosmetics(player);
            } else {
                PlayerStateManager.resetToLobby(player);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        IpCache.remove(e.getPlayer().getUniqueId());
        QueueManager.removePlayerFromQueues(e.getPlayer());
        HotbarManager.clearCache(e.getPlayer());
        StatsManager.evictCache(uuid);
        SpawnElytraManager.clearPendingRefill(uuid);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player player = e.getPlayer();
        String fromWorld = e.getFrom().getName();
        if (SpawnManager.isMainWorld(player)) {
            if (!HotbarManager.shouldHaveLobbyItems(player)) {
                return;
            }
            boolean fromBlacklisted = ConfigManager.blacklistedWorlds().contains(fromWorld);
            if (!HotbarListener.isInActiveMatchOrSpectate(player)) {
                if (fromBlacklisted) {
                    Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> {
                        if (player.isOnline() && SpawnManager.isMainWorld(player) && !HotbarListener.isInActiveMatchOrSpectate(player)) {
                            PlayerStateManager.resetToLobby(player);
                        }
                    }, 3L);
                } else {
                    PlayerStateManager.resetToLobby(player);
                }
            } else {
                PlayerStateManager.refreshInventory(player);
            }
        } else {
            player.getInventory().clear();
        }
    }

    private static boolean isInActiveMatchOrSpectate(Player player) {
        return MatchManager.inMatch(player.getUniqueId()) || DuelSession.inSession(player.getUniqueId()) || PartyDuelSession.inSession(player.getUniqueId()) || SpectateManager.isSpectating(player.getUniqueId());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        int slot;
        Player player;
        if (e.getHand() == EquipmentSlot.HAND && (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) && e.getItem() != null && !MatchManager.inMatch((player = e.getPlayer()).getUniqueId()) && SpawnManager.isMainWorld(player) && HotbarManager.isHotbarSlot(player, slot = player.getInventory().getHeldItemSlot())) {
            e.setCancelled(true);
            Material usedType = e.getItem().getType();
            if (player.getCooldown(usedType) <= 0) {
                player.setCooldown(usedType, 22);
                HotbarManager.HotbarType type = this.resolveType(player);
                SoundUtil.playClick(player);
                HotbarManager.handleClick(player, slot, type);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent e) {
        Player player;
        HumanEntity var3;
        if (HotbarManager.restrictionsEnabled() && (var3 = e.getWhoClicked()) instanceof Player && !HotbarListener.isKitEditing(player = (Player)var3) && SpawnManager.isMainWorld(player) && !MatchManager.inMatch(player.getUniqueId()) && e.getClickedInventory() != null) {
            UUID uuid = player.getUniqueId();
            int slot = e.getSlot();
            int rawSlot = e.getRawSlot();
            if (e.getView().getTopInventory().getType() != InventoryType.CRAFTING) {
                int invSize = e.getView().getTopInventory().getSize();
                if (!player.hasPermission("lifea.cosmetics.elytra") || !SpawnElytraManager.hasSpawnElytra(player) || rawSlot != invSize + 6 && rawSlot != invSize + 40) {
                    int hotbarNum;
                    int hotbarSlot;
                    if (rawSlot >= invSize + 27 && rawSlot <= invSize + 35 && HotbarManager.isHotbarSlot(player, hotbarSlot = rawSlot - (invSize + 27))) {
                        e.setCancelled(true);
                    }
                    if (!e.isCancelled() && (e.getAction() == InventoryAction.HOTBAR_SWAP || e.getAction() == InventoryAction.HOTBAR_MOVE_AND_READD) && (hotbarNum = e.getHotbarButton()) >= 0 && HotbarManager.isHotbarSlot(player, hotbarNum)) {
                        e.setCancelled(true);
                    }
                } else {
                    e.setCancelled(true);
                }
            } else {
                int hotbarNum;
                if (e.getClickedInventory().getType() == InventoryType.PLAYER && player.hasPermission("lifea.cosmetics.elytra") && SpawnElytraManager.hasSpawnElytra(player)) {
                    if (e.getSlotType() == InventoryType.SlotType.ARMOR && e.getSlot() == 38) {
                        e.setCancelled(true);
                        return;
                    }
                    if (e.getSlotType() == InventoryType.SlotType.QUICKBAR && e.getSlot() == 40) {
                        e.setCancelled(true);
                        return;
                    }
                    if (e.getClick() == ClickType.SWAP_OFFHAND) {
                        e.setCancelled(true);
                        return;
                    }
                }
                if (slot >= 0 && slot <= 8 && e.getClickedInventory().getType() == InventoryType.PLAYER && HotbarManager.isHotbarSlot(player, slot)) {
                    e.setCancelled(true);
                } else if ((e.getAction() == InventoryAction.HOTBAR_SWAP || e.getAction() == InventoryAction.HOTBAR_MOVE_AND_READD) && (hotbarNum = e.getHotbarButton()) >= 0 && HotbarManager.isHotbarSlot(player, hotbarNum)) {
                    e.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent e) {
        Player player;
        HumanEntity var3;
        if (HotbarManager.restrictionsEnabled() && (var3 = e.getWhoClicked()) instanceof Player && !HotbarListener.isKitEditing(player = (Player)var3) && SpawnManager.isMainWorld(player) && !MatchManager.inMatch(player.getUniqueId()) && e.getView().getTopInventory().getType() == InventoryType.CRAFTING) {
            int invSize = e.getView().getTopInventory().getSize();
            Iterator iterator = e.getRawSlots().iterator();
            while (iterator.hasNext()) {
                int hotbarSlot;
                int raw = (Integer)iterator.next();
                if (raw >= invSize + 27 && raw <= invSize + 35) {
                    hotbarSlot = raw - (invSize + 27);
                } else {
                    if (raw < 0 || raw > 8) continue;
                    hotbarSlot = raw;
                }
                if (!HotbarManager.isHotbarSlot(player, hotbarSlot)) continue;
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onDrop(PlayerDropItemEvent e) {
        if (HotbarManager.restrictionsEnabled() && !HotbarListener.isKitEditing(e.getPlayer()) && !MatchManager.inMatch(e.getPlayer().getUniqueId()) && SpawnManager.isMainWorld(e.getPlayer())) {
            if (!(e.getItemDrop().getItemStack().getType() == Material.ELYTRA || e.getItemDrop().getItemStack().getType() == Material.WIND_CHARGE && e.getPlayer().hasPermission("lifea.cosmetics.elytra"))) {
                int slot = e.getPlayer().getInventory().getHeldItemSlot();
                if (HotbarManager.isHotbarSlot(e.getPlayer(), slot)) {
                    e.setCancelled(true);
                }
            } else {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onWindChargeThrow(ProjectileLaunchEvent e) {
        Player player;
        ProjectileSource var3 = e.getEntity().getShooter();
        if (var3 instanceof Player && SpawnManager.isMainWorld(player = (Player)var3) && !MatchManager.inMatch(player.getUniqueId()) && e.getEntity().getType() == EntityType.WIND_CHARGE) {
            if (!player.hasPermission("lifea.cosmetics.elytra") || !PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA)) {
                e.setCancelled(true);
                return;
            }
            SpawnElytraManager.refillWindCharge(player);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onHeldItemChange(PlayerItemHeldEvent e) {
        Player player = e.getPlayer();
        if (!HotbarListener.isKitEditing(player) && SpawnManager.isMainWorld(player) && !MatchManager.inMatch(player.getUniqueId()) && player.hasPermission("lifea.cosmetics.elytra") && PlayerSettingsManager.get(player.getUniqueId(), PlayerSettingsManager.Setting.ELYTRA)) {
            if (HotbarManager.isHotbarSlot(player, e.getNewSlot())) {
                SpawnElytraManager.removeWindCharge(player);
            } else {
                ItemStack offhand = player.getInventory().getItemInOffHand();
                if (offhand == null || offhand.getType() == Material.AIR) {
                    SpawnElytraManager.refillWindCharge(player);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onSwapHand(PlayerSwapHandItemsEvent e) {
        if (HotbarManager.restrictionsEnabled() && !HotbarListener.isKitEditing(e.getPlayer()) && !MatchManager.inMatch(e.getPlayer().getUniqueId()) && SpawnManager.isMainWorld(e.getPlayer())) {
            if (e.getPlayer().hasPermission("lifea.cosmetics.elytra") && SpawnElytraManager.hasSpawnElytra(e.getPlayer())) {
                e.setCancelled(true);
            } else {
                int slot = e.getPlayer().getInventory().getHeldItemSlot();
                if (HotbarManager.isHotbarSlot(e.getPlayer(), slot)) {
                    e.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player player = e.getPlayer();
        e.setRespawnLocation(SpawnManager.getSpawn());
        Bukkit.getScheduler().runTaskLater((Plugin)Lifea.getInstance(), () -> HotbarListener.applyLobbyOnReconnect(player, false), 1L);
    }

    private HotbarManager.HotbarType resolveType(Player player) {
        if (!PartyManager.inParty(player.getUniqueId())) {
            return QueueManager.inQueue(player) ? HotbarManager.HotbarType.QUEUE : HotbarManager.HotbarType.SPAWN;
        }
        Party party = PartyManager.getParty(player.getUniqueId());
        return party != null && party.isLeader(player.getUniqueId()) ? HotbarManager.HotbarType.PARTY_LEADER : HotbarManager.HotbarType.PARTY_MEMBER;
    }
}

